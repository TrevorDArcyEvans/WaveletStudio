# Diagram.NET
Diagram.NET is a free open-source diagramming tools written entirely in C#.

Put Diagram.NET WinForm Control into your form and, like Microsoft Visio®, the user can draw shapes and links. With some code you can control, change, add and delete these elements.
