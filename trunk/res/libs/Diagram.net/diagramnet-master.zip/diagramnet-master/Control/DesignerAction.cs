using System;

namespace Dalssoft.DiagramNet
{
	public enum DesignerAction
	{
		Select,
		Add,
		Delete,
		Connect
	}
}
