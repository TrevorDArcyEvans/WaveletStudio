using System;

namespace Dalssoft.DiagramNet
{
	public interface IContainer
	{
		ElementCollection Elements
		{
			get;
		}
	}
}
