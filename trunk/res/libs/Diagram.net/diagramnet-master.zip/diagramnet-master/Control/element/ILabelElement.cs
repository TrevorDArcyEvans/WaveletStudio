using System;

namespace Dalssoft.DiagramNet
{
	public interface ILabelElement
	{
		LabelElement Label {get; set;}
	}
}
