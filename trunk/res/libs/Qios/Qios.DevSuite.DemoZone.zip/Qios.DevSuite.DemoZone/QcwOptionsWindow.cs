using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone
{
	/// <summary>
	/// Summary description for QrmwMenuWindow.
	/// </summary>
	public class QcwOptionsWindow : QCompositeWindow
	{
		private Qios.DevSuite.Components.QCompositeResizeItem qCompositeResizeItem1;
		private Qios.DevSuite.Components.QCompositeGroup qcgItems;
		private Qios.DevSuite.Components.QCompositeGroup qcgColorScheme;
		private Qios.DevSuite.Components.QCompositeGroup qcgColorSchemeHeader;
		private Qios.DevSuite.Components.QCompositeText qctHeaderColorScheme;
		private Qios.DevSuite.Components.QCompositeGroup qcgColorSchemeItems;
		private Qios.DevSuite.Components.QCompositeImage qciResizeItem;
		private Qios.DevSuite.Components.QCompositeResizeItem qcrResizeItemBottom;
		private Qios.DevSuite.Components.QCompositeResizeItem qCompositeResizeItemTop;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage1;
		private Qios.DevSuite.Components.QShape qsResizeItemBottom;
		private Qios.DevSuite.Components.QShape qsResizeItemTop;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPropertyGrid;
		private Qios.DevSuite.Components.QCompositeGroup qcgOther;
		private Qios.DevSuite.Components.QCompositeGroup qcgOtherHeader;
		private Qios.DevSuite.Components.QCompositeText qctOtherHeader;
		private Qios.DevSuite.Components.QCompositeGroup qcgOtherItems;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCollectGarbage;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiGlobalColorScheme;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiGlobalFont;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;

		public QcwOptionsWindow()
		{
			this.InitializeComponent();

			this.LoadColorSchemes();
			QGlobalColorScheme.Global.ColorsChanged += new EventHandler(Global_ColorsChanged);
			QGlobalColorScheme.Global.ThemesChanged +=new EventHandler(Global_ThemesChanged);
		}

		private void LoadColorSchemes()
		{
			this.SuspendChangeNotification();
			this.qcgColorSchemeItems.Items.Clear();

			//Add the 'inherit' item.
			QCompositeMenuItem tmp_oInheritItem = new QCompositeMenuItem();
			tmp_oInheritItem.ItemName = "__INHERIT";
			tmp_oInheritItem.Title = "&Inherit from Windows";
			tmp_oInheritItem.Configuration.StretchHorizontal = true;
			tmp_oInheritItem.Configuration.TitleConfiguration.StretchHorizontal = true;
			if (QColorScheme.Global.InheritCurrentThemeFromWindows) tmp_oInheritItem.Checked = true;
			this.qcgColorSchemeItems.Items.Add(tmp_oInheritItem);

			//Add the separator
			this.qcgColorSchemeItems.Items.Add(new QCompositeSeparator());

			//Add the the other items.
			for (int i = 0; i < QColorScheme.Global.Themes.Count; i++)
			{
				QCompositeMenuItem tmp_oItem = new QCompositeMenuItem();
				tmp_oItem.Configuration.StretchHorizontal = true;
				tmp_oItem.Configuration.TitleConfiguration.StretchHorizontal = true;
				tmp_oItem.ItemName = QColorScheme.Global.Themes[i].ThemeName;
				tmp_oItem.Title = "Use the &" + QColorScheme.Global.Themes[i].ThemeName + " theme";
				if ((!QColorScheme.Global.InheritCurrentThemeFromWindows) && 
					(QColorScheme.Global.CurrentTheme == QColorScheme.Global.Themes[i].ThemeName))
				{
					tmp_oItem.Checked = true;
				}
				this.qcgColorSchemeItems.Items.Add(tmp_oItem);
			}
			this.ResumeChangeNotification(false);
		}
	
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QcwOptionsWindow));
            this.qCompositeResizeItem1 = new Qios.DevSuite.Components.QCompositeResizeItem();
            this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
            this.qcgItems = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgColorScheme = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgColorSchemeHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctHeaderColorScheme = new Qios.DevSuite.Components.QCompositeText();
            this.qcgColorSchemeItems = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgOther = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgOtherHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctOtherHeader = new Qios.DevSuite.Components.QCompositeText();
            this.qcgOtherItems = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcmiPropertyGrid = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiGlobalColorScheme = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiGlobalFont = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiCollectGarbage = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcrResizeItemBottom = new Qios.DevSuite.Components.QCompositeResizeItem();
            this.qsResizeItemBottom = new Qios.DevSuite.Components.QShape();
            this.qciResizeItem = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeResizeItemTop = new Qios.DevSuite.Components.QCompositeResizeItem();
            this.qsResizeItemTop = new Qios.DevSuite.Components.QShape();
            this.qCompositeImage1 = new Qios.DevSuite.Components.QCompositeImage();
            this.SuspendLayout();
            // 
            // qCompositeResizeItem1
            // 
            this.qCompositeResizeItem1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qCompositeResizeItem1.Items.Add(this.qCompositeText1);
            // 
            // qCompositeText1
            // 
            this.qCompositeText1.Title = "Resize";
            // 
            // qcgItems
            // 
            this.qcgItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgItems.Configuration.ScrollConfiguration.ScrollOnMouseOver = true;
            this.qcgItems.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
            this.qcgItems.Configuration.ShrinkVertical = true;
            this.qcgItems.Configuration.StretchHorizontal = true;
            this.qcgItems.Configuration.StretchVertical = true;
            this.qcgItems.Items.Add(this.qcgColorScheme);
            this.qcgItems.Items.Add(this.qcgOther);
            // 
            // qcgColorScheme
            // 
            this.qcgColorScheme.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgColorScheme.Configuration.StretchHorizontal = true;
            this.qcgColorScheme.Items.Add(this.qcgColorSchemeHeader);
            this.qcgColorScheme.Items.Add(this.qcgColorSchemeItems);
            // 
            // qcgColorSchemeHeader
            // 
            this.qcgColorSchemeHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
            this.qcgColorSchemeHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
            this.qcgColorSchemeHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
            this.qcgColorSchemeHeader.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgColorSchemeHeader.Configuration.StretchHorizontal = true;
            this.qcgColorSchemeHeader.Items.Add(this.qctHeaderColorScheme);
            // 
            // qctHeaderColorScheme
            // 
            this.qctHeaderColorScheme.ColorScheme.CompositeText.SetColor("Default", System.Drawing.Color.White, false);
            this.qctHeaderColorScheme.ColorScheme.CompositeText.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qctHeaderColorScheme.ColorScheme.CompositeText.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qctHeaderColorScheme.ColorScheme.CompositeText.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qctHeaderColorScheme.ColorScheme.CompositeText.SetColor("HighContrast", System.Drawing.SystemColors.Window, false);
            this.qctHeaderColorScheme.ColorScheme.CompositeText.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qctHeaderColorScheme.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctHeaderColorScheme.Title = "QColorScheme options";
            // 
            // qcgColorSchemeItems
            // 
            this.qcgColorSchemeItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgColorSchemeItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
            this.qcgColorSchemeItems.Configuration.StretchHorizontal = true;
            // 
            // qcgOther
            // 
            this.qcgOther.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgOther.Configuration.StretchHorizontal = true;
            this.qcgOther.Items.Add(this.qcgOtherHeader);
            this.qcgOther.Items.Add(this.qcgOtherItems);
            // 
            // qcgOtherHeader
            // 
            this.qcgOtherHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
            this.qcgOtherHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
            this.qcgOtherHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
            this.qcgOtherHeader.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgOtherHeader.Configuration.StretchHorizontal = true;
            this.qcgOtherHeader.Items.Add(this.qctOtherHeader);
            // 
            // qctOtherHeader
            // 
            this.qctOtherHeader.ColorScheme.CompositeText.SetColor("Default", System.Drawing.Color.White, false);
            this.qctOtherHeader.ColorScheme.CompositeText.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qctOtherHeader.ColorScheme.CompositeText.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qctOtherHeader.ColorScheme.CompositeText.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qctOtherHeader.ColorScheme.CompositeText.SetColor("HighContrast", System.Drawing.SystemColors.Window, false);
            this.qctOtherHeader.ColorScheme.CompositeText.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qctOtherHeader.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctOtherHeader.Title = "Properties";
            // 
            // qcgOtherItems
            // 
            this.qcgOtherItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgOtherItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
            this.qcgOtherItems.Configuration.StretchHorizontal = true;
            this.qcgOtherItems.Items.Add(this.qcmiPropertyGrid);
            this.qcgOtherItems.Items.Add(this.qcmiGlobalColorScheme);
            this.qcgOtherItems.Items.Add(this.qcmiGlobalFont);
            this.qcgOtherItems.Items.Add(this.qcmiCollectGarbage);
            // 
            // qcmiPropertyGrid
            // 
            this.qcmiPropertyGrid.Configuration.StretchHorizontal = true;
            this.qcmiPropertyGrid.Configuration.TitleConfiguration.StretchHorizontal = true;
            this.qcmiPropertyGrid.HotkeyText = "L";
            this.qcmiPropertyGrid.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPropertyGrid.Icon")));
            this.qcmiPropertyGrid.Title = "&Launch PropertyGrid...";
            // 
            // qcmiGlobalColorScheme
            // 
            this.qcmiGlobalColorScheme.Configuration.StretchHorizontal = true;
            this.qcmiGlobalColorScheme.Configuration.TitleConfiguration.StretchHorizontal = true;
            this.qcmiGlobalColorScheme.HotkeyText = "S";
            this.qcmiGlobalColorScheme.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiGlobalColorScheme.Icon")));
            this.qcmiGlobalColorScheme.Title = "Show QGlobalColor&Scheme...";
            // 
            // qcmiGlobalFont
            // 
            this.qcmiGlobalFont.Configuration.StretchHorizontal = true;
            this.qcmiGlobalFont.Configuration.TitleConfiguration.StretchHorizontal = true;
            this.qcmiGlobalFont.HotkeyText = "F";
            this.qcmiGlobalFont.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiGlobalFont.Icon")));
            this.qcmiGlobalFont.Title = "Show QGlobal&Font";
            // 
            // qcmiCollectGarbage
            // 
            this.qcmiCollectGarbage.HotkeyText = "C";
            this.qcmiCollectGarbage.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCollectGarbage.Icon")));
            this.qcmiCollectGarbage.Title = "&Collect Garbage";
            // 
            // qcrResizeItemBottom
            // 
            this.qcrResizeItemBottom.ColorScheme.CompositeItemBackground1.ColorReference = "@CompositeButtonBackground1";
            this.qcrResizeItemBottom.ColorScheme.CompositeItemBackground2.ColorReference = "@CompositeButtonBackground2";
            this.qcrResizeItemBottom.ColorScheme.CompositeItemBorder.ColorReference = "@CompositeButtonBorder";
            this.qcrResizeItemBottom.Configuration.Appearance.Shape = this.qsResizeItemBottom;
            this.qcrResizeItemBottom.Configuration.HasHotState = Qios.DevSuite.Components.QTristateBool.False;
            this.qcrResizeItemBottom.Configuration.HasPressedState = Qios.DevSuite.Components.QTristateBool.False;
            this.qcrResizeItemBottom.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qcrResizeItemBottom.Configuration.ResizeBorder = Qios.DevSuite.Components.QCompositeResizeBorder.Bottom;
            this.qcrResizeItemBottom.Configuration.StretchHorizontal = true;
            this.qcrResizeItemBottom.Items.Add(this.qciResizeItem);
            // 
            // qsResizeItemBottom
            // 
            this.qsResizeItemBottom.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
            this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
            this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
            this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
            // 
            // qciResizeItem
            // 
            this.qciResizeItem.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qciResizeItem.Image = ((System.Drawing.Image)(resources.GetObject("qciResizeItem.Image")));
            // 
            // qCompositeResizeItemTop
            // 
            this.qCompositeResizeItemTop.ColorScheme.CompositeItemBackground1.ColorReference = "@CompositeButtonBackground1";
            this.qCompositeResizeItemTop.ColorScheme.CompositeItemBackground2.ColorReference = "@CompositeButtonBackground2";
            this.qCompositeResizeItemTop.ColorScheme.CompositeItemBorder.ColorReference = "@CompositeButtonBorder";
            this.qCompositeResizeItemTop.Configuration.Appearance.Shape = this.qsResizeItemTop;
            this.qCompositeResizeItemTop.Configuration.HasHotState = Qios.DevSuite.Components.QTristateBool.False;
            this.qCompositeResizeItemTop.Configuration.HasPressedState = Qios.DevSuite.Components.QTristateBool.False;
            this.qCompositeResizeItemTop.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qCompositeResizeItemTop.Configuration.ResizeBorder = Qios.DevSuite.Components.QCompositeResizeBorder.Top;
            this.qCompositeResizeItemTop.Configuration.StretchHorizontal = true;
            this.qCompositeResizeItemTop.Items.Add(this.qCompositeImage1);
            // 
            // qsResizeItemTop
            // 
            this.qsResizeItemTop.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
            this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
            this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
            this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
            this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qCompositeImage1
            // 
            this.qCompositeImage1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeImage1.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage1.Image")));
            // 
            // QcwOptionsWindow
            // 
            this.ColorScheme.CompositeIconBackground1.ColorReference = "@CompositeButtonBackground2";
            this.ColorScheme.CompositeIconBackground2.ColorReference = "@CompositeButtonBackground1";
            this.ColorScheme.CompositeIconBackgroundBorder.ColorReference = "@Empty";
            this.ColorScheme.CompositeScrollButtonBackground1.ColorReference = "@Empty";
            this.ColorScheme.CompositeScrollButtonBackground2.ColorReference = "@Empty";
            this.ColorScheme.CompositeScrollButtonBorder.ColorReference = "@Empty";
            this.ColorScheme.CompositeScrollButtonDisabledBackground1.ColorReference = "@Empty";
            this.ColorScheme.CompositeScrollButtonDisabledBackground2.ColorReference = "@Empty";
            this.ColorScheme.CompositeScrollButtonDisabledBorder.ColorReference = "@Empty";
            this.CompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.CompositeConfiguration.IconBackgroundSize = 26;
            this.CompositeConfiguration.IconBackgroundVisible = true;
            this.CompositeConfiguration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
            this.CompositeConfiguration.ShrinkHorizontal = false;
            this.CompositeConfiguration.StretchHorizontal = false;
            this.Configuration.UseSizeAsRequestedSize = true;
            this.Items.Add(this.qCompositeResizeItemTop);
            this.Items.Add(this.qcgItems);
            this.Items.Add(this.qcrResizeItemBottom);
            this.Name = "QcwOptionsWindow";
            this.Size = new System.Drawing.Size(197, 374);
            this.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.QcwOptionsWindow_ItemActivated);
            this.ResumeLayout(false);

		}

		private void QcwOptionsWindow_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
			if (e.Item.ParentPart == this.qcgColorSchemeItems)
			{
				if (e.Item.ItemName == "__INHERIT")
				{
					QColorScheme.Global.InheritCurrentThemeFromWindows = true;
					QColorScheme.Global.SetCurrentThemeToWindows();
				}
				else
				{
					QColorScheme.Global.InheritCurrentThemeFromWindows = false;
					QColorScheme.Global.CurrentTheme = e.Item.ItemName;
				}
				this.LoadColorSchemes();
			}		
			else if (e.Item == this.qcmiPropertyGrid)
			{
				FrmPropertyGrid tmp_oForm = new FrmPropertyGrid();
				tmp_oForm.Show();
			}
			else if (e.Item == this.qcmiGlobalColorScheme)
			{
				FrmPropertyGrid tmp_oForm = new FrmPropertyGrid();
				tmp_oForm.SetSingleObject(QColorScheme.Global, "QGlobalColorScheme");
				tmp_oForm.Show();
			}
			else if (e.Item == this.qcmiGlobalFont)
			{
				FrmPropertyGrid tmp_oForm = new FrmPropertyGrid();
				tmp_oForm.SetSingleObject(QGlobalFont.Instance, "QGlobalFont");
				tmp_oForm.Show();
			}					
			else if (e.Item == this.qcmiCollectGarbage)
			{
				GC.Collect();
				GC.WaitForPendingFinalizers();
				GC.Collect();
			}
		}

		private void Global_ColorsChanged(object sender, EventArgs e)
		{
			this.LoadColorSchemes();
		}

		private void Global_ThemesChanged(object sender, EventArgs e)
		{
			this.LoadColorSchemes();
		}
	}
}
