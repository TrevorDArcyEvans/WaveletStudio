using System;
using System.Windows.Forms;
using System.Collections;
using System.Reflection;
using System.ComponentModel;

namespace Qios.DevSuite.DemoZone.Misc
{
	/// <summary>
	/// Defines the attribute that is used on forms that should be visible in the selector form.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class)]
	public sealed class SelectorDisplayAttribute : Attribute
	{
		private int m_iItemOrder;
		private string m_sTitle;
		private string m_sDescription;

		/// <summary>
		/// Constructor.
		/// </summary>
		public SelectorDisplayAttribute(int itemOrder, string title, string description)
		{
			m_iItemOrder = itemOrder;
			m_sTitle = title;
			m_sDescription = description;
		}

		/// <summary>
		/// Gets the ItemOrder.
		/// </summary>
		public int ItemOrder
		{
			get { return m_iItemOrder; }
		}

		/// <summary>
		/// Gets the Title.
		/// </summary>
		public string Title
		{
			get { return m_sTitle; }
		}

		/// <summary>
		/// Gets the description.
		/// </summary>
		public string Description
		{
			get { return m_sDescription; }
		}


		/// <summary>
		/// Gets a list of all the types that have the SelectorDisplayAttribute defined in the executing assembly.
		/// </summary>
		public static IList GetAllDisplayedTypesFromExecutingAssembly()
		{
			Assembly tmp_oAssembly = Assembly.GetExecutingAssembly();
			return GetAllDisplayedTypesFromAssembly(tmp_oAssembly);
		}

		/// <summary>
		/// Gets a list of all the types that have the SelectorDisplayAttribute defined in the specified assembly.
		/// </summary>
		public static IList GetAllDisplayedTypesFromAssembly(Assembly assembly)
		{
			ArrayList tmp_oList = new ArrayList();
			Type[] tmp_aTypes = assembly.GetTypes();
			for (int i = 0; i < tmp_aTypes.Length; i++)
			{
				if (tmp_aTypes[i].IsDefined(typeof(SelectorDisplayAttribute), true))
				{
					tmp_oList.Add(tmp_aTypes[i]);
				}
			}
			return tmp_oList;
		}

		/// <summary>
		/// Gets a possible SelectorDisplayAttribute from the specified type.
		/// </summary>
		public static SelectorDisplayAttribute GetAttribute(Type type)
		{
			object[] tmp_aAttributes = type.GetCustomAttributes(typeof(SelectorDisplayAttribute), true);
			if ((tmp_aAttributes != null) && (tmp_aAttributes.Length > 0))
			{
				return tmp_aAttributes[0] as SelectorDisplayAttribute;
			}
			return null;
		}

		/// <summary>
		/// Gets the title from the specified type if that type has a SelectorDisplayAttribute defined.
		/// </summary>
		public static string GetTitle(Type type)
		{
			SelectorDisplayAttribute tmp_oAttribute = GetAttribute(type);
			if (tmp_oAttribute != null) return tmp_oAttribute.Title;
			return null;
		}

		/// <summary>
		/// Gets the description from the specified type if that type has a SelectorDisplayAttribute defined.
		/// </summary>
		public static string GetDescription(Type type)
		{
			SelectorDisplayAttribute tmp_oAttribute = GetAttribute(type);
			if (tmp_oAttribute != null) return tmp_oAttribute.Description;
			return null;
		}
	}
}
