using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone.Shared
{
	/// <summary>
	/// Summary description for QrmwMenuWindow.
	/// </summary>
	public class QcwFontMenuWindow : QCompositeWindow
	{
		private Qios.DevSuite.Components.QCompositeResizeItem qCompositeResizeItem1;
		private Qios.DevSuite.Components.QCompositeImage qciResizeItem;
		private Qios.DevSuite.Components.QCompositeResizeItem qcrResizeItemBottom;
		private Qios.DevSuite.Components.QShape qsResizeItemBottom;
		private Qios.DevSuite.Components.QShape qsResizeItemTop;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibFont;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibFontSize;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiFormatPainter;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiBold;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiItalic;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiUnderline;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiFormatter;
		private Qios.DevSuite.Components.QCompositeGroup qcgItems;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiIncreaseFont;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiDecreaseFont;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiTextHighlightColor;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiFontColor;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiAlignLeft;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiAlignCenter;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiAlignRight;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiDecreaseIndent;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiIncreaseIndent;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiBullets;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiFormatterChildItem1;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiHighlightColorSubItem;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiFontColorChildItem;
		private Qios.DevSuite.Components.QCompositeGroup qcgMenuItems;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCut;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmi;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPaste;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiOtherAction1;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiOtherAction2;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiOtherAction3;
		private Qios.DevSuite.Components.QShape qsItemGroup;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiOtherActions;
		private Qios.DevSuite.Components.QCompositeSeparator qcsSeparator01;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;

		public QcwFontMenuWindow()
		{
			this.InitializeComponent();
		}

	
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QcwFontMenuWindow));
			this.qCompositeResizeItem1 = new Qios.DevSuite.Components.QCompositeResizeItem();
			this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
			this.qcgItems = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsItemGroup = new Qios.DevSuite.Components.QShape();
			this.qcibFont = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcibFontSize = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcmiIncreaseFont = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiDecreaseFont = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiFormatter = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiFormatterChildItem1 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiFormatPainter = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiBold = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiItalic = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiUnderline = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiTextHighlightColor = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiHighlightColorSubItem = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiFontColor = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiFontColorChildItem = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiAlignLeft = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiAlignCenter = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiAlignRight = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiDecreaseIndent = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiIncreaseIndent = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiBullets = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcrResizeItemBottom = new Qios.DevSuite.Components.QCompositeResizeItem();
			this.qsResizeItemBottom = new Qios.DevSuite.Components.QShape();
			this.qciResizeItem = new Qios.DevSuite.Components.QCompositeImage();
			this.qsResizeItemTop = new Qios.DevSuite.Components.QShape();
			this.qcgMenuItems = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiCut = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmi = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiPaste = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcsSeparator01 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcmiOtherActions = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiOtherAction1 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiOtherAction2 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiOtherAction3 = new Qios.DevSuite.Components.QCompositeMenuItem();
			// 
			// qCompositeResizeItem1
			// 
			this.qCompositeResizeItem1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qCompositeResizeItem1.Items.Add(this.qCompositeText1);
			// 
			// qCompositeText1
			// 
			this.qCompositeText1.Title = "Resize";
			// 
			// qcgItems
			// 
			this.qcgItems.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeButtonBackground1";
			this.qcgItems.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeButtonBackground1";
			this.qcgItems.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qcgItems.Configuration.Appearance.Shape = this.qsItemGroup;
			this.qcgItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Flow;
			this.qcgItems.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgItems.Configuration.ScrollConfiguration.ScrollOnMouseOver = true;
			this.qcgItems.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.qcgItems.Configuration.ShrinkHorizontal = true;
			this.qcgItems.Configuration.ShrinkVertical = true;
			this.qcgItems.Configuration.StretchHorizontal = true;
			this.qcgItems.Configuration.StretchVertical = true;
			this.qcgItems.Items.Add(this.qcibFont);
			this.qcgItems.Items.Add(this.qcibFontSize);
			this.qcgItems.Items.Add(this.qcmiIncreaseFont);
			this.qcgItems.Items.Add(this.qcmiDecreaseFont);
			this.qcgItems.Items.Add(this.qcmiFormatter);
			this.qcgItems.Items.Add(this.qcmiFormatPainter);
			this.qcgItems.Items.Add(this.qcmiBold);
			this.qcgItems.Items.Add(this.qcmiItalic);
			this.qcgItems.Items.Add(this.qcmiUnderline);
			this.qcgItems.Items.Add(this.qcmiTextHighlightColor);
			this.qcgItems.Items.Add(this.qcmiFontColor);
			this.qcgItems.Items.Add(this.qcmiAlignLeft);
			this.qcgItems.Items.Add(this.qcmiAlignCenter);
			this.qcgItems.Items.Add(this.qcmiAlignRight);
			this.qcgItems.Items.Add(this.qcmiDecreaseIndent);
			this.qcgItems.Items.Add(this.qcmiIncreaseIndent);
			this.qcgItems.Items.Add(this.qcmiBullets);
			// 
			// qsItemGroup
			// 
			this.qsItemGroup.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareContent;
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			// 
			// qcibFont
			// 
			this.qcibFont.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibFont.InputBox
			// 
			this.qcibFont.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDown;
			this.qcibFont.InputBox.Location = new System.Drawing.Point(4, 4);
			this.qcibFont.InputBox.Name = "";
			this.qcibFont.InputBox.Size = new System.Drawing.Size(100, 20);
			this.qcibFont.InputBox.TabIndex = 0;
			this.qcibFont.InputBox.Tag = "";
			this.qcibFont.InputBox.Text = "Calibri (Body)";
			// 
			// qcibFontSize
			// 
			this.qcibFontSize.ControlSize = new System.Drawing.Size(40, 20);
			// 
			// qcibFontSize.InputBox
			// 
			this.qcibFontSize.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDown;
			this.qcibFontSize.InputBox.Location = new System.Drawing.Point(106, 4);
			this.qcibFontSize.InputBox.Name = "";
			this.qcibFontSize.InputBox.Size = new System.Drawing.Size(40, 20);
			this.qcibFontSize.InputBox.TabIndex = 1;
			this.qcibFontSize.InputBox.Text = "11";
			// 
			// qcmiIncreaseFont
			// 
			this.qcmiIncreaseFont.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiIncreaseFont.HotkeyText = "IF";
			this.qcmiIncreaseFont.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiIncreaseFont.Icon")));
			this.qcmiIncreaseFont.Title = "&Increase &Font";
			// 
			// qcmiDecreaseFont
			// 
			this.qcmiDecreaseFont.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiDecreaseFont.HotkeyText = "DF";
			this.qcmiDecreaseFont.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiDecreaseFont.Icon")));
			this.qcmiDecreaseFont.Title = "&Decrease Font";
			// 
			// qcmiFormatter
			// 
			this.qcmiFormatter.ChildItems.Add(this.qcmiFormatterChildItem1);
			this.qcmiFormatter.Configuration.DropDownButtonConfiguration.Mask = ((System.Drawing.Image)(resources.GetObject("resource.Mask")));
			this.qcmiFormatter.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiFormatter.HotkeyText = "F";
			this.qcmiFormatter.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiFormatter.Icon")));
			this.qcmiFormatter.Title = "&Formatter";
			// 
			// qcmiFormatterChildItem1
			// 
			this.qcmiFormatterChildItem1.Title = "Formatter Child Item";
			// 
			// qcmiFormatPainter
			// 
			this.qcmiFormatPainter.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiFormatPainter.HotkeyText = "F";
			this.qcmiFormatPainter.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiFormatPainter.Icon")));
			this.qcmiFormatPainter.Title = "&Format Painter";
			// 
			// qcmiBold
			// 
			this.qcmiBold.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiBold.HotkeyText = "B";
			this.qcmiBold.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiBold.Icon")));
			this.qcmiBold.Title = "&Bold";
			// 
			// qcmiItalic
			// 
			this.qcmiItalic.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiItalic.HotkeyText = "I";
			this.qcmiItalic.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItalic.Icon")));
			this.qcmiItalic.Title = "&Italic";
			// 
			// qcmiUnderline
			// 
			this.qcmiUnderline.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiUnderline.HotkeyText = "U";
			this.qcmiUnderline.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiUnderline.Icon")));
			this.qcmiUnderline.Title = "&Underline";
			// 
			// qcmiTextHighlightColor
			// 
			this.qcmiTextHighlightColor.ChildItems.Add(this.qcmiHighlightColorSubItem);
			this.qcmiTextHighlightColor.Configuration.DropDownButtonConfiguration.Mask = ((System.Drawing.Image)(resources.GetObject("resource.Mask1")));
			this.qcmiTextHighlightColor.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiTextHighlightColor.HotkeyText = "H";
			this.qcmiTextHighlightColor.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiTextHighlightColor.Icon")));
			this.qcmiTextHighlightColor.Title = "&HighlightColor";
			// 
			// qcmiHighlightColorSubItem
			// 
			this.qcmiHighlightColorSubItem.HotkeyText = "H";
			this.qcmiHighlightColorSubItem.Title = "&HighlightColor Child item";
			// 
			// qcmiFontColor
			// 
			this.qcmiFontColor.ChildItems.Add(this.qcmiFontColorChildItem);
			this.qcmiFontColor.Configuration.DropDownButtonConfiguration.Mask = ((System.Drawing.Image)(resources.GetObject("resource.Mask2")));
			this.qcmiFontColor.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiFontColor.HotkeyText = "F";
			this.qcmiFontColor.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiFontColor.Icon")));
			this.qcmiFontColor.Title = "&FontColor";
			// 
			// qcmiFontColorChildItem
			// 
			this.qcmiFontColorChildItem.HotkeyText = "F";
			this.qcmiFontColorChildItem.Title = "&Font Color Child Item";
			// 
			// qcmiAlignLeft
			// 
			this.qcmiAlignLeft.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiAlignLeft.HotkeyText = "AL";
			this.qcmiAlignLeft.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiAlignLeft.Icon")));
			this.qcmiAlignLeft.Title = "&Align &Left";
			this.qcmiAlignLeft.ToolTipText = "";
			// 
			// qcmiAlignCenter
			// 
			this.qcmiAlignCenter.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiAlignCenter.HotkeyText = "AC";
			this.qcmiAlignCenter.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiAlignCenter.Icon")));
			this.qcmiAlignCenter.Title = "&Align &Center";
			this.qcmiAlignCenter.ToolTipText = "";
			// 
			// qcmiAlignRight
			// 
			this.qcmiAlignRight.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiAlignRight.HotkeyText = "AR";
			this.qcmiAlignRight.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiAlignRight.Icon")));
			this.qcmiAlignRight.Title = "&Align &Right";
			this.qcmiAlignRight.ToolTipText = "";
			// 
			// qcmiDecreaseIndent
			// 
			this.qcmiDecreaseIndent.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiDecreaseIndent.HotkeyText = "DI";
			this.qcmiDecreaseIndent.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiDecreaseIndent.Icon")));
			this.qcmiDecreaseIndent.Title = "&Decrease Indent";
			// 
			// qcmiIncreaseIndent
			// 
			this.qcmiIncreaseIndent.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiIncreaseIndent.HotkeyText = "II";
			this.qcmiIncreaseIndent.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiIncreaseIndent.Icon")));
			this.qcmiIncreaseIndent.Title = "&Increase Indent";
			// 
			// qcmiBullets
			// 
			this.qcmiBullets.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiBullets.HotkeyText = "B";
			this.qcmiBullets.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiBullets.Icon")));
			this.qcmiBullets.Title = "&Bullets";
			// 
			// qcrResizeItemBottom
			// 
			this.qcrResizeItemBottom.ColorScheme.CompositeItemBackground1.ColorReference = "@CompositeButtonBackground1";
			this.qcrResizeItemBottom.ColorScheme.CompositeItemBackground2.ColorReference = "@CompositeButtonBackground2";
			this.qcrResizeItemBottom.ColorScheme.CompositeItemBorder.ColorReference = "@CompositeButtonBorder";
			this.qcrResizeItemBottom.Configuration.Appearance.Shape = this.qsResizeItemBottom;
			this.qcrResizeItemBottom.Configuration.HasHotState = Qios.DevSuite.Components.QTristateBool.False;
			this.qcrResizeItemBottom.Configuration.HasPressedState = Qios.DevSuite.Components.QTristateBool.False;
			this.qcrResizeItemBottom.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
			this.qcrResizeItemBottom.Configuration.StretchHorizontal = true;
			this.qcrResizeItemBottom.Items.Add(this.qciResizeItem);
			// 
			// qsResizeItemBottom
			// 
			this.qsResizeItemBottom.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// qciResizeItem
			// 
			this.qciResizeItem.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qciResizeItem.Image = ((System.Drawing.Image)(resources.GetObject("qciResizeItem.Image")));
			// 
			// qsResizeItemTop
			// 
			this.qsResizeItemTop.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsResizeItemTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			// 
			// qcgMenuItems
			// 
			this.qcgMenuItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgMenuItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qcgMenuItems.Configuration.StretchHorizontal = true;
			this.qcgMenuItems.Items.Add(this.qcmiCut);
			this.qcgMenuItems.Items.Add(this.qcmi);
			this.qcgMenuItems.Items.Add(this.qcmiPaste);
			this.qcgMenuItems.Items.Add(this.qcsSeparator01);
			this.qcgMenuItems.Items.Add(this.qcmiOtherActions);
			// 
			// qcmiCut
			// 
			this.qcmiCut.Configuration.ShrinkHorizontal = true;
			this.qcmiCut.Configuration.StretchHorizontal = true;
			this.qcmiCut.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qcmiCut.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qcmiCut.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qcmiCut.HotkeyText = "T";
			this.qcmiCut.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCut.Icon")));
			this.qcmiCut.Title = "Cu&t";
			// 
			// qcmi
			// 
			this.qcmi.Configuration.ShrinkHorizontal = true;
			this.qcmi.Configuration.StretchHorizontal = true;
			this.qcmi.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qcmi.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qcmi.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qcmi.HotkeyText = "C";
			this.qcmi.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmi.Icon")));
			this.qcmi.Title = "&Copy";
			// 
			// qcmiPaste
			// 
			this.qcmiPaste.Configuration.ShrinkHorizontal = true;
			this.qcmiPaste.Configuration.StretchHorizontal = true;
			this.qcmiPaste.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qcmiPaste.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qcmiPaste.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qcmiPaste.HotkeyText = "P";
			this.qcmiPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPaste.Icon")));
			this.qcmiPaste.Title = "&Paste";
			// 
			// qcsSeparator01
			// 
			this.qcsSeparator01.ColorScheme.CompositeSeparator1.ColorReference = "@CompositeButtonBorder";
			// 
			// qcmiOtherActions
			// 
			this.qcmiOtherActions.ChildItems.Add(this.qcmiOtherAction1);
			this.qcmiOtherActions.ChildItems.Add(this.qcmiOtherAction2);
			this.qcmiOtherActions.ChildItems.Add(this.qcmiOtherAction3);
			this.qcmiOtherActions.Configuration.ShrinkHorizontal = true;
			this.qcmiOtherActions.Configuration.StretchHorizontal = true;
			this.qcmiOtherActions.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qcmiOtherActions.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qcmiOtherActions.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qcmiOtherActions.HotkeyText = "O";
			this.qcmiOtherActions.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiOtherActions.Icon")));
			this.qcmiOtherActions.Title = "&Other actions";
			// 
			// qcmiOtherAction1
			// 
			this.qcmiOtherAction1.HotkeyText = "1";
			this.qcmiOtherAction1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiOtherAction1.Icon")));
			this.qcmiOtherAction1.Title = "Other action &1";
			// 
			// qcmiOtherAction2
			// 
			this.qcmiOtherAction2.HotkeyText = "2";
			this.qcmiOtherAction2.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiOtherAction2.Icon")));
			this.qcmiOtherAction2.Title = "Other action &2";
			// 
			// qcmiOtherAction3
			// 
			this.qcmiOtherAction3.HotkeyText = "3";
			this.qcmiOtherAction3.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiOtherAction3.Icon")));
			this.qcmiOtherAction3.Title = "Other action &3";
			// 
			// QcwFontMenuWindow
			// 
			this.ChildCompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.ChildCompositeConfiguration.IconBackgroundVisible = true;
			this.ChildCompositeConfiguration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.ColorScheme.CompositeIconBackground1.ColorReference = "@CompositeButtonBackground1";
			this.ColorScheme.CompositeIconBackground2.ColorReference = "@CompositeButtonBackground2";
			this.ColorScheme.CompositeIconBackgroundBorder.ColorReference = "@CompositeButtonBorder";
			this.ColorScheme.CompositeScrollButtonBackground1.ColorReference = "@Empty";
			this.ColorScheme.CompositeScrollButtonBackground2.ColorReference = "@Empty";
			this.ColorScheme.CompositeScrollButtonBorder.ColorReference = "@Empty";
			this.ColorScheme.CompositeScrollButtonDisabledBackground1.ColorReference = "@Empty";
			this.ColorScheme.CompositeScrollButtonDisabledBackground2.ColorReference = "@Empty";
			this.ColorScheme.CompositeScrollButtonDisabledBorder.ColorReference = "@Empty";
			this.CompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.CompositeConfiguration.IconBackgroundSize = 22;
			this.CompositeConfiguration.IconBackgroundVisible = true;
			this.CompositeConfiguration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.Configuration.UseSizeAsRequestedSize = true;
			this.Items.Add(this.qcgItems);
			this.Items.Add(this.qcgMenuItems);
			this.Items.Add(this.qcrResizeItemBottom);
			this.Name = "QcwFontMenuWindow";
			this.Size = new System.Drawing.Size(216, 184);

		}
	}
}
