using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components.Ribbon;
using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Shared
{
	/// <summary>
	/// Summary description for QrmwMainMenuWindow.
	/// </summary>
	public class QrmwMainMenuWindow : QRibbonMenuWindow
	{
		private Qios.DevSuite.Components.QCompositeButton qCompositeButton1;
		private Qios.DevSuite.Components.QCompositeButton qCompositeButton2;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiNew;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiOpen;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiSave;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiSaveAs;
		private Qios.DevSuite.Components.QCompositeSeparator qCompositeSeparator1;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPrint;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPrepare;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiSend;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPublish;
		private Qios.DevSuite.Components.QCompositeSeparator qCompositeSeparator2;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiClose;
		private Qios.DevSuite.Components.Ribbon.QRibbonSubMenuWindow qrsmwMainMenuSaveAs;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcliSaveAsWord;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcliSaveAsWordTemplate;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcliSaveAsWord2003;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcliSaveAsPdf;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcliSaveAsOtherDocuments;
		private Qios.DevSuite.Components.QCompositeMenuItem qciSaveAsOther1;
		private Qios.DevSuite.Components.QCompositeMenuItem qciSaveAsOther2;
		private Qios.DevSuite.Components.QCompositeItemTemplate qcitRecentDocument;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber;
		private Qios.DevSuite.Components.QCompositeText qctDocumentName;
		private Qios.DevSuite.Components.QCompositeImage qciPin;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;
		private Qios.DevSuite.Components.QCompositeText qCompositeText2;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage1;
		private Qios.DevSuite.Components.QCompositeText qCompositeText3;
		private Qios.DevSuite.Components.QCompositeText qCompositeText4;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage2;
		private Qios.DevSuite.Components.QCompositeText qCompositeText5;
		private Qios.DevSuite.Components.QCompositeText qCompositeText6;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage3;
		private Qios.DevSuite.Components.QCompositeText qCompositeText7;
		private Qios.DevSuite.Components.QCompositeText qCompositeText8;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage4;
		private Qios.DevSuite.Components.QCompositeText qCompositeText9;
		private Qios.DevSuite.Components.QCompositeText qCompositeText10;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage5;
		private Qios.DevSuite.Components.QCompositeText qCompositeText11;
		private Qios.DevSuite.Components.QCompositeText qCompositeText12;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage6;
		private Qios.DevSuite.Components.QCompositeText qCompositeText13;
		private Qios.DevSuite.Components.QCompositeText qCompositeText14;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage7;
		private Qios.DevSuite.Components.QCompositeItem qciDocument01;
		private Qios.DevSuite.Components.QCompositeItem qciDocument02;
		private Qios.DevSuite.Components.QCompositeItem qciDocument03;
		private Qios.DevSuite.Components.QCompositeItem qciDocument04;
		private Qios.DevSuite.Components.QCompositeItem qciDocument05;
		private Qios.DevSuite.Components.QCompositeItem qciDocument06;
		private Qios.DevSuite.Components.QCompositeText qCompositeText15;
		private Qios.DevSuite.Components.QCompositeText qCompositeText16;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage8;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber01;
		private Qios.DevSuite.Components.QCompositeText qctDocument01;
		private Qios.DevSuite.Components.QCompositeImage qcimDocument01;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber02;
		private Qios.DevSuite.Components.QCompositeText qctDocument02;
		private Qios.DevSuite.Components.QCompositeImage qcimDocument02;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber03;
		private Qios.DevSuite.Components.QCompositeText qctDocument03;
		private Qios.DevSuite.Components.QCompositeImage qcimDocument03;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber04;
		private Qios.DevSuite.Components.QCompositeText qctDocument04;
		private Qios.DevSuite.Components.QCompositeImage qcimDocument04;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber05;
		private Qios.DevSuite.Components.QCompositeText qctDocument05;
		private Qios.DevSuite.Components.QCompositeImage qcimDocument05;
		private Qios.DevSuite.Components.QCompositeText qctDocumentNumber06;
		private Qios.DevSuite.Components.QCompositeText qctDocument06;
		private Qios.DevSuite.Components.QCompositeImage qcimDocument06;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QrmwMainMenuWindow()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QrmwMainMenuWindow));
            this.qCompositeButton1 = new Qios.DevSuite.Components.QCompositeButton();
            this.qCompositeButton2 = new Qios.DevSuite.Components.QCompositeButton();
            this.qcmiNew = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiOpen = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiSave = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiSaveAs = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qrsmwMainMenuSaveAs = new Qios.DevSuite.Components.Ribbon.QRibbonSubMenuWindow();
            this.qcliSaveAsWord = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qcliSaveAsWordTemplate = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qcliSaveAsWord2003 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qcliSaveAsPdf = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qcliSaveAsOtherDocuments = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qciSaveAsOther1 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qciSaveAsOther2 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeSeparator1 = new Qios.DevSuite.Components.QCompositeSeparator();
            this.qcmiPrint = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiPrepare = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiSend = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiPublish = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeSeparator2 = new Qios.DevSuite.Components.QCompositeSeparator();
            this.qcmiClose = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcitRecentDocument = new Qios.DevSuite.Components.QCompositeItemTemplate();
            this.qctDocumentNumber = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocumentName = new Qios.DevSuite.Components.QCompositeText();
            this.qciPin = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText2 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage1 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText3 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText4 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage2 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText5 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText6 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage3 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText7 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText8 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage4 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText9 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText10 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage5 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText11 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText12 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage6 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText13 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText14 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage7 = new Qios.DevSuite.Components.QCompositeImage();
            this.qciDocument01 = new Qios.DevSuite.Components.QCompositeItem();
            this.qctDocumentNumber01 = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocument01 = new Qios.DevSuite.Components.QCompositeText();
            this.qcimDocument01 = new Qios.DevSuite.Components.QCompositeImage();
            this.qciDocument02 = new Qios.DevSuite.Components.QCompositeItem();
            this.qctDocumentNumber02 = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocument02 = new Qios.DevSuite.Components.QCompositeText();
            this.qcimDocument02 = new Qios.DevSuite.Components.QCompositeImage();
            this.qciDocument03 = new Qios.DevSuite.Components.QCompositeItem();
            this.qctDocumentNumber03 = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocument03 = new Qios.DevSuite.Components.QCompositeText();
            this.qcimDocument03 = new Qios.DevSuite.Components.QCompositeImage();
            this.qciDocument04 = new Qios.DevSuite.Components.QCompositeItem();
            this.qctDocumentNumber04 = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocument04 = new Qios.DevSuite.Components.QCompositeText();
            this.qcimDocument04 = new Qios.DevSuite.Components.QCompositeImage();
            this.qciDocument05 = new Qios.DevSuite.Components.QCompositeItem();
            this.qctDocumentNumber05 = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocument05 = new Qios.DevSuite.Components.QCompositeText();
            this.qcimDocument05 = new Qios.DevSuite.Components.QCompositeImage();
            this.qciDocument06 = new Qios.DevSuite.Components.QCompositeItem();
            this.qctDocumentNumber06 = new Qios.DevSuite.Components.QCompositeText();
            this.qctDocument06 = new Qios.DevSuite.Components.QCompositeText();
            this.qcimDocument06 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText15 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeText16 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeImage8 = new Qios.DevSuite.Components.QCompositeImage();
            this.SuspendLayout();
            // 
            // qCompositeButton1
            // 
            this.qCompositeButton1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qCompositeButton1.HotkeyText = "O";
            this.qCompositeButton1.Title = "&Options";
            // 
            // qCompositeButton2
            // 
            this.qCompositeButton2.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qCompositeButton2.HotkeyText = "C";
            this.qCompositeButton2.Title = "&Close";
            // 
            // qcmiNew
            // 
            this.qcmiNew.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiNew.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiNew.HotkeyText = "N";
            this.qcmiNew.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiNew.Icon")));
            this.qcmiNew.Title = "&New";
            // 
            // qcmiOpen
            // 
            this.qcmiOpen.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiOpen.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiOpen.HotkeyText = "O";
            this.qcmiOpen.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiOpen.Icon")));
            this.qcmiOpen.Title = "&Open";
            // 
            // qcmiSave
            // 
            this.qcmiSave.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiSave.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiSave.HotkeyText = "S";
            this.qcmiSave.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiSave.Icon")));
            this.qcmiSave.Title = "&Save";
            // 
            // qcmiSaveAs
            // 
            this.qcmiSaveAs.Configuration.DropDownSeparated = true;
            this.qcmiSaveAs.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiSaveAs.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiSaveAs.CustomChildWindow = this.qrsmwMainMenuSaveAs;
            this.qcmiSaveAs.HotkeyText = "A";
            this.qcmiSaveAs.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiSaveAs.Icon")));
            this.qcmiSaveAs.Title = "Save &As";
            // 
            // qrsmwMainMenuSaveAs
            // 
            this.qrsmwMainMenuSaveAs.CaptionText = "Save your file as...";
            this.qrsmwMainMenuSaveAs.Items.Add(this.qcliSaveAsWord);
            this.qrsmwMainMenuSaveAs.Items.Add(this.qcliSaveAsWordTemplate);
            this.qrsmwMainMenuSaveAs.Items.Add(this.qcliSaveAsWord2003);
            this.qrsmwMainMenuSaveAs.Items.Add(this.qcliSaveAsPdf);
            this.qrsmwMainMenuSaveAs.Items.Add(this.qcliSaveAsOtherDocuments);
            this.qrsmwMainMenuSaveAs.Location = new System.Drawing.Point(17, 17);
            this.qrsmwMainMenuSaveAs.Name = "qrsmwMainMenuSaveAs";
            this.qrsmwMainMenuSaveAs.Size = new System.Drawing.Size(505, 241);
            this.qrsmwMainMenuSaveAs.TabIndex = 0;
            this.qrsmwMainMenuSaveAs.Text = "qRibbonSubMenuWindow1";
            this.qrsmwMainMenuSaveAs.Visible = false;
            // 
            // qcliSaveAsWord
            // 
            this.qcliSaveAsWord.Description = "Save the document in the default file format";
            this.qcliSaveAsWord.HotkeyText = "W";
            this.qcliSaveAsWord.Icon = ((System.Drawing.Icon)(resources.GetObject("qcliSaveAsWord.Icon")));
            this.qcliSaveAsWord.Title = "&Word document";
            // 
            // qcliSaveAsWordTemplate
            // 
            this.qcliSaveAsWordTemplate.Description = "Save the document as a template that can be used to format future documents";
            this.qcliSaveAsWordTemplate.HotkeyText = "T";
            this.qcliSaveAsWordTemplate.Icon = ((System.Drawing.Icon)(resources.GetObject("qcliSaveAsWordTemplate.Icon")));
            this.qcliSaveAsWordTemplate.Title = "Word &Template";
            // 
            // qcliSaveAsWord2003
            // 
            this.qcliSaveAsWord2003.Description = "Save a copy of the document  that is fully compatible with Word 97-2003";
            this.qcliSaveAsWord2003.HotkeyText = "9";
            this.qcliSaveAsWord2003.Icon = ((System.Drawing.Icon)(resources.GetObject("qcliSaveAsWord2003.Icon")));
            this.qcliSaveAsWord2003.Title = "Word &97-2003";
            // 
            // qcliSaveAsPdf
            // 
            this.qcliSaveAsPdf.Description = "Publish a copy of the document as a PDF or XPS file";
            this.qcliSaveAsPdf.HotkeyText = "P";
            this.qcliSaveAsPdf.Icon = ((System.Drawing.Icon)(resources.GetObject("qcliSaveAsPdf.Icon")));
            this.qcliSaveAsPdf.Title = "&PDF-XPS";
            // 
            // qcliSaveAsOtherDocuments
            // 
            this.qcliSaveAsOtherDocuments.ChildItems.Add(this.qciSaveAsOther1);
            this.qcliSaveAsOtherDocuments.ChildItems.Add(this.qciSaveAsOther2);
            this.qcliSaveAsOtherDocuments.Description = "Open the Save As dialog box to select from all possible file types";
            this.qcliSaveAsOtherDocuments.HotkeyText = "O";
            this.qcliSaveAsOtherDocuments.Icon = ((System.Drawing.Icon)(resources.GetObject("qcliSaveAsOtherDocuments.Icon")));
            this.qcliSaveAsOtherDocuments.Title = "&Other formats";
            // 
            // qciSaveAsOther1
            // 
            this.qciSaveAsOther1.Title = "Save as other 1";
            // 
            // qciSaveAsOther2
            // 
            this.qciSaveAsOther2.Title = "Save as other 2";
            // 
            // qcmiPrint
            // 
            this.qcmiPrint.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiPrint.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiPrint.HotkeyText = "P";
            this.qcmiPrint.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPrint.Icon")));
            this.qcmiPrint.Title = "&Print";
            // 
            // qcmiPrepare
            // 
            this.qcmiPrepare.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiPrepare.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiPrepare.HotkeyText = "E";
            this.qcmiPrepare.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPrepare.Icon")));
            this.qcmiPrepare.Title = "Pr&epare";
            // 
            // qcmiSend
            // 
            this.qcmiSend.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiSend.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiSend.HotkeyText = "D";
            this.qcmiSend.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiSend.Icon")));
            this.qcmiSend.Title = "Sen&d";
            // 
            // qcmiPublish
            // 
            this.qcmiPublish.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiPublish.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiPublish.HotkeyText = "U";
            this.qcmiPublish.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPublish.Icon")));
            this.qcmiPublish.Title = "P&ublish";
            // 
            // qcmiClose
            // 
            this.qcmiClose.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qcmiClose.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 1);
            this.qcmiClose.HotkeyText = "C";
            this.qcmiClose.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiClose.Icon")));
            this.qcmiClose.Title = "&Close";
            // 
            // qcitRecentDocument
            // 
            this.qcitRecentDocument.Configuration.ShrinkHorizontal = true;
            this.qcitRecentDocument.Configuration.StretchHorizontal = true;
            this.qcitRecentDocument.Items.Add(this.qctDocumentNumber);
            this.qcitRecentDocument.Items.Add(this.qctDocumentName);
            this.qcitRecentDocument.Items.Add(this.qciPin);
            // 
            // qctDocumentNumber
            // 
            this.qctDocumentNumber.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber.Title = "&1";
            // 
            // qctDocumentName
            // 
            this.qctDocumentName.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocumentName.Configuration.ShrinkHorizontal = true;
            this.qctDocumentName.Configuration.StretchHorizontal = true;
            this.qctDocumentName.Title = "DocumentName";
            // 
            // qciPin
            // 
            this.qciPin.Image = ((System.Drawing.Image)(resources.GetObject("qciPin.Image")));
            // 
            // qCompositeText1
            // 
            this.qCompositeText1.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText1.Title = "&1";
            // 
            // qCompositeText2
            // 
            this.qCompositeText2.Configuration.StretchHorizontal = true;
            this.qCompositeText2.Title = "DocumentName";
            // 
            // qCompositeImage1
            // 
            this.qCompositeImage1.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage1.Image")));
            // 
            // qCompositeText3
            // 
            this.qCompositeText3.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText3.Title = "&1";
            // 
            // qCompositeText4
            // 
            this.qCompositeText4.Configuration.StretchHorizontal = true;
            this.qCompositeText4.Title = "DocumentName";
            // 
            // qCompositeImage2
            // 
            this.qCompositeImage2.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage2.Image")));
            // 
            // qCompositeText5
            // 
            this.qCompositeText5.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText5.Title = "&1";
            // 
            // qCompositeText6
            // 
            this.qCompositeText6.Configuration.StretchHorizontal = true;
            this.qCompositeText6.Title = "DocumentName";
            // 
            // qCompositeImage3
            // 
            this.qCompositeImage3.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage3.Image")));
            // 
            // qCompositeText7
            // 
            this.qCompositeText7.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText7.Title = "&1";
            // 
            // qCompositeText8
            // 
            this.qCompositeText8.Configuration.StretchHorizontal = true;
            this.qCompositeText8.Title = "DocumentName";
            // 
            // qCompositeImage4
            // 
            this.qCompositeImage4.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage4.Image")));
            // 
            // qCompositeText9
            // 
            this.qCompositeText9.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText9.Title = "&1";
            // 
            // qCompositeText10
            // 
            this.qCompositeText10.Configuration.StretchHorizontal = true;
            this.qCompositeText10.Title = "DocumentName";
            // 
            // qCompositeImage5
            // 
            this.qCompositeImage5.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage5.Image")));
            // 
            // qCompositeText11
            // 
            this.qCompositeText11.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText11.Title = "&1";
            // 
            // qCompositeText12
            // 
            this.qCompositeText12.Configuration.StretchHorizontal = true;
            this.qCompositeText12.Title = "DocumentName";
            // 
            // qCompositeImage6
            // 
            this.qCompositeImage6.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage6.Image")));
            // 
            // qCompositeText13
            // 
            this.qCompositeText13.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText13.Title = "&1";
            // 
            // qCompositeText14
            // 
            this.qCompositeText14.Configuration.StretchHorizontal = true;
            this.qCompositeText14.Title = "DocumentName";
            // 
            // qCompositeImage7
            // 
            this.qCompositeImage7.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage7.Image")));
            // 
            // qciDocument01
            // 
            this.qciDocument01.Configuration.ShrinkHorizontal = true;
            this.qciDocument01.Configuration.StretchHorizontal = true;
            this.qciDocument01.HotkeyText = "1";
            this.qciDocument01.Items.Add(this.qctDocumentNumber01);
            this.qciDocument01.Items.Add(this.qctDocument01);
            this.qciDocument01.Items.Add(this.qcimDocument01);
            // 
            // qctDocumentNumber01
            // 
            this.qctDocumentNumber01.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber01.Title = "&1";
            // 
            // qctDocument01
            // 
            this.qctDocument01.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocument01.Configuration.ShrinkHorizontal = true;
            this.qctDocument01.Configuration.StretchHorizontal = true;
            this.qctDocument01.Title = "Document 01";
            // 
            // qcimDocument01
            // 
            this.qcimDocument01.Image = ((System.Drawing.Image)(resources.GetObject("qcimDocument01.Image")));
            // 
            // qciDocument02
            // 
            this.qciDocument02.Configuration.ShrinkHorizontal = true;
            this.qciDocument02.Configuration.StretchHorizontal = true;
            this.qciDocument02.HotkeyText = "2";
            this.qciDocument02.Items.Add(this.qctDocumentNumber02);
            this.qciDocument02.Items.Add(this.qctDocument02);
            this.qciDocument02.Items.Add(this.qcimDocument02);
            // 
            // qctDocumentNumber02
            // 
            this.qctDocumentNumber02.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber02.Title = "&2";
            // 
            // qctDocument02
            // 
            this.qctDocument02.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocument02.Configuration.ShrinkHorizontal = true;
            this.qctDocument02.Configuration.StretchHorizontal = true;
            this.qctDocument02.Title = "Document 02";
            // 
            // qcimDocument02
            // 
            this.qcimDocument02.Image = ((System.Drawing.Image)(resources.GetObject("qcimDocument02.Image")));
            // 
            // qciDocument03
            // 
            this.qciDocument03.Configuration.ShrinkHorizontal = true;
            this.qciDocument03.Configuration.StretchHorizontal = true;
            this.qciDocument03.HotkeyText = "3";
            this.qciDocument03.Items.Add(this.qctDocumentNumber03);
            this.qciDocument03.Items.Add(this.qctDocument03);
            this.qciDocument03.Items.Add(this.qcimDocument03);
            // 
            // qctDocumentNumber03
            // 
            this.qctDocumentNumber03.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber03.Title = "&3";
            // 
            // qctDocument03
            // 
            this.qctDocument03.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocument03.Configuration.ShrinkHorizontal = true;
            this.qctDocument03.Configuration.StretchHorizontal = true;
            this.qctDocument03.Title = "Document 03";
            // 
            // qcimDocument03
            // 
            this.qcimDocument03.Image = ((System.Drawing.Image)(resources.GetObject("qcimDocument03.Image")));
            // 
            // qciDocument04
            // 
            this.qciDocument04.Configuration.ShrinkHorizontal = true;
            this.qciDocument04.Configuration.StretchHorizontal = true;
            this.qciDocument04.HotkeyText = "4";
            this.qciDocument04.Items.Add(this.qctDocumentNumber04);
            this.qciDocument04.Items.Add(this.qctDocument04);
            this.qciDocument04.Items.Add(this.qcimDocument04);
            // 
            // qctDocumentNumber04
            // 
            this.qctDocumentNumber04.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber04.Title = "&4";
            // 
            // qctDocument04
            // 
            this.qctDocument04.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocument04.Configuration.ShrinkHorizontal = true;
            this.qctDocument04.Configuration.StretchHorizontal = true;
            this.qctDocument04.Title = "Document 04";
            // 
            // qcimDocument04
            // 
            this.qcimDocument04.Image = ((System.Drawing.Image)(resources.GetObject("qcimDocument04.Image")));
            // 
            // qciDocument05
            // 
            this.qciDocument05.Configuration.ShrinkHorizontal = true;
            this.qciDocument05.Configuration.StretchHorizontal = true;
            this.qciDocument05.HotkeyText = "5";
            this.qciDocument05.Items.Add(this.qctDocumentNumber05);
            this.qciDocument05.Items.Add(this.qctDocument05);
            this.qciDocument05.Items.Add(this.qcimDocument05);
            // 
            // qctDocumentNumber05
            // 
            this.qctDocumentNumber05.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber05.Title = "&5";
            // 
            // qctDocument05
            // 
            this.qctDocument05.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocument05.Configuration.ShrinkHorizontal = true;
            this.qctDocument05.Configuration.StretchHorizontal = true;
            this.qctDocument05.Title = "Document 05";
            // 
            // qcimDocument05
            // 
            this.qcimDocument05.Image = ((System.Drawing.Image)(resources.GetObject("qcimDocument05.Image")));
            // 
            // qciDocument06
            // 
            this.qciDocument06.Configuration.ShrinkHorizontal = true;
            this.qciDocument06.Configuration.StretchHorizontal = true;
            this.qciDocument06.HotkeyText = "6";
            this.qciDocument06.Items.Add(this.qctDocumentNumber06);
            this.qciDocument06.Items.Add(this.qctDocument06);
            this.qciDocument06.Items.Add(this.qcimDocument06);
            // 
            // qctDocumentNumber06
            // 
            this.qctDocumentNumber06.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qctDocumentNumber06.Title = "&6";
            // 
            // qctDocument06
            // 
            this.qctDocument06.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctDocument06.Configuration.ShrinkHorizontal = true;
            this.qctDocument06.Configuration.StretchHorizontal = true;
            this.qctDocument06.Title = "Document 06";
            // 
            // qcimDocument06
            // 
            this.qcimDocument06.Image = ((System.Drawing.Image)(resources.GetObject("qcimDocument06.Image")));
            // 
            // qCompositeText15
            // 
            this.qCompositeText15.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 0, 0, 5);
            this.qCompositeText15.Title = "&1";
            // 
            // qCompositeText16
            // 
            this.qCompositeText16.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qCompositeText16.Configuration.ShrinkHorizontal = true;
            this.qCompositeText16.Configuration.StretchHorizontal = true;
            this.qCompositeText16.Title = "DocumentName";
            // 
            // qCompositeImage8
            // 
            this.qCompositeImage8.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage8.Image")));
            // 
            // QrmwMainMenuWindow
            // 
            this.DocumentItems.Add(this.qciDocument01);
            this.DocumentItems.Add(this.qciDocument02);
            this.DocumentItems.Add(this.qciDocument03);
            this.DocumentItems.Add(this.qciDocument04);
            this.DocumentItems.Add(this.qciDocument05);
            this.DocumentItems.Add(this.qciDocument06);
            this.FooterItems.Add(this.qCompositeButton1);
            this.FooterItems.Add(this.qCompositeButton2);
            this.Items.Add(this.qcmiNew);
            this.Items.Add(this.qcmiOpen);
            this.Items.Add(this.qcmiSave);
            this.Items.Add(this.qcmiSaveAs);
            this.Items.Add(this.qCompositeSeparator1);
            this.Items.Add(this.qcmiPrint);
            this.Items.Add(this.qcmiPrepare);
            this.Items.Add(this.qcmiSend);
            this.Items.Add(this.qcmiPublish);
            this.Items.Add(this.qCompositeSeparator2);
            this.Items.Add(this.qcmiClose);
            this.Name = "QrmwMainMenuWindow";
            this.Size = new System.Drawing.Size(424, 411);
            this.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.QrmwMainMenuWindow_ItemActivated);
            this.ResumeLayout(false);

		}
		#endregion

		private void QrmwMainMenuWindow_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeItem2_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeItem3_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeItem4_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeItem7_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}
	}
}
