using System;
using System.Xml;
using System.Reflection;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.DemoZone.Misc;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone
{
	/// <summary>
	/// Summary description for FrmSampleSelector.
	/// </summary>
	public class FrmLoadingZone : QRibbonForm
	{
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qRibbonCaption1;
		private Qios.DevSuite.Components.QCompositeGroup qcgItems;
		private Qios.DevSuite.Components.QCompositeGroup qcgCaption;
		private Qios.DevSuite.Components.QCompositeText qctDescription;
		private Qios.DevSuite.Components.QCompositeSeparator qcsCaptionSeparator;
		private Qios.DevSuite.Components.QCompositeControl qccCompositeControl;
		private Qios.DevSuite.Components.QCompositeGroup qcgFooter;
		private Qios.DevSuite.Components.QCompositeButton qcbOptions;
		private Qios.DevSuite.Components.QCompositeButton qcbClose;
		private Qios.DevSuite.Components.QCompositeGroup qcgHeader;
		private Qios.DevSuite.Components.QCompositeImage qciDevSuiteLogo;
		private Qios.DevSuite.Components.QCompositeText qctCaption;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmLoadingZone()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.qccCompositeControl.SuspendChangeNotification();
			this.AddAssemblyItems();
			this.LoadColorScheme();
			this.qcbOptions.CustomChildWindow = new QcwOptionsWindow();
			this.qccCompositeControl.ResumeChangeNotification(true);

			Screen tmp_oScreen = Screen.FromControl(this);
			this.Left = tmp_oScreen.WorkingArea.X + ((tmp_oScreen.WorkingArea.Width - this.Width) / 2);
			this.Top = tmp_oScreen.WorkingArea.Y + ((tmp_oScreen.WorkingArea.Height - this.Height) / 2);
		}

		/// <summary>
		/// Adds all the items that have a SelectorDisplayAttribute to the composite.
		/// </summary>
		private void AddAssemblyItems()
		{
			this.qccCompositeControl.SuspendChangeNotification();
			IList tmp_oList = SelectorDisplayAttribute.GetAllDisplayedTypesFromExecutingAssembly();
			for (int i = 0; i < tmp_oList.Count; i++)
			{
				Type tmp_oType = tmp_oList[i] as Type;
				IQPart tmp_oItem = this.CreateItemFromType(tmp_oType);
				if (tmp_oItem != null) this.qcgItems.Items.Add(tmp_oItem);
			}
			this.qccCompositeControl.ResumeChangeNotification(true);
		}

		/// <summary>
		/// Loads the QColorScheme from the resource
		/// </summary>
		private void LoadColorScheme()
		{
			XmlDocument tmp_oDocument = new XmlDocument();
			tmp_oDocument.Load(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Resources.QColorScheme.xml"));
			QColorScheme.Global.LoadFromXml(tmp_oDocument.DocumentElement);
		}

		/// <summary>
		/// Creates an item based on a type that has a SelectorDisplayAttribute;
		/// </summary>
		private QCompositeItem CreateItemFromType(Type type)
		{
			SelectorDisplayAttribute tmp_oAttribute = SelectorDisplayAttribute.GetAttribute(type);
			if (tmp_oAttribute != null)
			{
				QCompositeLargeMenuItem tmp_oItem = new QCompositeLargeMenuItem();
				tmp_oItem.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Qios.DevSuite.AllSizes.ico, Qios.DevSuite.DemoZone";
				tmp_oItem.Title = tmp_oAttribute.Title;
				tmp_oItem.Description = tmp_oAttribute.Description;
				tmp_oItem.LayoutOrder = tmp_oAttribute.ItemOrder;
				tmp_oItem.UserReference = type;
				return tmp_oItem;
			}
			return null;
		}

		/// <summary>
		/// Runs the specified type.
		/// </summary>
		public void RunSample(Type tmp_oType)
		{
			try
			{
				Cursor.Current = Cursors.WaitCursor;
				object tmp_oInstance = Activator.CreateInstance(tmp_oType);
				Form tmp_oForm = tmp_oInstance as Form;
				if (tmp_oForm != null)
				{
					tmp_oForm.StartPosition = FormStartPosition.Manual;
					tmp_oForm.Location = new Point(this.Location.X + 50, this.Location.Y + 50);
					tmp_oForm.Show();
				}
				Cursor.Current = Cursors.Default;
			}
			catch (Exception e)
			{
				MessageBox.Show("Cannot create item of type '" + tmp_oType.Name + "':\r\n" + e.Message);
			}
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLoadingZone));
            this.qRibbonCaption1 = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            this.qccCompositeControl = new Qios.DevSuite.Components.QCompositeControl();
            this.qcgCaption = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctCaption = new Qios.DevSuite.Components.QCompositeText();
            this.qciDevSuiteLogo = new Qios.DevSuite.Components.QCompositeImage();
            this.qcsCaptionSeparator = new Qios.DevSuite.Components.QCompositeSeparator();
            this.qctDescription = new Qios.DevSuite.Components.QCompositeText();
            this.qcgItems = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgFooter = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcbOptions = new Qios.DevSuite.Components.QCompositeButton();
            this.qcbClose = new Qios.DevSuite.Components.QCompositeButton();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qccCompositeControl)).BeginInit();
            this.SuspendLayout();
            // 
            // qRibbonCaption1
            // 
            this.qRibbonCaption1.Location = new System.Drawing.Point(0, 0);
            this.qRibbonCaption1.Name = "qRibbonCaption1";
            this.qRibbonCaption1.Size = new System.Drawing.Size(407, 28);
            this.qRibbonCaption1.TabIndex = 0;
            this.qRibbonCaption1.Text = "Loading Zone - Qios.DevSuite.DemoZone ";
            // 
            // qccCompositeControl
            // 
            this.qccCompositeControl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qccCompositeControl.BackgroundImage")));
            this.qccCompositeControl.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomLeft;
            this.qccCompositeControl.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qccCompositeControl.Configuration.Margin = new Qios.DevSuite.Components.QMargin(5, 5, 5, 5);
            this.qccCompositeControl.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 5, 2, 5);
            this.qccCompositeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qccCompositeControl.Focusable = true;
            this.qccCompositeControl.HandleAltKey = true;
            this.qccCompositeControl.Items.Add(this.qcgCaption);
            this.qccCompositeControl.Items.Add(this.qcgItems);
            this.qccCompositeControl.Items.Add(this.qcgFooter);
            this.qccCompositeControl.Location = new System.Drawing.Point(0, 28);
            this.qccCompositeControl.Name = "qccCompositeControl";
            this.qccCompositeControl.Size = new System.Drawing.Size(407, 526);
            this.qccCompositeControl.TabIndex = 1;
            this.qccCompositeControl.Text = "qccCompositeControl";
            this.qccCompositeControl.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qccCompositeControl_ItemActivated);
            // 
            // qcgCaption
            // 
            this.qcgCaption.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
            this.qcgCaption.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
            this.qcgCaption.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qcgCaption.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgCaption.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 3, 0);
            this.qcgCaption.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qcgCaption.Configuration.ShrinkHorizontal = true;
            this.qcgCaption.Configuration.StretchHorizontal = true;
            this.qcgCaption.Items.Add(this.qcgHeader);
            this.qcgCaption.Items.Add(this.qcsCaptionSeparator);
            this.qcgCaption.Items.Add(this.qctDescription);
            // 
            // qcgHeader
            // 
            this.qcgHeader.Configuration.ShrinkHorizontal = true;
            this.qcgHeader.Configuration.StretchHorizontal = true;
            this.qcgHeader.Items.Add(this.qctCaption);
            this.qcgHeader.Items.Add(this.qciDevSuiteLogo);
            // 
            // qctCaption
            // 
            this.qctCaption.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qctCaption.Configuration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
            this.qctCaption.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 10F);
            this.qctCaption.Configuration.ShrinkHorizontal = true;
            this.qctCaption.Configuration.StretchHorizontal = true;
            this.qctCaption.Configuration.WrapText = true;
            this.qctCaption.Title = "Welcome to Qios.DevSuite.DemoZone";
            // 
            // qciDevSuiteLogo
            // 
            this.qciDevSuiteLogo.Image = ((System.Drawing.Image)(resources.GetObject("qciDevSuiteLogo.Image")));
            // 
            // qctDescription
            // 
            this.qctDescription.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 9F);
            this.qctDescription.Configuration.ShrinkHorizontal = true;
            this.qctDescription.Configuration.StretchHorizontal = true;
            this.qctDescription.Configuration.WrapText = true;
            this.qctDescription.Title = "This application will demonstrate the possibilities of Qios.DevSuite.Components 3" +
                ".0. There are several forms && samples available. Just pick one below and the se" +
                "lected sample will launch.";
            // 
            // qcgItems
            // 
            this.qcgItems.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
            this.qcgItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
            this.qcgItems.Configuration.ScrollConfiguration.ScrollType = Qios.DevSuite.Components.QCompositeScrollType.ScrollBar;
            this.qcgItems.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
            this.qcgItems.Configuration.ShrinkHorizontal = true;
            this.qcgItems.Configuration.ShrinkVertical = true;
            this.qcgItems.Configuration.StretchHorizontal = true;
            this.qcgItems.Configuration.StretchVertical = true;
            // 
            // qcgFooter
            // 
            this.qcgFooter.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qcgFooter.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -3);
            this.qcgFooter.Items.Add(this.qcbOptions);
            this.qcgFooter.Items.Add(this.qcbClose);
            // 
            // qcbOptions
            // 
            this.qcbOptions.Configuration.DropDownSeparated = false;
            this.qcbOptions.Configuration.Padding = new Qios.DevSuite.Components.QPadding(15, 1, 1, 5);
            this.qcbOptions.Configuration.TitleConfiguration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 10);
            this.qcbOptions.HotkeyText = "O";
            this.qcbOptions.Title = "&Options";
            // 
            // qcbClose
            // 
            this.qcbClose.Configuration.Padding = new Qios.DevSuite.Components.QPadding(15, 1, 1, 15);
            this.qcbClose.HotkeyText = "C";
            this.qcbClose.Title = "&Close";
            // 
            // FrmLoadingZone
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(407, 554);
            this.Controls.Add(this.qccCompositeControl);
            this.Controls.Add(this.qRibbonCaption1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmLoadingZone";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Loading Zone - Qios.DevSuite.DemoZone ";
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qccCompositeControl)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Handles the activation of an item.
		/// </summary>
		private void qccCompositeControl_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
			QCompositeItemBase tmp_oItem = e.Item;
			if (e.Item == this.qcbClose)
			{
				this.Close();
			}
			else
			{
				Type tmp_oType = null;
				if ((tmp_oItem != null) && ((tmp_oType = tmp_oItem.UserReference as Type) != null))
				{
					//If the item as a type as userReference, just run the type.
					this.RunSample(tmp_oType);
				}
			}
		}
	}
}
