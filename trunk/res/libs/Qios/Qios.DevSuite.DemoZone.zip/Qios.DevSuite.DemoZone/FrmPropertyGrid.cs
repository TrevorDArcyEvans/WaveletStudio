using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone
{
	/// <summary>
	/// Summary description for FrmPropertyGrid.
	/// </summary>
	public class FrmPropertyGrid : QRibbonForm
	{
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qRibbonCaption1;
		private System.Windows.Forms.PropertyGrid propertyGrid1;
		private Qios.DevSuite.Components.QControlSelector qControlSelector1;
		private Qios.DevSuite.Components.QCompositeControl qCompositeControl1;
		private Qios.DevSuite.Components.QCompositeGroup qcgsSelectorHeader;
		private Qios.DevSuite.Components.QCompositeText qctSelectorHeader;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup1;
		private Qios.DevSuite.Components.QCompositeItemControl qcicControlSelector;
		private Qios.DevSuite.Components.QCompositeText qctSelectorDescription;
		private Qios.DevSuite.Components.QCompositeGroup qcgPropertyGrid;
		private Qios.DevSuite.Components.QCompositeGroup qgcPropertyGridHeader;
		private Qios.DevSuite.Components.QCompositeText qctPropertyGridHeader;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup4;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup5;
		private Qios.DevSuite.Components.QCompositeItemControl qcicPropertyGrid;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup2;
		private Qios.DevSuite.Components.QCompositeGroup qcgControlDetails;
		private Qios.DevSuite.Components.QCompositeGroup qcgControlType;
		private Qios.DevSuite.Components.QCompositeText qctControlType;
		private Qios.DevSuite.Components.QCompositeText qctControlName;
		private Qios.DevSuite.Components.QCompositeGroup qcgControlName;
		private Qios.DevSuite.Components.QCompositeGroup qcgControlText;
		private Qios.DevSuite.Components.QCompositeText qctControlTypeLabel;
		private Qios.DevSuite.Components.QCompositeText qctControlNameLabel;
		private Qios.DevSuite.Components.QCompositeText qctControlTextLabel;
		private Qios.DevSuite.Components.QCompositeText qctControlText;
		private Qios.DevSuite.Components.QCompositeGroup qcgSelector;
		private Qios.DevSuite.Components.QCompositeGroup qcgSelectorItem;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmPropertyGrid()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.propertyGrid1.SelectedObject = this;
		}

		/// <summary>
		/// Sets a single object that cannot be changed via the selector.
		/// </summary>
		public void SetSingleObject(object objectValue, string title)
		{
			this.propertyGrid1.SelectedObject = objectValue;
			this.Text = title + " - Qios.DevSuite.DemoZone";
			this.qcgSelector.Visible = false;
			this.ShowObjectDetails(objectValue, title, title);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPropertyGrid));
            this.qRibbonCaption1 = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            this.qControlSelector1 = new Qios.DevSuite.Components.QControlSelector();
            this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
            this.qCompositeControl1 = new Qios.DevSuite.Components.QCompositeControl();
            this.qcgSelector = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgsSelectorHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctSelectorHeader = new Qios.DevSuite.Components.QCompositeText();
            this.qcgSelectorItem = new Qios.DevSuite.Components.QCompositeGroup();
            this.qCompositeGroup1 = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcicControlSelector = new Qios.DevSuite.Components.QCompositeItemControl();
            this.qctSelectorDescription = new Qios.DevSuite.Components.QCompositeText();
            this.qcgPropertyGrid = new Qios.DevSuite.Components.QCompositeGroup();
            this.qgcPropertyGridHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctPropertyGridHeader = new Qios.DevSuite.Components.QCompositeText();
            this.qcgControlDetails = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgControlType = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctControlTypeLabel = new Qios.DevSuite.Components.QCompositeText();
            this.qctControlType = new Qios.DevSuite.Components.QCompositeText();
            this.qcgControlName = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctControlNameLabel = new Qios.DevSuite.Components.QCompositeText();
            this.qctControlName = new Qios.DevSuite.Components.QCompositeText();
            this.qcgControlText = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctControlTextLabel = new Qios.DevSuite.Components.QCompositeText();
            this.qctControlText = new Qios.DevSuite.Components.QCompositeText();
            this.qcicPropertyGrid = new Qios.DevSuite.Components.QCompositeItemControl();
            this.qCompositeGroup4 = new Qios.DevSuite.Components.QCompositeGroup();
            this.qCompositeGroup5 = new Qios.DevSuite.Components.QCompositeGroup();
            this.qCompositeGroup2 = new Qios.DevSuite.Components.QCompositeGroup();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qCompositeControl1)).BeginInit();
            this.qCompositeControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // qRibbonCaption1
            // 
            this.qRibbonCaption1.Location = new System.Drawing.Point(0, 0);
            this.qRibbonCaption1.Name = "qRibbonCaption1";
            this.qRibbonCaption1.Size = new System.Drawing.Size(346, 28);
            this.qRibbonCaption1.TabIndex = 0;
            this.qRibbonCaption1.Text = "PropertyGrid - Qios.DevSuite.DemoZone";
            // 
            // qControlSelector1
            // 
            this.qControlSelector1.Location = new System.Drawing.Point(10, 36);
            this.qControlSelector1.Name = "qControlSelector1";
            this.qControlSelector1.Size = new System.Drawing.Size(32, 32);
            this.qControlSelector1.TabIndex = 0;
            this.qControlSelector1.Text = "qTextBox1";
            this.qControlSelector1.HoveringControlChanged += new System.EventHandler(this.qControlSelector1_HoveringControlChanged);
            this.qControlSelector1.SelectedControlChanged += new System.EventHandler(this.qControlSelector1_SelectedControlChanged);
            // 
            // propertyGrid1
            // 
            this.propertyGrid1.CommandsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(246)))));
            this.propertyGrid1.HelpVisible = false;
            this.propertyGrid1.LineColor = System.Drawing.SystemColors.ScrollBar;
            this.propertyGrid1.Location = new System.Drawing.Point(6, 174);
            this.propertyGrid1.Name = "propertyGrid1";
            this.propertyGrid1.Size = new System.Drawing.Size(334, 162);
            this.propertyGrid1.TabIndex = 0;
            this.propertyGrid1.ToolbarVisible = false;
            this.propertyGrid1.SelectedObjectsChanged += new System.EventHandler(this.propertyGrid1_SelectedObjectsChanged);
            // 
            // qCompositeControl1
            // 
            this.qCompositeControl1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qCompositeControl1.Items.Add(this.qcgSelector);
            this.qCompositeControl1.Items.Add(this.qcgPropertyGrid);
            this.qCompositeControl1.Location = new System.Drawing.Point(0, 28);
            this.qCompositeControl1.Name = "qCompositeControl1";
            this.qCompositeControl1.Size = new System.Drawing.Size(346, 342);
            this.qCompositeControl1.TabIndex = 3;
            this.qCompositeControl1.Text = "qCompositeControl1";
            // 
            // qcgSelector
            // 
            this.qcgSelector.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgSelector.Configuration.ShrinkHorizontal = true;
            this.qcgSelector.Configuration.StretchHorizontal = true;
            this.qcgSelector.Items.Add(this.qcgsSelectorHeader);
            this.qcgSelector.Items.Add(this.qcgSelectorItem);
            // 
            // qcgsSelectorHeader
            // 
            this.qcgsSelectorHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
            this.qcgsSelectorHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
            this.qcgsSelectorHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
            this.qcgsSelectorHeader.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgsSelectorHeader.Configuration.StretchHorizontal = true;
            this.qcgsSelectorHeader.Items.Add(this.qctSelectorHeader);
            // 
            // qctSelectorHeader
            // 
            this.qctSelectorHeader.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctSelectorHeader.Title = "Select Control";
            // 
            // qcgSelectorItem
            // 
            this.qcgSelectorItem.Configuration.ShrinkHorizontal = true;
            this.qcgSelectorItem.Configuration.StretchHorizontal = true;
            this.qcgSelectorItem.Items.Add(this.qCompositeGroup1);
            // 
            // qCompositeGroup1
            // 
            this.qCompositeGroup1.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeGroup1.Configuration.ShrinkHorizontal = true;
            this.qCompositeGroup1.Configuration.StretchHorizontal = true;
            this.qCompositeGroup1.Items.Add(this.qcicControlSelector);
            this.qCompositeGroup1.Items.Add(this.qctSelectorDescription);
            // 
            // qcicControlSelector
            // 
            this.qcicControlSelector.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qcicControlSelector.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qcicControlSelector.Control = this.qControlSelector1;
            this.qcicControlSelector.ControlSize = new System.Drawing.Size(32, 32);
            // 
            // qctSelectorDescription
            // 
            this.qctSelectorDescription.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qctSelectorDescription.Configuration.ShrinkHorizontal = true;
            this.qctSelectorDescription.Configuration.StretchHorizontal = true;
            this.qctSelectorDescription.Configuration.WrapText = true;
            this.qctSelectorDescription.Title = "Press and hold the crosshair to select a Control. You can select every .NET Contr" +
                "ol that is created by this process.";
            // 
            // qcgPropertyGrid
            // 
            this.qcgPropertyGrid.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgPropertyGrid.Configuration.ShrinkHorizontal = true;
            this.qcgPropertyGrid.Configuration.ShrinkVertical = true;
            this.qcgPropertyGrid.Configuration.StretchHorizontal = true;
            this.qcgPropertyGrid.Configuration.StretchVertical = true;
            this.qcgPropertyGrid.Items.Add(this.qgcPropertyGridHeader);
            this.qcgPropertyGrid.Items.Add(this.qcgControlDetails);
            this.qcgPropertyGrid.Items.Add(this.qcicPropertyGrid);
            // 
            // qgcPropertyGridHeader
            // 
            this.qgcPropertyGridHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
            this.qgcPropertyGridHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
            this.qgcPropertyGridHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
            this.qgcPropertyGridHeader.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qgcPropertyGridHeader.Configuration.ShrinkHorizontal = true;
            this.qgcPropertyGridHeader.Configuration.StretchHorizontal = true;
            this.qgcPropertyGridHeader.Items.Add(this.qctPropertyGridHeader);
            // 
            // qctPropertyGridHeader
            // 
            this.qctPropertyGridHeader.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctPropertyGridHeader.Title = "Properties";
            // 
            // qcgControlDetails
            // 
            this.qcgControlDetails.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
            this.qcgControlDetails.ColorScheme.CompositeGroupBackground2.ColorReference = "@RibbonPanelBackground2";
            this.qcgControlDetails.ColorScheme.CompositeGroupBorder.ColorReference = "@RibbonPanelBorder";
            this.qcgControlDetails.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgControlDetails.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
            this.qcgControlDetails.Configuration.Margin = new Qios.DevSuite.Components.QMargin(3, 3, 3, 3);
            this.qcgControlDetails.Configuration.ShrinkHorizontal = true;
            this.qcgControlDetails.Configuration.StretchHorizontal = true;
            this.qcgControlDetails.Items.Add(this.qcgControlType);
            this.qcgControlDetails.Items.Add(this.qcgControlName);
            this.qcgControlDetails.Items.Add(this.qcgControlText);
            // 
            // qcgControlType
            // 
            this.qcgControlType.Configuration.ShrinkHorizontal = true;
            this.qcgControlType.Configuration.StretchHorizontal = true;
            this.qcgControlType.Items.Add(this.qctControlTypeLabel);
            this.qcgControlType.Items.Add(this.qctControlType);
            // 
            // qctControlTypeLabel
            // 
            this.qctControlTypeLabel.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctControlTypeLabel.Configuration.Padding = new Qios.DevSuite.Components.QPadding(10, 0, 0, 20);
            this.qctControlTypeLabel.Title = "Type";
            // 
            // qctControlType
            // 
            this.qctControlType.Configuration.ShrinkHorizontal = true;
            this.qctControlType.Configuration.StretchHorizontal = true;
            this.qctControlType.Configuration.WrapText = true;
            this.qctControlType.Title = "<Type>";
            // 
            // qcgControlName
            // 
            this.qcgControlName.Configuration.ShrinkHorizontal = true;
            this.qcgControlName.Configuration.StretchHorizontal = true;
            this.qcgControlName.Items.Add(this.qctControlNameLabel);
            this.qcgControlName.Items.Add(this.qctControlName);
            // 
            // qctControlNameLabel
            // 
            this.qctControlNameLabel.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctControlNameLabel.Configuration.Padding = new Qios.DevSuite.Components.QPadding(10, 0, 0, 20);
            this.qctControlNameLabel.Title = "Name";
            // 
            // qctControlName
            // 
            this.qctControlName.Configuration.ShrinkHorizontal = true;
            this.qctControlName.Configuration.StretchHorizontal = true;
            this.qctControlName.Configuration.WrapText = true;
            this.qctControlName.Title = "<Name>";
            // 
            // qcgControlText
            // 
            this.qcgControlText.Configuration.ShrinkHorizontal = true;
            this.qcgControlText.Configuration.StretchHorizontal = true;
            this.qcgControlText.Items.Add(this.qctControlTextLabel);
            this.qcgControlText.Items.Add(this.qctControlText);
            // 
            // qctControlTextLabel
            // 
            this.qctControlTextLabel.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctControlTextLabel.Configuration.Padding = new Qios.DevSuite.Components.QPadding(10, 0, 0, 20);
            this.qctControlTextLabel.Title = "Text";
            // 
            // qctControlText
            // 
            this.qctControlText.Configuration.ShrinkHorizontal = true;
            this.qctControlText.Configuration.StretchHorizontal = true;
            this.qctControlText.Configuration.WrapText = true;
            this.qctControlText.Title = "<Text>";
            // 
            // qcicPropertyGrid
            // 
            this.qcicPropertyGrid.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qcicPropertyGrid.Configuration.ShrinkHorizontal = true;
            this.qcicPropertyGrid.Configuration.ShrinkVertical = true;
            this.qcicPropertyGrid.Configuration.StretchHorizontal = true;
            this.qcicPropertyGrid.Configuration.StretchVertical = true;
            this.qcicPropertyGrid.Control = this.propertyGrid1;
            this.qcicPropertyGrid.ControlSize = new System.Drawing.Size(20, 20);
            // 
            // qCompositeGroup4
            // 
            this.qCompositeGroup4.Configuration.ShrinkHorizontal = true;
            this.qCompositeGroup4.Configuration.StretchHorizontal = true;
            // 
            // qCompositeGroup5
            // 
            this.qCompositeGroup5.Configuration.ShrinkHorizontal = true;
            this.qCompositeGroup5.Configuration.StretchHorizontal = true;
            // 
            // FrmPropertyGrid
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(346, 370);
            this.Controls.Add(this.qCompositeControl1);
            this.Controls.Add(this.qRibbonCaption1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmPropertyGrid";
            this.Text = "PropertyGrid - Qios.DevSuite.DemoZone";
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qCompositeControl1)).EndInit();
            this.qCompositeControl1.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		private void ShowObjectDetails(object selectedObject)
		{
			this.ShowObjectDetails(selectedObject, "(null)", "(null)");
		}

		/// <summary>
		/// Shows the details of the specified selected object.
		/// </summary>
		private void ShowObjectDetails(object selectedObject, string defaultTitle, string defaultName)
		{
			Control tmp_oControl = selectedObject as Control;

			this.qCompositeControl1.SuspendChangeNotification();
			if (selectedObject != null)
			{
				this.qctControlType.Title = selectedObject.GetType().ToString();
			}
			else
			{
				this.qctControlType.Title = defaultTitle;
			}

			if (tmp_oControl != null)
			{
				this.qctControlName.Title = tmp_oControl.Name;
				this.qctControlText.Title = tmp_oControl.Text;
			}
			else
			{
				this.qctControlName.Title = defaultName;
				this.qctControlText.Title = defaultTitle;
			}
			this.qCompositeControl1.ResumeChangeNotification(true);
		}

		/// <summary>
		/// Handles the hovering changed of the QControlSelector
		/// </summary>
		private void qControlSelector1_HoveringControlChanged(object sender, System.EventArgs e)
		{
			//Show which control we are currently hovering.
			this.ShowObjectDetails(qControlSelector1.HoveringControl);		
		}


		/// <summary>
		/// Handles the selected control changed of the QControlSelector1
		/// </summary>
		private void qControlSelector1_SelectedControlChanged(object sender, System.EventArgs e)
		{
			if (this.qControlSelector1.SelectedControl != null)
			{
				//If we have a selected control, set the property grid to that control.
				this.propertyGrid1.SelectedObject = this.qControlSelector1.SelectedControl;
			}
			else
			{
				//Otherwise show the object details of the current control
				this.ShowObjectDetails(this.propertyGrid1.SelectedObject);
			}
		}

		/// <summary>
		/// Handles the selected object changed of the property grid.
		/// </summary>
		private void propertyGrid1_SelectedObjectsChanged(object sender, System.EventArgs e)
		{
			//If the selected object of the property grid changes, show those details.
			this.ShowObjectDetails(propertyGrid1.SelectedObject);
		}

	}
}
