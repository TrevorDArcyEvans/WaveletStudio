using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

using Qios.DevSuite.DemoZone.Shared;

namespace Qios.DevSuite.DemoZone.Samples.Xbox360
{
	/// <summary>
	/// Defines a page for on a XBox360 Composite
	/// </summary>
	[Designer(typeof(QcgXbox360PageDesigner), typeof(System.ComponentModel.Design.IDesigner))]
	public class Xbox360Page : Qios.DevSuite.Components.QCompositeGroup
	{
		private QColorSet m_oActiveColorSet;
		private QColorSet m_oInactiveColorSet;
		private QColorSet m_oCurrentColorSet;

		private QCompositeGroup m_oPageHeader;
		private QCompositeItem m_oPageButtonItem;
		private QCompositeGroup m_oPageContent;
		private QCompositeText m_oPageHeaderText;

		/// <summary>
		/// Constructor
		/// </summary>
		public Xbox360Page()
		{
			m_oActiveColorSet = new QColorSet(Color.Lavender, Color.MediumSlateBlue, Color.Black, Color.Black);
			m_oInactiveColorSet = new QColorSet(Color.Gray, Color.LightGray, Color.Black, Color.FromArgb(128,0,0,0));

			this.m_oPageHeader = new Qios.DevSuite.Components.QCompositeGroup();
			this.m_oPageButtonItem = new Qios.DevSuite.Components.QCompositeItem();
			this.m_oPageHeaderText = new Qios.DevSuite.Components.QCompositeText();
			this.m_oPageContent = new Qios.DevSuite.Components.QCompositeGroup();

			//
			// The Page
			//
			this.Configuration.Margin = new Qios.DevSuite.Components.QMargin(-8, 0, 0, 0);
			this.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.Configuration.ShrinkHorizontal = true;
			this.Configuration.ShrinkVertical = true;
			this.Configuration.StretchVertical = true;
			this.Parts.Add(this.m_oPageHeader);
			this.Parts.Add(this.m_oPageContent);

			// 
			// m_oPageHeader
			// 
			this.m_oPageHeader.ColorScheme.SetAllThemeColors("CompositeGroupBackground1", Color.Silver);
			this.m_oPageHeader.ColorScheme.SetAllThemeColors("CompositeGroupBackground2", Color.WhiteSmoke);
			this.m_oPageHeader.Configuration.Appearance.GradientAngle = 0;
			this.m_oPageHeader.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, -2, -2, 2);
			this.m_oPageHeader.Configuration.ShrinkVertical = true;
			this.m_oPageHeader.Configuration.StretchVertical = true;
			this.m_oPageHeader.Items.Add(this.m_oPageButtonItem);

			// 
			// m_oPageButtonItem
			// 
			this.m_oPageButtonItem.Configuration.Appearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.m_oPageButtonItem.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -1);
			this.m_oPageButtonItem.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 5);
			this.m_oPageButtonItem.Configuration.ShrinkVertical = true;
			this.m_oPageButtonItem.Configuration.StretchVertical = true;
			this.m_oPageButtonItem.Items.Add(this.m_oPageHeaderText);
			this.m_oPageButtonItem.ItemActivated +=new QCompositeEventHandler(PageButtonItem_ItemActivated);

			// 
			// m_oPageHeaderText
			// 
			this.m_oPageHeaderText.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.m_oPageHeaderText.Configuration.FontDefinitionHot = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.m_oPageHeaderText.Configuration.FontDefinitionPressed = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.m_oPageHeaderText.Configuration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
			// 
			// m_oPageContent
			// 
			this.m_oPageContent.Configuration.ShrinkHorizontal = true;
			this.m_oPageContent.Configuration.ShrinkVertical = true;
			this.m_oPageContent.Configuration.StretchHorizontal = true;
			this.m_oPageContent.Configuration.StretchVertical = true;
			this.m_oPageContent.Configuration.Padding = new QPadding(10,10,10,20);
			this.m_oPageContent.Visible = false;

			this.SynchronizeColors(null);
		}


		/// <summary>
		/// Gets the XBox 360 dashboard this page belongs to.
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Xbox360Dash Xbox360Dash
		{
			get { return this.ParentControl as Xbox360Dash; }			
		}

		/// <summary>
		/// Gets or sets the Title of the page
		/// </summary>
		[Description("Gets or sets the Title of the page")]
		[Browsable(true)]
		[DefaultValue(null)]
		[Qios.DevSuite.Components.Design.QDesignerMainText(true)]
		public string Title
		{
			get { return m_oPageHeaderText.Title; }
			set { m_oPageHeaderText.Title = value; }
		}

		/// <summary>
		/// Gets or sets the first Color to use for this page.
		/// </summary>
		[Description("Gets or sets the first Color to use for this page")]
		[DefaultValue(typeof(Color), "Lavender")]
		public Color Color1
		{
			get { return m_oActiveColorSet.Background1; }
			set
			{
				m_oActiveColorSet.Background1 = value;
				this.SynchronizeColors(this.Xbox360Dash);
			}
		}

		/// <summary>
		/// Gets or sets the second Color to use for this page.
		/// </summary>
		[Description("Gets or sets the second Color to use for this page")]
		[DefaultValue(typeof(Color), "MediumSlateBlue")]
		public Color Color2
		{
			get { return m_oActiveColorSet.Background2; }
			set
			{
				m_oActiveColorSet.Background2 = value;
				this.SynchronizeColors(this.Xbox360Dash);
			}
		}

		/// <summary>
		/// Gets or sets the border Color to use for this page.
		/// </summary>
		[Description("Gets or sets the border Color to use for this page")]
		[DefaultValue(typeof(Color), "Black")]
		public Color ColorBorder
		{
			get { return m_oActiveColorSet.Border; }
			set
			{
				this.m_oActiveColorSet.Border = value;
				this.SynchronizeColors(this.Xbox360Dash);
			}
		}

		/// <summary>
		/// Gets or sets the text Color to use for this page.
		/// </summary>
		[Description("Gets or sets the text Color to use for this page")]
		[DefaultValue(typeof(Color), "Black")]
		public Color ColorText
		{
			get { return m_oActiveColorSet.Foreground; }
			set
			{
				this.m_oActiveColorSet.Foreground = value;
				this.SynchronizeColors(this.Xbox360Dash);
			}
		}

		/// <summary>
		/// Gets or sets the colorset used for active colors.
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QColorSet ActiveColorSet
		{
			get { return m_oActiveColorSet; }
			set { m_oActiveColorSet = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ColorScheme
		{
			get { return base.ColorScheme; }
			set { base.ColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public new QCompositeGroupConfiguration Configuration
		{
			get { return base.Configuration; }
			set { base.Configuration = value; }
		}

		/// <summary>
		/// Overridden. Returns the items of the content group, because those need to be designed.
		/// </summary>
		public override QPartCollection Items
		{
			get { return this.m_oPageContent.Items; }
		}

		/// <summary>
		/// Gets or sets whether this page is left aligned.
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public bool LeftAligned
		{
			get { return (this.Configuration.AlignmentHorizontal == QPartAlignment.Near); }
			set { this.Align(value); }
		}

		/// <summary>
		/// Overridden. Sets the parent
		/// </summary>
		protected override void SetParent(IQPart parentPart, QPartCollection parentCollection, bool removeFromCurrentParent, bool addToNewParent)
		{
			QComposite tmp_oParentComposite = parentPart as QComposite;
			Xbox360Dash tmp_oXbox360Dash = (tmp_oParentComposite != null) ? tmp_oParentComposite.ParentControl as Xbox360Dash : null;

			if (tmp_oXbox360Dash != null)
			{
				//If we are being added to a dashboard, synchronize this group.
				this.SuspendChangeNotification();
				this.SynchronizeShapes(tmp_oXbox360Dash);
				this.SynchronizeColors(tmp_oXbox360Dash);
				this.ResumeChangeNotification(false);
			}
			else if ((tmp_oXbox360Dash == null) && (this.Xbox360Dash != null))
			{
				//If we are being removed from a dashboard, set the previous page
				int tmp_iIndex = this.CalculatedProperties.PartIndex;
				if (tmp_iIndex > 0)
				{
					this.Xbox360Dash.ActivePage = this.ParentCollection[tmp_iIndex - 1] as Xbox360Page;
				}
				else
				{
					//Setting the active page to null selects the firsts one.
					this.Xbox360Dash.ActivePage = null;
				}
			}

			base.SetParent (parentPart, parentCollection, removeFromCurrentParent, addToNewParent);
		}

		/// <summary>
		/// Sets the display parent
		/// </summary>
		protected override void SetDisplayParent(IQManagedLayoutParent displayParent)
		{

			base.SetDisplayParent (displayParent);
			
			//Activate this page
			this.ActivatePage(true);
		}


		/// <summary>
		/// Aligns the page left or right.
		/// </summary>
		/// <param name="left"></param>
		public void Align(bool left)
		{
			if ((left) && (this.Configuration.AlignmentHorizontal != QPartAlignment.Near))
			{
				this.SuspendChangeNotification();
				this.Configuration.AlignmentHorizontal = QPartAlignment.Near;
				this.Configuration.Margin = new QMargin(-8, 0, 0, 0);
				this.m_oPageContent.Visible = false;
				this.SynchronizeShapes(this.Xbox360Dash);
				this.ResumeChangeNotification(true);
			}
			else if ((!left) && (this.Configuration.AlignmentHorizontal != QPartAlignment.Far))
			{
				this.SuspendChangeNotification();
				this.Configuration.AlignmentHorizontal = QPartAlignment.Far;
				this.Configuration.Margin = new QMargin(0, 0, 0, -6);
				this.m_oPageContent.Visible = false;
				this.SynchronizeShapes(this.Xbox360Dash);
				this.ResumeChangeNotification(true);
			}
		}

		/// <summary>
		/// Activates or deactivates this page.
		/// </summary>
		public void ActivatePage(bool activate)
		{
			if (this.Xbox360Dash != null)
			{
				this.SuspendChangeNotification();
				if (activate)
				{
					this.Xbox360Dash.ActivePage = this;
					this.Align(true);
					this.m_oPageContent.Visible = true;
					this.Configuration.Margin = new QMargin(-8,0,0,-10);
					this.Configuration.StretchHorizontal = true;
				}
				else
				{
					this.m_oPageContent.Visible = false;
					this.Configuration.Margin = this.LeftAligned ? new QMargin(-8,0,0,0) : new QMargin(0, 0, 0, -6);
					this.Configuration.StretchHorizontal = false;
				}

				this.SynchronizeColors(this.Xbox360Dash);

				this.ResumeChangeNotification(true);
			}
		}

		/// <summary>
		/// Overridden Suspends change notification
		/// </summary>
		/// <returns></returns>
		public override int SuspendChangeNotification()
		{
			this.m_oPageHeader.SuspendChangeNotification();
			this.m_oPageButtonItem.SuspendChangeNotification();
			this.m_oPageHeaderText.SuspendChangeNotification();
			this.m_oPageContent.SuspendChangeNotification();
			return base.SuspendChangeNotification();
		}

		/// <summary>
		/// Overridden Resumes change notification
		/// </summary>
		public override int ResumeChangeNotification(bool notifyChange)
		{
			this.m_oPageHeader.ResumeChangeNotification(false);
			this.m_oPageButtonItem.ResumeChangeNotification(false);
			this.m_oPageHeaderText.ResumeChangeNotification(false);
			this.m_oPageContent.ResumeChangeNotification(false);
			return base.ResumeChangeNotification(notifyChange);
		}

		/// <summary>
		/// Synchronizes the colors with the specified dashboard.
		/// </summary>
		private void SynchronizeColors(Xbox360Dash dash)
		{
			this.SuspendChangeNotification();

			//The page button item has the active colorset as hot.
			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemHotBackground1", this.m_oActiveColorSet.Background1);
			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemHotBackground2", this.m_oActiveColorSet.Background2);
			this.m_oPageHeaderText.ColorScheme.SetAllThemeColors("CompositeTextHot", this.m_oActiveColorSet.Foreground);
			this.m_oPageHeaderText.ColorScheme.SetAllThemeColors("CompositeTextPressed", this.m_oActiveColorSet.Foreground);

			this.ResumeChangeNotification(false);

			//Set the other colors based on whether the page is activated.
			if ((dash == null) || (dash.ActivePage == this))
			{
				this.SetColors(m_oActiveColorSet);
			}
			else
			{
				this.SetColors(m_oInactiveColorSet);
			}
		}

		/// <summary>
		/// Synchronizes the Shapes with the dash
		/// </summary>
		private void SynchronizeShapes(Xbox360Dash dash)
		{
			this.SuspendChangeNotification();
			if (dash != null)
			{
				if (this.LeftAligned)
				{
					this.m_oPageButtonItem.Configuration.Appearance.Shape = dash.PageButtonShape;
					this.m_oPageHeader.Configuration.Appearance.Shape = dash.PageHeaderShape;
					this.Configuration.Appearance.Shape = dash.PageShape;
				}
				else
				{
					this.m_oPageButtonItem.Configuration.Appearance.Shape = dash.PageButtonShapeRight;
					this.m_oPageHeader.Configuration.Appearance.Shape = dash.PageHeaderShapeRight;
					this.Configuration.Appearance.Shape = dash.PageShapeRight;
				}
			}
			this.ResumeChangeNotification(true);
		}

		/// <summary>
		/// Sets the colors to the specified colorSet
		/// </summary>
		private void SetColors(QColorSet colorSet)
		{
			if ((m_oCurrentColorSet != null) && (m_oCurrentColorSet.EqualsColorSet(colorSet))) return;
			m_oCurrentColorSet = new QColorSet(colorSet);

			this.SuspendChangeNotification();

			this.ColorScheme.SetAllThemeColors("CompositeGroupBackground1", colorSet.Background1);
			this.ColorScheme.SetAllThemeColors("CompositeGroupBackground2", colorSet.Background2);
			this.ColorScheme.SetAllThemeColors("CompositeGroupBorder", colorSet.Border);

			this.m_oPageHeader.ColorScheme.SetAllThemeColors("CompositeGroupBorder", colorSet.Border);

			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemBackground1", colorSet.Background1);
			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemBackground2", colorSet.Background2);
			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemBorder", colorSet.Border);
			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemHotBorder", colorSet.Border);
			this.m_oPageButtonItem.ColorScheme.SetAllThemeColors("CompositeItemPressedBorder", colorSet.Border);

			this.m_oPageHeaderText.ColorScheme.SetAllThemeColors("CompositeText", colorSet.Foreground);

			this.ResumeChangeNotification(true);
		}

		private void PageButtonItem_ItemActivated(object sender, QCompositeEventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			this.ActivatePage(true);
			Cursor.Current = Cursors.Default;
		}
	}

	/// <summary>
	/// Defines the designer for the Xbox360Page
	/// </summary>
	public class QcgXbox360PageDesigner : Qios.DevSuite.Components.Design.QCompositeGroupDesigner
	{
		protected override void HandleSelectionChanged()
		{
			if ((this.SelectionService != null) && (this.SelectionService.PrimarySelection == this.Component))
			{
				Xbox360Page tmp_oPage = this.Component as Xbox360Page;

				if (tmp_oPage != null)
				{
					tmp_oPage.ActivatePage(true);
				}
			}
		}

	}


}
