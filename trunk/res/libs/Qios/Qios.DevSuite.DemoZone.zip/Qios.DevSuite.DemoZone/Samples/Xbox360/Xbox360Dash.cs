using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

using Qios.DevSuite.DemoZone.Shared;

namespace Qios.DevSuite.DemoZone.Samples.Xbox360
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	[DesignTimeVisible(false)]
	[Designer(typeof(QccXbox360DashDesigner), typeof(System.ComponentModel.Design.IDesigner))]
	public class Xbox360Dash : Qios.DevSuite.Components.QCompositeControl
	{
		/// <summary>
		/// Contains the current active page
		/// </summary>
		private Xbox360Page m_oActivePage;

		private Qios.DevSuite.Components.QShape qsPageButton;
		private Qios.DevSuite.Components.QShape qsComposite;
		private Qios.DevSuite.Components.QShape qsPageHeader;
		private Qios.DevSuite.Components.QShape qsPageButtonRight;
		private Qios.DevSuite.Components.QShape qsPageRight;
		private Qios.DevSuite.Components.QShape qsPageHeaderRight;
		private Qios.DevSuite.Components.QShape qsPage;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Xbox360Dash()
		{

			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

//			QColorSet[] tmp_aColorSets = new QColorSet[] {
//															 new QColorSet(Color.Lavender, Color.MediumSlateBlue, Color.Black, Color.Black),
//															 new QColorSet(Color.Cornsilk, Color.Gold, Color.Black, Color.Black),
//															 new QColorSet(Color.LightGreen, Color.ForestGreen, Color.Black, Color.Black),
//															 new QColorSet(Color.FromArgb(180, 196, 255), Color.FromArgb(46, 78, 198), Color.Black, Color.Black),
//															 new QColorSet(Color.FromArgb(255,192,192), Color.Red, Color.Black, Color.Black),
//			};
//
//
//			for (int i = 0; i < 5; i++)
//			{
//				Xbox360Page tmp_oPage = new Xbox360Page();
//				tmp_oPage.Title = "Page " + (i + 1).ToString();
//				tmp_oPage.ActiveColorSet = tmp_aColorSets[i];
//				this.Items.Add(tmp_oPage);
//			}
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ColorScheme
		{
			get { return base.ColorScheme; }
			set { base.ColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration Configuration
		{
			get { return base.Configuration; }
			set { base.Configuration = value; }
		}

		/// <summary>
		/// Gets or sets the ActivePage.
		/// </summary>
		[Browsable(false)]
		public Xbox360Page ActivePage
		{
			get { return m_oActivePage; }
			set { this.SetActivePage(value); }
		}

		/// <summary>
		/// Gets the PageShape
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QShape PageShape
		{
			get { return this.qsPage; }
		}

		/// <summary>
		/// Gets the PageButtonShape
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QShape PageButtonShape
		{
			get { return this.qsPageButton; }
		}

		/// <summary>
		/// Gets the PageHeader shape
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QShape PageHeaderShape
		{
			get { return this.qsPageHeader; }
		}

		/// <summary>
		/// Gets the PageShapeRight
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QShape PageShapeRight
		{
			get { return this.qsPageRight; }
		}

		/// <summary>
		/// Gets the PageButtonShapeRight
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QShape PageButtonShapeRight
		{
			get { return this.qsPageButtonRight; }
		}

		/// <summary>
		/// Gets the PageHeaderShapeRight
		/// </summary>
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public QShape PageHeaderShapeRight
		{
			get { return this.qsPageHeaderRight; }
		}

		/// <summary>
		/// Sets the active page.
		/// </summary>
		public void SetActivePage(Xbox360Page page)
		{
			if ((page == null) && (this.Items.Count > 0))
			{
				page = this.Items[0] as Xbox360Page;
			}

			if (page == this.m_oActivePage) return;
			this.m_oActivePage = page;

			if (m_oActivePage != null)
			{
				this.SuspendChangeNotification();

				int tmp_iPageIndex = this.Items.IndexOf(page);
				if (tmp_iPageIndex >= 0)
				{
					for (int i = 0; i < tmp_iPageIndex; i++)
					{
						Xbox360Page tmp_oPage = this.Items[i] as Xbox360Page;
						if (tmp_oPage != null)
						{
							tmp_oPage.Align(true);
							tmp_oPage.ActivatePage(false);
						}
					}

					m_oActivePage.ActivatePage(true);

					for (int i = tmp_iPageIndex + 1; i < this.Items.Count; i++)
					{
						Xbox360Page tmp_oPage = this.Items[i] as Xbox360Page;
						if (tmp_oPage != null)
						{
							tmp_oPage.Align(false);
							tmp_oPage.ActivatePage(false);
						}
					}
				}
				this.ResumeChangeNotification(true);
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.qsPageButton = new Qios.DevSuite.Components.QShape();
			this.qsComposite = new Qios.DevSuite.Components.QShape();
			this.qsPageHeader = new Qios.DevSuite.Components.QShape();
			this.qsPageButtonRight = new Qios.DevSuite.Components.QShape();
			this.qsPageRight = new Qios.DevSuite.Components.QShape();
			this.qsPageHeaderRight = new Qios.DevSuite.Components.QShape();
			this.qsPage = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// qsPageButton
			// 
			this.qsPageButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageButton.ContentBounds = new System.Drawing.Rectangle(3, 63, 17, 50);
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(8F, 200F, 10F, 183F, 12F, 150F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 137F, 11F, 112F, 1F, 118F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(1F, 100F, 3F, 86F, 1F, 72F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 65F, 0F, 59F, 0F, 57F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 56F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(9F, 56F, 15F, 56F, 9F, 11F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(8F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 200F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Size = new System.Drawing.Size(20, 200);
			// 
			// qsComposite
			// 
			this.qsComposite.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsComposite.ContentBounds = new System.Drawing.Rectangle(0, 0, 20, 100);
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, 7F, 5F, 13F, 5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, 15F, 32F, 15F, 68F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, 13F, 95F, 7F, 95F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, 5F, 68F, 5F, 32F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsComposite.ShapeName = "SquareContent";
			this.qsComposite.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsComposite.Size = new System.Drawing.Size(20, 100);
			// 
			// qsPageHeader
			// 
			this.qsPageHeader.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageHeader.ContentBounds = new System.Drawing.Rectangle(6, 0, 14, 99);
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(14F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 0F, 20F, 25F, 20F, 75F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageHeader.ShapeName = "SquareContent";
			this.qsPageHeader.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPageHeader.Size = new System.Drawing.Size(20, 100);
			// 
			// qsPageButtonRight
			// 
			this.qsPageButtonRight.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageButtonRight.ContentBounds = new System.Drawing.Rectangle(0, 63, 17, 50);
			this.qsPageButtonRight.FocusPoint = new System.Drawing.Point(20, 0);
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 200F, 10F, 183F, 8F, 150F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(9F, 137F, 9F, 112F, 19F, 118F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(19F, 100F, 17F, 86F, 19F, 72F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 65F, 20F, 59F, 20F, 57F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 56F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 56F, 5F, 56F, 11F, 11F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 200F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Size = new System.Drawing.Size(20, 200);
			// 
			// qsPageRight
			// 
			this.qsPageRight.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageRight.ContentBounds = new System.Drawing.Rectangle(0, 0, 20, 100);
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 100F, 0F, 68F, 0F, 32F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, 15F, 32F, 15F, 68F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageRight.ShapeName = "SquareContent";
			this.qsPageRight.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPageRight.Size = new System.Drawing.Size(20, 100);
			// 
			// qsPageHeaderRight
			// 
			this.qsPageHeaderRight.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageHeaderRight.ContentBounds = new System.Drawing.Rectangle(0, 0, 14, 99);
			this.qsPageHeaderRight.FocusPoint = new System.Drawing.Point(20, 0);
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(6F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, 0F, 25F, 0F, 75F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsPageHeaderRight.ShapeName = "SquareContent";
			this.qsPageHeaderRight.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPageHeaderRight.Size = new System.Drawing.Size(20, 100);
			// 
			// qsPage
			// 
			this.qsPage.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPage.ContentBounds = new System.Drawing.Rectangle(0, 0, 20, 100);
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, 5F, 68F, 5F, 32F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, 15F, 32F, 15F, 68F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPage.ShapeName = "SquareContent";
			this.qsPage.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPage.Size = new System.Drawing.Size(20, 100);
			// 
			// Xbox360Dash
			// 
			this.ColorScheme.CompositeBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeText.ColorReference = "@TextColor";
			this.ColorScheme.CompositeTextHot.ColorReference = "@TextColor";
			this.ColorScheme.CompositeTextPressed.ColorReference = "@TextColor";
			this.Configuration.Appearance.Shape = this.qsComposite;
			this.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 5, 0, 0);
			this.Configuration.MinimumSize = new System.Drawing.Size(0, 224);
			this.Configuration.Padding = new Qios.DevSuite.Components.QPadding(8, 0, 0, 6);
			this.HandleAltKey = true;
			this.Name = "Xbox360Dash";
			this.Size = new System.Drawing.Size(312, 229);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
	}


	/// <summary>
	/// Defines the designer for the QccXBox360Dash
	/// </summary>
	public class QccXbox360DashDesigner : Qios.DevSuite.Components.Design.QCompositeControlDesigner
	{
		/// <summary>
		/// Overridden. Returns the types that can be created.
		/// </summary>
		public override Type[] GetCreationTypes()
		{
			return new Type[] { typeof(Xbox360Page) };
		}
	}
}
