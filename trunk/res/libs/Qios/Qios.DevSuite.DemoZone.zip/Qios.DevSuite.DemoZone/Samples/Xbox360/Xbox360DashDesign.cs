using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

using Qios.DevSuite.DemoZone.Shared;

namespace Qios.DevSuite.DemoZone.Samples.Xbox360
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	public class Xbox360DashDesign : Qios.DevSuite.Components.QCompositeControl
	{
		private Qios.DevSuite.Components.QCompositeGroup qcgPage;
		private Qios.DevSuite.Components.QShape qsPageButton;
		private Qios.DevSuite.Components.QCompositeGroup qcgPageHeader;
		private Qios.DevSuite.Components.QCompositeItem qciPageButton;
		private Qios.DevSuite.Components.QShape qsPageHeader;
		private Qios.DevSuite.Components.QCompositeGroup qcgPageContent;
		private Qios.DevSuite.Components.QCompositeText qctPageText;
		private Qios.DevSuite.Components.QShape qsPage;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup1;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup2;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem1;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup3;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup4;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup5;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem2;
		private Qios.DevSuite.Components.QCompositeText qCompositeText2;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup6;
		private Qios.DevSuite.Components.QShape qsPageRight;
		private Qios.DevSuite.Components.QCompositeText qCompositeText3;
		private Qios.DevSuite.Components.QShape qsComposite;
		private Qios.DevSuite.Components.QShape qsPageButtonRight;
		private Qios.DevSuite.Components.QShape qsPageHeaderRight;
		private Qios.DevSuite.Components.QCompositeGroup qcgPageRight;
		private Qios.DevSuite.Components.QCompositeGroup qcgPageHeaderRight;
		private Qios.DevSuite.Components.QCompositeItem qciPageButtonRight;
		private Qios.DevSuite.Components.QCompositeGroup qcgPageContentRight;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup7;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup8;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem3;
		private Qios.DevSuite.Components.QCompositeText qCompositeText4;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup9;
		private Qios.DevSuite.Components.QCompositeText qCompositeText5;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Xbox360DashDesign()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ChildCompositeColorScheme
		{
			get { return base.ChildCompositeColorScheme; }
			set { base.ChildCompositeColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration ChildCompositeConfiguration
		{
			get { return base.ChildCompositeConfiguration; }
			set { base.ChildCompositeConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeWindowConfiguration ChildWindowConfiguration
		{
			get { return base.ChildWindowConfiguration; }
			set { base.ChildWindowConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ColorScheme
		{
			get { return base.ColorScheme; }
			set { base.ColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration Configuration
		{
			get { return base.Configuration; }
			set { base.Configuration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QToolTipConfiguration ToolTipConfiguration
		{
			get { return base.ToolTipConfiguration; }
			set { base.ToolTipConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QPartCollection Items
		{
			get { return base.Items; }
		}

		/// <summary>
		/// Overridden. We don't want the designer be able to add Items (because they won't be serialized) when this Control
		/// is placed on a Form.
		/// </summary>
		protected override IList AssociatedComponents
		{
			get { return null; }
		}


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.qcgPage = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsPage = new Qios.DevSuite.Components.QShape();
			this.qcgPageHeader = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsPageHeader = new Qios.DevSuite.Components.QShape();
			this.qciPageButton = new Qios.DevSuite.Components.QCompositeItem();
			this.qsPageButton = new Qios.DevSuite.Components.QShape();
			this.qctPageText = new Qios.DevSuite.Components.QCompositeText();
			this.qcgPageContent = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsPageButtonRight = new Qios.DevSuite.Components.QShape();
			this.qCompositeGroup1 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeGroup2 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeItem1 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeGroup3 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsPageHeaderRight = new Qios.DevSuite.Components.QShape();
			this.qCompositeGroup4 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsPageRight = new Qios.DevSuite.Components.QShape();
			this.qCompositeGroup5 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeItem2 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeText2 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeGroup6 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgPageRight = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgPageHeaderRight = new Qios.DevSuite.Components.QCompositeGroup();
			this.qciPageButtonRight = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeText3 = new Qios.DevSuite.Components.QCompositeText();
			this.qcgPageContentRight = new Qios.DevSuite.Components.QCompositeGroup();
			this.qsComposite = new Qios.DevSuite.Components.QShape();
			this.qCompositeGroup7 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeGroup8 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeItem3 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeText4 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeGroup9 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeText5 = new Qios.DevSuite.Components.QCompositeText();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// qcgPage
			// 
			this.qcgPage.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Lavender, false);
			this.qcgPage.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Lavender, false);
			this.qcgPage.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Lavender, false);
			this.qcgPage.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Lavender, false);
			this.qcgPage.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Lavender, false);
			this.qcgPage.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.MediumSlateBlue, false);
			this.qcgPage.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qcgPage.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qcgPage.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qcgPage.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qcgPage.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qcgPage.Configuration.Appearance.Shape = this.qsPage;
			this.qcgPage.Configuration.Margin = new Qios.DevSuite.Components.QMargin(-8, 0, 0, 0);
			this.qcgPage.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qcgPage.Configuration.ShrinkHorizontal = true;
			this.qcgPage.Configuration.ShrinkVertical = true;
			this.qcgPage.Configuration.StretchVertical = true;
			this.qcgPage.Items.Add(this.qcgPageHeader);
			this.qcgPage.Items.Add(this.qcgPageContent);
			// 
			// qsPage
			// 
			this.qsPage.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPage.ContentBounds = new System.Drawing.Rectangle(0, 0, 20, 100);
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, 5F, 68F, 5F, 32F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, 15F, 32F, 15F, 68F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPage.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPage.ShapeName = "SquareContent";
			this.qsPage.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPage.Size = new System.Drawing.Size(20, 100);
			// 
			// qcgPageHeader
			// 
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Silver, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Silver, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Silver, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Silver, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Silver, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qcgPageHeader.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qcgPageHeader.Configuration.Appearance.GradientAngle = 0;
			this.qcgPageHeader.Configuration.Appearance.Shape = this.qsPageHeader;
			this.qcgPageHeader.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, -2, -2, 2);
			this.qcgPageHeader.Configuration.ShrinkVertical = true;
			this.qcgPageHeader.Configuration.StretchVertical = true;
			this.qcgPageHeader.Items.Add(this.qciPageButton);
			// 
			// qsPageHeader
			// 
			this.qsPageHeader.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageHeader.ContentBounds = new System.Drawing.Rectangle(6, 0, 14, 99);
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(14F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageHeader.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 0F, 20F, 25F, 20F, 75F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageHeader.ShapeName = "SquareContent";
			this.qsPageHeader.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPageHeader.Size = new System.Drawing.Size(20, 100);
			// 
			// qciPageButton
			// 
			this.qciPageButton.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.Gold, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.Cornsilk, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qciPageButton.ColorScheme.CompositeItemBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qciPageButton.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qciPageButton.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qciPageButton.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qciPageButton.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qciPageButton.ColorScheme.CompositeItemBorder.SetColor("HighContrast", System.Drawing.SystemColors.ControlDark, false);
			this.qciPageButton.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qciPageButton.Configuration.Appearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.qciPageButton.Configuration.Appearance.Shape = this.qsPageButton;
			this.qciPageButton.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -1);
			this.qciPageButton.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 5);
			this.qciPageButton.Configuration.ShrinkVertical = true;
			this.qciPageButton.Configuration.StretchVertical = true;
			this.qciPageButton.Items.Add(this.qctPageText);
			// 
			// qsPageButton
			// 
			this.qsPageButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageButton.ContentBounds = new System.Drawing.Rectangle(3, 63, 17, 50);
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(8F, 200F, 10F, 183F, 12F, 150F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 137F, 11F, 112F, 1F, 118F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(1F, 100F, 3F, 86F, 1F, 72F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 65F, 0F, 59F, 0F, 57F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 56F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(9F, 56F, 15F, 56F, 9F, 11F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(8F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 200F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButton.Size = new System.Drawing.Size(20, 200);
			// 
			// qctPageText
			// 
			this.qctPageText.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.qctPageText.Configuration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
			this.qctPageText.Title = "Page 1";
			// 
			// qcgPageContent
			// 
			this.qcgPageContent.Configuration.Appearance.BorderWidth = 2;
			this.qcgPageContent.Configuration.ShrinkHorizontal = true;
			this.qcgPageContent.Configuration.ShrinkVertical = true;
			this.qcgPageContent.Configuration.StretchHorizontal = true;
			this.qcgPageContent.Configuration.StretchVertical = true;
			this.qcgPageContent.Configuration.Visible = Qios.DevSuite.Components.QTristateBool.True;
			this.qcgPageContent.Visible = false;
			// 
			// qsPageButtonRight
			// 
			this.qsPageButtonRight.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageButtonRight.ContentBounds = new System.Drawing.Rectangle(0, 63, 17, 50);
			this.qsPageButtonRight.FocusPoint = new System.Drawing.Point(20, 0);
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 200F, 10F, 183F, 8F, 150F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(9F, 137F, 9F, 112F, 19F, 118F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(19F, 100F, 17F, 86F, 19F, 72F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 65F, 20F, 59F, 20F, 57F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 56F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 56F, 5F, 56F, 11F, 11F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsPageButtonRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 200F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageButtonRight.Size = new System.Drawing.Size(20, 200);
			// 
			// qCompositeGroup1
			// 
			this.qCompositeGroup1.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeGroup1.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeGroup1.Configuration.Appearance.Shape = this.qsPage;
			this.qCompositeGroup1.Configuration.Margin = new Qios.DevSuite.Components.QMargin(-8, 0, 0, -10);
			this.qCompositeGroup1.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qCompositeGroup1.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup1.Configuration.ShrinkVertical = true;
			this.qCompositeGroup1.Configuration.StretchHorizontal = true;
			this.qCompositeGroup1.Configuration.StretchVertical = true;
			this.qCompositeGroup1.Items.Add(this.qCompositeGroup2);
			this.qCompositeGroup1.Items.Add(this.qCompositeGroup3);
			// 
			// qCompositeGroup2
			// 
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Silver, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Silver, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Silver, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Silver, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Silver, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeGroup2.Configuration.Appearance.GradientAngle = 0;
			this.qCompositeGroup2.Configuration.Appearance.Shape = this.qsPageHeader;
			this.qCompositeGroup2.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, -2, -2, 2);
			this.qCompositeGroup2.Configuration.ShrinkVertical = true;
			this.qCompositeGroup2.Configuration.StretchVertical = true;
			this.qCompositeGroup2.Items.Add(this.qCompositeItem1);
			// 
			// qCompositeItem1
			// 
			this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.Lavender, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("HighContrast", System.Drawing.SystemColors.ControlDark, false);
			this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeItem1.Configuration.Appearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.qCompositeItem1.Configuration.Appearance.Shape = this.qsPageButton;
			this.qCompositeItem1.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -1);
			this.qCompositeItem1.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 5);
			this.qCompositeItem1.Configuration.ShrinkVertical = true;
			this.qCompositeItem1.Configuration.StretchVertical = true;
			this.qCompositeItem1.Items.Add(this.qCompositeText1);
			// 
			// qCompositeText1
			// 
			this.qCompositeText1.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.qCompositeText1.Configuration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
			this.qCompositeText1.Title = "Page 1";
			// 
			// qCompositeGroup3
			// 
			this.qCompositeGroup3.Configuration.Appearance.BorderWidth = 2;
			this.qCompositeGroup3.Configuration.Padding = new Qios.DevSuite.Components.QPadding(10, 10, 10, 10);
			this.qCompositeGroup3.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup3.Configuration.ShrinkVertical = true;
			this.qCompositeGroup3.Configuration.StretchHorizontal = true;
			this.qCompositeGroup3.Configuration.StretchVertical = true;
			this.qCompositeGroup3.Configuration.Visible = Qios.DevSuite.Components.QTristateBool.True;
			this.qCompositeGroup3.Items.Add(this.qCompositeText5);
			// 
			// qsPageHeaderRight
			// 
			this.qsPageHeaderRight.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageHeaderRight.ContentBounds = new System.Drawing.Rectangle(0, 0, 14, 99);
			this.qsPageHeaderRight.FocusPoint = new System.Drawing.Point(20, 0);
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(6F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageHeaderRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, 0F, 25F, 0F, 75F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsPageHeaderRight.ShapeName = "SquareContent";
			this.qsPageHeaderRight.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPageHeaderRight.Size = new System.Drawing.Size(20, 100);
			// 
			// qCompositeGroup4
			// 
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeGroup4.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qCompositeGroup4.Configuration.Appearance.Shape = this.qsPageRight;
			this.qCompositeGroup4.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -6);
			this.qCompositeGroup4.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qCompositeGroup4.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup4.Configuration.ShrinkVertical = true;
			this.qCompositeGroup4.Configuration.StretchVertical = true;
			this.qCompositeGroup4.Items.Add(this.qCompositeGroup5);
			this.qCompositeGroup4.Items.Add(this.qCompositeGroup6);
			// 
			// qsPageRight
			// 
			this.qsPageRight.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsPageRight.ContentBounds = new System.Drawing.Rectangle(0, 0, 20, 100);
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 100F, 0F, 68F, 0F, 32F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, 15F, 32F, 15F, 68F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageRight.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPageRight.ShapeName = "SquareContent";
			this.qsPageRight.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsPageRight.Size = new System.Drawing.Size(20, 100);
			// 
			// qCompositeGroup5
			// 
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Silver, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Silver, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Silver, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Silver, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Silver, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeGroup5.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeGroup5.Configuration.Appearance.GradientAngle = 0;
			this.qCompositeGroup5.Configuration.Appearance.Shape = this.qsPageHeaderRight;
			this.qCompositeGroup5.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, -2, -2, 2);
			this.qCompositeGroup5.Configuration.ShrinkVertical = true;
			this.qCompositeGroup5.Configuration.StretchVertical = true;
			this.qCompositeGroup5.Items.Add(this.qCompositeItem2);
			// 
			// qCompositeItem2
			// 
			this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.Red, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(192)), ((System.Byte)(192))), false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("HighContrast", System.Drawing.SystemColors.ControlDark, false);
			this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeItem2.Configuration.Appearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.qCompositeItem2.Configuration.Appearance.Shape = this.qsPageButtonRight;
			this.qCompositeItem2.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -1);
			this.qCompositeItem2.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 5);
			this.qCompositeItem2.Configuration.ShrinkVertical = true;
			this.qCompositeItem2.Configuration.StretchVertical = true;
			this.qCompositeItem2.Items.Add(this.qCompositeText2);
			// 
			// qCompositeText2
			// 
			this.qCompositeText2.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.qCompositeText2.Configuration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
			this.qCompositeText2.Title = "Page 1";
			// 
			// qCompositeGroup6
			// 
			this.qCompositeGroup6.Configuration.Appearance.BorderWidth = 2;
			this.qCompositeGroup6.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup6.Configuration.ShrinkVertical = true;
			this.qCompositeGroup6.Configuration.StretchHorizontal = true;
			this.qCompositeGroup6.Configuration.StretchVertical = true;
			this.qCompositeGroup6.Visible = false;
			// 
			// qcgPageRight
			// 
			this.qcgPageRight.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Lavender, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Lavender, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Lavender, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Lavender, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Lavender, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.MediumSlateBlue, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qcgPageRight.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qcgPageRight.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qcgPageRight.Configuration.Appearance.Shape = this.qsPageRight;
			this.qcgPageRight.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -6);
			this.qcgPageRight.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qcgPageRight.Configuration.ShrinkHorizontal = true;
			this.qcgPageRight.Configuration.ShrinkVertical = true;
			this.qcgPageRight.Configuration.StretchVertical = true;
			this.qcgPageRight.Items.Add(this.qcgPageHeaderRight);
			this.qcgPageRight.Items.Add(this.qcgPageContentRight);
			// 
			// qcgPageHeaderRight
			// 
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Silver, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Silver, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Silver, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Silver, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Silver, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.WhiteSmoke, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qcgPageHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qcgPageHeaderRight.Configuration.Appearance.GradientAngle = 0;
			this.qcgPageHeaderRight.Configuration.Appearance.Shape = this.qsPageHeaderRight;
			this.qcgPageHeaderRight.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, -2, -2, 2);
			this.qcgPageHeaderRight.Configuration.ShrinkVertical = true;
			this.qcgPageHeaderRight.Configuration.StretchVertical = true;
			this.qcgPageHeaderRight.Items.Add(this.qciPageButtonRight);
			// 
			// qciPageButtonRight
			// 
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(180)), ((System.Byte)(196)), ((System.Byte)(255))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(180)), ((System.Byte)(196)), ((System.Byte)(255))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(180)), ((System.Byte)(196)), ((System.Byte)(255))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(180)), ((System.Byte)(196)), ((System.Byte)(255))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(180)), ((System.Byte)(196)), ((System.Byte)(255))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(78)), ((System.Byte)(198))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(78)), ((System.Byte)(198))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(78)), ((System.Byte)(198))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(78)), ((System.Byte)(198))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(78)), ((System.Byte)(198))), false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBorder.SetColor("HighContrast", System.Drawing.SystemColors.ControlDark, false);
			this.qciPageButtonRight.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qciPageButtonRight.Configuration.Appearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.qciPageButtonRight.Configuration.Appearance.Shape = this.qsPageButtonRight;
			this.qciPageButtonRight.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -1);
			this.qciPageButtonRight.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 5);
			this.qciPageButtonRight.Configuration.ShrinkVertical = true;
			this.qciPageButtonRight.Configuration.StretchVertical = true;
			this.qciPageButtonRight.Items.Add(this.qCompositeText3);
			this.qciPageButtonRight.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qciPageButtonRight_ItemActivated);
			// 
			// qCompositeText3
			// 
			this.qCompositeText3.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.qCompositeText3.Configuration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
			this.qCompositeText3.Title = "Page 1";
			// 
			// qcgPageContentRight
			// 
			this.qcgPageContentRight.Configuration.Appearance.BorderWidth = 2;
			this.qcgPageContentRight.Configuration.ShrinkHorizontal = true;
			this.qcgPageContentRight.Configuration.ShrinkVertical = true;
			this.qcgPageContentRight.Configuration.StretchHorizontal = true;
			this.qcgPageContentRight.Configuration.StretchVertical = true;
			this.qcgPageContentRight.Visible = false;
			// 
			// qsComposite
			// 
			this.qsComposite.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsComposite.ContentBounds = new System.Drawing.Rectangle(0, 0, 20, 100);
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, 7F, 5F, 13F, 5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 0F, 15F, 32F, 15F, 68F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 100F, 13F, 95F, 7F, 95F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsComposite.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, 5F, 68F, 5F, 32F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsComposite.ShapeName = "SquareContent";
			this.qsComposite.ShapeType = Qios.DevSuite.Components.QShapeType.Content;
			this.qsComposite.Size = new System.Drawing.Size(20, 100);
			// 
			// qCompositeGroup7
			// 
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Lavender, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeGroup7.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeGroup7.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qCompositeGroup7.Configuration.Appearance.Shape = this.qsPageRight;
			this.qCompositeGroup7.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -6);
			this.qCompositeGroup7.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qCompositeGroup7.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup7.Configuration.ShrinkVertical = true;
			this.qCompositeGroup7.Configuration.StretchVertical = true;
			this.qCompositeGroup7.Items.Add(this.qCompositeGroup8);
			this.qCompositeGroup7.Items.Add(this.qCompositeGroup9);
			// 
			// qCompositeGroup8
			// 
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.Silver, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.Silver, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.Silver, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.Silver, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.Silver, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.WhiteSmoke, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeGroup8.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeGroup8.Configuration.Appearance.GradientAngle = 0;
			this.qCompositeGroup8.Configuration.Appearance.Shape = this.qsPageHeaderRight;
			this.qCompositeGroup8.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, -2, -2, 2);
			this.qCompositeGroup8.Configuration.ShrinkVertical = true;
			this.qCompositeGroup8.Configuration.StretchVertical = true;
			this.qCompositeGroup8.Items.Add(this.qCompositeItem3);
			// 
			// qCompositeItem3
			// 
			this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.ForestGreen, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.LightGreen, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBackground2.SetColor("VistaBlack", System.Drawing.Color.MediumSlateBlue, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("HighContrast", System.Drawing.SystemColors.ControlDark, false);
			this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.qCompositeItem3.Configuration.Appearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.qCompositeItem3.Configuration.Appearance.Shape = this.qsPageButtonRight;
			this.qCompositeItem3.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, -1);
			this.qCompositeItem3.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 1, 1, 5);
			this.qCompositeItem3.Configuration.ShrinkVertical = true;
			this.qCompositeItem3.Configuration.StretchVertical = true;
			this.qCompositeItem3.Items.Add(this.qCompositeText4);
			// 
			// qCompositeText4
			// 
			this.qCompositeText4.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 12F);
			this.qCompositeText4.Configuration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
			this.qCompositeText4.Title = "Page 1";
			// 
			// qCompositeGroup9
			// 
			this.qCompositeGroup9.Configuration.Appearance.BorderWidth = 2;
			this.qCompositeGroup9.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup9.Configuration.ShrinkVertical = true;
			this.qCompositeGroup9.Configuration.StretchHorizontal = true;
			this.qCompositeGroup9.Configuration.StretchVertical = true;
			this.qCompositeGroup9.Visible = false;
			// 
			// qCompositeText5
			// 
			this.qCompositeText5.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 11F);
			this.qCompositeText5.Configuration.ShrinkHorizontal = true;
			this.qCompositeText5.Configuration.WrapText = true;
			this.qCompositeText5.Title = "This Xbx360DashDesign control is only used to design the various shapes and confi" +
				"gurations. The actual used Xbox360 dashboard is located in Xbox360Dash and Xbox3" +
				"60Page";
			// 
			// Xbox360DashDesign
			// 
			this.ColorScheme.CompositeBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeBorder.SetColor("VistaBlack", System.Drawing.Color.Black, false);
			this.ColorScheme.CompositeText.ColorReference = "@TextColor";
			this.Configuration.Appearance.Shape = this.qsComposite;
			this.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 5, 0, 0);
			this.Configuration.MinimumSize = new System.Drawing.Size(0, 224);
			this.Configuration.Padding = new Qios.DevSuite.Components.QPadding(8, 0, 0, 6);
			this.Configuration.ScrollConfiguration.ScrollHorizontal = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.Items.Add(this.qcgPage);
			this.Items.Add(this.qCompositeGroup1);
			this.Items.Add(this.qCompositeGroup4);
			this.Items.Add(this.qcgPageRight);
			this.Items.Add(this.qCompositeGroup7);
			this.Name = "Xbox360DashDesign";
			this.Size = new System.Drawing.Size(496, 384);
			this.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.QccXbox360Dash_ItemActivated);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion

		private void qccToolBar_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeControl1_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void QccXbox360Dash_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qciPageButtonRight_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}
	}
}
