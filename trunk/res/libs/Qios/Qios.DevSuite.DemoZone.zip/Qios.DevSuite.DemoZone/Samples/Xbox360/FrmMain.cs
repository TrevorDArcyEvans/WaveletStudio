using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.DemoZone.Misc;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone.Samples.Xbox360
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	[SelectorDisplay(
		 50,
		"Xbox 360 Sample",
		"This is the ultimate QComposite Example.")]
	public class FrmMain : QRibbonForm
	{
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qrcCaption;
		private Qios.DevSuite.Components.QPanel qPanel1;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		private Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Dash xBox360Dash1;
		private Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page xbPageSettings;
		private Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page xbPageQiosLive;
		private Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page xbPageDownloads;
		private Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page xbPageContent;
		private Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page xbPageFriends;
		private Qios.DevSuite.Components.QCompositeGroup qcgLeftHeader;
		private Qios.DevSuite.Components.QCompositeGroup qcgFriendsLeft;
		private Qios.DevSuite.Components.QShape qsItem;
		private Qios.DevSuite.Components.QCompositeImage qcgLeftImage;
		private Qios.DevSuite.Components.QCompositeSeparator qcgFriendSeparator;
		private Qios.DevSuite.Components.QCompositeSeparator qcsLeftVertSeparator;
		private Qios.DevSuite.Components.QCompositeGroup qcgLeftItems;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiLeftItem1;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qCompositeLargeMenuItem1;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qCompositeLargeMenuItem2;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qCompositeLargeMenuItem3;
		private Qios.DevSuite.Components.QCompositeGroup qcgFriendsRight;
		private Qios.DevSuite.Components.QCompositeText qctFriendsDescription;
		private Qios.DevSuite.Components.QCompositeGroup qcgFriendsHeaderRight;
		private Qios.DevSuite.Components.QCompositeText qctFriendsHeaderRight;
		private Qios.DevSuite.Components.QCompositeGroup qcgCurrentOnlineFriends;
		private Qios.DevSuite.Components.QCompositeGroup qcgCurrentOnlineFriendsHeader;
		private Qios.DevSuite.Components.QCompositeText qctCurrentOnlineFriends;
		private Qios.DevSuite.Components.QCompositeGroup qcgCurrentOnlineFriendsContent;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem4;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage4;
		private Qios.DevSuite.Components.QCompositeText qCompositeText4;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem8;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage8;
		private Qios.DevSuite.Components.QCompositeText qCompositeText8;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem1;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage1;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem2;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage2;
		private Qios.DevSuite.Components.QCompositeText qCompositeText2;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem3;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage3;
		private Qios.DevSuite.Components.QCompositeText qCompositeText3;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem5;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage5;
		private Qios.DevSuite.Components.QCompositeText qCompositeText5;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem6;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage6;
		private Qios.DevSuite.Components.QCompositeText qCompositeText6;
		private System.ComponentModel.Container components = null;

		public FrmMain()
		{
			InitializeComponent();

			this.xBox360Dash1.ActivePage = this.xbPageFriends;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            Qios.DevSuite.Components.QMarkupTextStyle qMarkupTextStyle1 = new Qios.DevSuite.Components.QMarkupTextStyle();
            this.qrcCaption = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            this.qsItem = new Qios.DevSuite.Components.QShape();
            this.qPanel1 = new Qios.DevSuite.Components.QPanel();
            this.xBox360Dash1 = new Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Dash();
            this.xbPageFriends = new Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page();
            this.qcgFriendsLeft = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgLeftHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgLeftImage = new Qios.DevSuite.Components.QCompositeImage();
            this.qcsLeftVertSeparator = new Qios.DevSuite.Components.QCompositeSeparator();
            this.qcgLeftItems = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcmiLeftItem1 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qCompositeLargeMenuItem1 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qCompositeLargeMenuItem2 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qCompositeLargeMenuItem3 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
            this.qcgFriendSeparator = new Qios.DevSuite.Components.QCompositeSeparator();
            this.qcgFriendsRight = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgFriendsHeaderRight = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctFriendsHeaderRight = new Qios.DevSuite.Components.QCompositeText();
            this.qctFriendsDescription = new Qios.DevSuite.Components.QCompositeText();
            this.qcgCurrentOnlineFriends = new Qios.DevSuite.Components.QCompositeGroup();
            this.qcgCurrentOnlineFriendsHeader = new Qios.DevSuite.Components.QCompositeGroup();
            this.qctCurrentOnlineFriends = new Qios.DevSuite.Components.QCompositeText();
            this.qcgCurrentOnlineFriendsContent = new Qios.DevSuite.Components.QCompositeGroup();
            this.qCompositeItem8 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage8 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText8 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeItem1 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage1 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeItem2 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage2 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText2 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeItem3 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage3 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText3 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeItem5 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage5 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText5 = new Qios.DevSuite.Components.QCompositeText();
            this.qCompositeItem6 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage6 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText6 = new Qios.DevSuite.Components.QCompositeText();
            this.xbPageQiosLive = new Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page();
            this.xbPageDownloads = new Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page();
            this.xbPageContent = new Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page();
            this.xbPageSettings = new Qios.DevSuite.DemoZone.Samples.Xbox360.Xbox360Page();
            this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
            this.qCompositeItem4 = new Qios.DevSuite.Components.QCompositeItem();
            this.qCompositeImage4 = new Qios.DevSuite.Components.QCompositeImage();
            this.qCompositeText4 = new Qios.DevSuite.Components.QCompositeText();
            ((System.ComponentModel.ISupportInitialize)(this.qrcCaption)).BeginInit();
            this.qPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xBox360Dash1)).BeginInit();
            this.SuspendLayout();
            // 
            // qrcCaption
            // 
            this.qrcCaption.Location = new System.Drawing.Point(0, 0);
            this.qrcCaption.Name = "qrcCaption";
            this.qrcCaption.Size = new System.Drawing.Size(698, 28);
            this.qrcCaption.TabIndex = 0;
            this.qrcCaption.Text = "Xbox 360 Sample - Qios.DevSuite.DemoZone ";
            // 
            // qsItem
            // 
            this.qsItem.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
            this.qsItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
            this.qsItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
            this.qsItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
            this.qsItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qPanel1
            // 
            this.qPanel1.Appearance.ShowBorders = false;
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("Default", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qPanel1.Controls.Add(this.xBox360Dash1);
            this.qPanel1.Controls.Add(this.qMarkupLabel1);
            this.qPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qPanel1.Location = new System.Drawing.Point(0, 28);
            this.qPanel1.Name = "qPanel1";
            this.qPanel1.Padding = new System.Windows.Forms.Padding(5);
            this.qPanel1.Size = new System.Drawing.Size(698, 438);
            this.qPanel1.TabIndex = 1;
            this.qPanel1.Text = "qPanel1";
            // 
            // xBox360Dash1
            // 
            this.xBox360Dash1.ActivePage = this.xbPageSettings;
            this.xBox360Dash1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xBox360Dash1.HandleAltKey = true;
            this.xBox360Dash1.Items.Add(this.xbPageQiosLive);
            this.xBox360Dash1.Items.Add(this.xbPageDownloads);
            this.xBox360Dash1.Items.Add(this.xbPageFriends);
            this.xBox360Dash1.Items.Add(this.xbPageContent);
            this.xBox360Dash1.Items.Add(this.xbPageSettings);
            this.xBox360Dash1.Location = new System.Drawing.Point(5, 100);
            this.xBox360Dash1.Name = "xBox360Dash1";
            this.xBox360Dash1.Size = new System.Drawing.Size(688, 333);
            this.xBox360Dash1.TabIndex = 6;
            this.xBox360Dash1.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.xBox360Dash1_ItemActivated);
            // 
            // xbPageFriends
            // 
            this.xbPageFriends.Color1 = System.Drawing.Color.LightGreen;
            this.xbPageFriends.Color2 = System.Drawing.Color.ForestGreen;
            this.xbPageFriends.Items.Add(this.qcgFriendsLeft);
            this.xbPageFriends.Items.Add(this.qcgFriendSeparator);
            this.xbPageFriends.Items.Add(this.qcgFriendsRight);
            this.xbPageFriends.Title = "Friends";
            // 
            // qcgFriendsLeft
            // 
            this.qcgFriendsLeft.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgFriendsLeft.Configuration.MaximumSize = new System.Drawing.Size(150, 0);
            this.qcgFriendsLeft.Configuration.ShrinkHorizontal = true;
            this.qcgFriendsLeft.Configuration.ShrinkVertical = true;
            this.qcgFriendsLeft.Configuration.StretchHorizontal = true;
            this.qcgFriendsLeft.Configuration.StretchVertical = true;
            this.qcgFriendsLeft.Items.Add(this.qcgLeftHeader);
            this.qcgFriendsLeft.Items.Add(this.qcsLeftVertSeparator);
            this.qcgFriendsLeft.Items.Add(this.qcgLeftItems);
            // 
            // qcgLeftHeader
            // 
            this.qcgLeftHeader.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftHeader.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgLeftHeader.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qcgLeftHeader.Configuration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.RoundedContent);
            this.qcgLeftHeader.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qcgLeftHeader.Configuration.ShrinkHorizontal = true;
            this.qcgLeftHeader.Configuration.StretchHorizontal = true;
            this.qcgLeftHeader.Items.Add(this.qcgLeftImage);
            // 
            // qcgLeftImage
            // 
            this.qcgLeftImage.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qcgLeftImage.Image = ((System.Drawing.Image)(resources.GetObject("qcgLeftImage.Image")));
            // 
            // qcsLeftVertSeparator
            // 
            this.qcsLeftVertSeparator.ColorScheme.CompositeSeparator1.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcsLeftVertSeparator.ColorScheme.CompositeSeparator1.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcsLeftVertSeparator.ColorScheme.CompositeSeparator1.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcsLeftVertSeparator.ColorScheme.CompositeSeparator1.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcsLeftVertSeparator.ColorScheme.CompositeSeparator1.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcsLeftVertSeparator.Configuration.Margin = new Qios.DevSuite.Components.QMargin(1, 5, 0, 1);
            // 
            // qcgLeftItems
            // 
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgLeftItems.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgLeftItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgLeftItems.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
            this.qcgLeftItems.Configuration.ShrinkHorizontal = true;
            this.qcgLeftItems.Configuration.ShrinkVertical = true;
            this.qcgLeftItems.Configuration.StretchHorizontal = true;
            this.qcgLeftItems.Configuration.StretchVertical = true;
            this.qcgLeftItems.Items.Add(this.qcmiLeftItem1);
            this.qcgLeftItems.Items.Add(this.qCompositeLargeMenuItem1);
            this.qcgLeftItems.Items.Add(this.qCompositeLargeMenuItem2);
            this.qcgLeftItems.Items.Add(this.qCompositeLargeMenuItem3);
            // 
            // qcmiLeftItem1
            // 
            this.qcmiLeftItem1.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcmiLeftItem1.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcmiLeftItem1.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcmiLeftItem1.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcmiLeftItem1.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcmiLeftItem1.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Gradient;
            this.qcmiLeftItem1.Configuration.Appearance.Shape = this.qsItem;
            this.qcmiLeftItem1.Description = "Here you can add friends";
            this.qcmiLeftItem1.HotkeyText = "A";
            this.qcmiLeftItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiLeftItem1.Icon")));
            this.qcmiLeftItem1.Title = "&Add Friends";
            // 
            // qCompositeLargeMenuItem1
            // 
            this.qCompositeLargeMenuItem1.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem1.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem1.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem1.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem1.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem1.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Gradient;
            this.qCompositeLargeMenuItem1.Configuration.Appearance.Shape = this.qsItem;
            this.qCompositeLargeMenuItem1.Description = "Here you can remove friends";
            this.qCompositeLargeMenuItem1.HotkeyText = "R";
            this.qCompositeLargeMenuItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeLargeMenuItem1.Icon")));
            this.qCompositeLargeMenuItem1.Title = "&Remove friends";
            // 
            // qCompositeLargeMenuItem2
            // 
            this.qCompositeLargeMenuItem2.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem2.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem2.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem2.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem2.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem2.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Gradient;
            this.qCompositeLargeMenuItem2.Configuration.Appearance.Shape = this.qsItem;
            this.qCompositeLargeMenuItem2.Description = "Here you can invite friends";
            this.qCompositeLargeMenuItem2.HotkeyText = "I";
            this.qCompositeLargeMenuItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeLargeMenuItem2.Icon")));
            this.qCompositeLargeMenuItem2.Title = "&Invite friends";
            // 
            // qCompositeLargeMenuItem3
            // 
            this.qCompositeLargeMenuItem3.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem3.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem3.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem3.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem3.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeLargeMenuItem3.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Gradient;
            this.qCompositeLargeMenuItem3.Configuration.Appearance.Shape = this.qsItem;
            this.qCompositeLargeMenuItem3.Description = "Here you can chat with friends";
            this.qCompositeLargeMenuItem3.HotkeyText = "C";
            this.qCompositeLargeMenuItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeLargeMenuItem3.Icon")));
            this.qCompositeLargeMenuItem3.Title = "&Chat with friends";
            // 
            // qcgFriendSeparator
            // 
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator1.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator1.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator1.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator1.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator1.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator2.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator2.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator2.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator2.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.ColorScheme.CompositeSeparator2.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgFriendSeparator.Configuration.Margin = new Qios.DevSuite.Components.QMargin(5, 1, 1, 5);
            // 
            // qcgFriendsRight
            // 
            this.qcgFriendsRight.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgFriendsRight.Configuration.ShrinkHorizontal = true;
            this.qcgFriendsRight.Configuration.ShrinkVertical = true;
            this.qcgFriendsRight.Configuration.StretchHorizontal = true;
            this.qcgFriendsRight.Configuration.StretchVertical = true;
            this.qcgFriendsRight.Items.Add(this.qcgFriendsHeaderRight);
            this.qcgFriendsRight.Items.Add(this.qcgCurrentOnlineFriends);
            // 
            // qcgFriendsHeaderRight
            // 
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgFriendsHeaderRight.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgFriendsHeaderRight.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qcgFriendsHeaderRight.Configuration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.RoundedContent);
            this.qcgFriendsHeaderRight.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgFriendsHeaderRight.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qcgFriendsHeaderRight.Configuration.ShrinkHorizontal = true;
            this.qcgFriendsHeaderRight.Configuration.StretchHorizontal = true;
            this.qcgFriendsHeaderRight.Items.Add(this.qctFriendsHeaderRight);
            this.qcgFriendsHeaderRight.Items.Add(this.qctFriendsDescription);
            // 
            // qctFriendsHeaderRight
            // 
            this.qctFriendsHeaderRight.ColorScheme.CompositeText.SetColor("Default", System.Drawing.Color.DarkGreen, false);
            this.qctFriendsHeaderRight.ColorScheme.CompositeText.SetColor("LunaBlue", System.Drawing.Color.DarkGreen, false);
            this.qctFriendsHeaderRight.ColorScheme.CompositeText.SetColor("LunaOlive", System.Drawing.Color.DarkGreen, false);
            this.qctFriendsHeaderRight.ColorScheme.CompositeText.SetColor("LunaSilver", System.Drawing.Color.DarkGreen, false);
            this.qctFriendsHeaderRight.ColorScheme.CompositeText.SetColor("VistaBlack", System.Drawing.Color.DarkGreen, false);
            this.qctFriendsHeaderRight.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 10F);
            this.qctFriendsHeaderRight.Title = "Xbox 360 Friends";
            // 
            // qctFriendsDescription
            // 
            this.qctFriendsDescription.Configuration.ShrinkHorizontal = true;
            this.qctFriendsDescription.Configuration.Visible = Qios.DevSuite.Components.QTristateBool.True;
            this.qctFriendsDescription.Configuration.WrapText = true;
            this.qctFriendsDescription.Title = "Here you can add, remove, invite or chat with friends. You see the friends that a" +
                "re currently online below.";
            // 
            // qcgCurrentOnlineFriends
            // 
            this.qcgCurrentOnlineFriends.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriends.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriends.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriends.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriends.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriends.Configuration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.RoundedContent);
            this.qcgCurrentOnlineFriends.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qcgCurrentOnlineFriends.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 5, 0, 0);
            this.qcgCurrentOnlineFriends.Configuration.ShrinkHorizontal = true;
            this.qcgCurrentOnlineFriends.Configuration.ShrinkVertical = true;
            this.qcgCurrentOnlineFriends.Configuration.StretchHorizontal = true;
            this.qcgCurrentOnlineFriends.Configuration.StretchVertical = true;
            this.qcgCurrentOnlineFriends.Items.Add(this.qcgCurrentOnlineFriendsHeader);
            this.qcgCurrentOnlineFriends.Items.Add(this.qcgCurrentOnlineFriendsContent);
            // 
            // qcgCurrentOnlineFriendsHeader
            // 
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsHeader.ColorScheme.CompositeGroupBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsHeader.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qcgCurrentOnlineFriendsHeader.Configuration.Margin = new Qios.DevSuite.Components.QMargin(-2, -2, 0, -2);
            this.qcgCurrentOnlineFriendsHeader.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 5, 5, 2);
            this.qcgCurrentOnlineFriendsHeader.Configuration.ShrinkHorizontal = true;
            this.qcgCurrentOnlineFriendsHeader.Configuration.StretchHorizontal = true;
            this.qcgCurrentOnlineFriendsHeader.Items.Add(this.qctCurrentOnlineFriends);
            // 
            // qctCurrentOnlineFriends
            // 
            this.qctCurrentOnlineFriends.ColorScheme.CompositeText.SetColor("Default", System.Drawing.Color.DarkGreen, false);
            this.qctCurrentOnlineFriends.ColorScheme.CompositeText.SetColor("LunaBlue", System.Drawing.Color.DarkGreen, false);
            this.qctCurrentOnlineFriends.ColorScheme.CompositeText.SetColor("LunaOlive", System.Drawing.Color.DarkGreen, false);
            this.qctCurrentOnlineFriends.ColorScheme.CompositeText.SetColor("LunaSilver", System.Drawing.Color.DarkGreen, false);
            this.qctCurrentOnlineFriends.ColorScheme.CompositeText.SetColor("VistaBlack", System.Drawing.Color.DarkGreen, false);
            this.qctCurrentOnlineFriends.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
            this.qctCurrentOnlineFriends.Title = "Currently online friends";
            // 
            // qcgCurrentOnlineFriendsContent
            // 
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.ColorScheme.CompositeScrollButtonDisabledBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qcgCurrentOnlineFriendsContent.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Flow;
            this.qcgCurrentOnlineFriendsContent.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
            this.qcgCurrentOnlineFriendsContent.Configuration.ShrinkHorizontal = true;
            this.qcgCurrentOnlineFriendsContent.Configuration.ShrinkVertical = true;
            this.qcgCurrentOnlineFriendsContent.Configuration.StretchHorizontal = true;
            this.qcgCurrentOnlineFriendsContent.Configuration.StretchVertical = true;
            this.qcgCurrentOnlineFriendsContent.Items.Add(this.qCompositeItem8);
            this.qcgCurrentOnlineFriendsContent.Items.Add(this.qCompositeItem1);
            this.qcgCurrentOnlineFriendsContent.Items.Add(this.qCompositeItem2);
            this.qcgCurrentOnlineFriendsContent.Items.Add(this.qCompositeItem3);
            this.qcgCurrentOnlineFriendsContent.Items.Add(this.qCompositeItem5);
            this.qcgCurrentOnlineFriendsContent.Items.Add(this.qCompositeItem6);
            // 
            // qCompositeItem8
            // 
            this.qCompositeItem8.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem8.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem8.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem8.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem8.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem8.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem8.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem8.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem8.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem8.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem8.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem8.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem8.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem8.Items.Add(this.qCompositeImage8);
            this.qCompositeItem8.Items.Add(this.qCompositeText8);
            // 
            // qCompositeImage8
            // 
            this.qCompositeImage8.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage8.Image")));
            // 
            // qCompositeText8
            // 
            this.qCompositeText8.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeText8.Title = "Cartman";
            // 
            // qCompositeItem1
            // 
            this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem1.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem1.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem1.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem1.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem1.Items.Add(this.qCompositeImage1);
            this.qCompositeItem1.Items.Add(this.qCompositeText1);
            // 
            // qCompositeImage1
            // 
            this.qCompositeImage1.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage1.Image")));
            // 
            // qCompositeText1
            // 
            this.qCompositeText1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeText1.Title = "Kenny";
            // 
            // qCompositeItem2
            // 
            this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem2.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem2.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem2.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem2.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem2.Items.Add(this.qCompositeImage2);
            this.qCompositeItem2.Items.Add(this.qCompositeText2);
            // 
            // qCompositeImage2
            // 
            this.qCompositeImage2.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage2.Image")));
            // 
            // qCompositeText2
            // 
            this.qCompositeText2.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeText2.Title = "Kyle";
            // 
            // qCompositeItem3
            // 
            this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem3.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem3.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem3.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem3.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem3.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem3.Items.Add(this.qCompositeImage3);
            this.qCompositeItem3.Items.Add(this.qCompositeText3);
            // 
            // qCompositeImage3
            // 
            this.qCompositeImage3.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage3.Image")));
            // 
            // qCompositeText3
            // 
            this.qCompositeText3.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeText3.Title = "Stan";
            // 
            // qCompositeItem5
            // 
            this.qCompositeItem5.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem5.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem5.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem5.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem5.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem5.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem5.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem5.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem5.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem5.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem5.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem5.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem5.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem5.Items.Add(this.qCompositeImage5);
            this.qCompositeItem5.Items.Add(this.qCompositeText5);
            // 
            // qCompositeImage5
            // 
            this.qCompositeImage5.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage5.Image")));
            // 
            // qCompositeText5
            // 
            this.qCompositeText5.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeText5.Title = "Butters";
            // 
            // qCompositeItem6
            // 
            this.qCompositeItem6.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem6.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem6.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem6.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem6.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem6.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem6.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem6.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem6.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem6.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem6.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem6.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem6.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem6.Items.Add(this.qCompositeImage6);
            this.qCompositeItem6.Items.Add(this.qCompositeText6);
            // 
            // qCompositeImage6
            // 
            this.qCompositeImage6.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage6.Image")));
            // 
            // qCompositeText6
            // 
            this.qCompositeText6.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qCompositeText6.Title = "Tweek";
            // 
            // xbPageQiosLive
            // 
            this.xbPageQiosLive.Title = "Qios Live";
            // 
            // xbPageDownloads
            // 
            this.xbPageDownloads.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.xbPageDownloads.Color2 = System.Drawing.Color.Red;
            this.xbPageDownloads.Title = "Downloads";
            // 
            // xbPageContent
            // 
            this.xbPageContent.Color1 = System.Drawing.Color.Cornsilk;
            this.xbPageContent.Color2 = System.Drawing.Color.Gold;
            this.xbPageContent.Title = "Content";
            // 
            // xbPageSettings
            // 
            this.xbPageSettings.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(196)))), ((int)(((byte)(255)))));
            this.xbPageSettings.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(78)))), ((int)(((byte)(198)))));
            this.xbPageSettings.Title = "Settings";
            // 
            // qMarkupLabel1
            // 
            this.qMarkupLabel1.Appearance.ShowBorders = true;
            this.qMarkupLabel1.ColorScheme.MarkupLabelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qMarkupLabel1.ColorScheme.MarkupLabelBackground2.ColorReference = "@RibbonPanelBackground2";
            this.qMarkupLabel1.ColorScheme.MarkupLabelBorder.ColorReference = "@RibbonPanelBorder";
            this.qMarkupLabel1.Configuration.BiggerSmallerStep = 1;
            this.qMarkupLabel1.Configuration.MarkupPadding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
            qMarkupTextStyle1.DefaultTag = "H1";
            qMarkupTextStyle1.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 12F);
            qMarkupTextStyle1.NewLineAfter = true;
            qMarkupTextStyle1.TextColorProperty = "RibbonTabButtonActiveText";
            this.qMarkupLabel1.CustomStyles.Add(qMarkupTextStyle1);
            this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.qMarkupLabel1.Location = new System.Drawing.Point(5, 5);
            this.qMarkupLabel1.MarkupText = resources.GetString("qMarkupLabel1.MarkupText");
            this.qMarkupLabel1.Name = "qMarkupLabel1";
            this.qMarkupLabel1.Size = new System.Drawing.Size(688, 95);
            this.qMarkupLabel1.TabIndex = 2;
            // 
            // qCompositeItem4
            // 
            this.qCompositeItem4.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem4.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem4.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem4.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem4.ColorScheme.CompositeItemBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qCompositeItem4.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.Green, false);
            this.qCompositeItem4.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.Green, false);
            this.qCompositeItem4.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.Green, false);
            this.qCompositeItem4.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.Green, false);
            this.qCompositeItem4.ColorScheme.CompositeItemBorder.SetColor("VistaBlack", System.Drawing.Color.Green, false);
            this.qCompositeItem4.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qCompositeItem4.Configuration.Margin = new Qios.DevSuite.Components.QMargin(2, 2, 2, 2);
            this.qCompositeItem4.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qCompositeItem4.Items.Add(this.qCompositeImage4);
            this.qCompositeItem4.Items.Add(this.qCompositeText4);
            // 
            // qCompositeImage4
            // 
            this.qCompositeImage4.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage4.Image")));
            // 
            // qCompositeText4
            // 
            this.qCompositeText4.Title = "Donald";
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(698, 466);
            this.Controls.Add(this.qPanel1);
            this.Controls.Add(this.qrcCaption);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.Text = "Xbox 360 Sample - Qios.DevSuite.DemoZone ";
            ((System.ComponentModel.ISupportInitialize)(this.qrcCaption)).EndInit();
            this.qPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xBox360Dash1)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		private void xBox360Dash1_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

	}
}
