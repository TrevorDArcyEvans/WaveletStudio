using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	public class QdwProperties : QDockingWindow
	{
		public class QPropertyObject
		{
			public object ObjectInstance;
			public string Text;

			public QPropertyObject(object oObject, string sText)
			{
				this.ObjectInstance = oObject;
				this.Text = sText;
			}

			public override string ToString()
			{
				return this.Text;
			}
		}

		public class QdwPropertiesEventArgs : EventArgs
		{
			public ArrayList PropertyObjects;

			public QdwPropertiesEventArgs(ArrayList aPropertyObjects)
			{
				PropertyObjects = aPropertyObjects;
			}
		}

		public delegate void QdwPropertiesEventHandler(object sender, QdwPropertiesEventArgs e);

		private ArrayList m_aPropertyObjects = null;

		private PropertyGrid propertyGrid1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.ComboBox cbObjectSelector;

		public event QdwPropertiesEventHandler ObjectsRequested;

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QdwProperties()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			this.SetColors();

		}

		public PropertyGrid Grid
		{
			get { return this.propertyGrid1; }
		}

		public void SetGridObject(object objectToSelect)
		{
			//Retrieve the available objects via the ObjectsRequested event
			m_aPropertyObjects = new ArrayList();
			QdwPropertiesEventArgs tmp_oArgs = new QdwPropertiesEventArgs(m_aPropertyObjects);
			this.OnObjectsRequested(tmp_oArgs);

			//Fill the ComboBox with the objects and fine the objectToSelect in the received array.
			this.cbObjectSelector.Items.Clear();
			QPropertyObject tmp_oObjectToSelect = null;
			for (int i = 0; i < this.m_aPropertyObjects.Count; i++)
			{
				QPropertyObject tmp_oCurrentObject = (QPropertyObject)this.m_aPropertyObjects[i];
				//If the objectToSelect equals the CurrentObject, set it
				if (tmp_oCurrentObject.ObjectInstance == objectToSelect)
				{
					tmp_oObjectToSelect = tmp_oCurrentObject;
				}
				//Add it to the ComboBox
				this.cbObjectSelector.Items.Add(tmp_oCurrentObject);
			}

			//If there is a selected object, set it.
			if (tmp_oObjectToSelect != null)
			{
				this.Grid.SelectedObject = tmp_oObjectToSelect.ObjectInstance;
				this.cbObjectSelector.SelectedItem = tmp_oObjectToSelect;
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QdwProperties));
            this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbObjectSelector = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // propertyGrid1
            // 
            this.propertyGrid1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.propertyGrid1.CommandsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.propertyGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGrid1.HelpBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.propertyGrid1.LineColor = System.Drawing.SystemColors.ScrollBar;
            this.propertyGrid1.Location = new System.Drawing.Point(5, 32);
            this.propertyGrid1.Name = "propertyGrid1";
            this.propertyGrid1.Size = new System.Drawing.Size(297, 317);
            this.propertyGrid1.TabIndex = 0;
            this.propertyGrid1.ViewBackColor = System.Drawing.Color.White;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.cbObjectSelector);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(297, 27);
            this.panel1.TabIndex = 1;
            // 
            // cbObjectSelector
            // 
            this.cbObjectSelector.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbObjectSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbObjectSelector.Location = new System.Drawing.Point(0, 0);
            this.cbObjectSelector.Name = "cbObjectSelector";
            this.cbObjectSelector.Size = new System.Drawing.Size(297, 23);
            this.cbObjectSelector.TabIndex = 0;
            this.cbObjectSelector.DropDown += new System.EventHandler(this.cbObjectSelector_DropDown);
            this.cbObjectSelector.SelectedIndexChanged += new System.EventHandler(this.cbObjectSelector_SelectedIndexChanged);
            // 
            // QdwProperties
            // 
            this.Controls.Add(this.propertyGrid1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumClientSize = new System.Drawing.Size(150, 150);
            this.Name = "QdwProperties";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.PersistGuid = new System.Guid("16829bc3-9f32-4429-a564-6fb0461fe07d");
            this.Size = new System.Drawing.Size(307, 372);
            this.Text = "Properties";
            this.ColorsChanged += new System.EventHandler(this.QdwGlobalColorScheme_ColorsChanged);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		protected virtual void OnObjectsRequested(QdwPropertiesEventArgs e)
		{
			if (this.ObjectsRequested != null)
			{
				this.ObjectsRequested(this, e);
			}
		}

		private void SetColors()
		{
			this.propertyGrid1.BackColor = this.BackColor2;
			this.propertyGrid1.HelpBackColor = this.BackColor2;
		}

		private void QdwGlobalColorScheme_ColorsChanged(object sender, System.EventArgs e)
		{
			SetColors();
		}

		private void cbObjectSelector_DropDown(object sender, System.EventArgs e)
		{

			//Check if the ComboBox had an object selected.
			object tmp_oObjectToSelect = null;
			if (this.cbObjectSelector.SelectedItem != null)
			{
				tmp_oObjectToSelect = ((QPropertyObject)this.cbObjectSelector.SelectedItem).ObjectInstance;
			}

			//Call the SetGridObject with the object selected or null, so that the ComboBox is refilled
			this.SetGridObject(tmp_oObjectToSelect);
		}

		private void cbObjectSelector_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.propertyGrid1.SelectedObject = ((QPropertyObject)cbObjectSelector.SelectedItem).ObjectInstance;
		}
	}
}
