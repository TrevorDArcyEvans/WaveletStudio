using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Reflection;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	/// <summary>
	/// Summary description for FrmWelcome.
	/// </summary>
	public class FrmWelcome : System.Windows.Forms.Form
	{
		private string m_sLastTheme = null;

		private Qios.DevSuite.Components.QPanel qPanel3;
		private Qios.DevSuite.Components.QContextMenu qcmContextMenu;
		private Qios.DevSuite.Components.QMenuItem qmiCut;
		private Qios.DevSuite.Components.QMenuItem qmiCopy;
		private Qios.DevSuite.Components.QMenuItem qmiPaste;
		private Qios.DevSuite.Components.QMenuItem qmiSelectAll;
		private Qios.DevSuite.Components.QExplorerBar qExplorerBar1;
		private System.Windows.Forms.Splitter splVertical;
		private Qios.DevSuite.Components.QExplorerItem qeiFileFolderTasks;
		private Qios.DevSuite.Components.QExplorerItem qeiOtherPlaces;
		private Qios.DevSuite.Components.QExplorerItem qeiDetails;
		private Qios.DevSuite.Components.QExplorerItem qeiPictureTasks;
		private Qios.DevSuite.Components.QExplorerItem qeiViewSlideShow;
		private Qios.DevSuite.Components.QExplorerItem qeiOrderPrintsOnline;
		private Qios.DevSuite.Components.QExplorerItem qeiPrintPictures;
		private Qios.DevSuite.Components.QExplorerItem qeiCopyToCD;
		private Qios.DevSuite.Components.QExplorerItem qeiRenameFile;
		private Qios.DevSuite.Components.QExplorerItem qeiMoveFile;
		private Qios.DevSuite.Components.QExplorerItem qeiCopyFile;
		private Qios.DevSuite.Components.QExplorerItem qeiPublishFile;
		private Qios.DevSuite.Components.QExplorerItem qeiDeleteFile;
		private Qios.DevSuite.Components.QExplorerItem qeiMyDocuments;
		private Qios.DevSuite.Components.QExplorerItem qeiMyComputer;
		private Qios.DevSuite.Components.QExplorerItem qeiMyNetworkPlaces;
		private Qios.DevSuite.Components.QExplorerItem qeiClient1;
		private Qios.DevSuite.Components.QExplorerItem qeiClient2;
		private Qios.DevSuite.Components.QExplorerItem qeiClient3;
		private Qios.DevSuite.Components.QExplorerItem qeiDetailsItem;
		private Qios.DevSuite.Components.QCommandControlContainer qCommandControlContainer1;
		private Qios.DevSuite.Components.QTabControl qtcWelcome;
		private Qios.DevSuite.Components.QTabPage qtpWelcome;
		private Qios.DevSuite.Components.QTabPage qtpCopyToCD;
		private Qios.DevSuite.Components.QTabPage qtpSlideShow;
		private Qios.DevSuite.Components.QTabPage qtpOrderPrints;
		private Qios.DevSuite.Components.QTabPage qtpPrintPictures;
		private Qios.DevSuite.Components.QTabPage qtpMyComputer;
		private Qios.DevSuite.Components.QTabPage qtpMyDocuments;
		private Qios.DevSuite.Components.QTabPage qtpMyNetworkPlaces;
		private Qios.DevSuite.Components.QTabPage qtp1;
		private Qios.DevSuite.Components.QTabPage qtp2;
		private Qios.DevSuite.Components.QTabPage qtp3;
		private Qios.DevSuite.Components.QTabPage qtp4;
		private Qios.DevSuite.Components.QTabPage qtp5;
		private Qios.DevSuite.Components.QTabPage qtp6;
		private Qios.DevSuite.Components.QTabPage qtp7;
		private Qios.DevSuite.Components.QTabPage qtp8;
		private Qios.DevSuite.Components.QTabPage qtp9;
		private Qios.DevSuite.Components.QTabPage qtp10;
		private Qios.DevSuite.Components.QMarkupLabel qmlMarkupLabel;
		private Qios.DevSuite.Components.QShape qsCustomShape;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		private Qios.DevSuite.Components.QPanel qPanel1;
        private QExplorerItem qExplorerItem1;
		private System.ComponentModel.IContainer components;

		public FrmWelcome()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// make sure the splitter is between the tabcontrol and the explorer bar
			this.qExplorerBar1.SendToBack();

			qtpSlideShow.Paint += new PaintEventHandler(QTabPage_Paint);
			qtpOrderPrints.Paint += new PaintEventHandler(QTabPage_Paint);
			qtpPrintPictures.Paint += new PaintEventHandler(QTabPage_Paint);
			qtpCopyToCD.Paint += new PaintEventHandler(QTabPage_Paint);

			qtpMyComputer.Paint += new PaintEventHandler(QTabPage_Paint);
			qtpMyDocuments.Paint += new PaintEventHandler(QTabPage_Paint);
			qtpMyNetworkPlaces.Paint += new PaintEventHandler(QTabPage_Paint);
			
			SetSpecialGroup();
		}

		/// <summary>
		/// Set the special group colors to the specified theme
		/// </summary>
		private void SetSpecialGroup()
		{
			if (QColorScheme.Global.CurrentTheme == m_sLastTheme) return;

			m_sLastTheme = QColorScheme.Global.CurrentTheme;
			
			
			qeiPictureTasks.Configuration.HasChildItemsMask = Image.FromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Images.ExplorerBarHasChildItemsDarkMask.png"));
			qeiPictureTasks.Configuration.HasChildItemsMaskReverse = Image.FromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Images.ExplorerBarHasChildItemsDarkMaskReverse.png"));
			
			switch (QColorScheme.Global.CurrentTheme)
			{
				case "LunaBlue":
					qeiPictureTasks.ColorScheme.ExplorerBarExpandedGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(0, 73, 181));
					qeiPictureTasks.ColorScheme.ExplorerBarExpandedGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(41, 93, 206));
					qeiPictureTasks.ColorScheme.ExplorerBarGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(0, 73, 181));
					qeiPictureTasks.ColorScheme.ExplorerBarGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(41, 93, 206));
					qeiPictureTasks.ColorScheme.ExplorerBarHotGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(0, 73, 181));
					qeiPictureTasks.ColorScheme.ExplorerBarHotGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(41, 93, 206));
					qeiPictureTasks.ColorScheme.ExplorerBarPressedGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(0, 73, 181));
					qeiPictureTasks.ColorScheme.ExplorerBarPressedGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(41, 93, 206));
					qeiPictureTasks.ColorScheme.ExplorerBarHasMoreChildItemsColor.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(41, 93, 206));
					qeiPictureTasks.ColorScheme.ExplorerBarTextHot.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(239,243, 255));
					qeiPictureTasks.ColorScheme.ExplorerBarTextPressed.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(239,243, 255));
					break;
				case "LunaSilver":
					qeiPictureTasks.ColorScheme.ExplorerBarExpandedGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 119, 146));
					qeiPictureTasks.ColorScheme.ExplorerBarExpandedGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(180, 182, 199));
					qeiPictureTasks.ColorScheme.ExplorerBarGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 119, 146));
					qeiPictureTasks.ColorScheme.ExplorerBarGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(180, 182, 199));
					qeiPictureTasks.ColorScheme.ExplorerBarHotGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 119, 146));
					qeiPictureTasks.ColorScheme.ExplorerBarHotGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(180, 182, 199));
					qeiPictureTasks.ColorScheme.ExplorerBarPressedGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 119, 146));
					qeiPictureTasks.ColorScheme.ExplorerBarPressedGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(180, 182, 199));
					qeiPictureTasks.ColorScheme.ExplorerBarHasMoreChildItemsColor.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(180, 182, 199));
					qeiPictureTasks.ColorScheme.ExplorerBarTextHot.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(240,241, 245));
					qeiPictureTasks.ColorScheme.ExplorerBarTextPressed.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(240,241, 245));
					break;
				case "LunaOlive":
					qeiPictureTasks.ColorScheme.ExplorerBarExpandedGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 140, 64));
					qeiPictureTasks.ColorScheme.ExplorerBarExpandedGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(150, 168, 103));
					qeiPictureTasks.ColorScheme.ExplorerBarGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 140, 64));
					qeiPictureTasks.ColorScheme.ExplorerBarGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(150, 168, 103));
					qeiPictureTasks.ColorScheme.ExplorerBarHotGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 140, 64));
					qeiPictureTasks.ColorScheme.ExplorerBarHotGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(150, 168, 103));
					qeiPictureTasks.ColorScheme.ExplorerBarPressedGroupItemBackground1.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(119, 140, 64));
					qeiPictureTasks.ColorScheme.ExplorerBarPressedGroupItemBackground2.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(150, 168, 103));
					qeiPictureTasks.ColorScheme.ExplorerBarHasMoreChildItemsColor.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(150, 168, 103));
					qeiPictureTasks.ColorScheme.ExplorerBarTextHot.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(246,246, 236));
					qeiPictureTasks.ColorScheme.ExplorerBarTextPressed.SetColor(QColorScheme.Global.CurrentTheme, Color.FromArgb(246,246, 236));
					break;
		
				default:
					return;

			}

			qeiPictureTasks.ColorScheme.ExplorerBarText.SetColor(QColorScheme.Global.CurrentTheme, Color.White);
			qeiPictureTasks.ColorScheme.ExplorerBarTextExpanded.SetColor(QColorScheme.Global.CurrentTheme, Color.White);
		}

		/// <summary>
		/// Gets the explorer bar
		/// </summary>
		public QExplorerBar ExplorerBar
		{
			get
			{
				return this.qExplorerBar1;
			}
		}

		/// <summary>
		/// Gets the tabcontrol
		/// </summary>
		public QTabControl TabControl
		{
			get
			{
				return this.qtcWelcome;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmWelcome));
            Qios.DevSuite.Components.QMarkupTextStyle qMarkupTextStyle1 = new Qios.DevSuite.Components.QMarkupTextStyle();
            Qios.DevSuite.Components.QMarkupTextStyle qMarkupTextStyle2 = new Qios.DevSuite.Components.QMarkupTextStyle();
            this.qPanel3 = new Qios.DevSuite.Components.QPanel();
            this.qcmContextMenu = new Qios.DevSuite.Components.QContextMenu(this.components);
            this.qmiCut = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiCopy = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiPaste = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiSelectAll = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qExplorerBar1 = new Qios.DevSuite.Components.QExplorerBar();
            this.qCommandControlContainer1 = new Qios.DevSuite.Components.QCommandControlContainer();
            this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
            this.qeiPictureTasks = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiViewSlideShow = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiOrderPrintsOnline = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiPrintPictures = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiCopyToCD = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiFileFolderTasks = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiRenameFile = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiMoveFile = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiCopyFile = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiPublishFile = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiDeleteFile = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiOtherPlaces = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiMyDocuments = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiMyComputer = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiMyNetworkPlaces = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiClient1 = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiClient2 = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiClient3 = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiDetails = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qeiDetailsItem = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.splVertical = new System.Windows.Forms.Splitter();
            this.qtcWelcome = new Qios.DevSuite.Components.QTabControl();
            this.qtpWelcome = new Qios.DevSuite.Components.QTabPage();
            this.qPanel1 = new Qios.DevSuite.Components.QPanel();
            this.qmlMarkupLabel = new Qios.DevSuite.Components.QMarkupLabel();
            this.qtpSlideShow = new Qios.DevSuite.Components.QTabPage();
            this.qtpCopyToCD = new Qios.DevSuite.Components.QTabPage();
            this.qtp2 = new Qios.DevSuite.Components.QTabPage();
            this.qtp1 = new Qios.DevSuite.Components.QTabPage();
            this.qtpOrderPrints = new Qios.DevSuite.Components.QTabPage();
            this.qtpPrintPictures = new Qios.DevSuite.Components.QTabPage();
            this.qtpMyDocuments = new Qios.DevSuite.Components.QTabPage();
            this.qtpMyComputer = new Qios.DevSuite.Components.QTabPage();
            this.qtpMyNetworkPlaces = new Qios.DevSuite.Components.QTabPage();
            this.qtp3 = new Qios.DevSuite.Components.QTabPage();
            this.qtp4 = new Qios.DevSuite.Components.QTabPage();
            this.qtp5 = new Qios.DevSuite.Components.QTabPage();
            this.qtp6 = new Qios.DevSuite.Components.QTabPage();
            this.qtp7 = new Qios.DevSuite.Components.QTabPage();
            this.qtp8 = new Qios.DevSuite.Components.QTabPage();
            this.qtp9 = new Qios.DevSuite.Components.QTabPage();
            this.qtp10 = new Qios.DevSuite.Components.QTabPage();
            this.qsCustomShape = new Qios.DevSuite.Components.QShape();
            this.qExplorerItem1 = new Qios.DevSuite.Components.QExplorerItem(this.components);
            this.qExplorerBar1.SuspendLayout();
            this.qCommandControlContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtcWelcome)).BeginInit();
            this.qtcWelcome.SuspendLayout();
            this.qtpWelcome.SuspendLayout();
            this.qPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // qPanel3
            // 
            this.qPanel3.Location = new System.Drawing.Point(0, 0);
            this.qPanel3.Name = "qPanel3";
            this.qPanel3.Size = new System.Drawing.Size(0, 0);
            this.qPanel3.TabIndex = 0;
            // 
            // qcmContextMenu
            // 
            this.qcmContextMenu.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiCut,
            this.qmiCopy,
            this.qmiPaste,
            this.qmiSelectAll});
            this.qcmContextMenu.MenuItemSelected += new Qios.DevSuite.Components.QMenuEventHandler(this.qcmContextMenu_MenuItemSelected);
            // 
            // qmiCut
            // 
            this.qmiCut.Title = "Cut";
            this.qmiCut.ToolTip = "Cut";
            // 
            // qmiCopy
            // 
            this.qmiCopy.Title = "Copy";
            this.qmiCopy.ToolTip = "Copy";
            // 
            // qmiPaste
            // 
            this.qmiPaste.Title = "Paste";
            this.qmiPaste.ToolTip = "Paste";
            // 
            // qmiSelectAll
            // 
            this.qmiSelectAll.Title = "Select all";
            this.qmiSelectAll.ToolTip = "Select all";
            // 
            // qExplorerBar1
            // 
            this.qExplorerBar1.Appearance.ShowBorderBottom = false;
            this.qExplorerBar1.Appearance.ShowBorderLeft = false;
            this.qExplorerBar1.Appearance.ShowBorderTop = false;
            this.qExplorerBar1.Controls.Add(this.qCommandControlContainer1);
            this.qExplorerBar1.Dock = System.Windows.Forms.DockStyle.Left;
            this.qExplorerBar1.ExplorerItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qeiPictureTasks,
            this.qeiFileFolderTasks,
            this.qeiOtherPlaces,
            this.qeiDetails});
            this.qExplorerBar1.Location = new System.Drawing.Point(3, 0);
            this.qExplorerBar1.Name = "qExplorerBar1";
            this.qExplorerBar1.PersistGuid = new System.Guid("a80647c5-9482-4599-bbca-51bb0c0b493a");
            this.qExplorerBar1.Size = new System.Drawing.Size(203, 454);
            this.qExplorerBar1.TabIndex = 1;
            this.qExplorerBar1.Text = "qExplorerBar1";
            this.qExplorerBar1.ToolTipConfiguration.BalloonWindowClassReference = "Qios.DevSuite.DemoZone.Samples.TestLab.QbCustomBalloonWindow, Qios.DevSuite.DemoZ" +
                "one";
            this.qExplorerBar1.ToolTipConfiguration.ColorSchemeSource = Qios.DevSuite.Components.QBalloonWindowPropertySource.QBalloonWindow;
            this.qExplorerBar1.ToolTipConfiguration.Enabled = true;
            this.qExplorerBar1.ToolTipConfiguration.FontSource = Qios.DevSuite.Components.QBalloonWindowPropertySource.QBalloonWindow;
            this.qExplorerBar1.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.qExplorerBar1_MenuItemActivated);
            this.qExplorerBar1.ColorsChanged += new System.EventHandler(this.qExplorerBar1_ColorsChanged);
            // 
            // qCommandControlContainer1
            // 
            this.qCommandControlContainer1.Controls.Add(this.qMarkupLabel1);
            this.qCommandControlContainer1.Name = "qCommandControlContainer1";
            this.qCommandControlContainer1.PreferredSize = new System.Drawing.Size(151, 93);
            this.qCommandControlContainer1.Size = new System.Drawing.Size(151, 93);
            this.qCommandControlContainer1.TabIndex = 0;
            // 
            // qMarkupLabel1
            // 
            this.qMarkupLabel1.Configuration.MarkupPadding = new Qios.DevSuite.Components.QPadding(5, 5, 0, 0);
            this.qMarkupLabel1.Configuration.WrapText = false;
            this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qMarkupLabel1.Location = new System.Drawing.Point(0, 0);
            this.qMarkupLabel1.MarkupText = "<b>ExplorerBar</b><br /><br />File Folder<br /><br />Date Modified: Monday 5<br /" +
                ">december 2005, 10:39";
            this.qMarkupLabel1.Name = "qMarkupLabel1";
            this.qMarkupLabel1.Size = new System.Drawing.Size(151, 95);
            this.qMarkupLabel1.TabIndex = 0;
            // 
            // qeiPictureTasks
            // 
            this.qeiPictureTasks.GroupPanelBackgroundImage = ((System.Drawing.Image)(resources.GetObject("qeiPictureTasks.GroupPanelBackgroundImage")));
            this.qeiPictureTasks.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiPictureTasks.Icon")));
            this.qeiPictureTasks.ItemName = "qeiPictureTasks";
            this.qeiPictureTasks.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qeiViewSlideShow,
            this.qeiOrderPrintsOnline,
            this.qeiPrintPictures,
            this.qeiCopyToCD});
            this.qeiPictureTasks.Title = "&Picture Tasks";
            this.qeiPictureTasks.ToolTip = "Picture Tasks";
            // 
            // qeiViewSlideShow
            // 
            this.qeiViewSlideShow.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiViewSlideShow.Icon")));
            this.qeiViewSlideShow.ItemName = "qeiViewSlideShow";
            this.qeiViewSlideShow.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qExplorerItem1});
            this.qeiViewSlideShow.Title = "View as a slide show";
            this.qeiViewSlideShow.ToolTip = "View as a slide show";
            // 
            // qeiOrderPrintsOnline
            // 
            this.qeiOrderPrintsOnline.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiOrderPrintsOnline.Icon")));
            this.qeiOrderPrintsOnline.ItemName = "qeiOrderPrintsOnline";
            this.qeiOrderPrintsOnline.Title = "Order prints online";
            this.qeiOrderPrintsOnline.ToolTip = "Order prints online";
            // 
            // qeiPrintPictures
            // 
            this.qeiPrintPictures.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiPrintPictures.Icon")));
            this.qeiPrintPictures.ItemName = "qeiPrintPictures";
            this.qeiPrintPictures.Title = "Print pictures";
            this.qeiPrintPictures.ToolTip = "Print pictures";
            // 
            // qeiCopyToCD
            // 
            this.qeiCopyToCD.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiCopyToCD.Icon")));
            this.qeiCopyToCD.ItemName = "qeiCopyToCD";
            this.qeiCopyToCD.Title = "Copy all items to CD";
            this.qeiCopyToCD.ToolTip = "Copy all items to CD";
            // 
            // qeiFileFolderTasks
            // 
            this.qeiFileFolderTasks.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiFileFolderTasks.Icon")));
            this.qeiFileFolderTasks.ItemName = "qeiFileFolderTasks";
            this.qeiFileFolderTasks.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qeiRenameFile,
            this.qeiMoveFile,
            this.qeiCopyFile,
            this.qeiPublishFile,
            this.qeiDeleteFile});
            this.qeiFileFolderTasks.Title = "&File and Folder Tasks";
            this.qeiFileFolderTasks.ToolTip = "File and Folder Tasks";
            // 
            // qeiRenameFile
            // 
            this.qeiRenameFile.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiRenameFile.Icon")));
            this.qeiRenameFile.ItemName = "qeiRenameFile";
            this.qeiRenameFile.Title = "Rename this file";
            this.qeiRenameFile.ToolTip = "Rename this file";
            // 
            // qeiMoveFile
            // 
            this.qeiMoveFile.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiMoveFile.Icon")));
            this.qeiMoveFile.ItemName = "qeiMoveFile";
            this.qeiMoveFile.Title = "Move this file";
            this.qeiMoveFile.ToolTip = "Move this file";
            // 
            // qeiCopyFile
            // 
            this.qeiCopyFile.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiCopyFile.Icon")));
            this.qeiCopyFile.ItemName = "qeiCopyFile";
            this.qeiCopyFile.Title = "Copy this file";
            this.qeiCopyFile.ToolTip = "Copy this file";
            // 
            // qeiPublishFile
            // 
            this.qeiPublishFile.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiPublishFile.Icon")));
            this.qeiPublishFile.ItemName = "qeiPublishFile";
            this.qeiPublishFile.Title = "Publish this file to the web";
            this.qeiPublishFile.ToolTip = "Publish this file to the web";
            // 
            // qeiDeleteFile
            // 
            this.qeiDeleteFile.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiDeleteFile.Icon")));
            this.qeiDeleteFile.ItemName = "qeiDeleteFile";
            this.qeiDeleteFile.Title = "Delete this file";
            this.qeiDeleteFile.ToolTip = "Delete this file";
            // 
            // qeiOtherPlaces
            // 
            this.qeiOtherPlaces.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiOtherPlaces.Icon")));
            this.qeiOtherPlaces.ItemName = "qeiOtherPlaces";
            this.qeiOtherPlaces.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qeiMyDocuments,
            this.qeiMyComputer,
            this.qeiMyNetworkPlaces});
            this.qeiOtherPlaces.Title = "&Other Places";
            this.qeiOtherPlaces.ToolTip = resources.GetString("qeiOtherPlaces.ToolTip");
            // 
            // qeiMyDocuments
            // 
            this.qeiMyDocuments.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiMyDocuments.Icon")));
            this.qeiMyDocuments.ItemName = "qeiMyDocuments";
            this.qeiMyDocuments.Title = "My Documents";
            this.qeiMyDocuments.ToolTip = "My Documents";
            // 
            // qeiMyComputer
            // 
            this.qeiMyComputer.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiMyComputer.Icon")));
            this.qeiMyComputer.ItemName = "qeiMyComputer";
            this.qeiMyComputer.Title = "My Computer";
            this.qeiMyComputer.ToolTip = "My Computer";
            // 
            // qeiMyNetworkPlaces
            // 
            this.qeiMyNetworkPlaces.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiMyNetworkPlaces.Icon")));
            this.qeiMyNetworkPlaces.ItemName = "qeiMyNetworkPlaces";
            this.qeiMyNetworkPlaces.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qeiClient1,
            this.qeiClient2,
            this.qeiClient3});
            this.qeiMyNetworkPlaces.Title = "My Network Places";
            this.qeiMyNetworkPlaces.ToolTip = "My Network Places";
            // 
            // qeiClient1
            // 
            this.qeiClient1.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiClient1.Icon")));
            this.qeiClient1.ItemName = "qeiClient1";
            this.qeiClient1.Title = "Client 1";
            this.qeiClient1.ToolTip = "Client 1";
            // 
            // qeiClient2
            // 
            this.qeiClient2.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiClient2.Icon")));
            this.qeiClient2.ItemName = "qeiClient2";
            this.qeiClient2.Title = "Client 2";
            this.qeiClient2.ToolTip = "Client 2";
            // 
            // qeiClient3
            // 
            this.qeiClient3.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiClient3.Icon")));
            this.qeiClient3.ItemName = "qeiClient3";
            this.qeiClient3.Title = "Client 3";
            this.qeiClient3.ToolTip = "Client 3";
            // 
            // qeiDetails
            // 
            this.qeiDetails.Icon = ((System.Drawing.Icon)(resources.GetObject("qeiDetails.Icon")));
            this.qeiDetails.ItemName = "qeiDetails";
            this.qeiDetails.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qeiDetailsItem});
            this.qeiDetails.Title = "&Details";
            this.qeiDetails.ToolTip = "Details";
            // 
            // qeiDetailsItem
            // 
            this.qeiDetailsItem.Control = this.qCommandControlContainer1;
            this.qeiDetailsItem.ItemName = "qeiDetailsItem";
            // 
            // splVertical
            // 
            this.splVertical.BackColor = System.Drawing.Color.Navy;
            this.splVertical.Location = new System.Drawing.Point(0, 0);
            this.splVertical.Name = "splVertical";
            this.splVertical.Size = new System.Drawing.Size(3, 454);
            this.splVertical.TabIndex = 3;
            this.splVertical.TabStop = false;
            // 
            // qtcWelcome
            // 
            this.qtcWelcome.ActiveTabPage = this.qtpWelcome;
            this.qtcWelcome.AllowDrag = true;
            this.qtcWelcome.AllowDrop = true;
            this.qtcWelcome.Appearance.ShowBorders = false;
            this.qtcWelcome.Controls.Add(this.qtpWelcome);
            this.qtcWelcome.Controls.Add(this.qtpSlideShow);
            this.qtcWelcome.Controls.Add(this.qtpCopyToCD);
            this.qtcWelcome.Controls.Add(this.qtp2);
            this.qtcWelcome.Controls.Add(this.qtp1);
            this.qtcWelcome.Controls.Add(this.qtpOrderPrints);
            this.qtcWelcome.Controls.Add(this.qtpPrintPictures);
            this.qtcWelcome.Controls.Add(this.qtpMyDocuments);
            this.qtcWelcome.Controls.Add(this.qtpMyComputer);
            this.qtcWelcome.Controls.Add(this.qtpMyNetworkPlaces);
            this.qtcWelcome.Controls.Add(this.qtp3);
            this.qtcWelcome.Controls.Add(this.qtp4);
            this.qtcWelcome.Controls.Add(this.qtp5);
            this.qtcWelcome.Controls.Add(this.qtp6);
            this.qtcWelcome.Controls.Add(this.qtp7);
            this.qtcWelcome.Controls.Add(this.qtp8);
            this.qtcWelcome.Controls.Add(this.qtp9);
            this.qtcWelcome.Controls.Add(this.qtp10);
            this.qtcWelcome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qtcWelcome.Location = new System.Drawing.Point(206, 0);
            this.qtcWelcome.Name = "qtcWelcome";
            this.qtcWelcome.PersistGuid = new System.Guid("3e36b006-20e2-46b5-b73c-f6f0c45383b8");
            this.qtcWelcome.Size = new System.Drawing.Size(546, 454);
            this.qtcWelcome.TabIndex = 4;
            this.qtcWelcome.TabStripLeftConfiguration.ButtonConfiguration.Appearance.Shape = this.qsCustomShape;
            this.qtcWelcome.TabStripLeftConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
            this.qtcWelcome.TabStripLeftConfiguration.ButtonConfiguration.MinimumSize = new System.Drawing.Size(35, -1);
            this.qtcWelcome.TabStripLeftConfiguration.ButtonConfiguration.TextAlignment = System.Drawing.ContentAlignment.MiddleRight;
            this.qtcWelcome.TabStripLeftConfiguration.ButtonSpacing = -5;
            this.qtcWelcome.TabStripRightConfiguration.ButtonConfiguration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.MSOneNoteTab);
            this.qtcWelcome.TabStripRightConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
            this.qtcWelcome.TabStripRightConfiguration.ButtonConfiguration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalDown;
            this.qtcWelcome.TabStripTopConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
            this.qtcWelcome.Text = "qTabControl1";
            this.qtcWelcome.ToolTipConfiguration.BalloonWindowAppearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.RoundedRectangleShapedWindow);
            // 
            // qtpWelcome
            // 
            this.qtpWelcome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qtpWelcome.BackgroundImage")));
            this.qtpWelcome.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomMiddle;
            this.qtpWelcome.BackgroundImageOffset = new System.Drawing.Point(0, -10);
            this.qtpWelcome.ButtonOrder = 0;
            this.qtpWelcome.Controls.Add(this.qPanel1);
            this.qtpWelcome.Location = new System.Drawing.Point(41, 30);
            this.qtpWelcome.Name = "qtpWelcome";
            this.qtpWelcome.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.qtpWelcome.PersistGuid = new System.Guid("aeb7c3bc-deb3-4f8c-bf01-56c99614c590");
            this.qtpWelcome.Size = new System.Drawing.Size(476, 424);
            this.qtpWelcome.Text = "Welcome";
            // 
            // qPanel1
            // 
            this.qPanel1.Appearance.GradientAngle = -90;
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(199)))), ((int)(((byte)(251))))), false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(196))))), false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(249))))), false);
            this.qPanel1.ColorScheme.PanelBorder.SetColor("LunaBlue", System.Drawing.Color.DarkBlue, false);
            this.qPanel1.ColorScheme.TextColor.SetColor("LunaBlue", System.Drawing.Color.DarkBlue, false);
            this.qPanel1.ColorScheme.TextColor.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(141)))), ((int)(((byte)(94))))), false);
            this.qPanel1.ColorScheme.TextColor.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(157)))), ((int)(((byte)(169))))), false);
            this.qPanel1.Configuration.ShowText = true;
            this.qPanel1.Configuration.TextAlignment = System.Drawing.StringAlignment.Far;
            this.qPanel1.Configuration.TextDock = System.Windows.Forms.DockStyle.Left;
            this.qPanel1.Configuration.VerticalTextOrientation = Qios.DevSuite.Components.QVerticalTextOrientation.VerticalUp;
            this.qPanel1.Controls.Add(this.qmlMarkupLabel);
            this.qPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qPanel1.FontScope = Qios.DevSuite.Components.QFontScope.Local;
            this.qPanel1.LocalFont = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qPanel1.Location = new System.Drawing.Point(0, 5);
            this.qPanel1.Name = "qPanel1";
            this.qPanel1.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.qPanel1.Size = new System.Drawing.Size(471, 414);
            this.qPanel1.TabIndex = 1;
            this.qPanel1.Text = "About";
            // 
            // qmlMarkupLabel
            // 
            this.qmlMarkupLabel.ColorScheme.MarkupTextCustom2.SetColor("LunaBlue", System.Drawing.Color.DarkBlue, false);
            this.qmlMarkupLabel.ColorScheme.MarkupTextCustom2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(141)))), ((int)(((byte)(94))))), false);
            this.qmlMarkupLabel.ColorScheme.MarkupTextCustom2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(124)))), ((int)(((byte)(148))))), false);
            this.qmlMarkupLabel.Configuration.BiggerSmallerStep = 1;
            this.qmlMarkupLabel.Configuration.MarkupPadding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            qMarkupTextStyle1.DefaultTag = "h1";
            qMarkupTextStyle1.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 12F);
            qMarkupTextStyle1.TextColorProperty = "MarkupTextCustom2";
            this.qmlMarkupLabel.CustomStyles.Add(qMarkupTextStyle1);
            this.qmlMarkupLabel.CustomStyles.Add(qMarkupTextStyle2);
            this.qmlMarkupLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qmlMarkupLabel.Location = new System.Drawing.Point(0, 5);
            this.qmlMarkupLabel.MarkupText = resources.GetString("qmlMarkupLabel.MarkupText");
            this.qmlMarkupLabel.Name = "qmlMarkupLabel";
            this.qmlMarkupLabel.Size = new System.Drawing.Size(440, 95);
            this.qmlMarkupLabel.TabIndex = 0;
            this.qmlMarkupLabel.ElementLinkClick += new Qios.DevSuite.Components.QMarkupTextElementEventHandler(this.qmlMarkupLabel_ElementLinkClick);
            // 
            // qtpSlideShow
            // 
            this.qtpSlideShow.ButtonOrder = 1;
            this.qtpSlideShow.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpSlideShow.Icon")));
            this.qtpSlideShow.Location = new System.Drawing.Point(41, 30);
            this.qtpSlideShow.Name = "qtpSlideShow";
            this.qtpSlideShow.PersistGuid = new System.Guid("cd754636-5469-4eb1-8a6b-c43b30c22d90");
            this.qtpSlideShow.Size = new System.Drawing.Size(476, 424);
            this.qtpSlideShow.Text = "Slide show";
            // 
            // qtpCopyToCD
            // 
            this.qtpCopyToCD.ButtonOrder = 3;
            this.qtpCopyToCD.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpCopyToCD.Icon")));
            this.qtpCopyToCD.Location = new System.Drawing.Point(41, 30);
            this.qtpCopyToCD.Name = "qtpCopyToCD";
            this.qtpCopyToCD.PersistGuid = new System.Guid("afed936d-4362-4f53-a8b3-47c0b3e83786");
            this.qtpCopyToCD.Size = new System.Drawing.Size(476, 424);
            this.qtpCopyToCD.Text = "Copy to CD";
            // 
            // qtp2
            // 
            this.qtp2.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp2.ButtonOrder = 1;
            this.qtp2.Location = new System.Drawing.Point(41, 30);
            this.qtp2.Name = "qtp2";
            this.qtp2.PersistGuid = new System.Guid("862e43f9-cd0f-45b6-962c-0fb3135399f5");
            this.qtp2.Size = new System.Drawing.Size(476, 424);
            this.qtp2.Text = "2";
            // 
            // qtp1
            // 
            this.qtp1.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp1.ButtonOrder = 0;
            this.qtp1.Location = new System.Drawing.Point(41, 30);
            this.qtp1.Name = "qtp1";
            this.qtp1.PersistGuid = new System.Guid("be6e9736-15f5-49b6-9721-7cec60e0cbce");
            this.qtp1.Size = new System.Drawing.Size(476, 424);
            this.qtp1.Text = "1";
            // 
            // qtpOrderPrints
            // 
            this.qtpOrderPrints.ButtonOrder = 2;
            this.qtpOrderPrints.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpOrderPrints.Icon")));
            this.qtpOrderPrints.Location = new System.Drawing.Point(41, 30);
            this.qtpOrderPrints.Name = "qtpOrderPrints";
            this.qtpOrderPrints.PersistGuid = new System.Guid("a518d185-da65-4c7f-a02e-6f4e640ce6e0");
            this.qtpOrderPrints.Size = new System.Drawing.Size(476, 424);
            this.qtpOrderPrints.Text = "Order Prints";
            // 
            // qtpPrintPictures
            // 
            this.qtpPrintPictures.ButtonOrder = 4;
            this.qtpPrintPictures.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpPrintPictures.Icon")));
            this.qtpPrintPictures.Location = new System.Drawing.Point(41, 30);
            this.qtpPrintPictures.Name = "qtpPrintPictures";
            this.qtpPrintPictures.PersistGuid = new System.Guid("66b40c4c-8cba-4df1-a8cb-2aaa24d8f4cd");
            this.qtpPrintPictures.Size = new System.Drawing.Size(476, 424);
            this.qtpPrintPictures.Text = "Print pictures";
            // 
            // qtpMyDocuments
            // 
            this.qtpMyDocuments.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
            this.qtpMyDocuments.ButtonOrder = 0;
            this.qtpMyDocuments.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpMyDocuments.Icon")));
            this.qtpMyDocuments.Location = new System.Drawing.Point(41, 30);
            this.qtpMyDocuments.Name = "qtpMyDocuments";
            this.qtpMyDocuments.PersistGuid = new System.Guid("21f69d44-5e4a-4c3e-b472-6b2f1ddedf07");
            this.qtpMyDocuments.Size = new System.Drawing.Size(476, 424);
            this.qtpMyDocuments.Text = "My Documents";
            // 
            // qtpMyComputer
            // 
            this.qtpMyComputer.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
            this.qtpMyComputer.ButtonOrder = 1;
            this.qtpMyComputer.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpMyComputer.Icon")));
            this.qtpMyComputer.Location = new System.Drawing.Point(41, 30);
            this.qtpMyComputer.Name = "qtpMyComputer";
            this.qtpMyComputer.PersistGuid = new System.Guid("279684d8-cc52-481d-8623-95ce367e2b05");
            this.qtpMyComputer.Size = new System.Drawing.Size(476, 424);
            this.qtpMyComputer.Text = "My Computer";
            // 
            // qtpMyNetworkPlaces
            // 
            this.qtpMyNetworkPlaces.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
            this.qtpMyNetworkPlaces.ButtonOrder = 2;
            this.qtpMyNetworkPlaces.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpMyNetworkPlaces.Icon")));
            this.qtpMyNetworkPlaces.Location = new System.Drawing.Point(41, 30);
            this.qtpMyNetworkPlaces.Name = "qtpMyNetworkPlaces";
            this.qtpMyNetworkPlaces.PersistGuid = new System.Guid("851e2166-e61d-42e3-a8c6-d144fd59d0da");
            this.qtpMyNetworkPlaces.Size = new System.Drawing.Size(476, 424);
            this.qtpMyNetworkPlaces.Text = "My Network Places";
            // 
            // qtp3
            // 
            this.qtp3.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp3.ButtonOrder = 2;
            this.qtp3.Location = new System.Drawing.Point(41, 30);
            this.qtp3.Name = "qtp3";
            this.qtp3.PersistGuid = new System.Guid("98a67e99-b40c-42de-a072-5f7792f41821");
            this.qtp3.Size = new System.Drawing.Size(476, 424);
            this.qtp3.Text = "3";
            // 
            // qtp4
            // 
            this.qtp4.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp4.ButtonOrder = 3;
            this.qtp4.Location = new System.Drawing.Point(41, 30);
            this.qtp4.Name = "qtp4";
            this.qtp4.PersistGuid = new System.Guid("80bbccc9-fe00-4377-ac09-557723c9fae9");
            this.qtp4.Size = new System.Drawing.Size(476, 424);
            this.qtp4.Text = "4";
            // 
            // qtp5
            // 
            this.qtp5.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp5.ButtonOrder = 4;
            this.qtp5.Location = new System.Drawing.Point(41, 30);
            this.qtp5.Name = "qtp5";
            this.qtp5.PersistGuid = new System.Guid("7fb92e80-76bb-48d5-8967-dd572a7f8b4e");
            this.qtp5.Size = new System.Drawing.Size(476, 424);
            this.qtp5.Text = "5";
            // 
            // qtp6
            // 
            this.qtp6.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp6.ButtonOrder = 5;
            this.qtp6.Location = new System.Drawing.Point(41, 30);
            this.qtp6.Name = "qtp6";
            this.qtp6.PersistGuid = new System.Guid("45879b19-2fe7-4021-b794-521a3499e41d");
            this.qtp6.Size = new System.Drawing.Size(476, 424);
            this.qtp6.Text = "6";
            // 
            // qtp7
            // 
            this.qtp7.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp7.ButtonOrder = 6;
            this.qtp7.Location = new System.Drawing.Point(41, 30);
            this.qtp7.Name = "qtp7";
            this.qtp7.PersistGuid = new System.Guid("87900cf3-506d-4414-b699-f53ec813a095");
            this.qtp7.Size = new System.Drawing.Size(476, 424);
            this.qtp7.Text = "7";
            // 
            // qtp8
            // 
            this.qtp8.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp8.ButtonOrder = 7;
            this.qtp8.Location = new System.Drawing.Point(41, 30);
            this.qtp8.Name = "qtp8";
            this.qtp8.PersistGuid = new System.Guid("2020b014-6e09-409d-9937-d86d27947115");
            this.qtp8.Size = new System.Drawing.Size(476, 424);
            this.qtp8.Text = "8";
            // 
            // qtp9
            // 
            this.qtp9.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp9.ButtonOrder = 8;
            this.qtp9.Location = new System.Drawing.Point(41, 30);
            this.qtp9.Name = "qtp9";
            this.qtp9.PersistGuid = new System.Guid("1fcab702-745c-4bf8-85ae-b2e8dcd8b3be");
            this.qtp9.Size = new System.Drawing.Size(476, 424);
            this.qtp9.Text = "9";
            // 
            // qtp10
            // 
            this.qtp10.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
            this.qtp10.ButtonOrder = 9;
            this.qtp10.Location = new System.Drawing.Point(41, 30);
            this.qtp10.Name = "qtp10";
            this.qtp10.PersistGuid = new System.Guid("411d03d3-44df-4762-a431-e888b37010f4");
            this.qtp10.Size = new System.Drawing.Size(476, 424);
            this.qtp10.Text = "10";
            // 
            // qsCustomShape
            // 
            this.qsCustomShape.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
            this.qsCustomShape.ContentBounds = new System.Drawing.Rectangle(2, 6, 16, 32);
            this.qsCustomShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 40F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsCustomShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, 17F, 0F, 20F, 26F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsCustomShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 40F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
            this.qsCustomShape.Size = new System.Drawing.Size(20, 40);
            // 
            // qExplorerItem1
            // 
            this.qExplorerItem1.Title = "Test155";
            // 
            // FrmWelcome
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(752, 454);
            this.Controls.Add(this.qtcWelcome);
            this.Controls.Add(this.qExplorerBar1);
            this.Controls.Add(this.splVertical);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmWelcome";
            this.Text = "Welcome";
            this.qExplorerBar1.ResumeLayout(false);
            this.qCommandControlContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.qtcWelcome)).EndInit();
            this.qtcWelcome.ResumeLayout(false);
            this.qtpWelcome.ResumeLayout(false);
            this.qPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		private void qcmContextMenu_MenuItemSelected(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			//If there was a selected menuItem
			if ((e.MenuItem != null) && (!e.MenuItem.IsSeparator))
			{
				//Set the text to the selected item.
				FrmMain.StatusPanel.Text = "Context item " + e.MenuItem.Title.Replace("&","") + " selected via " + e.ActivationType.ToString();
				FrmMain.MouseOffMenuItem = -1;
			}
			else
			{
				//Set the timer so that the statustext will disappear after a while.
				FrmMain.MouseOffMenuItem = Environment.TickCount;
			}		
		}

		private void qExplorerBar1_ColorsChanged(object sender, System.EventArgs e)
		{
			SetSpecialGroup();
		}

		private void qExplorerBar1_MenuItemActivated(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			if (e.MenuItem == qeiViewSlideShow)
			{
				qtcWelcome.ActiveTabPage = qtpSlideShow;
			}
			else if (e.MenuItem == qeiPrintPictures)
			{
				qtcWelcome.ActiveTabPage = qtpPrintPictures;
			}
			else if (e.MenuItem == qeiCopyToCD)
			{
				qtcWelcome.ActiveTabPage = qtpCopyToCD;
			}
			else if (e.MenuItem == qeiOrderPrintsOnline)
			{
				qtcWelcome.ActiveTabPage = qtpOrderPrints;
			}
		}

		private void QTabPage_Paint(object sender, PaintEventArgs e)
		{
			QTabPage tmp_oPage = sender as QTabPage;
			if (tmp_oPage != null && tmp_oPage.Icon != null)
			{
				QControlPaint.DrawIcon(tmp_oPage.Icon, 10,10, e.Graphics);
				Brush tmp_oBrush = new SolidBrush(Color.Black);
				e.Graphics.DrawString(tmp_oPage.Text, this.Font, tmp_oBrush, 30, 12);
				tmp_oBrush.Dispose();
			}
		}

		private void qmlMarkupLabel_ElementLinkClick(object sender, QMarkupTextElementEventArgs e)
		{
			try
			{
				System.Diagnostics.Process.Start("IEXPLORE.EXE", e.HRef);
			}
			catch {}
		}
	}
}
