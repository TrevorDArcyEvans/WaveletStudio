using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private Qios.DevSuite.Components.QPanel qpnlLeft;
		private Qios.DevSuite.Components.QPanel qpnlRight;
		private System.Windows.Forms.Label lblContextLeft;
		private Qios.DevSuite.Components.QContextMenu qcmLeft;
		private Qios.DevSuite.Components.QMenuItem qmiLeftCut;
		private Qios.DevSuite.Components.QMenuItem qmiLeftCopy;
		private Qios.DevSuite.Components.QMenuItem qmiLeftPaste;
		private Qios.DevSuite.Components.QMenuItem qmiLeftSelectAll;
		private Qios.DevSuite.Components.QContextMenu qcmRight;
		private Qios.DevSuite.Components.QMenuItem qmiRightCut;
		private Qios.DevSuite.Components.QMenuItem qmiRightCopy;
		private Qios.DevSuite.Components.QMenuItem qmiRightPaste;
		private Qios.DevSuite.Components.QMenuItem qmiRightSelectAll;
		private System.ComponentModel.IContainer components;
		private Qios.DevSuite.Components.QMenuItem qmiRightSeperator;
		private Qios.DevSuite.Components.QMenuItem qmiLeftSeperator;
		private System.Windows.Forms.Label lblContextRight;
	
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}


		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.qpnlLeft = new Qios.DevSuite.Components.QPanel();
			this.lblContextLeft = new System.Windows.Forms.Label();
			this.qpnlRight = new Qios.DevSuite.Components.QPanel();
			this.lblContextRight = new System.Windows.Forms.Label();
			this.qcmLeft = new Qios.DevSuite.Components.QContextMenu(this.components);
			this.qmiLeftCut = new Qios.DevSuite.Components.QMenuItem();
			this.qmiLeftCopy = new Qios.DevSuite.Components.QMenuItem();
			this.qmiLeftPaste = new Qios.DevSuite.Components.QMenuItem();
			this.qmiLeftSeperator = new Qios.DevSuite.Components.QMenuItem();
			this.qmiLeftSelectAll = new Qios.DevSuite.Components.QMenuItem();
			this.qcmRight = new Qios.DevSuite.Components.QContextMenu(this.components);
			this.qmiRightCut = new Qios.DevSuite.Components.QMenuItem();
			this.qmiRightCopy = new Qios.DevSuite.Components.QMenuItem();
			this.qmiRightPaste = new Qios.DevSuite.Components.QMenuItem();
			this.qmiRightSeperator = new Qios.DevSuite.Components.QMenuItem();
			this.qmiRightSelectAll = new Qios.DevSuite.Components.QMenuItem();
			this.qpnlLeft.SuspendLayout();
			this.qpnlRight.SuspendLayout();
			this.SuspendLayout();
			// 
			// qpnlLeft
			// 
			this.qpnlLeft.Controls.Add(this.lblContextLeft);
			this.qpnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.qpnlLeft.DockPadding.All = 5;
			this.qpnlLeft.Location = new System.Drawing.Point(10, 10);
			this.qpnlLeft.Name = "qpnlLeft";
			this.qpnlLeft.Size = new System.Drawing.Size(200, 418);
			this.qpnlLeft.TabIndex = 0;
			// 
			// lblContextLeft
			// 
			this.lblContextLeft.BackColor = System.Drawing.Color.Transparent;
			this.lblContextLeft.Dock = System.Windows.Forms.DockStyle.Top;
			this.lblContextLeft.Location = new System.Drawing.Point(5, 5);
			this.lblContextLeft.Name = "lblContextLeft";
			this.lblContextLeft.Size = new System.Drawing.Size(188, 35);
			this.lblContextLeft.TabIndex = 0;
			this.lblContextLeft.Text = "Right click on this panel to show a default context menu";
			// 
			// qpnlRight
			// 
			this.qpnlRight.Controls.Add(this.lblContextRight);
			this.qpnlRight.Dock = System.Windows.Forms.DockStyle.Left;
			this.qpnlRight.DockPadding.All = 5;
			this.qpnlRight.Location = new System.Drawing.Point(210, 10);
			this.qpnlRight.Name = "qpnlRight";
			this.qpnlRight.Size = new System.Drawing.Size(200, 418);
			this.qpnlRight.TabIndex = 1;
			// 
			// lblContextRight
			// 
			this.lblContextRight.BackColor = System.Drawing.Color.Transparent;
			this.lblContextRight.Dock = System.Windows.Forms.DockStyle.Top;
			this.lblContextRight.Location = new System.Drawing.Point(5, 5);
			this.lblContextRight.Name = "lblContextRight";
			this.lblContextRight.Size = new System.Drawing.Size(188, 75);
			this.lblContextRight.TabIndex = 1;
			this.lblContextRight.Text = "Right click on this panel to show a more customized context menu, with increased " +
				"paddings, animation style, bigger icons and thicker seperators";
			// 
			// qcmLeft
			// 
			this.qcmLeft.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
																						 this.qmiLeftCut,
																						 this.qmiLeftCopy,
																						 this.qmiLeftPaste,
																						 this.qmiLeftSeperator,
																						 this.qmiLeftSelectAll});
			this.qcmLeft.AddListener(this.qpnlLeft);
			// 
			// qmiLeftCut
			// 
			this.qmiLeftCut.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiLeftCut.Icon")));
			this.qmiLeftCut.Title = "Cut";
			// 
			// qmiLeftCopy
			// 
			this.qmiLeftCopy.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiLeftCopy.Icon")));
			this.qmiLeftCopy.Title = "Copy";
			// 
			// qmiLeftPaste
			// 
			this.qmiLeftPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiLeftPaste.Icon")));
			this.qmiLeftPaste.Title = "Paste";
			// 
			// qmiLeftSeperator
			// 
			this.qmiLeftSeperator.IsSeparator = true;
			// 
			// qmiLeftSelectAll
			// 
			this.qmiLeftSelectAll.Title = "SelectAll";
			// 
			// qcmRight
			// 
			this.qcmRight.Configuration.AnimateTime = 500;
			this.qcmRight.Configuration.IconSize = new System.Drawing.Size(32, 32);
			this.qcmRight.Configuration.InheritWindowsSettings = false;
			this.qcmRight.Configuration.ItemPadding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
			this.qcmRight.Configuration.SeparatorSize = 3;
			this.qcmRight.Configuration.SeparatorSpacing = new Qios.DevSuite.Components.QSpacing(10, 10);
			this.qcmRight.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
																						  this.qmiRightCut,
																						  this.qmiRightCopy,
																						  this.qmiRightPaste,
																						  this.qmiRightSeperator,
																						  this.qmiRightSelectAll});
			this.qcmRight.AddListener(this.qpnlRight);
			// 
			// qmiRightCut
			// 
			this.qmiRightCut.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiRightCut.Icon")));
			this.qmiRightCut.Title = "Cut";
			this.qmiRightCut.VisibleWhenPersonalized = false;
			// 
			// qmiRightCopy
			// 
			this.qmiRightCopy.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiRightCopy.Icon")));
			this.qmiRightCopy.Title = "Copy";
			this.qmiRightCopy.VisibleWhenPersonalized = false;
			// 
			// qmiRightPaste
			// 
			this.qmiRightPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiRightPaste.Icon")));
			this.qmiRightPaste.Title = "Paste";
			this.qmiRightPaste.VisibleWhenPersonalized = false;
			// 
			// qmiRightSeperator
			// 
			this.qmiRightSeperator.IsSeparator = true;
			this.qmiRightSeperator.VisibleWhenPersonalized = false;
			// 
			// qmiRightSelectAll
			// 
			this.qmiRightSelectAll.Title = "Select All";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.AutoScrollMargin = new System.Drawing.Size(20, 20);
			this.ClientSize = new System.Drawing.Size(616, 438);
			this.Controls.Add(this.qpnlRight);
			this.Controls.Add(this.qpnlLeft);
			this.DockPadding.All = 10;
			this.Name = "Form1";
			this.Text = "Form1";
			this.qpnlLeft.ResumeLayout(false);
			this.qpnlRight.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
