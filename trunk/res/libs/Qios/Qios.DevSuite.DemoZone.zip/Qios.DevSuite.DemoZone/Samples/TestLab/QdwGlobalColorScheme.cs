using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	public class QdwGlobalColorScheme : QDockingWindow
	{
		private PropertyGrid propertyGrid1;

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QdwGlobalColorScheme()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			this.propertyGrid1.SelectedObject = QColorScheme.Global;
			this.SetColors();

		}

		public PropertyGrid Grid
		{
			get { return this.propertyGrid1; }
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QdwGlobalColorScheme));
			this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
			this.SuspendLayout();
			// 
			// propertyGrid1
			// 
			this.propertyGrid1.CommandsBackColor = System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231)));
			this.propertyGrid1.CommandsVisibleIfAvailable = true;
			this.propertyGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGrid1.HelpBackColor = System.Drawing.Color.FromArgb(((System.Byte)(223)), ((System.Byte)(237)), ((System.Byte)(254)));
			this.propertyGrid1.LargeButtons = false;
			this.propertyGrid1.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.propertyGrid1.Location = new System.Drawing.Point(5, 5);
			this.propertyGrid1.Name = "propertyGrid1";
			this.propertyGrid1.Size = new System.Drawing.Size(286, 364);
			this.propertyGrid1.TabIndex = 0;
			this.propertyGrid1.Text = "propertyGrid1";
			this.propertyGrid1.ToolbarVisible = false;
			this.propertyGrid1.ViewBackColor = System.Drawing.Color.White;
			this.propertyGrid1.ViewForeColor = System.Drawing.SystemColors.WindowText;
			// 
			// QdwGlobalColorScheme
			// 
			this.AutoScroll = true;
			this.Controls.Add(this.propertyGrid1);
			this.DockPadding.All = 5;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "QdwGlobalColorScheme";
			this.PersistGuid = new System.Guid("c76803f2-ef4f-466e-8c97-2537099645ec");
			this.Size = new System.Drawing.Size(296, 392);
			this.Text = "Global Color Scheme";
			this.ColorsChanged += new System.EventHandler(this.QdwGlobalColorScheme_ColorsChanged);
			this.ResumeLayout(false);

		}
		#endregion

		private void SetColors()
		{
			this.propertyGrid1.BackColor = this.BackColor2;
			this.propertyGrid1.HelpBackColor = this.BackColor2;
			//this.propertyGrid1.LineColor = this.ColorScheme.StatusBarPanelBorder;		
		}

		private void QdwGlobalColorScheme_ColorsChanged(object sender, System.EventArgs e)
		{
			SetColors();
		}
	}
}
