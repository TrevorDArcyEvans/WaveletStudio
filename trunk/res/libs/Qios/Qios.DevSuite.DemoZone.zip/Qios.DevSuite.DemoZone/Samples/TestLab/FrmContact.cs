using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	/// <summary>
	/// Summary description for FrmContact.
	/// </summary>
	public class FrmContact : System.Windows.Forms.Form
	{
		private Qios.DevSuite.Components.QToolBarHost qtbhTop;
		private Qios.DevSuite.Components.QToolBar qtbContactToolbar;
		private Qios.DevSuite.Components.QToolItem qtiSaveClose;
		private Qios.DevSuite.Components.QToolItem qtiSeperator1;
		private Qios.DevSuite.Components.QToolItem qtiPrint;
		private Qios.DevSuite.Components.QToolItem qtiTasks;
		private Qios.DevSuite.Components.QPanel qpnlContainer;
		private Qios.DevSuite.Components.QPanel qpnlContact2;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;
		private Qios.DevSuite.Components.QPanel qpnlMargin;
		private Qios.DevSuite.Components.QPanel qpnlContact1;
		private System.Windows.Forms.Label lblMobile;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.TextBox txtJobTitle;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Label lblBusinessTelephone;
		private System.Windows.Forms.Label lblCompany;
		private System.Windows.Forms.TextBox txtCompany;
		private System.Windows.Forms.TextBox txtBusinessFax;
		private System.Windows.Forms.TextBox txtBusinessPhone;
		private System.Windows.Forms.Label lblBusinessFax;
		private System.Windows.Forms.Label lblHomeTelephone;
		private System.Windows.Forms.TextBox txtHomePhone;
		private System.Windows.Forms.Label lblJobTitle;
		private System.Windows.Forms.TextBox txtMobilePhone;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmContact()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FrmContact));
			this.qtbhTop = new Qios.DevSuite.Components.QToolBarHost();
			this.qtbContactToolbar = new Qios.DevSuite.Components.QToolBar();
			this.qtiSaveClose = new Qios.DevSuite.Components.QToolItem();
			this.qtiSeperator1 = new Qios.DevSuite.Components.QToolItem();
			this.qtiPrint = new Qios.DevSuite.Components.QToolItem();
			this.qtiTasks = new Qios.DevSuite.Components.QToolItem();
			this.qpnlContainer = new Qios.DevSuite.Components.QPanel();
			this.qpnlContact2 = new Qios.DevSuite.Components.QPanel();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.qpnlMargin = new Qios.DevSuite.Components.QPanel();
			this.qpnlContact1 = new Qios.DevSuite.Components.QPanel();
			this.lblMobile = new System.Windows.Forms.Label();
			this.lblEmail = new System.Windows.Forms.Label();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.txtJobTitle = new System.Windows.Forms.TextBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.lblName = new System.Windows.Forms.Label();
			this.lblBusinessTelephone = new System.Windows.Forms.Label();
			this.lblCompany = new System.Windows.Forms.Label();
			this.txtCompany = new System.Windows.Forms.TextBox();
			this.txtBusinessFax = new System.Windows.Forms.TextBox();
			this.txtBusinessPhone = new System.Windows.Forms.TextBox();
			this.lblBusinessFax = new System.Windows.Forms.Label();
			this.lblHomeTelephone = new System.Windows.Forms.Label();
			this.txtHomePhone = new System.Windows.Forms.TextBox();
			this.lblJobTitle = new System.Windows.Forms.Label();
			this.txtMobilePhone = new System.Windows.Forms.TextBox();
			this.qtbhTop.SuspendLayout();
			this.qpnlContainer.SuspendLayout();
			this.qpnlContact2.SuspendLayout();
			this.qpnlContact1.SuspendLayout();
			this.SuspendLayout();
			// 
			// qtbhTop
			// 
			this.qtbhTop.Controls.Add(this.qtbContactToolbar);
			this.qtbhTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.qtbhTop.Location = new System.Drawing.Point(0, 0);
			this.qtbhTop.Name = "qtbhTop";
			this.qtbhTop.Size = new System.Drawing.Size(688, 32);
			this.qtbhTop.TabIndex = 2;
			// 
			// qtbContactToolbar
			// 
			this.qtbContactToolbar.Configuration.CanFloat = false;
			this.qtbContactToolbar.Configuration.CanMove = false;
			this.qtbContactToolbar.Location = new System.Drawing.Point(2, 2);
			this.qtbContactToolbar.Name = "qtbContactToolbar";
			this.qtbContactToolbar.RequestedPosition = 0;
			this.qtbContactToolbar.RowIndex = 0;
			this.qtbContactToolbar.Size = new System.Drawing.Size(230, 28);
			this.qtbContactToolbar.TabIndex = 4;
			this.qtbContactToolbar.Text = "Contact";
			this.qtbContactToolbar.ToolBarIndex = 0;
			this.qtbContactToolbar.ToolItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
																								   this.qtiSaveClose,
																								   this.qtiSeperator1,
																								   this.qtiPrint,
																								   this.qtiTasks});
			this.qtbContactToolbar.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.qtbContactToolbar_MenuItemActivated);
			// 
			// qtiSaveClose
			// 
			this.qtiSaveClose.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiSaveClose.Icon")));
			this.qtiSaveClose.IconColorToReplace = System.Drawing.Color.Empty;
			this.qtiSaveClose.ItemName = "saveclose";
			this.qtiSaveClose.Title = "Save and Close";
			this.qtiSaveClose.ToolTip = "Save and Close";
			// 
			// qtiSeperator1
			// 
			this.qtiSeperator1.IconColorToReplace = System.Drawing.Color.Empty;
			this.qtiSeperator1.IsSeparator = true;
			// 
			// qtiPrint
			// 
			this.qtiPrint.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiPrint.Icon")));
			this.qtiPrint.IconColorToReplace = System.Drawing.Color.Empty;
			this.qtiPrint.Title = "Print";
			this.qtiPrint.ToolTip = "Print";
			// 
			// qtiTasks
			// 
			this.qtiTasks.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiTasks.Icon")));
			this.qtiTasks.IconColorToReplace = System.Drawing.Color.Empty;
			this.qtiTasks.Title = "Tasks";
			this.qtiTasks.ToolTip = "Tasks";
			// 
			// qpnlContainer
			// 
			this.qpnlContainer.Appearance.BorderWidth = 0;
			this.qpnlContainer.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground1.SetColor("HighContrast", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground2.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.ColorScheme.PanelBackground2.SetColor("HighContrast", System.Drawing.Color.Transparent, false);
			this.qpnlContainer.Controls.Add(this.qpnlContact2);
			this.qpnlContainer.Controls.Add(this.qpnlMargin);
			this.qpnlContainer.Controls.Add(this.qpnlContact1);
			this.qpnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qpnlContainer.DockPadding.All = 7;
			this.qpnlContainer.Location = new System.Drawing.Point(0, 32);
			this.qpnlContainer.Name = "qpnlContainer";
			this.qpnlContainer.Size = new System.Drawing.Size(688, 429);
			this.qpnlContainer.TabIndex = 101;
			this.qpnlContainer.Text = "qPanel1";
			// 
			// qpnlContact2
			// 
			this.qpnlContact2.Controls.Add(this.textBox2);
			this.qpnlContact2.Controls.Add(this.label2);
			this.qpnlContact2.Controls.Add(this.label1);
			this.qpnlContact2.Controls.Add(this.textBox1);
			this.qpnlContact2.Dock = System.Windows.Forms.DockStyle.Top;
			this.qpnlContact2.Location = new System.Drawing.Point(7, 143);
			this.qpnlContact2.Name = "qpnlContact2";
			this.qpnlContact2.Size = new System.Drawing.Size(674, 104);
			this.qpnlContact2.TabIndex = 103;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(408, 16);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(144, 21);
			this.textBox2.TabIndex = 120;
			this.textBox2.Text = "";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(288, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(104, 16);
			this.label2.TabIndex = 43;
			this.label2.Text = "Web page address:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 16);
			this.label1.TabIndex = 41;
			this.label1.Text = "Address:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(88, 16);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(184, 72);
			this.textBox1.TabIndex = 110;
			this.textBox1.Text = "";
			// 
			// qpnlMargin
			// 
			this.qpnlMargin.Appearance.BorderWidth = 0;
			this.qpnlMargin.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground1.SetColor("HighContrast", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground2.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.ColorScheme.PanelBackground2.SetColor("HighContrast", System.Drawing.Color.Transparent, false);
			this.qpnlMargin.Dock = System.Windows.Forms.DockStyle.Top;
			this.qpnlMargin.Location = new System.Drawing.Point(7, 135);
			this.qpnlMargin.MinimumClientSize = new System.Drawing.Size(50, 5);
			this.qpnlMargin.Name = "qpnlMargin";
			this.qpnlMargin.Size = new System.Drawing.Size(674, 8);
			this.qpnlMargin.TabIndex = 102;
			this.qpnlMargin.TabStop = false;
			// 
			// qpnlContact1
			// 
			this.qpnlContact1.Controls.Add(this.lblMobile);
			this.qpnlContact1.Controls.Add(this.lblEmail);
			this.qpnlContact1.Controls.Add(this.txtEmail);
			this.qpnlContact1.Controls.Add(this.txtJobTitle);
			this.qpnlContact1.Controls.Add(this.txtName);
			this.qpnlContact1.Controls.Add(this.lblName);
			this.qpnlContact1.Controls.Add(this.lblBusinessTelephone);
			this.qpnlContact1.Controls.Add(this.lblCompany);
			this.qpnlContact1.Controls.Add(this.txtCompany);
			this.qpnlContact1.Controls.Add(this.txtBusinessFax);
			this.qpnlContact1.Controls.Add(this.txtBusinessPhone);
			this.qpnlContact1.Controls.Add(this.lblBusinessFax);
			this.qpnlContact1.Controls.Add(this.lblHomeTelephone);
			this.qpnlContact1.Controls.Add(this.txtHomePhone);
			this.qpnlContact1.Controls.Add(this.lblJobTitle);
			this.qpnlContact1.Controls.Add(this.txtMobilePhone);
			this.qpnlContact1.Dock = System.Windows.Forms.DockStyle.Top;
			this.qpnlContact1.Location = new System.Drawing.Point(7, 7);
			this.qpnlContact1.Name = "qpnlContact1";
			this.qpnlContact1.Size = new System.Drawing.Size(674, 128);
			this.qpnlContact1.TabIndex = 101;
			// 
			// lblMobile
			// 
			this.lblMobile.BackColor = System.Drawing.Color.Transparent;
			this.lblMobile.Location = new System.Drawing.Point(288, 88);
			this.lblMobile.Name = "lblMobile";
			this.lblMobile.Size = new System.Drawing.Size(112, 16);
			this.lblMobile.TabIndex = 13;
			this.lblMobile.Text = "Mobile:";
			this.lblMobile.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// lblEmail
			// 
			this.lblEmail.BackColor = System.Drawing.Color.Transparent;
			this.lblEmail.Location = new System.Drawing.Point(16, 88);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(64, 16);
			this.lblEmail.TabIndex = 16;
			this.lblEmail.Text = "E-mail:";
			this.lblEmail.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// txtEmail
			// 
			this.txtEmail.Location = new System.Drawing.Point(88, 88);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(184, 21);
			this.txtEmail.TabIndex = 40;
			this.txtEmail.Text = "";
			// 
			// txtJobTitle
			// 
			this.txtJobTitle.Location = new System.Drawing.Point(88, 40);
			this.txtJobTitle.Name = "txtJobTitle";
			this.txtJobTitle.Size = new System.Drawing.Size(184, 21);
			this.txtJobTitle.TabIndex = 20;
			this.txtJobTitle.Text = "";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(88, 16);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(184, 21);
			this.txtName.TabIndex = 10;
			this.txtName.Text = "";
			// 
			// lblName
			// 
			this.lblName.BackColor = System.Drawing.Color.Transparent;
			this.lblName.Location = new System.Drawing.Point(16, 16);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(56, 16);
			this.lblName.TabIndex = 1;
			this.lblName.Text = "Name:";
			this.lblName.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// lblBusinessTelephone
			// 
			this.lblBusinessTelephone.BackColor = System.Drawing.Color.Transparent;
			this.lblBusinessTelephone.Location = new System.Drawing.Point(288, 16);
			this.lblBusinessTelephone.Name = "lblBusinessTelephone";
			this.lblBusinessTelephone.Size = new System.Drawing.Size(112, 16);
			this.lblBusinessTelephone.TabIndex = 7;
			this.lblBusinessTelephone.Text = "Business telephone:";
			this.lblBusinessTelephone.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// lblCompany
			// 
			this.lblCompany.BackColor = System.Drawing.Color.Transparent;
			this.lblCompany.Location = new System.Drawing.Point(16, 64);
			this.lblCompany.Name = "lblCompany";
			this.lblCompany.Size = new System.Drawing.Size(64, 16);
			this.lblCompany.TabIndex = 6;
			this.lblCompany.Text = "Company:";
			this.lblCompany.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// txtCompany
			// 
			this.txtCompany.Location = new System.Drawing.Point(88, 64);
			this.txtCompany.Name = "txtCompany";
			this.txtCompany.Size = new System.Drawing.Size(184, 21);
			this.txtCompany.TabIndex = 30;
			this.txtCompany.Text = "";
			// 
			// txtBusinessFax
			// 
			this.txtBusinessFax.Location = new System.Drawing.Point(408, 64);
			this.txtBusinessFax.Name = "txtBusinessFax";
			this.txtBusinessFax.Size = new System.Drawing.Size(144, 21);
			this.txtBusinessFax.TabIndex = 70;
			this.txtBusinessFax.Text = "";
			// 
			// txtBusinessPhone
			// 
			this.txtBusinessPhone.Location = new System.Drawing.Point(408, 16);
			this.txtBusinessPhone.Name = "txtBusinessPhone";
			this.txtBusinessPhone.Size = new System.Drawing.Size(144, 21);
			this.txtBusinessPhone.TabIndex = 50;
			this.txtBusinessPhone.Text = "";
			// 
			// lblBusinessFax
			// 
			this.lblBusinessFax.BackColor = System.Drawing.Color.Transparent;
			this.lblBusinessFax.Location = new System.Drawing.Point(288, 64);
			this.lblBusinessFax.Name = "lblBusinessFax";
			this.lblBusinessFax.Size = new System.Drawing.Size(112, 16);
			this.lblBusinessFax.TabIndex = 11;
			this.lblBusinessFax.Text = "Business fax:";
			this.lblBusinessFax.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// lblHomeTelephone
			// 
			this.lblHomeTelephone.BackColor = System.Drawing.Color.Transparent;
			this.lblHomeTelephone.Location = new System.Drawing.Point(288, 40);
			this.lblHomeTelephone.Name = "lblHomeTelephone";
			this.lblHomeTelephone.Size = new System.Drawing.Size(112, 16);
			this.lblHomeTelephone.TabIndex = 10;
			this.lblHomeTelephone.Text = "Home telephone:";
			this.lblHomeTelephone.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// txtHomePhone
			// 
			this.txtHomePhone.Location = new System.Drawing.Point(408, 40);
			this.txtHomePhone.Name = "txtHomePhone";
			this.txtHomePhone.Size = new System.Drawing.Size(144, 21);
			this.txtHomePhone.TabIndex = 60;
			this.txtHomePhone.Text = "";
			// 
			// lblJobTitle
			// 
			this.lblJobTitle.BackColor = System.Drawing.Color.Transparent;
			this.lblJobTitle.Location = new System.Drawing.Point(16, 40);
			this.lblJobTitle.Name = "lblJobTitle";
			this.lblJobTitle.Size = new System.Drawing.Size(56, 16);
			this.lblJobTitle.TabIndex = 3;
			this.lblJobTitle.Text = "Job title:";
			this.lblJobTitle.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// txtMobilePhone
			// 
			this.txtMobilePhone.Location = new System.Drawing.Point(408, 88);
			this.txtMobilePhone.Name = "txtMobilePhone";
			this.txtMobilePhone.Size = new System.Drawing.Size(144, 21);
			this.txtMobilePhone.TabIndex = 80;
			this.txtMobilePhone.Text = "";
			// 
			// FrmContact
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(688, 461);
			this.Controls.Add(this.qpnlContainer);
			this.Controls.Add(this.qtbhTop);
			this.Name = "FrmContact";
			this.qtbhTop.ResumeLayout(false);
			this.qpnlContainer.ResumeLayout(false);
			this.qpnlContact2.ResumeLayout(false);
			this.qpnlContact1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void qtbContactToolbar_MenuItemActivated(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			if (e.MenuItem.ItemName == "saveclose")
			{
				this.Close();
			}
		}
	}
}
