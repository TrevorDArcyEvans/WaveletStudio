using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	public class QbCustomBalloonWindow : QBalloonWindow
	{
		private Qios.DevSuite.Components.QShape qsCustomBalloonShape;
	
		public QbCustomBalloonWindow()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.qsCustomBalloonShape = new Qios.DevSuite.Components.QShape();
			// 
			// qsCustomBalloonShape
			// 
			this.qsCustomBalloonShape.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.BalloonShapedWindow;
			this.qsCustomBalloonShape.ContentBounds = new System.Drawing.Rectangle(26, 23, 49, 77);
			this.qsCustomBalloonShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(19F, 1F, 29F, 6F, 37F, 10F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCustomBalloonShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(48F, 21F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCustomBalloonShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(82F, 21F, 87F, 30F, 74F, 89F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsCustomBalloonShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(63F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsCustomBalloonShape.Items.Add(new Qios.DevSuite.Components.QShapeItem(1F, 100F, 14F, 84F, 38F, 23F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCustomBalloonShape.Precision = 0;
			this.qsCustomBalloonShape.ShapeName = "BalloonShapedWindow";
			this.qsCustomBalloonShape.ShapeType = Qios.DevSuite.Components.QShapeType.ShapedWindow;
			this.qsCustomBalloonShape.Size = new System.Drawing.Size(100, 100);
			// 
			// QbCustomBalloonWindow
			// 
			this.Appearance.GradientAngle = 90;
			this.Appearance.Shape = this.qsCustomBalloonShape;
			this.ClientSize = new System.Drawing.Size(384, 136);
			this.ColorScheme.BalloonWindowBackground1.SetColor("LunaBlue", System.Drawing.Color.Silver, false);
			this.ColorScheme.BalloonWindowBackground1.SetColor("LunaOlive", System.Drawing.Color.Silver, false);
			this.ColorScheme.BalloonWindowBackground1.SetColor("LunaSilver", System.Drawing.Color.Silver, false);
			this.ColorScheme.BalloonWindowBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.ColorScheme.BalloonWindowBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.ColorScheme.BalloonWindowBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.ColorScheme.MarkupTextCustom1.SetColor("LunaBlue", System.Drawing.Color.Navy, false);
			this.Configuration.AutoMinimumSize = false;
			this.Appearance.ShadeOffset = new System.Drawing.Point(6, 6);
			this.Configuration.TextPadding = new Qios.DevSuite.Components.QPadding(10, 10, 10, 10);
			this.MarkupText = "<b><font color=\"MarkupTextCustom1\" size=\"12\">Other Places</font></b><br /><big>Wi" +
				"th <a>Other Places</a> you can view places like:<br /> <a>My Computer</a>, <a>My" +
				" documents</a> or <a>My Network Places</a>.</big>";
			this.Name = "QbCustomBalloonWindow";

		}
		#endregion
	}
}
