using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{
	public class QdwTasks : QDockingWindow
	{
		private System.Windows.Forms.ListView listView1;
		private Qios.DevSuite.Components.QPanel qPanel1;
		private System.Windows.Forms.ColumnHeader chTaskName;
		private System.Windows.Forms.ImageList imageList1;
		private System.ComponentModel.IContainer components;

		public QdwTasks()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//Because Task windows are created on demand, be sure it always has a unique guid.
			this.PersistGuid = Guid.NewGuid();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Task number one", 0);
			System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Task number two", 0);
			System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Task number three", 0);
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QdwTasks));
			this.listView1 = new System.Windows.Forms.ListView();
			this.chTaskName = new System.Windows.Forms.ColumnHeader();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.qPanel1 = new Qios.DevSuite.Components.QPanel();
			this.qPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// listView1
			// 
			this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.listView1.CheckBoxes = true;
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.chTaskName});
			this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listView1.FullRowSelect = true;
			this.listView1.GridLines = true;
			listViewItem1.StateImageIndex = 0;
			listViewItem2.StateImageIndex = 0;
			listViewItem3.StateImageIndex = 0;
			this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
																					  listViewItem1,
																					  listViewItem2,
																					  listViewItem3});
			this.listView1.Location = new System.Drawing.Point(0, 0);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(572, 82);
			this.listView1.SmallImageList = this.imageList1;
			this.listView1.TabIndex = 0;
			this.listView1.View = System.Windows.Forms.View.Details;
			// 
			// chTaskName
			// 
			this.chTaskName.Text = "Description";
			this.chTaskName.Width = 528;
			// 
			// imageList1
			// 
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// qPanel1
			// 
			this.qPanel1.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qPanel1.Controls.Add(this.listView1);
			this.qPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qPanel1.Location = new System.Drawing.Point(5, 5);
			this.qPanel1.MinimumClientSize = new System.Drawing.Size(20, 20);
			this.qPanel1.Name = "qPanel1";
			this.qPanel1.Size = new System.Drawing.Size(574, 84);
			this.qPanel1.TabIndex = 1;
			this.qPanel1.Text = "qPanel1";
			// 
			// QdwTasks
			// 
			this.AutoScroll = true;
			this.Controls.Add(this.qPanel1);
			this.DockPadding.All = 5;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "QdwTasks";
			this.Size = new System.Drawing.Size(584, 112);
			this.Text = "Tasks";
			this.CreateNew = true;
			this.qPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
