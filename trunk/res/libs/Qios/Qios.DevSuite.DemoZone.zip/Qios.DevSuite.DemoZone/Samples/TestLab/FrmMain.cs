using System;
using System.IO;
//using System.Management;
using System.Reflection;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

using Qios.DevSuite.Components;

using Qios.DevSuite.DemoZone.Misc;

namespace Qios.DevSuite.DemoZone.Samples.TestLab
{

	[SelectorDisplay(70,
		 "TestLab 1.0",
		 "Shows you the TestLab previously installed with Qios.DevSuite 1.X, that demonstrates QMainMenu, QToolBar, QExplorerBar, QDockingWindow, QPersistenceManager, QTabControl, QContextMenu, QStatusBar, QMarkupLabel, and more...")]
	public class FrmMain : System.Windows.Forms.Form
	{
		[DllImport("user32.dll", CharSet=CharSet.Auto)]
		public static extern short GetKeyState(int iKey);

		private string m_sPersistenceFileName;
		private string m_sColorSchemeFileName;

		private QdwGlobalColorScheme m_oGlobalColorSchemeWindow = null;
		private QdwProperties m_oPropertiesWindow = null;

		private System.Collections.Queue m_oStatusBarQueue;

		private QProgressBar m_oProgressBar = null;
		private Panel m_oAppStateImageContainer = null;
		private Bitmap m_oAnimationBitmap = null;

		private int m_iStatusBarRefreshTime = 200;
		private int m_iStatusBarLastMessageTime = 2000;

		//contains the time counter for when the statusbar should get reset.
		private static int m_iLastMessageShownTime = -1;

		//Contains the static statusPanel so that other windows can reach it.
		internal static QStatusBarPanel StatusPanel;
		//Contains the time counter for when the statusbar should get reset.
		internal static int MouseOffMenuItem = -1;

		private QStatusBar qsbStatusBar;
		private QStatusBarPanelControlContainer qspStatus;
		private QStatusBarPanel qspCapsLock;
		private QStatusBarPanel qspNumLock;
		private QStatusBarPanel qspUser;
		private QStatusBarPanel qspDate;
		private QStatusBarPanel qspSystem;
		private Qios.DevSuite.Components.QStatusBarPanelControlContainer qspProgressBar;
		private Qios.DevSuite.Components.QAppStateIndicator qsiAppState;
		private System.Windows.Forms.Timer tmrTimedRetrievals;
		private System.ComponentModel.IContainer components;
		private Qios.DevSuite.Components.QDockBar qdbDockBarLeft;
		private Qios.DevSuite.Components.QDockBar qdbDockBarRight;
		private Qios.DevSuite.Components.QDockBar qdbDockBarBottom;
		private Qios.DevSuite.Components.QDockBar qdbDockBarTop;
		private Qios.DevSuite.Components.QMainMenu qMainMenu1;
		private Qios.DevSuite.Components.QGlobalColorSchemeManager qgcGlobalManager;
		private Qios.DevSuite.Components.QToolBar qtbToolbar;
		private Qios.DevSuite.Components.QToolItem qtiNew;
		private Qios.DevSuite.Components.QToolItem qtiSeperator1;
		private Qios.DevSuite.Components.QToolItem qtiPrint;
		private Qios.DevSuite.Components.QToolItem qtiSeperator2;
		private Qios.DevSuite.Components.QToolItem qtiCopy;
		private Qios.DevSuite.Components.QToolItem qtiPaste;
		private Qios.DevSuite.Components.QToolItem qtiCut;
		private Qios.DevSuite.Components.QToolItem qtiSeperator3;
		private Qios.DevSuite.Components.QToolItem qtiFind;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarNewNote;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarNewMail;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarNewTask;
		private Qios.DevSuite.Components.QToolItem qtiLogoff;
		private Qios.DevSuite.Components.QToolItem qtiShutDown;
		private Qios.DevSuite.Components.QToolItem qtiSeperator;
		private Qios.DevSuite.Components.QToolItem qtiPrint2;
		private Qios.DevSuite.Components.QToolBarHost qtbhToolBarHostTop;
		private Qios.DevSuite.Components.QToolBarHost qtbhToolBarHostLeft;
		private Qios.DevSuite.Components.QToolBarHost qtbhToolBarHostBottom;
		private Qios.DevSuite.Components.QToolBarHost qtbhToolBarHostRight;
		private Qios.DevSuite.Components.QToolItem qtiOpen;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarOpenWelcome;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarOpenForm1;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarOpenSeperator;
		private Qios.DevSuite.Components.QToolBar qtbNavigation;
		private Qios.DevSuite.Components.QToolItem qtiNavigationBack;
		private Qios.DevSuite.Components.QMenuItem qmiNavigationHistory1;
		private Qios.DevSuite.Components.QMenuItem qmiNavigationHistory2;
		private Qios.DevSuite.Components.QMenuItem qmiNavigationHistory3;
		private Qios.DevSuite.Components.QToolItem qtiNavigationForward;
		private Qios.DevSuite.Components.QToolItem qtiNavigationStop;
		private Qios.DevSuite.Components.QToolItem qtiNavigationRefresh;
		private Qios.DevSuite.Components.QToolItem qtiNavigationHome;
		private Qios.DevSuite.Components.QToolItem qtiNavigationSearch;
		private Qios.DevSuite.Components.QToolItem qtiNavigationFavorites;
		private Qios.DevSuite.Components.QToolBar qtbTextToolbar;
		private Qios.DevSuite.Components.QToolItem qtiBold;
		private Qios.DevSuite.Components.QToolItem qtiItalic;
		private Qios.DevSuite.Components.QToolItem qtiUnderline;
		private Qios.DevSuite.Components.QToolItem qtiTextColor;
		private Qios.DevSuite.Components.QToolItem qtiNavigationSeperator1;
		private Qios.DevSuite.Components.QToolItem qtiNavigationSeperator2;
		private Qios.DevSuite.Components.QToolItem qtiNavigationHistory;
		private Qios.DevSuite.Components.QToolItem qtiTextDivider1;
		private Qios.DevSuite.Components.QToolItem qtiAlignleft;
		private Qios.DevSuite.Components.QToolItem qtiAlignCenter;
		private Qios.DevSuite.Components.QToolItem qtiAlignRight;
		private Qios.DevSuite.Components.QToolItem qtiTextDivider2;
		private Qios.DevSuite.Components.QToolItem qtiTextDivider3;
		private Qios.DevSuite.Components.QToolItem qtiNumbering;
		private Qios.DevSuite.Components.QToolItem qtiBullets;
		private Qios.DevSuite.Components.QToolItem qtiDecreaseIndent;
		private Qios.DevSuite.Components.QToolItem qtiIncreaseIndent;
		private Qios.DevSuite.Components.QMenuItem qmiToolbarOpenContact;
		private Qios.DevSuite.Components.QPersistenceManager qpmPersistenceManager;
		private Qios.DevSuite.Components.QMenuItem qmiFile;
		private Qios.DevSuite.Components.QMenuItem qmiFileNew;
		private Qios.DevSuite.Components.QMenuItem qmiFileOpen;
		private Qios.DevSuite.Components.QMenuItem qmiFileOpenWelcome;
		private Qios.DevSuite.Components.QMenuItem qmiSeparator5;
		private Qios.DevSuite.Components.QMenuItem qmiFileOpenForm1;
		private Qios.DevSuite.Components.QMenuItem qmiFileOpenContact;
		private Qios.DevSuite.Components.QMenuItem qmiFileSave;
		private Qios.DevSuite.Components.QMenuItem qmiFilePrintPreview;
		private Qios.DevSuite.Components.QMenuItem qmiFilePrint;
		private Qios.DevSuite.Components.QMenuItem qmiFileSeparator1;
		private Qios.DevSuite.Components.QMenuItem qmiSavePersistence;
		private Qios.DevSuite.Components.QMenuItem qmiLoadPersistence;
		private Qios.DevSuite.Components.QMenuItem qmiFileSeparator2;
		private Qios.DevSuite.Components.QMenuItem qmiFileExit;
		private Qios.DevSuite.Components.QMenuItem qmiEdit;
		private Qios.DevSuite.Components.QMenuItem qmiEditCut;
		private Qios.DevSuite.Components.QMenuItem qmiEditCopy;
		private Qios.DevSuite.Components.QMenuItem qmiEditPaste;
		private Qios.DevSuite.Components.QMenuItem qmiEditDelete;
		private Qios.DevSuite.Components.QMenuItem qmiEditSeparator1;
		private Qios.DevSuite.Components.QMenuItem qmiEditCustomActions;
		private Qios.DevSuite.Components.QMenuItem qmiEditCustomActionsAction1;
		private Qios.DevSuite.Components.QMenuItem qmiEditCustomActionsAction2;
		private Qios.DevSuite.Components.QMenuItem qmiEditCustomActionsAction3;
		private Qios.DevSuite.Components.QMenuItem qmiEditCustomActionsAction4;
		private Qios.DevSuite.Components.QMenuItem qmiView;
		private Qios.DevSuite.Components.QMenuItem qmiViewWindows;
		private Qios.DevSuite.Components.QMenuItem qmiViewProperties;
		private Qios.DevSuite.Components.QMenuItem qmiViewTasks;
		private Qios.DevSuite.Components.QMenuItem qmiViewGlobalColorScheme;
		private Qios.DevSuite.Components.QMenuItem qmiOnPropertiesTabbed;
		private Qios.DevSuite.Components.QMenuItem qmiViewGlobalColorSchemeSeparator1;
		private Qios.DevSuite.Components.QMenuItem qmiOnPropertiesTop;
		private Qios.DevSuite.Components.QMenuItem qmiOnPropertiesBottom;
		private Qios.DevSuite.Components.QMenuItem qmiOnPropertiesLeft;
		private Qios.DevSuite.Components.QMenuItem qmiOnPropertiesRight;
		private Qios.DevSuite.Components.QMenuItem qmiViewGlobalColorSchemeSeparator2;
		private Qios.DevSuite.Components.QMenuItem qmiOnRightDockBar;
		private Qios.DevSuite.Components.QMenuItem qmiOnRichtDockBarSlidedIn;
		private Qios.DevSuite.Components.QMenuItem qmiOnRightDockBarSlidedOut;
		private Qios.DevSuite.Components.QMenuItem qmiViewGlobalColorSchemeSeparator3;
		private Qios.DevSuite.Components.QMenuItem qmiUndocked;
		private Qios.DevSuite.Components.QMenuItem qmiViewThemes;
		private Qios.DevSuite.Components.QMenuItem qmiSeparator1;
		private Qios.DevSuite.Components.QMenuItem qmiGo;
		private Qios.DevSuite.Components.QMenuItem qmiGo1;
		private Qios.DevSuite.Components.QMenuItem qmiGo2;
		private Qios.DevSuite.Components.QMenuItem qmiGo3;
		private Qios.DevSuite.Components.QMenuItem qmiTools;
		private Qios.DevSuite.Components.QMenuItem qmiActions;
		private Qios.DevSuite.Components.QMenuItem qmiActionsDockMenuLeft;
		private Qios.DevSuite.Components.QMenuItem qmiActionsDockMenuRight;
		private Qios.DevSuite.Components.QMenuItem qmiActionsDockMenuTop;
		private Qios.DevSuite.Components.QMenuItem qmiActionsDockMenuBottom;
		private System.Windows.Forms.ComboBox cboSearch;
		private Qios.DevSuite.Components.QContextMenu qcmNotifyIconMenu;
		private Qios.DevSuite.Components.QMenuItem qmiNotifyExit;
		private System.Windows.Forms.NotifyIcon niNotifyIcon;
		private Qios.DevSuite.Components.QBalloon qbNotifyBalloon;
		private Qios.DevSuite.Components.QMenuItem qmiNotifyItem1;
		private Qios.DevSuite.Components.QMenuItem qmiNotifyItem2;
		private Qios.DevSuite.Components.QMenuItem qmiNotifyItem3;
		private Qios.DevSuite.Components.QMenuItem qmiNotifyDivider;
		private Qios.DevSuite.Components.QMenuItem qmiNotifyShow;
		private Qios.DevSuite.Components.QToolItem qtiNavigationSearchControl;
		private Qios.DevSuite.Components.QCommandControlContainer qCommandControlContainer2;
		private Qios.DevSuite.Components.QMenuItem qmiFileSeperator3;
		private Qios.DevSuite.Components.QMenuItem qmiSaveColorScheme;
		private Qios.DevSuite.Components.QMenuItem qmiLoadColorScheme;
        private QMenuItem qMenuItem1;
        private QMenuItem qMenuItem2;
        private QMenuItem qMenuItem3;
        private QMenuItem qMenuItem4;
        private QMenuItem qMenuItem5;
		private Qios.DevSuite.Components.QStatusBarPanel qStatusBarPanel1;

		/// <summary>
		/// Default constructor
		/// </summary>
		public FrmMain()
		{
			InitializeComponent();

			//Create the fileName where the persistence is loaded and saved
			m_sPersistenceFileName = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			if (!m_sPersistenceFileName.EndsWith("\\")) m_sPersistenceFileName += "\\";
			m_sPersistenceFileName += "QIOS\\Qios.DevSuite.DemoZone\\TestLab - QPersistence.xml";

			//create the filename where the colorscheme is loaded and saved
			m_sColorSchemeFileName = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			if (!m_sColorSchemeFileName.EndsWith("\\")) m_sColorSchemeFileName += "\\";
			m_sColorSchemeFileName += "QIOS\\Qios.DevSuite.DemoZone\\TestLab - QColorScheme.xml";


			//create a queue for displaying events
			this.m_oStatusBarQueue = new Queue();

			//set the interval for the timer
			tmrTimedRetrievals.Interval = m_iStatusBarRefreshTime;

			//create a lot of menu items to display scrolling functionality
			QMenuItem tmp_oGoItem = this.qMainMenu1.FindMenuItem("go");
			for (int i = 4; i <= 50; i++)
			{
				QMenuItem tmp_oItem;
				if (i % 10 == 0)
				{
					//add a seperator item
					tmp_oItem = new QMenuItem(true);
					tmp_oItem.ItemName = "Separator" + (i / 10).ToString();
				}
				else
				{
					//add a menuitem
					tmp_oItem = new QMenuItem("Go " + i.ToString(), "Go" + i.ToString());
				}

				//display personalized functionality
				if (i > 25) tmp_oItem.VisibleWhenPersonalized = false;

				tmp_oGoItem.MenuItems.Add(tmp_oItem);
			}

			//retrieve the animation bitmap for the statusbar
			m_oAnimationBitmap = new Bitmap(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Images.QActionAni.gif"));

			//create a progressbar for the status bar
			m_oProgressBar = new QProgressBar();
			this.qspProgressBar.Control = m_oProgressBar;
			m_oProgressBar.BlockSize = 6;
			m_oProgressBar.BlockMargin = 1;
			m_oProgressBar.Dock = DockStyle.Fill;
			m_oProgressBar.Location = new Point(200, 10);
			m_oProgressBar.Size = new Size(50,16);
			m_oProgressBar.MaxValue = 10;

			//create a status panel for the statusbar
			m_oAppStateImageContainer = new Panel();
			m_oAppStateImageContainer.Size = new Size(60, 16);
			m_oAppStateImageContainer.Dock = DockStyle.Right;
			m_oAppStateImageContainer.BackColor = Color.Transparent;

			this.qspStatus.Control = m_oAppStateImageContainer;

			qsiAppState.StateImagesContainer = m_oAppStateImageContainer;
			qsiAppState.MainProgressBar = this.m_oProgressBar;
			qsiAppState.MainStatusBarPanel = this.qspStatus;

			this.qspDate.Text =  DateTime.Now.ToLongDateString();
			this.qspUser.Text = "info@Qios.nl";

			this.qsiAppState.SetState("RetrievalState","Downloading...","Downloading...", this.qsiAppState["RetrievalState"] + 5, QAppStateIndicatorType.AllInMain, null);		

			//show welcome screen
			FrmWelcome tmp_oFormWelcome = new FrmWelcome();
			tmp_oFormWelcome.WindowState = FormWindowState.Maximized;
			tmp_oFormWelcome.MdiParent = this;
			tmp_oFormWelcome.Show();

			//dynamically add a list of menuitems representing available themes
			this.FillThemesMenu();

			QColorScheme.Global.ColorsChanged += new EventHandler(Global_ColorsChanged);
			QColorScheme.Global.ThemesChanged +=new EventHandler(Global_ThemesChanged);

			//open the task window
			this.OpenTasks();
			//open the properties window
			this.OpenProperties();

			//set the checked option of the correct menuitem to indicate where the mainmenu is docked
			ShowCurrentMenuDockStyle();

			//Set the Static StatPanel, so that the other windows can reach it.
			FrmMain.StatusPanel = this.qspStatus;

			//select the first item of the search combobox
			this.cboSearch.SelectedIndex = 0;

		}

		protected override void OnClosed(EventArgs e)
		{
			base.OnClosed (e);

			if (niNotifyIcon != null)
			{
				niNotifyIcon.Visible = false;
				niNotifyIcon.Dispose();
				niNotifyIcon = null;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.qStatusBarPanel1 = new Qios.DevSuite.Components.QStatusBarPanel();
            this.qspProgressBar = new Qios.DevSuite.Components.QStatusBarPanelControlContainer();
            this.qsbStatusBar = new Qios.DevSuite.Components.QStatusBar();
            this.qspStatus = new Qios.DevSuite.Components.QStatusBarPanelControlContainer();
            this.qspCapsLock = new Qios.DevSuite.Components.QStatusBarPanel();
            this.qspNumLock = new Qios.DevSuite.Components.QStatusBarPanel();
            this.qspSystem = new Qios.DevSuite.Components.QStatusBarPanel();
            this.qspUser = new Qios.DevSuite.Components.QStatusBarPanel();
            this.qspDate = new Qios.DevSuite.Components.QStatusBarPanel();
            this.tmrTimedRetrievals = new System.Windows.Forms.Timer(this.components);
            this.qsiAppState = new Qios.DevSuite.Components.QAppStateIndicator(this.components);
            this.qdbDockBarLeft = new Qios.DevSuite.Components.QDockBar();
            this.qdbDockBarRight = new Qios.DevSuite.Components.QDockBar();
            this.qdbDockBarBottom = new Qios.DevSuite.Components.QDockBar();
            this.qdbDockBarTop = new Qios.DevSuite.Components.QDockBar();
            this.qMainMenu1 = new Qios.DevSuite.Components.QMainMenu();
            this.qmiFile = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileNew = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileOpen = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileOpenWelcome = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiSeparator5 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileOpenForm1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileOpenContact = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileSave = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFilePrintPreview = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFilePrint = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileSeparator1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiSavePersistence = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiLoadPersistence = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileSeparator2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiSaveColorScheme = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiLoadColorScheme = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileSeperator3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiFileExit = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEdit = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCut = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCopy = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditPaste = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditDelete = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditSeparator1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCustomActions = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCustomActionsAction1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCustomActionsAction2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCustomActionsAction3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiEditCustomActionsAction4 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiView = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewWindows = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewProperties = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewTasks = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewGlobalColorScheme = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnPropertiesTabbed = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewGlobalColorSchemeSeparator1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnPropertiesTop = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnPropertiesBottom = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnPropertiesLeft = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnPropertiesRight = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewGlobalColorSchemeSeparator2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnRightDockBar = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnRichtDockBarSlidedIn = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiOnRightDockBarSlidedOut = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewGlobalColorSchemeSeparator3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiUndocked = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiViewThemes = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiSeparator1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiGo = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiGo1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiGo2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiGo3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiTools = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiActions = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiActionsDockMenuLeft = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiActionsDockMenuRight = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiActionsDockMenuTop = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiActionsDockMenuBottom = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qMenuItem1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qMenuItem2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qMenuItem3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qgcGlobalManager = new Qios.DevSuite.Components.QGlobalColorSchemeManager(this.components);
            this.qtbhToolBarHostTop = new Qios.DevSuite.Components.QToolBarHost();
            this.qtbNavigation = new Qios.DevSuite.Components.QToolBar();
            this.qCommandControlContainer2 = new Qios.DevSuite.Components.QCommandControlContainer();
            this.cboSearch = new System.Windows.Forms.ComboBox();
            this.qtiNavigationBack = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qmiNavigationHistory1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNavigationHistory2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNavigationHistory3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qtiNavigationForward = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationSeperator1 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationStop = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationRefresh = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationHome = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationSeperator2 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationSearch = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationSearchControl = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationFavorites = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNavigationHistory = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtbToolbar = new Qios.DevSuite.Components.QToolBar();
            this.qtiNew = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qmiToolbarNewNote = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiToolbarNewMail = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiToolbarNewTask = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qtiOpen = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qmiToolbarOpenWelcome = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiToolbarOpenSeperator = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiToolbarOpenForm1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiToolbarOpenContact = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qtiSeperator1 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiPrint = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiSeperator2 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiCut = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiCopy = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiPaste = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiSeperator3 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiFind = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtbTextToolbar = new Qios.DevSuite.Components.QToolBar();
            this.qtiBold = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiItalic = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiUnderline = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiTextDivider1 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiAlignleft = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiAlignCenter = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiAlignRight = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiTextDivider2 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiNumbering = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiBullets = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiDecreaseIndent = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiIncreaseIndent = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiTextDivider3 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiTextColor = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtbhToolBarHostLeft = new Qios.DevSuite.Components.QToolBarHost();
            this.qtiLogoff = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiShutDown = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiSeperator = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtiPrint2 = new Qios.DevSuite.Components.QToolItem(this.components);
            this.qtbhToolBarHostBottom = new Qios.DevSuite.Components.QToolBarHost();
            this.qtbhToolBarHostRight = new Qios.DevSuite.Components.QToolBarHost();
            this.qpmPersistenceManager = new Qios.DevSuite.Components.QPersistenceManager(this.components);
            this.qcmNotifyIconMenu = new Qios.DevSuite.Components.QContextMenu(this.components);
            this.qmiNotifyShow = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNotifyExit = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNotifyDivider = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNotifyItem1 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNotifyItem2 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qmiNotifyItem3 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.niNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.qbNotifyBalloon = new Qios.DevSuite.Components.QBalloon();
            this.qMenuItem4 = new Qios.DevSuite.Components.QMenuItem(this.components);
            this.qMenuItem5 = new Qios.DevSuite.Components.QMenuItem(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.qMainMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostTop)).BeginInit();
            this.qtbhToolBarHostTop.SuspendLayout();
            this.qtbNavigation.SuspendLayout();
            this.qCommandControlContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostLeft)).BeginInit();
            this.qtbhToolBarHostLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostRight)).BeginInit();
            this.SuspendLayout();
            // 
            // qStatusBarPanel1
            // 
            this.qStatusBarPanel1.Icon = ((System.Drawing.Icon)(resources.GetObject("qStatusBarPanel1.Icon")));
            this.qStatusBarPanel1.IconAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.qStatusBarPanel1.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 5);
            this.qStatusBarPanel1.RequestedWidth = 19;
            // 
            // qspProgressBar
            // 
            this.qspProgressBar.CustomAppearance.ShowBorders = false;
            this.qspProgressBar.MinWidth = 50;
            this.qspProgressBar.Text = "";
            this.qspProgressBar.ToolTipText = "";
            // 
            // qsbStatusBar
            // 
            this.qsbStatusBar.Appearance.ShowBorders = false;
            this.qsbStatusBar.Location = new System.Drawing.Point(0, 534);
            this.qsbStatusBar.Name = "qsbStatusBar";
            this.qsbStatusBar.PanelAppearance.GradientAngle = 20;
            this.qsbStatusBar.PanelAppearance.GradientBlendPosition = 40;
            this.qsbStatusBar.PanelAppearance.ShowBorderBottom = false;
            this.qsbStatusBar.PanelAppearance.ShowBorderLeft = false;
            this.qsbStatusBar.PanelAppearance.ShowBorderTop = false;
            this.qsbStatusBar.PanelMarginBottom = 2;
            this.qsbStatusBar.PanelMarginTop = 3;
            this.qsbStatusBar.Panels.AddRange(new Qios.DevSuite.Components.QStatusBarPanel[] {
            this.qspStatus,
            this.qspProgressBar,
            this.qspCapsLock,
            this.qspNumLock,
            this.qspSystem,
            this.qStatusBarPanel1,
            this.qspUser,
            this.qspDate});
            this.qsbStatusBar.Size = new System.Drawing.Size(1099, 25);
            this.qsbStatusBar.TabIndex = 1;
            this.qsbStatusBar.TextVerticalMargin = 0;
            this.qsbStatusBar.PanelClick += new Qios.DevSuite.Components.QStatusBarPanelEventHandler(this.qsbStatusBar_PanelClick);
            // 
            // qspStatus
            // 
            this.qspStatus.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
            this.qspStatus.MinWidth = 50;
            this.qspStatus.Text = "";
            this.qspStatus.ToolTipText = "";
            // 
            // qspCapsLock
            // 
            this.qspCapsLock.Alignment = System.Drawing.StringAlignment.Center;
            this.qspCapsLock.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
            this.qspCapsLock.MinWidth = 25;
            this.qspCapsLock.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 5);
            this.qspCapsLock.Text = "CAP";
            this.qspCapsLock.ToolTipText = "CAP";
            // 
            // qspNumLock
            // 
            this.qspNumLock.Alignment = System.Drawing.StringAlignment.Center;
            this.qspNumLock.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
            this.qspNumLock.MinWidth = 25;
            this.qspNumLock.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 5);
            this.qspNumLock.Text = "NUM";
            this.qspNumLock.ToolTipText = "NUM";
            // 
            // qspSystem
            // 
            this.qspSystem.Alignment = System.Drawing.StringAlignment.Center;
            this.qspSystem.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
            this.qspSystem.MinWidth = 30;
            this.qspSystem.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 5);
            this.qspSystem.Text = "QWS1";
            this.qspSystem.ToolTipText = "QWS1";
            // 
            // qspUser
            // 
            this.qspUser.Alignment = System.Drawing.StringAlignment.Center;
            this.qspUser.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
            this.qspUser.MinWidth = 1;
            this.qspUser.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 5);
            this.qspUser.Text = "info@Qios.nl";
            this.qspUser.ToolTipText = "info@Qios.nl";
            // 
            // qspDate
            // 
            this.qspDate.Alignment = System.Drawing.StringAlignment.Center;
            this.qspDate.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
            this.qspDate.CustomAppearance.ShowBorders = false;
            this.qspDate.MinWidth = 50;
            this.qspDate.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 5);
            this.qspDate.Text = "";
            this.qspDate.ToolTipText = "";
            // 
            // tmrTimedRetrievals
            // 
            this.tmrTimedRetrievals.Enabled = true;
            this.tmrTimedRetrievals.Tick += new System.EventHandler(this.tmrTimedRetrievals_Tick);
            // 
            // qsiAppState
            // 
            this.qsiAppState.MainDoneText = "Ready";
            this.qsiAppState.MainToolTipText = "You have %d current operation(s)";
            // 
            // qdbDockBarLeft
            // 
            this.qdbDockBarLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.qdbDockBarLeft.Location = new System.Drawing.Point(34, 94);
            this.qdbDockBarLeft.Name = "qdbDockBarLeft";
            this.qdbDockBarLeft.PersistGuid = new System.Guid("e961cf38-0853-4fcf-80ef-20768d1a3f79");
            this.qdbDockBarLeft.Size = new System.Drawing.Size(22, 398);
            this.qdbDockBarLeft.TabIndex = 29;
            this.qdbDockBarLeft.Text = "qDockBar1";
            // 
            // qdbDockBarRight
            // 
            this.qdbDockBarRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.qdbDockBarRight.Location = new System.Drawing.Point(1057, 94);
            this.qdbDockBarRight.Name = "qdbDockBarRight";
            this.qdbDockBarRight.PersistGuid = new System.Guid("56486b86-f61e-43d9-9815-bcc532e51f15");
            this.qdbDockBarRight.Size = new System.Drawing.Size(22, 398);
            this.qdbDockBarRight.TabIndex = 31;
            this.qdbDockBarRight.Text = "qDockBar2";
            // 
            // qdbDockBarBottom
            // 
            this.qdbDockBarBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.qdbDockBarBottom.Location = new System.Drawing.Point(34, 492);
            this.qdbDockBarBottom.Name = "qdbDockBarBottom";
            this.qdbDockBarBottom.PersistGuid = new System.Guid("e559a1e5-64e5-45d3-91a8-9b65abc2f193");
            this.qdbDockBarBottom.Size = new System.Drawing.Size(1045, 22);
            this.qdbDockBarBottom.TabIndex = 32;
            this.qdbDockBarBottom.Text = "qDockBar3";
            // 
            // qdbDockBarTop
            // 
            this.qdbDockBarTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.qdbDockBarTop.Location = new System.Drawing.Point(34, 72);
            this.qdbDockBarTop.Name = "qdbDockBarTop";
            this.qdbDockBarTop.PersistGuid = new System.Guid("2eef63c5-0d21-476b-9e8b-7f3e72e29502");
            this.qdbDockBarTop.Size = new System.Drawing.Size(1045, 22);
            this.qdbDockBarTop.TabIndex = 33;
            this.qdbDockBarTop.Text = "qDockBar4";
            // 
            // qMainMenu1
            // 
            this.qMainMenu1.Appearance.ShowBorders = false;
            this.qMainMenu1.Dock = System.Windows.Forms.DockStyle.None;
            this.qMainMenu1.Form = this;
            this.qMainMenu1.Location = new System.Drawing.Point(2, 2);
            this.qMainMenu1.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiFile,
            this.qmiEdit,
            this.qmiView,
            this.qmiSeparator1,
            this.qmiGo,
            this.qmiTools,
            this.qmiActions,
            this.qMenuItem1});
            this.qMainMenu1.Name = "qMainMenu1";
            this.qMainMenu1.PersistGuid = new System.Guid("efcc8e76-f894-43ab-8339-6dee5c2d2687");
            this.qMainMenu1.RowIndex = 0;
            this.qMainMenu1.Size = new System.Drawing.Size(1095, 30);
            this.qMainMenu1.TabIndex = 37;
            this.qMainMenu1.Text = "Main menu";
            this.qMainMenu1.ToolBarIndex = 0;
            this.qMainMenu1.MenuItemSelected += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuItemSelected);
            this.qMainMenu1.MenuItemActivating += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuItemActivating);
            this.qMainMenu1.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.qMainMenu1_MenuItemActivated);
            this.qMainMenu1.MenuShowing += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuShowing);
            this.qMainMenu1.MenuShowed += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuShowed);
            this.qMainMenu1.ParentChanged += new System.EventHandler(this.qMainMenu1_ParentChanged);
            // 
            // qmiFile
            // 
            this.qmiFile.ItemName = "File";
            this.qmiFile.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiFileNew,
            this.qmiFileOpen,
            this.qmiFileSave,
            this.qmiFilePrintPreview,
            this.qmiFilePrint,
            this.qmiFileSeparator1,
            this.qmiSavePersistence,
            this.qmiLoadPersistence,
            this.qmiFileSeparator2,
            this.qmiSaveColorScheme,
            this.qmiLoadColorScheme,
            this.qmiFileSeperator3,
            this.qmiFileExit});
            this.qmiFile.Shortcut = System.Windows.Forms.Shortcut.CtrlF;
            this.qmiFile.Title = "&File";
            this.qmiFile.ToolTip = "File";
            // 
            // qmiFileNew
            // 
            this.qmiFileNew.IconResourceName = "Qios.DevSuite.DemoZone.Icons.New.ico, Qios.DevSuite.DemoZone";
            this.qmiFileNew.ItemName = "New";
            this.qmiFileNew.Title = "New";
            this.qmiFileNew.ToolTip = "New";
            // 
            // qmiFileOpen
            // 
            this.qmiFileOpen.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Open.ico, Qios.DevSuite.DemoZone";
            this.qmiFileOpen.ItemName = "Open";
            this.qmiFileOpen.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiFileOpenWelcome,
            this.qmiSeparator5,
            this.qmiFileOpenForm1,
            this.qmiFileOpenContact});
            this.qmiFileOpen.Title = "Open";
            this.qmiFileOpen.ToolTip = "Open";
            // 
            // qmiFileOpenWelcome
            // 
            this.qmiFileOpenWelcome.ItemName = "Welcome";
            this.qmiFileOpenWelcome.Title = "&Welcome";
            this.qmiFileOpenWelcome.ToolTip = "Welcome";
            // 
            // qmiSeparator5
            // 
            this.qmiSeparator5.IsSeparator = true;
            this.qmiSeparator5.ItemName = "Separator1";
            // 
            // qmiFileOpenForm1
            // 
            this.qmiFileOpenForm1.ItemName = "OpenForm1";
            this.qmiFileOpenForm1.Shortcut = System.Windows.Forms.Shortcut.AltF1;
            this.qmiFileOpenForm1.Title = "Open Form &1";
            this.qmiFileOpenForm1.ToolTip = "Open Form 1";
            // 
            // qmiFileOpenContact
            // 
            this.qmiFileOpenContact.ItemName = "OpenContact";
            this.qmiFileOpenContact.Title = "Open &Contact";
            this.qmiFileOpenContact.ToolTip = "Open Contact";
            // 
            // qmiFileSave
            // 
            this.qmiFileSave.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Save.ico, Qios.DevSuite.DemoZone";
            this.qmiFileSave.ItemName = "Save";
            this.qmiFileSave.Title = "Save";
            this.qmiFileSave.ToolTip = "Save";
            // 
            // qmiFilePrintPreview
            // 
            this.qmiFilePrintPreview.IconResourceName = "Qios.DevSuite.DemoZone.Icons.PrintPreview.ico, Qios.DevSuite.DemoZone";
            this.qmiFilePrintPreview.ItemName = "PrintPreview";
            this.qmiFilePrintPreview.Title = "Print Preview";
            this.qmiFilePrintPreview.ToolTip = "Print Preview";
            this.qmiFilePrintPreview.VisibleWhenPersonalized = false;
            // 
            // qmiFilePrint
            // 
            this.qmiFilePrint.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Print.ico, Qios.DevSuite.DemoZone";
            this.qmiFilePrint.ItemName = "Print";
            this.qmiFilePrint.Title = "Print";
            this.qmiFilePrint.ToolTip = "Print";
            // 
            // qmiFileSeparator1
            // 
            this.qmiFileSeparator1.IsSeparator = true;
            this.qmiFileSeparator1.ItemName = "Separator1";
            // 
            // qmiSavePersistence
            // 
            this.qmiSavePersistence.ItemName = "SavePersistence";
            this.qmiSavePersistence.Title = "Save persistence";
            this.qmiSavePersistence.ToolTip = "Save persistence";
            // 
            // qmiLoadPersistence
            // 
            this.qmiLoadPersistence.ItemName = "LoadPersistence";
            this.qmiLoadPersistence.Title = "Load Persistence";
            this.qmiLoadPersistence.ToolTip = "Load Persistence";
            // 
            // qmiFileSeparator2
            // 
            this.qmiFileSeparator2.IsSeparator = true;
            this.qmiFileSeparator2.ItemName = "Separator2";
            // 
            // qmiSaveColorScheme
            // 
            this.qmiSaveColorScheme.ItemName = "SaveColorScheme";
            this.qmiSaveColorScheme.Title = "Save global colorscheme";
            // 
            // qmiLoadColorScheme
            // 
            this.qmiLoadColorScheme.ItemName = "LoadColorScheme";
            this.qmiLoadColorScheme.Title = "Load global colorscheme";
            // 
            // qmiFileSeperator3
            // 
            this.qmiFileSeperator3.IsSeparator = true;
            // 
            // qmiFileExit
            // 
            this.qmiFileExit.ItemName = "Exit";
            this.qmiFileExit.Shortcut = System.Windows.Forms.Shortcut.AltF4;
            this.qmiFileExit.Title = "Exit";
            this.qmiFileExit.ToolTip = "Exit";
            // 
            // qmiEdit
            // 
            this.qmiEdit.ItemName = "Edit";
            this.qmiEdit.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiEditCut,
            this.qmiEditCopy,
            this.qmiEditPaste,
            this.qmiEditDelete,
            this.qmiEditSeparator1,
            this.qmiEditCustomActions});
            this.qmiEdit.Shortcut = System.Windows.Forms.Shortcut.CtrlE;
            this.qmiEdit.Title = "&Edit";
            this.qmiEdit.ToolTip = "Edit";
            // 
            // qmiEditCut
            // 
            this.qmiEditCut.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Cut.ico, Qios.DevSuite.DemoZone";
            this.qmiEditCut.ItemName = "Cut";
            this.qmiEditCut.Shortcut = System.Windows.Forms.Shortcut.CtrlX;
            this.qmiEditCut.Title = "Cu&t";
            this.qmiEditCut.ToolTip = "Cut";
            this.qmiEditCut.VisibleWhenPersonalized = false;
            // 
            // qmiEditCopy
            // 
            this.qmiEditCopy.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Copy.ico, Qios.DevSuite.DemoZone";
            this.qmiEditCopy.ItemName = "Copy";
            this.qmiEditCopy.Shortcut = System.Windows.Forms.Shortcut.CtrlC;
            this.qmiEditCopy.Title = "&Copy";
            this.qmiEditCopy.ToolTip = "Copy";
            // 
            // qmiEditPaste
            // 
            this.qmiEditPaste.Enabled = false;
            this.qmiEditPaste.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Paste.ico, Qios.DevSuite.DemoZone";
            this.qmiEditPaste.ItemName = "Paste";
            this.qmiEditPaste.Shortcut = System.Windows.Forms.Shortcut.CtrlP;
            this.qmiEditPaste.Title = "&Paste";
            this.qmiEditPaste.ToolTip = "Paste";
            // 
            // qmiEditDelete
            // 
            this.qmiEditDelete.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Delete.ico, Qios.DevSuite.DemoZone";
            this.qmiEditDelete.ItemName = "Delete";
            this.qmiEditDelete.Shortcut = System.Windows.Forms.Shortcut.CtrlDel;
            this.qmiEditDelete.Title = "&Delete";
            this.qmiEditDelete.ToolTip = "Delete";
            // 
            // qmiEditSeparator1
            // 
            this.qmiEditSeparator1.IsSeparator = true;
            this.qmiEditSeparator1.ItemName = "Separator1";
            this.qmiEditSeparator1.Title = "-";
            this.qmiEditSeparator1.ToolTip = "-";
            this.qmiEditSeparator1.VisibleWhenPersonalized = false;
            // 
            // qmiEditCustomActions
            // 
            this.qmiEditCustomActions.ItemName = "CustomActions";
            this.qmiEditCustomActions.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiEditCustomActionsAction1,
            this.qmiEditCustomActionsAction2,
            this.qmiEditCustomActionsAction3,
            this.qmiEditCustomActionsAction4});
            this.qmiEditCustomActions.Title = "Custom &Actions";
            this.qmiEditCustomActions.ToolTip = "Custom Actions";
            this.qmiEditCustomActions.VisibleWhenPersonalized = false;
            // 
            // qmiEditCustomActionsAction1
            // 
            this.qmiEditCustomActionsAction1.ItemName = "Action1";
            this.qmiEditCustomActionsAction1.Shortcut = System.Windows.Forms.Shortcut.Ctrl1;
            this.qmiEditCustomActionsAction1.Title = "Action &1";
            this.qmiEditCustomActionsAction1.ToolTip = "Action 1";
            this.qmiEditCustomActionsAction1.UserHasRightToExecute = false;
            // 
            // qmiEditCustomActionsAction2
            // 
            this.qmiEditCustomActionsAction2.ItemName = "Action2";
            this.qmiEditCustomActionsAction2.Shortcut = System.Windows.Forms.Shortcut.Ctrl2;
            this.qmiEditCustomActionsAction2.Title = "Action &2";
            this.qmiEditCustomActionsAction2.ToolTip = "Action 2";
            this.qmiEditCustomActionsAction2.VisibleWhenPersonalized = false;
            // 
            // qmiEditCustomActionsAction3
            // 
            this.qmiEditCustomActionsAction3.ItemName = "Action3";
            this.qmiEditCustomActionsAction3.Shortcut = System.Windows.Forms.Shortcut.Ctrl3;
            this.qmiEditCustomActionsAction3.Title = "Action &3";
            this.qmiEditCustomActionsAction3.ToolTip = "Action 3";
            this.qmiEditCustomActionsAction3.VisibleWhenPersonalized = false;
            // 
            // qmiEditCustomActionsAction4
            // 
            this.qmiEditCustomActionsAction4.ItemName = "Action4";
            this.qmiEditCustomActionsAction4.Shortcut = System.Windows.Forms.Shortcut.Ctrl4;
            this.qmiEditCustomActionsAction4.Title = "Action &4";
            this.qmiEditCustomActionsAction4.ToolTip = "Action 4";
            // 
            // qmiView
            // 
            this.qmiView.ItemName = "View";
            this.qmiView.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiViewWindows,
            this.qmiViewThemes});
            this.qmiView.Shortcut = System.Windows.Forms.Shortcut.CtrlI;
            this.qmiView.Title = "&View";
            this.qmiView.ToolTip = "View";
            // 
            // qmiViewWindows
            // 
            this.qmiViewWindows.ItemName = "Windows";
            this.qmiViewWindows.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiViewProperties,
            this.qmiViewTasks,
            this.qmiViewGlobalColorScheme});
            this.qmiViewWindows.Title = "Windows";
            this.qmiViewWindows.ToolTip = "Windows";
            // 
            // qmiViewProperties
            // 
            this.qmiViewProperties.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Properties.ico, Qios.DevSuite.DemoZone";
            this.qmiViewProperties.ItemName = "Properties";
            this.qmiViewProperties.Shortcut = System.Windows.Forms.Shortcut.F2;
            this.qmiViewProperties.Title = "Properties";
            this.qmiViewProperties.ToolTip = "Properties";
            // 
            // qmiViewTasks
            // 
            this.qmiViewTasks.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Tasks.ico, Qios.DevSuite.DemoZone";
            this.qmiViewTasks.ItemName = "Tasks";
            this.qmiViewTasks.Title = "Tasks";
            this.qmiViewTasks.ToolTip = "Tasks";
            // 
            // qmiViewGlobalColorScheme
            // 
            this.qmiViewGlobalColorScheme.IconResourceName = "Qios.DevSuite.DemoZone.Icons.ColorScheme.ico, Qios.DevSuite.DemoZone";
            this.qmiViewGlobalColorScheme.ItemName = "GlobalColorScheme";
            this.qmiViewGlobalColorScheme.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiOnPropertiesTabbed,
            this.qmiViewGlobalColorSchemeSeparator1,
            this.qmiOnPropertiesTop,
            this.qmiOnPropertiesBottom,
            this.qmiOnPropertiesLeft,
            this.qmiOnPropertiesRight,
            this.qmiViewGlobalColorSchemeSeparator2,
            this.qmiOnRightDockBar,
            this.qmiOnRichtDockBarSlidedIn,
            this.qmiOnRightDockBarSlidedOut,
            this.qmiViewGlobalColorSchemeSeparator3,
            this.qmiUndocked});
            this.qmiViewGlobalColorScheme.Title = "Global Colorscheme";
            this.qmiViewGlobalColorScheme.ToolTip = "Global Colorscheme";
            // 
            // qmiOnPropertiesTabbed
            // 
            this.qmiOnPropertiesTabbed.ItemName = "OnPropertiesTabbed";
            this.qmiOnPropertiesTabbed.Shortcut = System.Windows.Forms.Shortcut.F3;
            this.qmiOnPropertiesTabbed.Title = "On Properties T&abbed";
            this.qmiOnPropertiesTabbed.ToolTip = "On Properties Tabbed";
            // 
            // qmiViewGlobalColorSchemeSeparator1
            // 
            this.qmiViewGlobalColorSchemeSeparator1.IsSeparator = true;
            this.qmiViewGlobalColorSchemeSeparator1.ItemName = "Separator1";
            this.qmiViewGlobalColorSchemeSeparator1.VisibleWhenPersonalized = false;
            // 
            // qmiOnPropertiesTop
            // 
            this.qmiOnPropertiesTop.ItemName = "OnPropertiesTop";
            this.qmiOnPropertiesTop.Title = "On Properties &Top";
            this.qmiOnPropertiesTop.ToolTip = "On Properties Top";
            this.qmiOnPropertiesTop.VisibleWhenPersonalized = false;
            // 
            // qmiOnPropertiesBottom
            // 
            this.qmiOnPropertiesBottom.ItemName = "OnPropertiesBottom";
            this.qmiOnPropertiesBottom.Title = "On Properties &Bottom";
            this.qmiOnPropertiesBottom.ToolTip = "On Properties Bottom";
            this.qmiOnPropertiesBottom.VisibleWhenPersonalized = false;
            // 
            // qmiOnPropertiesLeft
            // 
            this.qmiOnPropertiesLeft.ItemName = "OnPropertiesLeft";
            this.qmiOnPropertiesLeft.Title = "On Properties &Left";
            this.qmiOnPropertiesLeft.ToolTip = "On Properties Left";
            this.qmiOnPropertiesLeft.VisibleWhenPersonalized = false;
            // 
            // qmiOnPropertiesRight
            // 
            this.qmiOnPropertiesRight.ItemName = "OnPropertiesRight";
            this.qmiOnPropertiesRight.Title = "On Properties &Right";
            this.qmiOnPropertiesRight.ToolTip = "On Properties Right";
            this.qmiOnPropertiesRight.VisibleWhenPersonalized = false;
            // 
            // qmiViewGlobalColorSchemeSeparator2
            // 
            this.qmiViewGlobalColorSchemeSeparator2.IsSeparator = true;
            this.qmiViewGlobalColorSchemeSeparator2.ItemName = "Separator2";
            this.qmiViewGlobalColorSchemeSeparator2.VisibleWhenPersonalized = false;
            // 
            // qmiOnRightDockBar
            // 
            this.qmiOnRightDockBar.ItemName = "OnRightDockBar";
            this.qmiOnRightDockBar.Shortcut = System.Windows.Forms.Shortcut.CtrlF3;
            this.qmiOnRightDockBar.Title = "On Right &DockBar";
            this.qmiOnRightDockBar.ToolTip = "On Right DockBar";
            // 
            // qmiOnRichtDockBarSlidedIn
            // 
            this.qmiOnRichtDockBarSlidedIn.ItemName = "OnRightDockBarSlidedIn";
            this.qmiOnRichtDockBarSlidedIn.Shortcut = System.Windows.Forms.Shortcut.CtrlF4;
            this.qmiOnRichtDockBarSlidedIn.Title = "On Right DockBar Slided &In";
            this.qmiOnRichtDockBarSlidedIn.ToolTip = "On Right DockBar Slided In";
            // 
            // qmiOnRightDockBarSlidedOut
            // 
            this.qmiOnRightDockBarSlidedOut.ItemName = "OnRightDockBarSlidedOut";
            this.qmiOnRightDockBarSlidedOut.Shortcut = System.Windows.Forms.Shortcut.CtrlF5;
            this.qmiOnRightDockBarSlidedOut.Title = "On Right DockBar Slided &Out";
            this.qmiOnRightDockBarSlidedOut.ToolTip = "On Right DockBar Slided Out";
            // 
            // qmiViewGlobalColorSchemeSeparator3
            // 
            this.qmiViewGlobalColorSchemeSeparator3.IsSeparator = true;
            this.qmiViewGlobalColorSchemeSeparator3.ItemName = "Separator3";
            // 
            // qmiUndocked
            // 
            this.qmiUndocked.ItemName = "Undocked";
            this.qmiUndocked.Shortcut = System.Windows.Forms.Shortcut.CtrlF6;
            this.qmiUndocked.Title = "&Undocked";
            this.qmiUndocked.ToolTip = "Undocked";
            // 
            // qmiViewThemes
            // 
            this.qmiViewThemes.ItemName = "Themes";
            this.qmiViewThemes.Title = "Themes";
            this.qmiViewThemes.ToolTip = "Themes";
            // 
            // qmiSeparator1
            // 
            this.qmiSeparator1.IsSeparator = true;
            this.qmiSeparator1.ItemName = "Separator1";
            this.qmiSeparator1.Title = "-";
            this.qmiSeparator1.ToolTip = "-";
            // 
            // qmiGo
            // 
            this.qmiGo.ItemName = "Go";
            this.qmiGo.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiGo1,
            this.qmiGo2,
            this.qmiGo3});
            this.qmiGo.Shortcut = System.Windows.Forms.Shortcut.CtrlG;
            this.qmiGo.Title = "&Go";
            this.qmiGo.ToolTip = "Go";
            // 
            // qmiGo1
            // 
            this.qmiGo1.ItemName = "Go1";
            this.qmiGo1.Title = "Go 1";
            this.qmiGo1.ToolTip = "Go 1";
            // 
            // qmiGo2
            // 
            this.qmiGo2.ItemName = "Go2";
            this.qmiGo2.Title = "Go 2";
            this.qmiGo2.ToolTip = "Go 2";
            // 
            // qmiGo3
            // 
            this.qmiGo3.ItemName = "Go3";
            this.qmiGo3.Title = "&Go 3";
            this.qmiGo3.ToolTip = "Go 3";
            // 
            // qmiTools
            // 
            this.qmiTools.ItemName = "Tools";
            this.qmiTools.Title = "&Tools";
            this.qmiTools.ToolTip = "Tools";
            // 
            // qmiActions
            // 
            this.qmiActions.ItemName = "Actions";
            this.qmiActions.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiActionsDockMenuLeft,
            this.qmiActionsDockMenuRight,
            this.qmiActionsDockMenuTop,
            this.qmiActionsDockMenuBottom});
            this.qmiActions.Title = "&Actions";
            this.qmiActions.ToolTip = "Actions";
            // 
            // qmiActionsDockMenuLeft
            // 
            this.qmiActionsDockMenuLeft.ItemName = "DockMenuLeft";
            this.qmiActionsDockMenuLeft.Title = "Dock menu left";
            this.qmiActionsDockMenuLeft.ToolTip = "Dock menu left";
            // 
            // qmiActionsDockMenuRight
            // 
            this.qmiActionsDockMenuRight.ItemName = "DockMenuRight";
            this.qmiActionsDockMenuRight.Title = "Dock menu right";
            this.qmiActionsDockMenuRight.ToolTip = "Dock menu right";
            // 
            // qmiActionsDockMenuTop
            // 
            this.qmiActionsDockMenuTop.ItemName = "DockMenuTop";
            this.qmiActionsDockMenuTop.Title = "Dock menu top";
            this.qmiActionsDockMenuTop.ToolTip = "Dock menu top";
            // 
            // qmiActionsDockMenuBottom
            // 
            this.qmiActionsDockMenuBottom.ItemName = "DockMenuBottom";
            this.qmiActionsDockMenuBottom.Title = "Dock menu bottom";
            this.qmiActionsDockMenuBottom.ToolTip = "Dock menu bottom";
            // 
            // qMenuItem1
            // 
            this.qMenuItem1.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qMenuItem2});
            this.qMenuItem1.Title = "Test12";
            // 
            // qMenuItem2
            // 
            this.qMenuItem2.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qMenuItem3});
            this.qMenuItem2.Title = "Test13";
            // 
            // qMenuItem3
            // 
            this.qMenuItem3.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qMenuItem4});
            this.qMenuItem3.Title = "Test14";
            // 
            // qtbhToolBarHostTop
            // 
            this.qtbhToolBarHostTop.Controls.Add(this.qMainMenu1);
            this.qtbhToolBarHostTop.Controls.Add(this.qtbNavigation);
            this.qtbhToolBarHostTop.Controls.Add(this.qtbToolbar);
            this.qtbhToolBarHostTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.qtbhToolBarHostTop.Location = new System.Drawing.Point(0, 0);
            this.qtbhToolBarHostTop.Name = "qtbhToolBarHostTop";
            this.qtbhToolBarHostTop.PersistGuid = new System.Guid("c8186000-9a18-458a-b597-8b5bd0f7ba42");
            this.qtbhToolBarHostTop.Size = new System.Drawing.Size(1099, 72);
            this.qtbhToolBarHostTop.TabIndex = 41;
            // 
            // qtbNavigation
            // 
            this.qtbNavigation.Configuration.IconSize = new System.Drawing.Size(24, 24);
            this.qtbNavigation.Configuration.ItemPadding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
            this.qtbNavigation.Controls.Add(this.qCommandControlContainer2);
            this.qtbNavigation.Location = new System.Drawing.Point(317, 34);
            this.qtbNavigation.Name = "qtbNavigation";
            this.qtbNavigation.PersistGuid = new System.Guid("82ed222b-6664-451e-bf68-67849cbe5f57");
            this.qtbNavigation.RowIndex = 1;
            this.qtbNavigation.Size = new System.Drawing.Size(566, 36);
            this.qtbNavigation.TabIndex = 47;
            this.qtbNavigation.Text = "Navigation";
            this.qtbNavigation.ToolBarIndex = 2;
            this.qtbNavigation.ToolItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qtiNavigationBack,
            this.qtiNavigationForward,
            this.qtiNavigationSeperator1,
            this.qtiNavigationStop,
            this.qtiNavigationRefresh,
            this.qtiNavigationHome,
            this.qtiNavigationSeperator2,
            this.qtiNavigationSearch,
            this.qtiNavigationSearchControl,
            this.qtiNavigationFavorites,
            this.qtiNavigationHistory});
            this.qtbNavigation.MenuItemSelected += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuItemSelected);
            this.qtbNavigation.MenuItemActivating += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuItemActivating);
            this.qtbNavigation.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuItemActivated);
            this.qtbNavigation.MenuShowing += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuShowing);
            this.qtbNavigation.MenuShowed += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuShowed);
            // 
            // qCommandControlContainer2
            // 
            this.qCommandControlContainer2.Controls.Add(this.cboSearch);
            this.qCommandControlContainer2.Name = "qCommandControlContainer2";
            this.qCommandControlContainer2.PreferredSize = new System.Drawing.Size(121, 24);
            this.qCommandControlContainer2.Size = new System.Drawing.Size(121, 24);
            this.qCommandControlContainer2.TabIndex = 1;
            // 
            // cboSearch
            // 
            this.cboSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSearch.Items.AddRange(new object[] {
            "Contacts",
            "Files",
            "Keywords"});
            this.cboSearch.Location = new System.Drawing.Point(0, 0);
            this.cboSearch.Name = "cboSearch";
            this.cboSearch.Size = new System.Drawing.Size(121, 23);
            this.cboSearch.TabIndex = 0;
            // 
            // qtiNavigationBack
            // 
            this.qtiNavigationBack.CheckedIcon = ((System.Drawing.Icon)(resources.GetObject("qtiNavigationBack.CheckedIcon")));
            this.qtiNavigationBack.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Back.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationBack.ItemName = "back";
            this.qtiNavigationBack.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiNavigationHistory1,
            this.qmiNavigationHistory2,
            this.qmiNavigationHistory3});
            this.qtiNavigationBack.Title = "Back";
            this.qtiNavigationBack.ToolTip = "Back";
            // 
            // qmiNavigationHistory1
            // 
            this.qmiNavigationHistory1.ItemName = "History1";
            this.qmiNavigationHistory1.Title = "History item 1";
            this.qmiNavigationHistory1.ToolTip = "History item 1";
            // 
            // qmiNavigationHistory2
            // 
            this.qmiNavigationHistory2.ItemName = "History2";
            this.qmiNavigationHistory2.Title = "History item 2";
            this.qmiNavigationHistory2.ToolTip = "History item 2";
            // 
            // qmiNavigationHistory3
            // 
            this.qmiNavigationHistory3.ItemName = "History3";
            this.qmiNavigationHistory3.Title = "History item 3";
            this.qmiNavigationHistory3.ToolTip = "History item 3";
            // 
            // qtiNavigationForward
            // 
            this.qtiNavigationForward.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Forward.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationForward.ItemName = "forward";
            this.qtiNavigationForward.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiNavigationForward.Title = "Forward";
            this.qtiNavigationForward.ToolTip = "Forward";
            // 
            // qtiNavigationSeperator1
            // 
            this.qtiNavigationSeperator1.IsSeparator = true;
            this.qtiNavigationSeperator1.ItemName = "Separator1";
            // 
            // qtiNavigationStop
            // 
            this.qtiNavigationStop.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Stop.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationStop.ItemName = "Stop";
            this.qtiNavigationStop.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiNavigationStop.Title = "Stop";
            this.qtiNavigationStop.ToolTip = "Stop";
            // 
            // qtiNavigationRefresh
            // 
            this.qtiNavigationRefresh.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Refresh.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationRefresh.ItemName = "Refresh";
            this.qtiNavigationRefresh.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiNavigationRefresh.Title = "Refresh";
            this.qtiNavigationRefresh.ToolTip = "Refresh";
            // 
            // qtiNavigationHome
            // 
            this.qtiNavigationHome.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Home.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationHome.ItemName = "Home";
            this.qtiNavigationHome.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiNavigationHome.Title = "Home";
            this.qtiNavigationHome.ToolTip = "Home";
            // 
            // qtiNavigationSeperator2
            // 
            this.qtiNavigationSeperator2.IsSeparator = true;
            this.qtiNavigationSeperator2.ItemName = "Separator2";
            // 
            // qtiNavigationSearch
            // 
            this.qtiNavigationSearch.IconResourceName = "Qios.DevSuite.DemoZone.Icons.SearchDocument.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationSearch.ItemName = "Search";
            this.qtiNavigationSearch.Title = "Search";
            this.qtiNavigationSearch.ToolTip = "Search";
            // 
            // qtiNavigationSearchControl
            // 
            this.qtiNavigationSearchControl.Control = this.qCommandControlContainer2;
            this.qtiNavigationSearchControl.ItemName = "SearchControl";
            this.qtiNavigationSearchControl.Title = "";
            this.qtiNavigationSearchControl.ToolTip = "";
            // 
            // qtiNavigationFavorites
            // 
            this.qtiNavigationFavorites.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Fav.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationFavorites.ItemName = "Favorites";
            this.qtiNavigationFavorites.Title = "Favorites";
            this.qtiNavigationFavorites.ToolTip = "Favorites";
            // 
            // qtiNavigationHistory
            // 
            this.qtiNavigationHistory.IconResourceName = "Qios.DevSuite.DemoZone.Icons.History.ico, Qios.DevSuite.DemoZone";
            this.qtiNavigationHistory.ItemName = "History";
            this.qtiNavigationHistory.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiNavigationHistory.Title = "History";
            this.qtiNavigationHistory.ToolTip = "History";
            // 
            // qtbToolbar
            // 
            this.qtbToolbar.Location = new System.Drawing.Point(2, 34);
            this.qtbToolbar.Name = "qtbToolbar";
            this.qtbToolbar.PersistGuid = new System.Guid("7dbded1a-f707-4b20-a233-70c09145d8f4");
            this.qtbToolbar.RowIndex = 1;
            this.qtbToolbar.Size = new System.Drawing.Size(313, 36);
            this.qtbToolbar.TabIndex = 41;
            this.qtbToolbar.Text = "Standard";
            this.qtbToolbar.ToolBarIndex = 0;
            this.qtbToolbar.ToolItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qtiNew,
            this.qtiOpen,
            this.qtiSeperator1,
            this.qtiPrint,
            this.qtiSeperator2,
            this.qtiCut,
            this.qtiCopy,
            this.qtiPaste,
            this.qtiSeperator3,
            this.qtiFind});
            this.qtbToolbar.MenuItemSelected += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuItemSelected);
            this.qtbToolbar.MenuItemActivating += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuItemActivating);
            this.qtbToolbar.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.qtbToolbar_MenuItemActivated);
            this.qtbToolbar.MenuShowing += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuShowing);
            this.qtbToolbar.MenuShowed += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuShowed);
            // 
            // qtiNew
            // 
            this.qtiNew.IconResourceName = "Qios.DevSuite.DemoZone.Icons.New.ico, Qios.DevSuite.DemoZone";
            this.qtiNew.ItemName = "New";
            this.qtiNew.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiToolbarNewNote,
            this.qmiToolbarNewMail,
            this.qmiToolbarNewTask});
            this.qtiNew.Title = "New";
            this.qtiNew.ToolTip = "New";
            // 
            // qmiToolbarNewNote
            // 
            this.qmiToolbarNewNote.IconResourceName = "Qios.DevSuite.DemoZone.Icons.New.ico, Qios.DevSuite.DemoZone";
            this.qmiToolbarNewNote.ItemName = "Note";
            this.qmiToolbarNewNote.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qMenuItem5});
            this.qmiToolbarNewNote.Title = "Note";
            this.qmiToolbarNewNote.ToolTip = "Note";
            // 
            // qmiToolbarNewMail
            // 
            this.qmiToolbarNewMail.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Mail.ico, Qios.DevSuite.DemoZone";
            this.qmiToolbarNewMail.ItemName = "Mail";
            this.qmiToolbarNewMail.Title = "Mail";
            this.qmiToolbarNewMail.ToolTip = "Mail";
            // 
            // qmiToolbarNewTask
            // 
            this.qmiToolbarNewTask.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Tasks.ico, Qios.DevSuite.DemoZone";
            this.qmiToolbarNewTask.ItemName = "Task";
            this.qmiToolbarNewTask.Title = "Task";
            this.qmiToolbarNewTask.ToolTip = "Task";
            // 
            // qtiOpen
            // 
            this.qtiOpen.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Open.ico, Qios.DevSuite.DemoZone";
            this.qtiOpen.ItemName = "Open";
            this.qtiOpen.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiToolbarOpenWelcome,
            this.qmiToolbarOpenSeperator,
            this.qmiToolbarOpenForm1,
            this.qmiToolbarOpenContact});
            this.qtiOpen.Title = "Open";
            this.qtiOpen.ToolTip = "Open";
            // 
            // qmiToolbarOpenWelcome
            // 
            this.qmiToolbarOpenWelcome.ItemName = "OpenWelcome";
            this.qmiToolbarOpenWelcome.Title = "Welcome";
            this.qmiToolbarOpenWelcome.ToolTip = "Welcome";
            // 
            // qmiToolbarOpenSeperator
            // 
            this.qmiToolbarOpenSeperator.IsSeparator = true;
            this.qmiToolbarOpenSeperator.ItemName = "Separator1";
            // 
            // qmiToolbarOpenForm1
            // 
            this.qmiToolbarOpenForm1.ItemName = "OpenForm1";
            this.qmiToolbarOpenForm1.Title = "Open Form 1";
            this.qmiToolbarOpenForm1.ToolTip = "Open Form 1";
            // 
            // qmiToolbarOpenContact
            // 
            this.qmiToolbarOpenContact.ItemName = "OpenContact";
            this.qmiToolbarOpenContact.Title = "Open Contact";
            this.qmiToolbarOpenContact.ToolTip = "Open Contact";
            // 
            // qtiSeperator1
            // 
            this.qtiSeperator1.IsSeparator = true;
            this.qtiSeperator1.ItemName = "Separator1";
            // 
            // qtiPrint
            // 
            this.qtiPrint.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Print.ico, Qios.DevSuite.DemoZone";
            this.qtiPrint.ItemName = "Print";
            this.qtiPrint.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiPrint.Title = "Print";
            this.qtiPrint.ToolTip = "Print";
            // 
            // qtiSeperator2
            // 
            this.qtiSeperator2.IsSeparator = true;
            this.qtiSeperator2.ItemName = "Separator2";
            // 
            // qtiCut
            // 
            this.qtiCut.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Cut.ico, Qios.DevSuite.DemoZone";
            this.qtiCut.ItemName = "Cut";
            this.qtiCut.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiCut.Title = "Cut";
            this.qtiCut.ToolTip = "Cut";
            // 
            // qtiCopy
            // 
            this.qtiCopy.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Copy.ico, Qios.DevSuite.DemoZone";
            this.qtiCopy.ItemName = "Copy";
            this.qtiCopy.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiCopy.Title = "Copy";
            this.qtiCopy.ToolTip = "Copy";
            // 
            // qtiPaste
            // 
            this.qtiPaste.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Paste.ico, Qios.DevSuite.DemoZone";
            this.qtiPaste.ItemName = "Paste";
            this.qtiPaste.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiPaste.Title = "Paste";
            this.qtiPaste.ToolTip = "Paste";
            // 
            // qtiSeperator3
            // 
            this.qtiSeperator3.IsSeparator = true;
            this.qtiSeperator3.ItemName = "Separator3";
            // 
            // qtiFind
            // 
            this.qtiFind.IconResourceName = "Qios.DevSuite.DemoZone.Icons.SearchDocument.ico, Qios.DevSuite.DemoZone";
            this.qtiFind.ItemName = "Find";
            this.qtiFind.Title = "Find";
            this.qtiFind.ToolTip = "Find";
            // 
            // qtbTextToolbar
            // 
            this.qtbTextToolbar.Location = new System.Drawing.Point(2, 2);
            this.qtbTextToolbar.Name = "qtbTextToolbar";
            this.qtbTextToolbar.PersistGuid = new System.Guid("c14251fb-4c52-402b-bac5-5dbefa2783a4");
            this.qtbTextToolbar.RowIndex = 1;
            this.qtbTextToolbar.Size = new System.Drawing.Size(30, 277);
            this.qtbTextToolbar.TabIndex = 43;
            this.qtbTextToolbar.Text = "Formatting";
            this.qtbTextToolbar.ToolBarIndex = 1;
            this.qtbTextToolbar.ToolItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qtiBold,
            this.qtiItalic,
            this.qtiUnderline,
            this.qtiTextDivider1,
            this.qtiAlignleft,
            this.qtiAlignCenter,
            this.qtiAlignRight,
            this.qtiTextDivider2,
            this.qtiNumbering,
            this.qtiBullets,
            this.qtiDecreaseIndent,
            this.qtiIncreaseIndent,
            this.qtiTextDivider3,
            this.qtiTextColor});
            this.qtbTextToolbar.MenuItemSelected += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuItemSelected);
            this.qtbTextToolbar.MenuItemActivating += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuItemActivating);
            this.qtbTextToolbar.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuItemActivated);
            this.qtbTextToolbar.MenuShowing += new Qios.DevSuite.Components.QMenuCancelEventHandler(this.Object_MenuShowing);
            this.qtbTextToolbar.MenuShowed += new Qios.DevSuite.Components.QMenuEventHandler(this.Object_MenuShowed);
            // 
            // qtiBold
            // 
            this.qtiBold.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiBold.IconResourceName = "Qios.DevSuite.DemoZone.Icons.TextBold.ico, Qios.DevSuite.DemoZone";
            this.qtiBold.ItemName = "Bold";
            this.qtiBold.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiBold.Title = "Bold";
            this.qtiBold.ToolTip = "Bold";
            // 
            // qtiItalic
            // 
            this.qtiItalic.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiItalic.IconResourceName = "Qios.DevSuite.DemoZone.Icons.TextItalic.ico, Qios.DevSuite.DemoZone";
            this.qtiItalic.ItemName = "Italic";
            this.qtiItalic.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiItalic.Title = "Italic";
            this.qtiItalic.ToolTip = "Italic";
            // 
            // qtiUnderline
            // 
            this.qtiUnderline.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiUnderline.IconResourceName = "Qios.DevSuite.DemoZone.Icons.TextUnderline.ico, Qios.DevSuite.DemoZone";
            this.qtiUnderline.ItemName = "Underline";
            this.qtiUnderline.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiUnderline.Title = "Underline";
            this.qtiUnderline.ToolTip = "Underline";
            // 
            // qtiTextDivider1
            // 
            this.qtiTextDivider1.IsSeparator = true;
            this.qtiTextDivider1.ItemName = "Separator1";
            // 
            // qtiAlignleft
            // 
            this.qtiAlignleft.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiAlignleft.IconResourceName = "Qios.DevSuite.DemoZone.Icons.AlignLeft.ico, Qios.DevSuite.DemoZone";
            this.qtiAlignleft.ItemName = "AlignLeft";
            this.qtiAlignleft.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiAlignleft.Title = "Align left";
            this.qtiAlignleft.ToolTip = "Align left";
            // 
            // qtiAlignCenter
            // 
            this.qtiAlignCenter.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiAlignCenter.IconResourceName = "Qios.DevSuite.DemoZone.Icons.AlignCenter.ico, Qios.DevSuite.DemoZone";
            this.qtiAlignCenter.ItemName = "AlignCenter";
            this.qtiAlignCenter.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiAlignCenter.Title = "Align center";
            this.qtiAlignCenter.ToolTip = "Align center";
            // 
            // qtiAlignRight
            // 
            this.qtiAlignRight.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiAlignRight.IconResourceName = "Qios.DevSuite.DemoZone.Icons.AlignRight.ico, Qios.DevSuite.DemoZone";
            this.qtiAlignRight.ItemName = "AlignRight";
            this.qtiAlignRight.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiAlignRight.Title = "Align right";
            this.qtiAlignRight.ToolTip = "Align right";
            // 
            // qtiTextDivider2
            // 
            this.qtiTextDivider2.IsSeparator = true;
            this.qtiTextDivider2.ItemName = "Separator2";
            // 
            // qtiNumbering
            // 
            this.qtiNumbering.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiNumbering.IconResourceName = "Qios.DevSuite.DemoZone.Icons.Numbering.ico, Qios.DevSuite.DemoZone";
            this.qtiNumbering.ItemName = "Numbering";
            this.qtiNumbering.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiNumbering.Title = "Numbering";
            this.qtiNumbering.ToolTip = "Numbering";
            // 
            // qtiBullets
            // 
            this.qtiBullets.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiBullets.IconResourceName = "Qios.DevSuite.DemoZone.Icons.List.ico, Qios.DevSuite.DemoZone";
            this.qtiBullets.ItemName = "Bullets";
            this.qtiBullets.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiBullets.Title = "Bullets";
            this.qtiBullets.ToolTip = "Bullets";
            // 
            // qtiDecreaseIndent
            // 
            this.qtiDecreaseIndent.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiDecreaseIndent.Icon")));
            this.qtiDecreaseIndent.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiDecreaseIndent.ItemName = "DecreaseIndent";
            this.qtiDecreaseIndent.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiDecreaseIndent.Title = "Decrease indent";
            this.qtiDecreaseIndent.ToolTip = "Decrease indent";
            // 
            // qtiIncreaseIndent
            // 
            this.qtiIncreaseIndent.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiIncreaseIndent.Icon")));
            this.qtiIncreaseIndent.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiIncreaseIndent.ItemName = "IncreaseIndent";
            this.qtiIncreaseIndent.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiIncreaseIndent.Title = "Increase indent";
            this.qtiIncreaseIndent.ToolTip = "Increase indent";
            // 
            // qtiTextDivider3
            // 
            this.qtiTextDivider3.IsSeparator = true;
            this.qtiTextDivider3.ItemName = "Separator3";
            // 
            // qtiTextColor
            // 
            this.qtiTextColor.IconColorToReplace = System.Drawing.Color.Red;
            this.qtiTextColor.IconResourceName = "Qios.DevSuite.DemoZone.Icons.TextForeColor.ico, Qios.DevSuite.DemoZone";
            this.qtiTextColor.ItemName = "TextColor";
            this.qtiTextColor.ItemType = Qios.DevSuite.Components.QToolItemType.Icon;
            this.qtiTextColor.Title = "Text color";
            this.qtiTextColor.ToolTip = "Text color";
            // 
            // qtbhToolBarHostLeft
            // 
            this.qtbhToolBarHostLeft.Controls.Add(this.qtbTextToolbar);
            this.qtbhToolBarHostLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.qtbhToolBarHostLeft.Location = new System.Drawing.Point(0, 72);
            this.qtbhToolBarHostLeft.Name = "qtbhToolBarHostLeft";
            this.qtbhToolBarHostLeft.PersistGuid = new System.Guid("3329d00a-8cf0-4c2f-85a4-9c9291289c78");
            this.qtbhToolBarHostLeft.Size = new System.Drawing.Size(34, 442);
            this.qtbhToolBarHostLeft.TabIndex = 43;
            this.qtbhToolBarHostLeft.Text = "Navigation";
            // 
            // qtiLogoff
            // 
            this.qtiLogoff.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiLogoff.Icon")));
            this.qtiLogoff.ItemName = "logoff";
            // 
            // qtiShutDown
            // 
            this.qtiShutDown.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiShutDown.Icon")));
            this.qtiShutDown.ItemName = "shutdown";
            // 
            // qtiSeperator
            // 
            this.qtiSeperator.IsSeparator = true;
            // 
            // qtiPrint2
            // 
            this.qtiPrint2.Icon = ((System.Drawing.Icon)(resources.GetObject("qtiPrint2.Icon")));
            this.qtiPrint2.ItemName = "print";
            // 
            // qtbhToolBarHostBottom
            // 
            this.qtbhToolBarHostBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.qtbhToolBarHostBottom.Location = new System.Drawing.Point(0, 514);
            this.qtbhToolBarHostBottom.Name = "qtbhToolBarHostBottom";
            this.qtbhToolBarHostBottom.PersistGuid = new System.Guid("68906138-2497-449f-954e-2cbd4c6b51ed");
            this.qtbhToolBarHostBottom.Size = new System.Drawing.Size(1099, 20);
            this.qtbhToolBarHostBottom.TabIndex = 45;
            this.qtbhToolBarHostBottom.Text = "qToolBarHost1";
            // 
            // qtbhToolBarHostRight
            // 
            this.qtbhToolBarHostRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.qtbhToolBarHostRight.Location = new System.Drawing.Point(1079, 72);
            this.qtbhToolBarHostRight.Name = "qtbhToolBarHostRight";
            this.qtbhToolBarHostRight.PersistGuid = new System.Guid("6ff29cdd-6861-45fa-bc86-d42f2b65c52a");
            this.qtbhToolBarHostRight.Size = new System.Drawing.Size(20, 442);
            this.qtbhToolBarHostRight.TabIndex = 46;
            this.qtbhToolBarHostRight.Text = "qToolBarHost1";
            // 
            // qpmPersistenceManager
            // 
            this.qpmPersistenceManager.OwnerControl = this;
            this.qpmPersistenceManager.PersistGuid = new System.Guid("2d2ca0a1-b52a-4081-9d8b-3e793f696a61");
            this.qpmPersistenceManager.PersistableObjectRequested += new Qios.DevSuite.Components.QPersistenceEventHandler(this.qpmPersistenceManager_PersistableObjectRequested);
            this.qpmPersistenceManager.PersistableHostRequested += new Qios.DevSuite.Components.QPersistenceEventHandler(this.qpmPersistenceManager_PersistableHostRequested);
            this.qpmPersistenceManager.PersistableObjectCreated += new Qios.DevSuite.Components.QPersistenceEventHandler(this.qpmPersistenceManager_PersistableObjectCreated);
            this.qpmPersistenceManager.PersistableObjectLoaded += new Qios.DevSuite.Components.QPersistenceEventHandler(this.qpmPersistenceManager_PersistableObjectLoaded);
            this.qpmPersistenceManager.PersistableObjectUnloaded += new Qios.DevSuite.Components.QPersistenceEventHandler(this.qpmPersistenceManager_PersistableObjectUnloaded);
            this.qpmPersistenceManager.PersistableObjectSaved += new Qios.DevSuite.Components.QPersistenceEventHandler(this.qpmPersistenceManager_PersistableObjectSaved);
            // 
            // qcmNotifyIconMenu
            // 
            this.qcmNotifyIconMenu.MenuItems.AddRange(new Qios.DevSuite.Components.QMenuItem[] {
            this.qmiNotifyShow,
            this.qmiNotifyExit,
            this.qmiNotifyDivider,
            this.qmiNotifyItem1,
            this.qmiNotifyItem2,
            this.qmiNotifyItem3});
            this.qcmNotifyIconMenu.MenuItemActivated += new Qios.DevSuite.Components.QMenuEventHandler(this.qcmNotifyIconMenu_MenuItemActivated);
            this.qcmNotifyIconMenu.AddListener(this.niNotifyIcon);
            // 
            // qmiNotifyShow
            // 
            this.qmiNotifyShow.Icon = ((System.Drawing.Icon)(resources.GetObject("qmiNotifyShow.Icon")));
            this.qmiNotifyShow.Title = "Show application";
            this.qmiNotifyShow.ToolTip = "Show application";
            // 
            // qmiNotifyExit
            // 
            this.qmiNotifyExit.Title = "Exit application";
            this.qmiNotifyExit.ToolTip = "Exit application";
            // 
            // qmiNotifyDivider
            // 
            this.qmiNotifyDivider.IsSeparator = true;
            // 
            // qmiNotifyItem1
            // 
            this.qmiNotifyItem1.Title = "Item 1";
            this.qmiNotifyItem1.ToolTip = "Item 1";
            // 
            // qmiNotifyItem2
            // 
            this.qmiNotifyItem2.Title = "Item 2";
            this.qmiNotifyItem2.ToolTip = "Item 2";
            // 
            // qmiNotifyItem3
            // 
            this.qmiNotifyItem3.Title = "Item 3";
            this.qmiNotifyItem3.ToolTip = "Item 3";
            // 
            // niNotifyIcon
            // 
            this.niNotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("niNotifyIcon.Icon")));
            this.niNotifyIcon.Visible = true;
            this.niNotifyIcon.MouseUp += new System.Windows.Forms.MouseEventHandler(this.niNotifyIcon_MouseUp);
            // 
            // qbNotifyBalloon
            // 
            this.qbNotifyBalloon.Configuration.BalloonWindowAppearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.BalloonShapedWindow);
            this.qbNotifyBalloon.Configuration.BalloonWindowConfiguration.CanClose = true;
            this.qbNotifyBalloon.Configuration.BalloonWindowConfiguration.TextPadding = new Qios.DevSuite.Components.QPadding(1, 0, 0, 25);
            this.qbNotifyBalloon.Configuration.BalloonWindowConfiguration.TopMost = true;
            // 
            // qMenuItem4
            // 
            this.qMenuItem4.Title = "Test15";
            // 
            // qMenuItem5
            // 
            this.qMenuItem5.Title = "Test16";
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(1099, 559);
            this.Controls.Add(this.qdbDockBarLeft);
            this.Controls.Add(this.qdbDockBarRight);
            this.Controls.Add(this.qdbDockBarBottom);
            this.Controls.Add(this.qdbDockBarTop);
            this.Controls.Add(this.qtbhToolBarHostLeft);
            this.Controls.Add(this.qtbhToolBarHostRight);
            this.Controls.Add(this.qtbhToolBarHostTop);
            this.Controls.Add(this.qtbhToolBarHostBottom);
            this.Controls.Add(this.qsbStatusBar);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "FrmMain";
            this.Text = "TestLab - Qios.DevSuite.DemoZone";
            this.SizeChanged += new System.EventHandler(this.FrmTestLab_SizeChanged);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.niNotifyIcon_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.qMainMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostTop)).EndInit();
            this.qtbhToolBarHostTop.ResumeLayout(false);
            this.qtbNavigation.ResumeLayout(false);
            this.qCommandControlContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostLeft)).EndInit();
            this.qtbhToolBarHostLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtbhToolBarHostRight)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion


		private void FrmTestLab_SizeChanged(object sender, System.EventArgs e)
		{
			//hide the sizing grip if the main form is maximized
			this.qsbStatusBar.SizingGrip = (this.WindowState != FormWindowState.Maximized);
		}

		/// <summary>
		/// Makes sure the PropertiesWindow exists.
		/// </summary>
		private void SecureProperties()
		{
			if (m_oPropertiesWindow == null)
			{
				m_oPropertiesWindow = new QdwProperties();
				m_oPropertiesWindow.Owner = this;
				m_oPropertiesWindow.ObjectsRequested += new Qios.DevSuite.DemoZone.Samples.TestLab.QdwProperties.QdwPropertiesEventHandler(PropertiesWindow_ObjectsRequested);
				m_oPropertiesWindow.Closed +=new EventHandler(PropertiesWindow_Closed);
			}
		}

		/// <summary>
		/// If the global colorscheme window does not exists yet, create it.
		/// </summary>
		private void SecureGlobalColorScheme()
		{
			//create the globalcolorscheme window if neccesary
			if (m_oGlobalColorSchemeWindow == null) 
			{
				m_oGlobalColorSchemeWindow = new QdwGlobalColorScheme();
				m_oGlobalColorSchemeWindow.Owner = this;
				this.m_oGlobalColorSchemeWindow.Closed +=new EventHandler(GlobalColorSchemeWindow_Closed);
			}
		}

		/// <summary>
		/// If the properties window does not exists yet, create it and dock it to the right dockbar.
		/// </summary>
		private void OpenProperties()
		{
			//create the properties window if neccesary and dock it to the right side
			if (m_oPropertiesWindow == null)
			{
				this.SecureProperties();
				this.m_oPropertiesWindow.DockWindow(this.qdbDockBarRight);
				//Set the GridObject to the QMainMenu1.
				m_oPropertiesWindow.SetGridObject(this.qMainMenu1);
			}
		}

		/// <summary>
		/// Creates a new tasks window and docks it to the bottom dockbar.
		/// </summary>
		private void OpenTasks()
		{
			QdwTasks tmp_oTasks = new QdwTasks();
			tmp_oTasks.Owner = this;
			tmp_oTasks.Closing +=new CancelEventHandler(Tasks_Closing);
			tmp_oTasks.DockWindow(this.qdbDockBarBottom);	
		}

		/// <summary>
		/// Updates capslock and numlock panels
		/// </summary>
		private void SynchronizeKeyBoardState()
		{
			//enabled the capslock qstatusbarpanel when capslock is on
			if (!(qspCapsLock.IsDisposed)) this.qspCapsLock.Enabled = (GetKeyState(0x14) == 1);
			
			//enabled the numlock qstatusbarpanel when numlock is on
			if (!(qspNumLock.IsDisposed)) this.qspNumLock.Enabled = (GetKeyState(0x90) == 1);				
		}

		private void tmrTimedRetrievals_Tick(object sender, EventArgs e)
		{
			this.tmrTimedRetrievals.Interval = Math.Max(10, m_iStatusBarRefreshTime - (int)((this.m_oStatusBarQueue.Count /10.0) * m_iStatusBarRefreshTime));

			//update the caplock and numlock panels
			this.SynchronizeKeyBoardState();

			//show the current item in the queue
			if (this.m_oStatusBarQueue.Count > 0)
			{
				string tmp_sCurrentMessage = (string)this.m_oStatusBarQueue.Dequeue();
				this.qspStatus.Text = tmp_sCurrentMessage;
				if (this.m_oStatusBarQueue.Count == 0) m_iLastMessageShownTime = Environment.TickCount;
			}
			else if ((m_iLastMessageShownTime > 0) && ((m_iLastMessageShownTime + m_iStatusBarLastMessageTime) < Environment.TickCount))
			{
				m_iLastMessageShownTime = -1;
				this.qspStatus.Text = "";
			}
		}

		private void qsbStatusBar_PanelClick(object sender, Qios.DevSuite.Components.QStatusBarPanelEventArgs e)
		{
			//show click event
			MessageBox.Show("Panel click " + e.Panel.Text);		
		}

		private void Tasks_Closing(object sender, CancelEventArgs e)
		{
			//allow the user to cancel the closing of forms
			//e.Cancel = (MessageBox.Show("Do you want to close " + ((Control)sender).Text + "?", "Closing...", MessageBoxButtons.OKCancel) == DialogResult.Cancel);
		}

		private void PropertiesWindow_Closed(object sender, EventArgs e)
		{
			//set the properties window to null when closed.
			this.m_oPropertiesWindow = null;
		}

		private void GlobalColorSchemeWindow_Closed(object sender, EventArgs e)
		{
			//Set the global color scheme window to null when closed.
			this.m_oGlobalColorSchemeWindow = null;
		}

		private void PropertiesWindow_ObjectsRequested(object sender, Qios.DevSuite.DemoZone.Samples.TestLab.QdwProperties.QdwPropertiesEventArgs e)
		{
			//allow the properties window to edit the properties of the following objects
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qsbStatusBar, "StatusBar"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qdbDockBarRight, "DockbarRight"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qdbDockBarLeft, "DockbarLeft"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qdbDockBarTop, "DockbarTop"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qdbDockBarBottom, "DockbarBottom"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qMainMenu1, "MainMenu"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbhToolBarHostRight, "ToolbarHostRight"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbhToolBarHostLeft, "ToolbarHostLeft"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbhToolBarHostTop, "ToolbarHostTop"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbhToolBarHostBottom, "ToolbarHostBottom"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbNavigation, "ToolbarNavigation"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbTextToolbar, "ToolbarFormatting"));
			e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.qtbToolbar, "ToolbarDefault"));

			//check for FrmWelcome to show the explorerbar and tabcontrol
			for (int i=0; i<this.MdiChildren.Length; i++)
			{
				if (this.MdiChildren[i] is FrmWelcome)
				{
					e.PropertyObjects.Add(new QdwProperties.QPropertyObject(
						((FrmWelcome)this.MdiChildren[i]).ExplorerBar, 
						"WelcomeExplorerBar")
						);
					e.PropertyObjects.Add(new QdwProperties.QPropertyObject(
						((FrmWelcome)this.MdiChildren[i]).TabControl, 
						"WelcomeTabControl")
						);
					break;
				}
			}
			

			if (this.m_oPropertiesWindow != null) e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.m_oPropertiesWindow, "PropertiesWindow"));
			if (this.m_oGlobalColorSchemeWindow != null) e.PropertyObjects.Add(new QdwProperties.QPropertyObject(this.m_oGlobalColorSchemeWindow, "GlobalColorSchemeWindow"));
		}

		/// <summary>
		/// Opens the global colorscheme window on the property window in tabbed form
		/// </summary>
		private void OpenGlobalColorSchemeOnPropertiesTabbed()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();
			
			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(m_oPropertiesWindow, QDockOrientation.Tabbed, true);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme window above the properties window
		/// </summary>
		private void OpenGlobalColorSchemeOnPropertiesTop()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();
			
			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(m_oPropertiesWindow, QDockOrientation.Vertical, false);		
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme window below the properties window
		/// </summary>
		private void OpenGlobalColorSchemeOnPropertiesBottom()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();

			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(m_oPropertiesWindow, QDockOrientation.Vertical, true);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme window on the lef side of the properties window
		/// </summary>
		private void OpenGlobalColorSchemeOnPropertiesLeft()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();

			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(m_oPropertiesWindow, QDockOrientation.Horizontal, false);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme window on the right side of the properties window
		/// </summary>
		private void OpenGlobalColorSchemeOnPropertiesRight()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();

			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(m_oPropertiesWindow, QDockOrientation.Horizontal, true);		
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme on the right dockbar
		/// </summary>
		private void OpenGlobalColorSchemeOnDockBar()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();

			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(qdbDockBarRight);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme on the right dockbar slided in
		/// </summary>
		private void OpenGlobalColorSchemeOnDockBarSlidedIn()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();
			
			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(qdbDockBarRight, true, false);		
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme on the right dockbar slided out
		/// </summary>
		private void OpenGlobalColorSchemeOnDockBarSlidedOut()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();

			try
			{
				//make sure the properties window exists
				OpenProperties();

				//dock the new window in the requested style
				this.m_oGlobalColorSchemeWindow.DockWindow(qdbDockBarRight, true, true);				
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Opens the global colorscheme in an undocked window
		/// </summary>
		private void OpenGlobalColorSchemeUndocked()
		{
			//make sure the globalcolorscheme window is created
			this.SecureGlobalColorScheme();

			//show the window undocked
			this.m_oGlobalColorSchemeWindow.UndockWindow(300,300);
		}


		/// <summary>
		/// Fills the themes menu with menuitems representing all available themes
		/// </summary>
		private void FillThemesMenu()
		{
			this.qmiViewThemes.MenuItems.Clear();

			//create and array of subitem, and keep room for a seperator and an extra menuitem to inherit the windows theme
			QMenuItem[] tmp_aSubItems = new QMenuItem[qgcGlobalManager.Global.Themes.Count + 2];

			//loop all themes
			for (int i=0; i<qgcGlobalManager.Global.Themes.Count; i++)
			{
				//create a new menuitem based on the themename
				tmp_aSubItems[i] = new QMenuItem(qgcGlobalManager.Global.Themes[i].ThemeName, qgcGlobalManager.Global.Themes[i].ThemeName);
			}
			
			//create the other two menuitems
			QMenuItem tmp_oSeperator = new QMenuItem("ViewThemesSeperator", "ViewThemesSeperator");
			tmp_oSeperator.IsSeparator = true;
			QMenuItem tmp_oInherit = new QMenuItem("Inherit from Windows", "InheritWindows");
			tmp_oInherit.ItemName = "inherit";

			//add a seperator
			tmp_aSubItems[tmp_aSubItems.Length - 2] = tmp_oSeperator;
			//add the inherit menu item
			tmp_aSubItems[tmp_aSubItems.Length - 1] = tmp_oInherit;

			//add all subitems
			this.qmiViewThemes.MenuItems.AddRange(tmp_aSubItems);

			//set the current theme menuitem to checked
			ShowCurrentThemeSelection();
		}

		/// <summary>
		/// Checks the menuitem representing the current theme
		/// </summary>        
		private void ShowCurrentThemeSelection()
		{
			for (int i=0; i<qmiViewThemes.MenuItems.Count; i++)
			{
				if (qmiViewThemes.MenuItems[i].ItemName == "inherit") qmiViewThemes.MenuItems[i].Checked = QGlobalColorScheme.Global.InheritCurrentThemeFromWindows;
				else if (qmiViewThemes.MenuItems[i].Title == QColorScheme.Global.CurrentTheme) qmiViewThemes.MenuItems[i].Checked = true;
				else qmiViewThemes.MenuItems[i].Checked = false;
			}
		}

		/// <summary>
		/// Checks the menuitem representing the current dockstyle of the mainmenu
		/// </summary>
		private void ShowCurrentMenuDockStyle()
		{
			this.qmiActionsDockMenuBottom.Checked = false;
			this.qmiActionsDockMenuTop.Checked = false;
			this.qmiActionsDockMenuRight.Checked = false;
			this.qmiActionsDockMenuLeft.Checked = false;

			if (qMainMenu1.Parent == this.qtbhToolBarHostLeft) this.qmiActionsDockMenuLeft.Checked = true;
			if (qMainMenu1.Parent == this.qtbhToolBarHostRight) this.qmiActionsDockMenuRight.Checked = true;
			if (qMainMenu1.Parent == this.qtbhToolBarHostTop) this.qmiActionsDockMenuTop.Checked = true;
			if (qMainMenu1.Parent == this.qtbhToolBarHostBottom) this.qmiActionsDockMenuBottom.Checked = true;
		}


		/// <summary>
		/// Saves the current persistence.
		/// </summary>
		private void SavePersistence()
		{
			//Add all the persistableObjects and hosts from the Owner (which is this).
			//Note: It is not required to call InitializeFromOwner, you can also 
			//add the persistableObjects and hosts manually. 
			this.qpmPersistenceManager.InitializeFromOwner();

			try
			{
				//Save the persistence to the file
				this.qpmPersistenceManager.Save(m_sPersistenceFileName);
			}
			catch(Exception e)
			{
				MessageBox.Show(e.Message);
			}
		}

		/// <summary>
		/// Saves the current colorscheme
		/// </summary>
		private void SaveColorScheme()
		{
			//save the colorscheme
			try
			{
				QColorScheme.Global.SaveToXml(m_sColorSchemeFileName, QColorSaveType.ChangedThemeColors);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Loads the current colorscheme
		/// </summary>
		private void LoadColorScheme()
		{
			//check if the file exists
			if (!System.IO.File.Exists(this.m_sColorSchemeFileName))
			{
				MessageBox.Show("Cannot load the colorscheme, save the colorscheme first.");
				return;
			}

			//load the colorscheme
			try
			{
				QColorScheme.Global.LoadFromXml(m_sColorSchemeFileName);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		/// <summary>
		/// Loads the persistence.
		/// </summary>
		private void LoadPersistence()
		{
			if (!System.IO.File.Exists(this.m_sPersistenceFileName))
			{
				MessageBox.Show("Cannot load the persistence, save the persistance first.");
				return;
			}

			//Add all the persistableObjects and hosts from the Owner (which is this).
			//Note: It is not required to call InitializeFromOwner, you can also 
			//add the persistableObjects and hosts manually. 
			this.qpmPersistenceManager.InitializeFromOwner();

			try
			{
				//First unload all the persistableObjects that get persisted.
				this.qpmPersistenceManager.UnloadPersistableObjects(QPersistenceUnloadOptions.WhereRequiresUnload);
				//Load the objects from the persistence.
				this.qpmPersistenceManager.Load(m_sPersistenceFileName);
			}
			catch(Exception e)
			{
				MessageBox.Show(e.Message);
			}
		}

		private void qMainMenu1_MenuItemActivated(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			//Show the event in the statusbar
			SetStatusBar(e, "activated");

			//get the string representation of the full path of its parent
			string tmp_sParentFullName = e.MenuItem.ParentFullName != null ? e.MenuItem.ParentFullName.ToLower() : null;
			
			//get the name of the menuitem
			string tmp_sName = e.MenuItem.ItemName != null ? e.MenuItem.ItemName.ToLower() : null;

			if (tmp_sParentFullName == "file/open")
			{
				if (tmp_sName == "welcome")
				{
					//create and show the welcome screen as an mdichild of the main form
					FrmWelcome tmp_oForm = new FrmWelcome();
					tmp_oForm.MdiParent = this;
					tmp_oForm.Show();
				}
				else if (tmp_sName == "openform1")
				{
					//create and show the Form1 as an mdichild of the main form
					Form1 tmp_oForm = new Form1();
					tmp_oForm.MdiParent = this;
					tmp_oForm.Show();
				}
				else if (tmp_sName == "opencontact")
				{
					FrmContact tmp_oForm = new FrmContact();
					tmp_oForm.MdiParent = this;
					tmp_oForm.Show();
				}			
			}
			else if (tmp_sParentFullName == "file")
			{
				if (tmp_sName == "exit")
				{
					this.Close();
				}
				else if (tmp_sName == "savepersistence")
				{
					this.SavePersistence();
				}
				else if (tmp_sName == "loadpersistence")
				{
					this.LoadPersistence();
				}
				else if (tmp_sName == "savecolorscheme")
				{
					this.SaveColorScheme();
				}
				else if (tmp_sName == "loadcolorscheme")
				{
					this.LoadColorScheme();
				}
			}
			else if (tmp_sParentFullName == "view/themes")
			{
				if (tmp_sName == "inherit")
				{
					//inherit the theme from windows
					QColorScheme.Global.InheritCurrentThemeFromWindows = !e.MenuItem.Checked;
				}
				else
				{
					//do not inherit the theme from windows
					QColorScheme.Global.InheritCurrentThemeFromWindows = false;

					//set the current theme to the title of the menuitem
					QColorScheme.Global.CurrentTheme = e.MenuItem.Title;
				}

				//set the current theme menuitem to checked
				ShowCurrentThemeSelection();
			}
			else if (tmp_sParentFullName == "actions")
			{
				//dock the main menu in the requested docksite
				if (tmp_sName == "dockmenutop")
				{
					if (qMainMenu1.Parent != null) qMainMenu1.Parent.Controls.Remove(qMainMenu1);
					this.qtbhToolBarHostTop.Controls.Add(qMainMenu1);
				}
				else if (tmp_sName == "dockmenubottom")
				{
					if (qMainMenu1.Parent != null) qMainMenu1.Parent.Controls.Remove(qMainMenu1);
					this.qtbhToolBarHostBottom.Controls.Add(qMainMenu1);
				}
				else if (tmp_sName == "dockmenuleft")
				{
					if (qMainMenu1.Parent != null) qMainMenu1.Parent.Controls.Remove(qMainMenu1);
					this.qtbhToolBarHostLeft.Controls.Add(qMainMenu1);
				}
				else if (tmp_sName == "dockmenuright")
				{
					if (qMainMenu1.Parent != null) qMainMenu1.Parent.Controls.Remove(qMainMenu1);
					this.qtbhToolBarHostRight.Controls.Add(qMainMenu1);
				}

				//check the correct menuitem
				ShowCurrentMenuDockStyle();
			}
			else if (tmp_sParentFullName == "view/windows")
			{
				if (tmp_sName == "properties")
				{
					//create and show the properties window
					this.OpenProperties();
				}
				else if (tmp_sName == "tasks")
				{
					//create and show the tasks window
					this.OpenTasks();
				}				
			}
			else if (tmp_sParentFullName == "view/windows/globalcolorscheme")
			{
				//create and show the global colorscheme window
				if (tmp_sName == "onpropertiestabbed")
				{
					this.OpenGlobalColorSchemeOnPropertiesTabbed();
				}
				else if (tmp_sName == "onpropertiestop")
				{
					this.OpenGlobalColorSchemeOnPropertiesTop();
				}
				else if (tmp_sName == "onpropertiesbottom")
				{
					this.OpenGlobalColorSchemeOnPropertiesBottom();
				}
				else if (tmp_sName == "onpropertiesleft")
				{
					this.OpenGlobalColorSchemeOnPropertiesLeft();
				}
				else if (tmp_sName == "onpropertiesright")
				{
					this.OpenGlobalColorSchemeOnPropertiesRight();
				}
				else if (tmp_sName == "onrightdockbar")
				{
					this.OpenGlobalColorSchemeOnDockBar();
				}
				else if (tmp_sName == "onrightdockbarslidedin")
				{
					this.OpenGlobalColorSchemeOnDockBarSlidedIn();
				}
				else if (tmp_sName == "onrightdockbarslidedout")
				{
					this.OpenGlobalColorSchemeOnDockBarSlidedOut();
				}
				else if (tmp_sName == "undocked")
				{
					this.OpenGlobalColorSchemeUndocked();
				}
			}
		}

		private void qtbToolbar_MenuItemActivated(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			SetStatusBar(e, "activated");

			//get the name of the menuitem
			string tmp_sName = e.MenuItem.ItemName != null ? e.MenuItem.ItemName.ToLower() : null;

			if (tmp_sName == "openwelcome")
			{
				//create and show the welcome screen as an mdichild of the main form
				FrmWelcome tmp_oForm = new FrmWelcome();
				tmp_oForm.MdiParent = this;
				tmp_oForm.Show();
			}
			else if (tmp_sName == "openform1")
			{
				//create and show the Form1 as an mdichild of the main form
				Form1 tmp_oForm = new Form1();
				tmp_oForm.MdiParent = this;
				tmp_oForm.Show();
			}
			else if (tmp_sName == "opencontact")
			{
				FrmContact tmp_oForm = new FrmContact();
				tmp_oForm.MdiParent = this;
				tmp_oForm.Show();
			}
		}

		/// <summary>
		/// Sets the statusbar text
		/// </summary>
		/// <param name="e"></param>
		/// <param name="action"></param>
		private void SetStatusBar(QMenuEventArgs e, string action)
		{
			//If there was a selected menuItem
			if ((e.MenuItem != null) && (!e.MenuItem.IsSeparator))
			{
				string tmp_sTitle = ((e.MenuItem.Title != null) && (e.MenuItem.Title != "")) ? e.MenuItem.Title.Replace("&",""): "(no title)";
				//Set the text to the selected item.
				string tmp_sFormat;
				if (e.Expanded)
				{
					tmp_sFormat = "Item {0} is {1} with expansion via {2}";
				}
				else
				{
					tmp_sFormat = "Item {0} is {1} via {2}";
				}

				string tmp_sText = String.Format(tmp_sFormat, tmp_sTitle, action, e.ActivationType);

				this.m_oStatusBarQueue.Enqueue(tmp_sText);
			}
		}

		private void Object_MenuItemSelected(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			//Show the event in the statusbar
			SetStatusBar(e, "selected");
		}

		private void Object_MenuItemActivating(object sender, QMenuCancelEventArgs e)
		{
			//Show the event in the statusbar
			SetStatusBar(e, "activating");
		}

		private void Object_MenuShowed(object sender, QMenuEventArgs e)
		{
			//Show the event in the statusbar
			SetStatusBar(e, "showed");
		}

		private void Object_MenuShowing(object sender, QMenuCancelEventArgs e)
		{
			//Show the event in the statusbar
			SetStatusBar(e, "showing");
		}

		private void Object_MenuItemActivated(object sender, QMenuEventArgs e)
		{
			//Show the event in the statusbar
			SetStatusBar(e, "activated");
		}

		/// <summary>
		/// Handles the request for a host.
		/// </summary>
		private void qpmPersistenceManager_PersistableHostRequested(object sender, Qios.DevSuite.Components.QPersistenceEventArgs e)
		{
			//Is called when a host is requested, our hosts are always there, so don't need to do anything.
		}

		/// <summary>
		/// Handles the PersistableObjectRequestedEvent.
		/// </summary>
		private void qpmPersistenceManager_PersistableObjectRequested(object sender, Qios.DevSuite.Components.QPersistenceEventArgs e)
		{
			//When a persistableObject is not created created but matched by its PersistGuid the manager tries to find
			//it in its PersistableObjects collection. When it is not there this event is called. This allows you to
			//dynamically provide those persistableObjects on the fly. Because the Properties and GlobalColorScheme
			//windows are only created once (as opposed to the Tasks window). When they are closed
			//they will not be added during the PersistenceManager.InitializeFromOwner method, so it is possible
			//that they are not in the PersistableObjects collection. Therefore we provide those objects
			//via this eventHandler.

			//PersistableObjects are matched by their PersistGuid, but, because we have only
			//one instance of QdwProperties and QdwGlobalColorScheme, we can do it by type.
			if (e.PersistableObjectType == typeof(QdwProperties))
			{
				//When a PropertiesWindow is requested, it means it wasn't in the PersistableObjects
				//collection, so initialize it.
				this.SecureProperties();
				e.PersistableObject = this.m_oPropertiesWindow;
			}
			else if (e.PersistableObjectType == typeof(QdwGlobalColorScheme))
			{
				//When a GlobalColorSchemeWindow is requested, it means it wasn't in the PersistableObjects
				//collection, so initialize it.
				this.SecureGlobalColorScheme();
				e.PersistableObject = this.m_oGlobalColorSchemeWindow;
			}		
		}

		/// <summary>
		/// Handles the creation of a persistableObject.
		/// </summary>
		private void qpmPersistenceManager_PersistableObjectCreated(object sender, Qios.DevSuite.Components.QPersistenceEventArgs e)
		{
			//The Tasks window is created on demand, multiple instances are possible.
			//Attach the event closing event.
			if (e.PersistableObjectType == typeof(QdwTasks))
			{
				//(VB CONVERSION:) Do not forget to set the new Guid in QdwTasks constructor.
				QdwTasks tmp_oTasks = (QdwTasks) e.PersistableObject;
				tmp_oTasks.Closing +=new CancelEventHandler(Tasks_Closing);
			}		
		}

		/// <summary>
		/// Handles the load of a persistableObject.
		/// </summary>
		private void qpmPersistenceManager_PersistableObjectLoaded(object sender, Qios.DevSuite.Components.QPersistenceEventArgs e)
		{
			//After a persistableObject is loaded, this event is called. You can do additional 
			//configuration during this event.

			if (e.PersistableObject == this.m_oPropertiesWindow)
			{
				//If the properties window is loaded, set its GridObject.
				m_oPropertiesWindow.SetGridObject(this.qMainMenu1);
			}
			else if (e.PersistableObjectType == typeof(QToolBar))
			{
				//A toolBar is loaded, because we saved the 'myAdditionalProperty' (for demonstration purposes), load
				//it here.
				((QToolBar)e.PersistableObject).Text = QXmlHelper.GetChildElementString(e.PersistableObjectElement, "myAdditionalTextProperty");
			}
		}

		/// <summary>
		/// Is called when a persistableObject is unloaded (for reloading for example)
		/// </summary>
		private void qpmPersistenceManager_PersistableObjectUnloaded(object sender, Qios.DevSuite.Components.QPersistenceEventArgs e)
		{
			//Remove the Closing event 
			if (e.PersistableObjectType == typeof(QdwTasks))
			{
				//Remove the Closing event when the tasks are unloaded.
				QdwTasks tmp_oTasks = (QdwTasks) e.PersistableObject;
				tmp_oTasks.Closing -=new CancelEventHandler(Tasks_Closing);
			}
			else if (e.PersistableObject == m_oPropertiesWindow)
			{
				m_oPropertiesWindow = null;
			}
			else if (e.PersistableObject == m_oGlobalColorSchemeWindow)
			{
				m_oGlobalColorSchemeWindow = null;
			}
		}

		/// <summary>
		/// Is called when a persistableObject is saved.
		/// </summary>
		private void qpmPersistenceManager_PersistableObjectSaved(object sender, Qios.DevSuite.Components.QPersistenceEventArgs e)
		{
			if (e.PersistableObjectType == typeof(QToolBar))
			{
				//When a toolBar is saved, add the myAdditionalProperty to the element (demonstration purposes).
				QXmlHelper.AddElement(e.PersistableObjectElement, "myAdditionalTextProperty", ((QToolBar)e.PersistableObject).Text);
			}

		}

		private void qcmNotifyIconMenu_MenuItemActivated(object sender, Qios.DevSuite.Components.QMenuEventArgs e)
		{
			if (e.MenuItem == qmiNotifyExit)
				this.Close();
			else if (e.MenuItem == qmiNotifyShow)
			{
				if (this.WindowState == FormWindowState.Minimized) this.WindowState = FormWindowState.Normal;
				else this.BringToFront();
			}
		}

		private void niNotifyIcon_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.qbNotifyBalloon.Show(Control.MousePosition, "You can very easily add a QContextMenu<br/>or a QBalloon to a NotifyIcon.");
			}
		}

		private void qMainMenu1_ParentChanged(object sender, EventArgs e)
		{
			ShowCurrentMenuDockStyle();
		}

		private void Global_ColorsChanged(object sender, EventArgs e)
		{
			this.FillThemesMenu();
		}

		private void Global_ThemesChanged(object sender, EventArgs e)
		{
			this.FillThemesMenu();
		}
	}
}
