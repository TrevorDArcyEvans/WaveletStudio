using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.TabControl
{
	/// <summary>
	/// Summary description for UcCustom01.
	/// </summary>
	public class UcCustom01 : System.Windows.Forms.UserControl
	{
		private Qios.DevSuite.Components.QTabControl qTabControl1;
		private Qios.DevSuite.Components.QShape qsLeftTopTab;
		private Qios.DevSuite.Components.QTabPage qtpLeft;
		private Qios.DevSuite.Components.QTabPage qtpRight;
		private Qios.DevSuite.Components.QShape qsRightTopTab;
		private Qios.DevSuite.Components.QShape qsSecondLeftTopTab;
		private Qios.DevSuite.Components.QShape qsSecondRightTopTab;
		private Qios.DevSuite.Components.QTabPage qtpGettingStarted;
		private Qios.DevSuite.Components.QTabPage qtpSearch;
		private Qios.DevSuite.Components.QTabPage qtpContents;
		private Qios.DevSuite.Components.QTabPage qtpHelp;
		private Qios.DevSuite.Components.QTabPage qtpSettings;
		private Qios.DevSuite.Components.QTabPage qtpAccounts;
		private Qios.DevSuite.Components.QTabPage qtpOptions;
		private Qios.DevSuite.Components.QTabPage qtpControlPanel;
		private Qios.DevSuite.Components.QTabPage qtpAbout;
		private Qios.DevSuite.Components.QTabPage qtpMyNetworkPlaces;
		private Qios.DevSuite.Components.QTabPage qtpMyComputer;
		private Qios.DevSuite.Components.QTabPage qtpMyDocuments;
		private Qios.DevSuite.Components.QTabPage qtpPicturePrint;
		private Qios.DevSuite.Components.QShape qShape1;
		private Qios.DevSuite.Components.QTabPage qtpQiosDevSuiteSite;
		private Qios.DevSuite.Components.QTabPage qtpQiosPelicanSite;
		private Qios.DevSuite.Components.QTabPage qtpFavorites;
		private Qios.DevSuite.Components.QTabPage qtpMsdnSite;
		private Qios.DevSuite.Components.QTabPage qtpWindowsFormsSite;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public UcCustom01()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(UcCustom01));
			this.qTabControl1 = new Qios.DevSuite.Components.QTabControl();
			this.qtpLeft = new Qios.DevSuite.Components.QTabPage();
			this.qsLeftTopTab = new Qios.DevSuite.Components.QShape();
			this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
			this.qtpMsdnSite = new Qios.DevSuite.Components.QTabPage();
			this.qtpQiosDevSuiteSite = new Qios.DevSuite.Components.QTabPage();
			this.qtpQiosPelicanSite = new Qios.DevSuite.Components.QTabPage();
			this.qtpRight = new Qios.DevSuite.Components.QTabPage();
			this.qsRightTopTab = new Qios.DevSuite.Components.QShape();
			this.qtpContents = new Qios.DevSuite.Components.QTabPage();
			this.qtpSearch = new Qios.DevSuite.Components.QTabPage();
			this.qtpGettingStarted = new Qios.DevSuite.Components.QTabPage();
			this.qsSecondLeftTopTab = new Qios.DevSuite.Components.QShape();
			this.qtpHelp = new Qios.DevSuite.Components.QTabPage();
			this.qsSecondRightTopTab = new Qios.DevSuite.Components.QShape();
			this.qtpSettings = new Qios.DevSuite.Components.QTabPage();
			this.qtpAccounts = new Qios.DevSuite.Components.QTabPage();
			this.qtpOptions = new Qios.DevSuite.Components.QTabPage();
			this.qtpControlPanel = new Qios.DevSuite.Components.QTabPage();
			this.qtpAbout = new Qios.DevSuite.Components.QTabPage();
			this.qtpMyNetworkPlaces = new Qios.DevSuite.Components.QTabPage();
			this.qtpMyComputer = new Qios.DevSuite.Components.QTabPage();
			this.qtpMyDocuments = new Qios.DevSuite.Components.QTabPage();
			this.qtpPicturePrint = new Qios.DevSuite.Components.QTabPage();
			this.qtpWindowsFormsSite = new Qios.DevSuite.Components.QTabPage();
			this.qtpFavorites = new Qios.DevSuite.Components.QTabPage();
			this.qShape1 = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).BeginInit();
			this.qTabControl1.SuspendLayout();
			this.qtpLeft.SuspendLayout();
			this.SuspendLayout();
			// 
			// qTabControl1
			// 
			this.qTabControl1.ActiveTabPage = this.qtpLeft;
			this.qTabControl1.AllowDrag = true;
			this.qTabControl1.AllowDrop = true;
			this.qTabControl1.Controls.Add(this.qtpLeft);
			this.qTabControl1.Controls.Add(this.qtpMsdnSite);
			this.qTabControl1.Controls.Add(this.qtpQiosDevSuiteSite);
			this.qTabControl1.Controls.Add(this.qtpQiosPelicanSite);
			this.qTabControl1.Controls.Add(this.qtpRight);
			this.qTabControl1.Controls.Add(this.qtpContents);
			this.qTabControl1.Controls.Add(this.qtpSearch);
			this.qTabControl1.Controls.Add(this.qtpGettingStarted);
			this.qTabControl1.Controls.Add(this.qtpHelp);
			this.qTabControl1.Controls.Add(this.qtpSettings);
			this.qTabControl1.Controls.Add(this.qtpAccounts);
			this.qTabControl1.Controls.Add(this.qtpOptions);
			this.qTabControl1.Controls.Add(this.qtpControlPanel);
			this.qTabControl1.Controls.Add(this.qtpAbout);
			this.qTabControl1.Controls.Add(this.qtpMyNetworkPlaces);
			this.qTabControl1.Controls.Add(this.qtpMyComputer);
			this.qTabControl1.Controls.Add(this.qtpMyDocuments);
			this.qTabControl1.Controls.Add(this.qtpPicturePrint);
			this.qTabControl1.Controls.Add(this.qtpWindowsFormsSite);
			this.qTabControl1.Controls.Add(this.qtpFavorites);
			this.qTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qTabControl1.FocusTabButtons = false;
			this.qTabControl1.Location = new System.Drawing.Point(0, 0);
			this.qTabControl1.Name = "qTabControl1";
			this.qTabControl1.PersistGuid = new System.Guid("a16c8bc9-1184-44cf-8e8e-ee2f1f90cd2d");
			this.qTabControl1.Size = new System.Drawing.Size(480, 336);
			this.qTabControl1.TabIndex = 0;
			this.qTabControl1.TabStripBottomConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
			this.qTabControl1.TabStripBottomConfiguration.ButtonConfiguration.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
			this.qTabControl1.TabStripBottomConfiguration.SizeBehavior = ((Qios.DevSuite.Components.QTabStripSizeBehaviors)((Qios.DevSuite.Components.QTabStripSizeBehaviors.Stack | Qios.DevSuite.Components.QTabStripSizeBehaviors.Grow)));
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.Orientation = Qios.DevSuite.Components.QContentOrientation.VerticalUp;
			this.qTabControl1.TabStripLeftConfiguration.NavigationAreaAppearance.GradientAngle = 90;
			this.qTabControl1.TabStripLeftConfiguration.NavigationAreaAppearance.Shape = this.qShape1;
			this.qTabControl1.TabStripRightConfiguration.ButtonAreaMargin = new Qios.DevSuite.Components.QMargin(5, 5, 0, 5);
			this.qTabControl1.TabStripRightConfiguration.ButtonConfiguration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.MSVisualStudio2005Tab);
			this.qTabControl1.TabStripRightConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
			this.qTabControl1.TabStripRightConfiguration.ButtonConfiguration.IconSize = new System.Drawing.Size(32, 32);
			this.qTabControl1.TabStripRightConfiguration.NavigationAreaAppearance.GradientAngle = 90;
			this.qTabControl1.TabStripTopConfiguration.ButtonAreaMargin = new Qios.DevSuite.Components.QMargin(5, 5, 0, 6);
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.SquareTab);
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.MinimumSize = new System.Drawing.Size(30, 22);
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
			this.qTabControl1.TabStripTopConfiguration.ButtonSpacing = 4;
			this.qTabControl1.TabStripTopConfiguration.SizeBehavior = ((Qios.DevSuite.Components.QTabStripSizeBehaviors)(((Qios.DevSuite.Components.QTabStripSizeBehaviors.Shrink | Qios.DevSuite.Components.QTabStripSizeBehaviors.Scroll) 
				| Qios.DevSuite.Components.QTabStripSizeBehaviors.Grow)));
			// 
			// qtpLeft
			// 
			this.qtpLeft.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qtpLeft.BackgroundImage")));
			this.qtpLeft.ButtonBackgroundImage = ((System.Drawing.Image)(resources.GetObject("qtpLeft.ButtonBackgroundImage")));
			this.qtpLeft.ButtonConfiguration.Appearance.Shape = this.qsLeftTopTab;
			this.qtpLeft.ButtonConfiguration.AppearanceActive.Shape = this.qsLeftTopTab;
			this.qtpLeft.ButtonConfiguration.AppearanceHot.Shape = this.qsLeftTopTab;
			this.qtpLeft.ButtonConfiguration.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomMiddle;
			this.qtpLeft.ButtonConfiguration.BackgroundImageClip = false;
			this.qtpLeft.ButtonConfiguration.MaximumSize = new System.Drawing.Size(80, -1);
			this.qtpLeft.ButtonConfiguration.MinimumSize = new System.Drawing.Size(80, 30);
			this.qtpLeft.ButtonConfiguration.Spacing = new Qios.DevSuite.Components.QSpacing(0, -11);
			this.qtpLeft.ButtonOrder = 0;
			this.qtpLeft.Controls.Add(this.qMarkupLabel1);
			this.qtpLeft.DockPadding.All = 5;
			this.qtpLeft.Location = new System.Drawing.Point(27, 36);
			this.qtpLeft.Name = "qtpLeft";
			this.qtpLeft.PersistGuid = new System.Guid("04bb8bf1-4fd9-4551-954d-5f13eb7b6a33");
			this.qtpLeft.Size = new System.Drawing.Size(402, 251);
			// 
			// qsLeftTopTab
			// 
			this.qsLeftTopTab.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsLeftTopTab.ContentBounds = new System.Drawing.Rectangle(10, 11, 80, 7);
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(2F, 30F, 7F, 26F, 1F, 25F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(6F, 17F, 3F, 12F, 4F, 2F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, -1F, 20F, -3F, 26F, 2F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(28F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(91F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 8F, 96F, 8F, 96F, 10F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 14F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 22F, 96F, 27F, 95F, 30F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(89F, 30F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsLeftTopTab.Size = new System.Drawing.Size(100, 30);
			// 
			// qMarkupLabel1
			// 
			this.qMarkupLabel1.ColorScheme.MarkupText.ColorReference = "@CompositeText";
			this.qMarkupLabel1.Configuration.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.qMarkupLabel1.Configuration.WrapText = false;
			this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.qMarkupLabel1.Location = new System.Drawing.Point(5, 5);
			this.qMarkupLabel1.MarkupText = "<big><b>Don\'t forget to drag and drop the tabs...</b></big>";
			this.qMarkupLabel1.Name = "qMarkupLabel1";
			this.qMarkupLabel1.Size = new System.Drawing.Size(392, 17);
			this.qMarkupLabel1.TabIndex = 1;
			// 
			// qtpMsdnSite
			// 
			this.qtpMsdnSite.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Bottom;
			this.qtpMsdnSite.ButtonOrder = 2;
			this.qtpMsdnSite.Location = new System.Drawing.Point(27, 36);
			this.qtpMsdnSite.Name = "qtpMsdnSite";
			this.qtpMsdnSite.PersistGuid = new System.Guid("9697e89e-814e-4dfb-a8a2-b4ecfdbafff9");
			this.qtpMsdnSite.Size = new System.Drawing.Size(402, 251);
			this.qtpMsdnSite.Text = "msdn.microsoft.com";
			// 
			// qtpQiosDevSuiteSite
			// 
			this.qtpQiosDevSuiteSite.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Bottom;
			this.qtpQiosDevSuiteSite.ButtonOrder = 1;
			this.qtpQiosDevSuiteSite.Location = new System.Drawing.Point(27, 36);
			this.qtpQiosDevSuiteSite.Name = "qtpQiosDevSuiteSite";
			this.qtpQiosDevSuiteSite.PersistGuid = new System.Guid("15a65649-82df-4747-be66-31642793d14d");
			this.qtpQiosDevSuiteSite.Size = new System.Drawing.Size(402, 251);
			this.qtpQiosDevSuiteSite.Text = "www.qiosdevsuite.com";
			// 
			// qtpQiosPelicanSite
			// 
			this.qtpQiosPelicanSite.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Bottom;
			this.qtpQiosPelicanSite.ButtonOrder = 2;
			this.qtpQiosPelicanSite.Location = new System.Drawing.Point(27, 36);
			this.qtpQiosPelicanSite.Name = "qtpQiosPelicanSite";
			this.qtpQiosPelicanSite.PersistGuid = new System.Guid("3a0bfe8f-88c1-43f3-900c-73bdbe93d316");
			this.qtpQiosPelicanSite.Size = new System.Drawing.Size(402, 251);
			this.qtpQiosPelicanSite.Text = "www.qiospelican.com";
			// 
			// qtpRight
			// 
			this.qtpRight.ButtonBackgroundImage = ((System.Drawing.Image)(resources.GetObject("qtpRight.ButtonBackgroundImage")));
			this.qtpRight.ButtonConfiguration.Appearance.Shape = this.qsRightTopTab;
			this.qtpRight.ButtonConfiguration.AppearanceActive.Shape = this.qsRightTopTab;
			this.qtpRight.ButtonConfiguration.AppearanceHot.Shape = this.qsRightTopTab;
			this.qtpRight.ButtonConfiguration.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomRight;
			this.qtpRight.ButtonConfiguration.BackgroundImageClip = false;
			this.qtpRight.ButtonConfiguration.MaximumSize = new System.Drawing.Size(40, -1);
			this.qtpRight.ButtonConfiguration.MinimumSize = new System.Drawing.Size(40, 30);
			this.qtpRight.ButtonConfiguration.Spacing = new Qios.DevSuite.Components.QSpacing(-11, 0);
			this.qtpRight.ButtonOrder = 5;
			this.qtpRight.Location = new System.Drawing.Point(27, 36);
			this.qtpRight.Name = "qtpRight";
			this.qtpRight.PersistGuid = new System.Guid("9446d293-eef0-4779-9fc2-a231dbf806e1");
			this.qtpRight.Size = new System.Drawing.Size(402, 251);
			// 
			// qsRightTopTab
			// 
			this.qsRightTopTab.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsRightTopTab.ContentBounds = new System.Drawing.Rectangle(10, 4, 27, 24);
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(45F, 12F, 34F, 17F, 32F, 23F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(33F, 30F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(13F, 30F, 7F, 30F, 4F, 29F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 22F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 18F, 5F, 8F, 3F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 8F, 14F, 5F, 18F, 1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(22F, -2F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(45F, 3F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(34F, 9F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsRightTopTab.Size = new System.Drawing.Size(40, 30);
			// 
			// qtpContents
			// 
			this.qtpContents.ButtonOrder = 3;
			this.qtpContents.Location = new System.Drawing.Point(27, 36);
			this.qtpContents.Name = "qtpContents";
			this.qtpContents.PersistGuid = new System.Guid("ffcda2ca-01e0-4594-853a-4cb76940c1e9");
			this.qtpContents.Size = new System.Drawing.Size(402, 251);
			this.qtpContents.Text = "Contents";
			// 
			// qtpSearch
			// 
			this.qtpSearch.ButtonOrder = 2;
			this.qtpSearch.Location = new System.Drawing.Point(27, 36);
			this.qtpSearch.Name = "qtpSearch";
			this.qtpSearch.PersistGuid = new System.Guid("2aed2228-3698-435b-9a0b-134a5f9691e7");
			this.qtpSearch.Size = new System.Drawing.Size(402, 251);
			this.qtpSearch.Text = "Search";
			// 
			// qtpGettingStarted
			// 
			this.qtpGettingStarted.ButtonConfiguration.Appearance.Shape = this.qsSecondLeftTopTab;
			this.qtpGettingStarted.ButtonConfiguration.AppearanceActive.Shape = this.qsSecondLeftTopTab;
			this.qtpGettingStarted.ButtonConfiguration.AppearanceHot.Shape = this.qsSecondLeftTopTab;
			this.qtpGettingStarted.ButtonOrder = 1;
			this.qtpGettingStarted.Location = new System.Drawing.Point(27, 36);
			this.qtpGettingStarted.Name = "qtpGettingStarted";
			this.qtpGettingStarted.PersistGuid = new System.Guid("20fabb89-402f-4b02-9524-38451050cfac");
			this.qtpGettingStarted.Size = new System.Drawing.Size(402, 251);
			this.qtpGettingStarted.Text = "Getting started";
			// 
			// qsSecondLeftTopTab
			// 
			this.qsSecondLeftTopTab.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsSecondLeftTopTab.ContentBounds = new System.Drawing.Rectangle(10, 2, 88, 16);
			this.qsSecondLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, 4F, 20F, 7F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSecondLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(7F, 13F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSecondLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(7F, 8F, 7F, 4F, 7F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSecondLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSecondLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsSecondLeftTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// qtpHelp
			// 
			this.qtpHelp.ButtonConfiguration.Appearance.Shape = this.qsSecondRightTopTab;
			this.qtpHelp.ButtonConfiguration.AppearanceActive.Shape = this.qsSecondRightTopTab;
			this.qtpHelp.ButtonConfiguration.AppearanceHot.Shape = this.qsSecondRightTopTab;
			this.qtpHelp.ButtonOrder = 4;
			this.qtpHelp.Location = new System.Drawing.Point(27, 36);
			this.qtpHelp.Name = "qtpHelp";
			this.qtpHelp.PersistGuid = new System.Guid("7b87119b-1168-4a84-b3e1-6ac73d72d4eb");
			this.qtpHelp.Size = new System.Drawing.Size(402, 251);
			this.qtpHelp.Text = "Help";
			// 
			// qsSecondRightTopTab
			// 
			this.qsSecondRightTopTab.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsSecondRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSecondRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSecondRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(88F, 0F, 93F, 0F, 93F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsSecondRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(93F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsSecondRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(93F, 13F, 93F, 20F, 96F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsSecondRightTopTab.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// qtpSettings
			// 
			this.qtpSettings.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qtpSettings.ButtonOrder = 0;
			this.qtpSettings.Location = new System.Drawing.Point(27, 36);
			this.qtpSettings.Name = "qtpSettings";
			this.qtpSettings.PersistGuid = new System.Guid("ca341252-bcf7-4b55-a6a3-9c59c161700a");
			this.qtpSettings.Size = new System.Drawing.Size(402, 251);
			this.qtpSettings.Text = "Settings";
			// 
			// qtpAccounts
			// 
			this.qtpAccounts.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qtpAccounts.ButtonOrder = 1;
			this.qtpAccounts.Location = new System.Drawing.Point(27, 36);
			this.qtpAccounts.Name = "qtpAccounts";
			this.qtpAccounts.PersistGuid = new System.Guid("e654b4bd-ac43-46af-bb8c-61377b4f2f6e");
			this.qtpAccounts.Size = new System.Drawing.Size(402, 251);
			this.qtpAccounts.Text = "Accounts";
			// 
			// qtpOptions
			// 
			this.qtpOptions.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qtpOptions.ButtonOrder = 2;
			this.qtpOptions.Location = new System.Drawing.Point(27, 36);
			this.qtpOptions.Name = "qtpOptions";
			this.qtpOptions.PersistGuid = new System.Guid("8dedc328-ddc5-428e-ae48-ef982ce28a07");
			this.qtpOptions.Size = new System.Drawing.Size(402, 251);
			this.qtpOptions.Text = "Options";
			// 
			// qtpControlPanel
			// 
			this.qtpControlPanel.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qtpControlPanel.ButtonOrder = 3;
			this.qtpControlPanel.Location = new System.Drawing.Point(27, 36);
			this.qtpControlPanel.Name = "qtpControlPanel";
			this.qtpControlPanel.PersistGuid = new System.Guid("ce804622-73e2-48d0-9522-88a376bf470f");
			this.qtpControlPanel.Size = new System.Drawing.Size(402, 251);
			this.qtpControlPanel.Text = "Control Panel";
			// 
			// qtpAbout
			// 
			this.qtpAbout.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qtpAbout.ButtonOrder = 4;
			this.qtpAbout.Location = new System.Drawing.Point(27, 36);
			this.qtpAbout.Name = "qtpAbout";
			this.qtpAbout.PersistGuid = new System.Guid("ff317f59-2272-4ca7-97b6-1a8d65b36529");
			this.qtpAbout.Size = new System.Drawing.Size(402, 251);
			this.qtpAbout.Text = "About";
			// 
			// qtpMyNetworkPlaces
			// 
			this.qtpMyNetworkPlaces.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
			this.qtpMyNetworkPlaces.ButtonOrder = 0;
			this.qtpMyNetworkPlaces.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpMyNetworkPlaces.Icon")));
			this.qtpMyNetworkPlaces.Location = new System.Drawing.Point(27, 36);
			this.qtpMyNetworkPlaces.Name = "qtpMyNetworkPlaces";
			this.qtpMyNetworkPlaces.PersistGuid = new System.Guid("b692ce74-09be-4817-86c7-909a5139693d");
			this.qtpMyNetworkPlaces.Size = new System.Drawing.Size(402, 251);
			// 
			// qtpMyComputer
			// 
			this.qtpMyComputer.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
			this.qtpMyComputer.ButtonOrder = 1;
			this.qtpMyComputer.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpMyComputer.Icon")));
			this.qtpMyComputer.Location = new System.Drawing.Point(27, 36);
			this.qtpMyComputer.Name = "qtpMyComputer";
			this.qtpMyComputer.PersistGuid = new System.Guid("ad75cf97-4de4-4058-ae2d-09455ccb74fd");
			this.qtpMyComputer.Size = new System.Drawing.Size(402, 251);
			// 
			// qtpMyDocuments
			// 
			this.qtpMyDocuments.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
			this.qtpMyDocuments.ButtonOrder = 2;
			this.qtpMyDocuments.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpMyDocuments.Icon")));
			this.qtpMyDocuments.Location = new System.Drawing.Point(27, 36);
			this.qtpMyDocuments.Name = "qtpMyDocuments";
			this.qtpMyDocuments.PersistGuid = new System.Guid("af6c5a5e-de8a-47af-91cc-5a80a454dcaf");
			this.qtpMyDocuments.Size = new System.Drawing.Size(402, 251);
			// 
			// qtpPicturePrint
			// 
			this.qtpPicturePrint.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Right;
			this.qtpPicturePrint.ButtonOrder = 3;
			this.qtpPicturePrint.Icon = ((System.Drawing.Icon)(resources.GetObject("qtpPicturePrint.Icon")));
			this.qtpPicturePrint.Location = new System.Drawing.Point(27, 36);
			this.qtpPicturePrint.Name = "qtpPicturePrint";
			this.qtpPicturePrint.PersistGuid = new System.Guid("47bac9c9-9ec7-4ece-a21b-93ed075e93f3");
			this.qtpPicturePrint.Size = new System.Drawing.Size(402, 251);
			// 
			// qtpWindowsFormsSite
			// 
			this.qtpWindowsFormsSite.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Bottom;
			this.qtpWindowsFormsSite.ButtonOrder = 3;
			this.qtpWindowsFormsSite.Location = new System.Drawing.Point(27, 36);
			this.qtpWindowsFormsSite.Name = "qtpWindowsFormsSite";
			this.qtpWindowsFormsSite.PersistGuid = new System.Guid("ab10da4c-40bd-46cf-ac01-b8dc9dfb7617");
			this.qtpWindowsFormsSite.Size = new System.Drawing.Size(402, 251);
			this.qtpWindowsFormsSite.Text = "www.windowsforms.net";
			// 
			// qtpFavorites
			// 
			this.qtpFavorites.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Bottom;
			this.qtpFavorites.ButtonOrder = 0;
			this.qtpFavorites.Location = new System.Drawing.Point(27, 36);
			this.qtpFavorites.Name = "qtpFavorites";
			this.qtpFavorites.PersistGuid = new System.Guid("cdcc638c-3170-4e72-a894-322985416be1");
			this.qtpFavorites.Size = new System.Drawing.Size(402, 251);
			this.qtpFavorites.Text = "Favorites";
			// 
			// qShape1
			// 
			this.qShape1.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.LeftCurvedTabStripNavigationArea;
			this.qShape1.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qShape1.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 5F, 15F, 1F, 17F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qShape1.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qShape1.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qShape1.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			// 
			// UcCustom01
			// 
			this.Controls.Add(this.qTabControl1);
			this.Name = "UcCustom01";
			this.Size = new System.Drawing.Size(480, 336);
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).EndInit();
			this.qTabControl1.ResumeLayout(false);
			this.qtpLeft.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
