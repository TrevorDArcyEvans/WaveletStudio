using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.TabControl
{
	/// <summary>
	/// Summary description for UcCustom01.
	/// </summary>
	public class UcCustom02 : System.Windows.Forms.UserControl
	{
		private Qios.DevSuite.Components.QTabControl qTabControl1;
		private Qios.DevSuite.Components.QShape qsMickey;
		private Qios.DevSuite.Components.QShape qsDonald;
		private Qios.DevSuite.Components.QShape qsGoofy;
		private Qios.DevSuite.Components.QShape qsDaisy;
		private Qios.DevSuite.Components.QShape qsMinnie;
		private Qios.DevSuite.Components.QShape qsPluto;
		private Qios.DevSuite.Components.QTabPage qtpMinnie;
		private Qios.DevSuite.Components.QTabPage qtpGoofy;
		private Qios.DevSuite.Components.QTabPage qtpDonald;
		private Qios.DevSuite.Components.QTabPage qtpMickey;
		private Qios.DevSuite.Components.QTabPage qtpDaisy;
		private Qios.DevSuite.Components.QTabPage qtpPluto;
		private Qios.DevSuite.Components.QShape qsNavigationArea;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public UcCustom02()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(UcCustom02));
			this.qTabControl1 = new Qios.DevSuite.Components.QTabControl();
			this.qtpMickey = new Qios.DevSuite.Components.QTabPage();
			this.qsMickey = new Qios.DevSuite.Components.QShape();
			this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
			this.qtpGoofy = new Qios.DevSuite.Components.QTabPage();
			this.qsGoofy = new Qios.DevSuite.Components.QShape();
			this.qtpDaisy = new Qios.DevSuite.Components.QTabPage();
			this.qsDaisy = new Qios.DevSuite.Components.QShape();
			this.qtpDonald = new Qios.DevSuite.Components.QTabPage();
			this.qsDonald = new Qios.DevSuite.Components.QShape();
			this.qtpMinnie = new Qios.DevSuite.Components.QTabPage();
			this.qsMinnie = new Qios.DevSuite.Components.QShape();
			this.qtpPluto = new Qios.DevSuite.Components.QTabPage();
			this.qsPluto = new Qios.DevSuite.Components.QShape();
			this.qsNavigationArea = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).BeginInit();
			this.qTabControl1.SuspendLayout();
			this.qtpMickey.SuspendLayout();
			this.SuspendLayout();
			// 
			// qTabControl1
			// 
			this.qTabControl1.ActiveTabPage = this.qtpMickey;
			this.qTabControl1.Appearance.ShowBorders = false;
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabControlBackground1.SetColor("HighContrast", System.Drawing.SystemColors.Window, false);
			this.qTabControl1.ColorScheme.TabControlBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabControlBackground2.SetColor("HighContrast", System.Drawing.SystemColors.Window, false);
			this.qTabControl1.ColorScheme.TabControlBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabPageBorder.ColorReference = "@TabStripBorder";
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("Default", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaBlue", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaOlive", System.Drawing.Color.Black, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaSilver", System.Drawing.Color.Black, false);
			this.qTabControl1.Controls.Add(this.qtpGoofy);
			this.qTabControl1.Controls.Add(this.qtpDaisy);
			this.qTabControl1.Controls.Add(this.qtpMickey);
			this.qTabControl1.Controls.Add(this.qtpDonald);
			this.qTabControl1.Controls.Add(this.qtpMinnie);
			this.qTabControl1.Controls.Add(this.qtpPluto);
			this.qTabControl1.Cursor = System.Windows.Forms.Cursors.Default;
			this.qTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qTabControl1.FocusTabButtons = false;
			this.qTabControl1.Location = new System.Drawing.Point(0, 0);
			this.qTabControl1.Name = "qTabControl1";
			this.qTabControl1.PersistGuid = new System.Guid("739ddeb5-91c6-4fa7-9700-eed4027d0fdb");
			this.qTabControl1.Size = new System.Drawing.Size(432, 368);
			this.qTabControl1.TabIndex = 0;
			this.qTabControl1.TabStripTopConfiguration.ButtonAreaMargin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 0);
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.BorderWidth = 2;
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.MinimumSize = new System.Drawing.Size(30, 22);
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
			this.qTabControl1.TabStripTopConfiguration.ButtonSpacing = -10;
			this.qTabControl1.TabStripTopConfiguration.NavigationAreaAlignment = Qios.DevSuite.Components.QContentAlignment.Far;
			this.qTabControl1.TabStripTopConfiguration.NavigationAreaAppearance.Shape = this.qsNavigationArea;
			// 
			// qtpMickey
			// 
			this.qtpMickey.Appearance.ShowBorders = true;
			this.qtpMickey.Appearance.ShowBorderTop = false;
			this.qtpMickey.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qtpMickey.BackgroundImage")));
			this.qtpMickey.ButtonConfiguration.Appearance.Shape = this.qsMickey;
			this.qtpMickey.ButtonConfiguration.AppearanceActive.Shape = this.qsMickey;
			this.qtpMickey.ButtonConfiguration.AppearanceHot.Shape = this.qsMickey;
			this.qtpMickey.ButtonConfiguration.MaximumSize = new System.Drawing.Size(64, 64);
			this.qtpMickey.ButtonConfiguration.MinimumSize = new System.Drawing.Size(64, 64);
			this.qtpMickey.ButtonOrder = 0;
			this.qtpMickey.Controls.Add(this.qMarkupLabel1);
			this.qtpMickey.DockPadding.All = 5;
			this.qtpMickey.Location = new System.Drawing.Point(0, 65);
			this.qtpMickey.Name = "qtpMickey";
			this.qtpMickey.PersistGuid = new System.Guid("1683feca-7272-4afe-be4a-499774195b49");
			this.qtpMickey.Size = new System.Drawing.Size(432, 303);
			// 
			// qsMickey
			// 
			this.qsMickey.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsMickey.ContentBounds = new System.Drawing.Rectangle(20, 32, 33, 32);
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 56F, 19F, 52F, 19F, 45F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 42F, 10F, 51F, -3F, 36F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(3F, 25F, 4F, 18F, 23F, 12F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 33F, 25F, 31F, 29F, 26F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(38F, 26F, 27F, 15F, 35F, 5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(40F, 5F, 54F, 5F, 62F, 25F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(47F, 29F, 53F, 32F, 54F, 36F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(56F, 41F, 58F, 45F, 56F, 58F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(44F, 64F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsMickey.Items.Add(new Qios.DevSuite.Components.QShapeItem(32F, 64F, 27F, 63F, 24F, 60F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMickey.Precision = 2;
			this.qsMickey.ShapeName = null;
			this.qsMickey.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			this.qsMickey.Size = new System.Drawing.Size(64, 64);
			// 
			// qMarkupLabel1
			// 
			this.qMarkupLabel1.ColorScheme.MarkupText.ColorReference = "@CompositeText";
			this.qMarkupLabel1.Configuration.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.qMarkupLabel1.Configuration.WrapText = false;
			this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.qMarkupLabel1.Location = new System.Drawing.Point(5, 5);
			this.qMarkupLabel1.MarkupText = "<big><b>What kind of shape do you want?... <br /><br />A Mickey Mouse Shape?</b><" +
				"/big>";
			this.qMarkupLabel1.Name = "qMarkupLabel1";
			this.qMarkupLabel1.Size = new System.Drawing.Size(420, 51);
			this.qMarkupLabel1.TabIndex = 0;
			// 
			// qtpGoofy
			// 
			this.qtpGoofy.Appearance.ShowBorders = true;
			this.qtpGoofy.Appearance.ShowBorderTop = false;
			this.qtpGoofy.ButtonConfiguration.Appearance.Shape = this.qsGoofy;
			this.qtpGoofy.ButtonConfiguration.AppearanceActive.Shape = this.qsGoofy;
			this.qtpGoofy.ButtonConfiguration.AppearanceHot.Shape = this.qsGoofy;
			this.qtpGoofy.ButtonConfiguration.MaximumSize = new System.Drawing.Size(64, 64);
			this.qtpGoofy.ButtonConfiguration.MinimumSize = new System.Drawing.Size(64, 64);
			this.qtpGoofy.ButtonOrder = 2;
			this.qtpGoofy.Location = new System.Drawing.Point(0, 65);
			this.qtpGoofy.Name = "qtpGoofy";
			this.qtpGoofy.PersistGuid = new System.Guid("71a7d70e-18b9-48a5-ba02-29908ef3b0aa");
			this.qtpGoofy.Size = new System.Drawing.Size(432, 303);
			// 
			// qsGoofy
			// 
			this.qsGoofy.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsGoofy.ContentBounds = new System.Drawing.Rectangle(6, 32, 45, 32);
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(19.4F, 45.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(21F, 40.8F, 11.6F, 42.6F, 10.9F, 45.3F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(8.1F, 55.7F, 3.3F, 66.5F, -2.5F, 61F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(4.3F, 48.3F, 9.9F, 39.4F, 17.3F, 39.5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(21.6F, 37.2F, 24.1F, 29.3F, 27.8F, 24.4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(31.6F, 24.8F, 32.6F, 21.8F, 32.6F, 18.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(31.4F, 18.1F, 32.9F, 16.1F, 34.2F, 15.9F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(36.2F, 16.1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(39.6F, 11.8F, 35.6F, -4.2F, 53.6F, -0.2F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(50.6F, 8.8F, 59.6F, 11.8F, 64.6F, 27.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(47.6F, 21.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(44.6F, 24.8F, 45.3F, 26.3F, 45.6F, 27.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(44.6F, 28.8F, 40.6F, 28.8F, 38.6F, 30.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(36.6F, 32.8F, 37.6F, 33.7F, 38.1F, 36.5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(37.9F, 39.3F, 46.5F, 44.3F, 55F, 41F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(59.3F, 50.2F, 62.4F, 65.1F, 56F, 65F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(53.2F, 53.7F, 51.1F, 48F, 46.6F, 47F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(37.4F, 41.8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(36.9F, 46.9F, 47.2F, 52.2F, 43.8F, 58.6F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(33.8F, 64.1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsGoofy.Items.Add(new Qios.DevSuite.Components.QShapeItem(20.6F, 64.1F, 6.6F, 57.6F, 9.6F, 48.5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsGoofy.Precision = 1;
			this.qsGoofy.ShapeName = null;
			this.qsGoofy.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			this.qsGoofy.Size = new System.Drawing.Size(64, 64);
			// 
			// qtpDaisy
			// 
			this.qtpDaisy.Appearance.ShowBorders = true;
			this.qtpDaisy.Appearance.ShowBorderTop = false;
			this.qtpDaisy.ButtonConfiguration.Appearance.Shape = this.qsDaisy;
			this.qtpDaisy.ButtonConfiguration.AppearanceActive.Shape = this.qsDaisy;
			this.qtpDaisy.ButtonConfiguration.AppearanceHot.Shape = this.qsDaisy;
			this.qtpDaisy.ButtonConfiguration.MaximumSize = new System.Drawing.Size(64, 64);
			this.qtpDaisy.ButtonConfiguration.MinimumSize = new System.Drawing.Size(64, 64);
			this.qtpDaisy.ButtonOrder = 3;
			this.qtpDaisy.Location = new System.Drawing.Point(0, 65);
			this.qtpDaisy.Name = "qtpDaisy";
			this.qtpDaisy.PersistGuid = new System.Guid("cef7a1ff-e688-4165-8763-c5fd4df0be7d");
			this.qtpDaisy.Size = new System.Drawing.Size(432, 303);
			// 
			// qsDaisy
			// 
			this.qsDaisy.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsDaisy.ContentBounds = new System.Drawing.Rectangle(10, 32, 38, 33);
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(23.67F, 28.62F, 11.7F, 36.69F, 13.46F, 20.1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(25.31F, 15.02F, 17.11F, 17.97F, 32.35F, -0.97F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(36.34F, 1.71F, 40.33F, 2.96F, 45.1F, 8.86F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(38.8F, 23.16F, 42.33F, 11.5F, 55.79F, 7.28F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(58.93F, 11.39F, 63.64F, 13.98F, 54.05F, 36.07F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(51.96F, 26.76F, 55.23F, 39.96F, 52.68F, 50.5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(46.88F, 40.39F, 50.44F, 48.2F, 45.1F, 57.28F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(38.81F, 63.85F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsDaisy.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 64F, 13.42F, 59.09F, 2.45F, 37.46F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDaisy.Precision = 2;
			this.qsDaisy.ShapeName = null;
			this.qsDaisy.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			this.qsDaisy.Size = new System.Drawing.Size(64, 64);
			// 
			// qtpDonald
			// 
			this.qtpDonald.Appearance.ShowBorders = true;
			this.qtpDonald.Appearance.ShowBorderTop = false;
			this.qtpDonald.ButtonConfiguration.Appearance.Shape = this.qsDonald;
			this.qtpDonald.ButtonConfiguration.AppearanceActive.Shape = this.qsDonald;
			this.qtpDonald.ButtonConfiguration.AppearanceHot.Shape = this.qsDonald;
			this.qtpDonald.ButtonConfiguration.MaximumSize = new System.Drawing.Size(64, 64);
			this.qtpDonald.ButtonConfiguration.MinimumSize = new System.Drawing.Size(64, 64);
			this.qtpDonald.ButtonOrder = 1;
			this.qtpDonald.Location = new System.Drawing.Point(0, 65);
			this.qtpDonald.Name = "qtpDonald";
			this.qtpDonald.PersistGuid = new System.Guid("9df1332e-cfbf-4cc1-b2b3-78f2b69f30c0");
			this.qtpDonald.Size = new System.Drawing.Size(432, 303);
			// 
			// qsDonald
			// 
			this.qsDonald.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsDonald.ContentBounds = new System.Drawing.Rectangle(12, 32, 37, 32);
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 37F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 36F, 14F, 42F, 12F, 47F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(8F, 54F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(7F, 46F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(2F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 33F, 2F, 24F, 18F, 19F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(25F, 15F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(21F, 23F, 35F, -3F, 44F, -1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(51F, 5F, 55F, 9F, 50F, 22F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(45F, 25F, 53F, 29F, 56F, 40F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(50F, 54F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(46F, 64F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsDonald.Items.Add(new Qios.DevSuite.Components.QShapeItem(24F, 64F, 20F, 58F, 16F, 42F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDonald.Precision = 2;
			this.qsDonald.ShapeName = null;
			this.qsDonald.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			this.qsDonald.Size = new System.Drawing.Size(64, 64);
			// 
			// qtpMinnie
			// 
			this.qtpMinnie.Appearance.ShowBorders = true;
			this.qtpMinnie.Appearance.ShowBorderTop = false;
			this.qtpMinnie.ButtonConfiguration.Appearance.Shape = this.qsMinnie;
			this.qtpMinnie.ButtonConfiguration.AppearanceActive.Shape = this.qsMinnie;
			this.qtpMinnie.ButtonConfiguration.AppearanceHot.Shape = this.qsMinnie;
			this.qtpMinnie.ButtonConfiguration.MaximumSize = new System.Drawing.Size(64, 64);
			this.qtpMinnie.ButtonConfiguration.MinimumSize = new System.Drawing.Size(64, 64);
			this.qtpMinnie.ButtonOrder = 4;
			this.qtpMinnie.Location = new System.Drawing.Point(0, 65);
			this.qtpMinnie.Name = "qtpMinnie";
			this.qtpMinnie.PersistGuid = new System.Guid("d215d4ca-6f90-43c0-a9df-8dca4864b47d");
			this.qtpMinnie.Size = new System.Drawing.Size(432, 303);
			// 
			// qsMinnie
			// 
			this.qsMinnie.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsMinnie.ContentBounds = new System.Drawing.Rectangle(20, 32, 39, 32);
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(19.1F, 43.81F, -2.58F, 53.63F, -6.09F, 20.27F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(14.45F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(16.41F, 27.28F, 4.35F, -3.41F, 26.61F, 7.13F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(32.66F, 24.25F, 32.01F, 21.2F, 34.04F, 19.24F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(36.28F, 21.55F, 33F, 13.65F, 41.78F, 1.27F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(46.45F, 0.17F, 49.99F, 0.39F, 52.84F, 3.86F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(51.97F, 16.53F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(52.45F, 10.29F, 66.93F, 11.41F, 64.48F, 32.52F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(52.02F, 31.94F, 59.7F, 37.05F, 62.48F, 55.84F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(53.98F, 63.99F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsMinnie.Items.Add(new Qios.DevSuite.Components.QShapeItem(27.28F, 64F, 18.8F, 57.69F, 17.46F, 47.81F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsMinnie.Precision = 2;
			this.qsMinnie.ShapeName = null;
			this.qsMinnie.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			this.qsMinnie.Size = new System.Drawing.Size(64, 64);
			// 
			// qtpPluto
			// 
			this.qtpPluto.Appearance.ShowBorders = true;
			this.qtpPluto.Appearance.ShowBorderTop = false;
			this.qtpPluto.ButtonConfiguration.Appearance.Shape = this.qsPluto;
			this.qtpPluto.ButtonConfiguration.AppearanceActive.Shape = this.qsPluto;
			this.qtpPluto.ButtonConfiguration.AppearanceHot.Shape = this.qsPluto;
			this.qtpPluto.ButtonConfiguration.MaximumSize = new System.Drawing.Size(64, 64);
			this.qtpPluto.ButtonConfiguration.MinimumSize = new System.Drawing.Size(64, 64);
			this.qtpPluto.ButtonOrder = 5;
			this.qtpPluto.Location = new System.Drawing.Point(0, 65);
			this.qtpPluto.Name = "qtpPluto";
			this.qtpPluto.PersistGuid = new System.Guid("85a00310-d31f-4933-b93a-917ebf03ac84");
			this.qtpPluto.Size = new System.Drawing.Size(432, 303);
			// 
			// qsPluto
			// 
			this.qsPluto.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsPluto.ContentBounds = new System.Drawing.Rectangle(11, 32, 31, 32);
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(23.1F, 52.28F, 11.65F, 52.84F, 16.89F, 42.75F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(20.77F, 36.76F, 17.85F, 35.15F, 15.69F, 32.6F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(14.59F, 29.39F, 9.15F, 27.64F, 9.3F, 16.99F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(14.38F, 17.99F, 15.19F, 13.8F, 22.19F, 15.05F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(18.45F, 23.63F, 19.65F, 16.96F, 26.29F, 24.54F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(28.62F, 27.12F, 31.16F, 20.66F, 33.1F, 18.62F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(37.13F, 17.72F, 43.02F, 15.8F, 45.9F, 17.18F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(40.27F, 20.7F, 46.38F, 18.05F, 49.79F, 20.72F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(45.29F, 26.66F, 47.72F, 29.62F, 46.85F, 33.97F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(42.55F, 35.67F, 43.95F, 47.06F, 45.11F, 54.04F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(43.88F, 59.32F, 42.6F, 64.71F, 38.18F, 65.5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(39.08F, 56.01F, 39.02F, 49.84F, 39.47F, 44.09F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(39.85F, 36.87F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(37.59F, 37.59F, 35.25F, 40.71F, 33.43F, 44.91F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(32.79F, 48.25F, 32.2F, 56.19F, 35.7F, 54.79F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(37.8F, 64.2F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsPluto.Items.Add(new Qios.DevSuite.Components.QShapeItem(13.5F, 64.23F, 13.65F, 61.85F, 21.16F, 53F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsPluto.Precision = 2;
			this.qsPluto.ShapeName = null;
			this.qsPluto.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			this.qsPluto.Size = new System.Drawing.Size(64, 64);
			// 
			// qsNavigationArea
			// 
			this.qsNavigationArea.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.LeftCurvedTabStripNavigationArea;
			this.qsNavigationArea.ContentBounds = new System.Drawing.Rectangle(13, 2, 85, 16);
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 5F, 15F, 1F, 17F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsNavigationArea.Precision = 2;
			this.qsNavigationArea.ShapeName = null;
			this.qsNavigationArea.ShapeType = Qios.DevSuite.Components.QShapeType.Generic;
			// 
			// UcCustom02
			// 
			this.Controls.Add(this.qTabControl1);
			this.Name = "UcCustom02";
			this.Size = new System.Drawing.Size(432, 368);
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).EndInit();
			this.qTabControl1.ResumeLayout(false);
			this.qtpMickey.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
