using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.TabControl
{
	/// <summary>
	/// Summary description for UcOneNote.
	/// </summary>
	public class UcOneNote : System.Windows.Forms.UserControl
	{
		private Qios.DevSuite.Components.QTabControl qTabControl1;
		private Qios.DevSuite.Components.QTabPage qtpNewSection;
		private Qios.DevSuite.Components.QShape qsTabButton;
		private Qios.DevSuite.Components.QTabPage qtpNewSection1;
		private Qios.DevSuite.Components.QTabPage qtpNewSection2;
		private Qios.DevSuite.Components.QTextBox tbFind;
		private Qios.DevSuite.Components.QTabPage qtpSubPage1;
		private Qios.DevSuite.Components.QTabPage qTabPage1;
		private Qios.DevSuite.Components.QPanel qPanel2;
		private Qios.DevSuite.Components.QTabPage qTabPage2;
		private Qios.DevSuite.Components.QPanel qPanel3;
		private Qios.DevSuite.Components.QShape qsSubTabButton;
		private Qios.DevSuite.Components.QTabPage qTabPage3;
		private Qios.DevSuite.Components.QTabPage qTabPage4;
		private Qios.DevSuite.Components.QPanel qPanel1;
		private Qios.DevSuite.Components.QShape qsNewSubPageTabButton;
		private Qios.DevSuite.Components.QTabControl qtcChildTabControl;

		public UcOneNote()
		{
			this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(UcOneNote));
			this.qTabControl1 = new Qios.DevSuite.Components.QTabControl();
			this.qtpNewSection = new Qios.DevSuite.Components.QTabPage();
			this.qtcChildTabControl = new Qios.DevSuite.Components.QTabControl();
			this.qTabPage1 = new Qios.DevSuite.Components.QTabPage();
			this.qPanel2 = new Qios.DevSuite.Components.QPanel();
			this.qTabPage4 = new Qios.DevSuite.Components.QTabPage();
			this.qsNewSubPageTabButton = new Qios.DevSuite.Components.QShape();
			this.qTabPage3 = new Qios.DevSuite.Components.QTabPage();
			this.qTabPage2 = new Qios.DevSuite.Components.QTabPage();
			this.qPanel3 = new Qios.DevSuite.Components.QPanel();
			this.qtpSubPage1 = new Qios.DevSuite.Components.QTabPage();
			this.qPanel1 = new Qios.DevSuite.Components.QPanel();
			this.qsSubTabButton = new Qios.DevSuite.Components.QShape();
			this.tbFind = new Qios.DevSuite.Components.QTextBox();
			this.qtpNewSection1 = new Qios.DevSuite.Components.QTabPage();
			this.qtpNewSection2 = new Qios.DevSuite.Components.QTabPage();
			this.qsTabButton = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).BeginInit();
			this.qTabControl1.SuspendLayout();
			this.qtpNewSection.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.qtcChildTabControl)).BeginInit();
			this.qtcChildTabControl.SuspendLayout();
			this.qTabPage1.SuspendLayout();
			this.qTabPage2.SuspendLayout();
			this.qtpSubPage1.SuspendLayout();
			this.SuspendLayout();
			// 
			// qTabControl1
			// 
			this.qTabControl1.ActiveTabPage = this.qtpNewSection;
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("Default", System.Drawing.Color.Moccasin, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("LunaBlue", System.Drawing.Color.Moccasin, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("LunaOlive", System.Drawing.Color.Moccasin, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("LunaSilver", System.Drawing.Color.Moccasin, false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("VistaBlack", System.Drawing.Color.Moccasin, false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("Default", System.Drawing.SystemColors.Control, false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(217)), ((System.Byte)(217)), ((System.Byte)(176))), false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(215)), ((System.Byte)(215)), ((System.Byte)(229))), false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(215)), ((System.Byte)(215)), ((System.Byte)(229))), false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground1.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground1.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground1.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground1.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground1.SetColor("VistaBlack", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("VistaBlack", System.Drawing.Color.Transparent, false);
			this.qTabControl1.Controls.Add(this.tbFind);
			this.qTabControl1.Controls.Add(this.qtpNewSection1);
			this.qTabControl1.Controls.Add(this.qtpNewSection);
			this.qTabControl1.Controls.Add(this.qtpNewSection2);
			this.qTabControl1.Cursor = System.Windows.Forms.Cursors.Default;
			this.qTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qTabControl1.FocusTabButtons = false;
			this.qTabControl1.Location = new System.Drawing.Point(0, 0);
			this.qTabControl1.Name = "qTabControl1";
			this.qTabControl1.PersistGuid = new System.Guid("2c333e2b-007f-41e1-8bb7-b3b6f805edfe");
			this.qTabControl1.Size = new System.Drawing.Size(432, 256);
			this.qTabControl1.TabIndex = 0;
			this.qTabControl1.TabStripTopConfiguration.Appearance.GradientAngle = 90;
			this.qTabControl1.TabStripTopConfiguration.ButtonAreaClip = true;
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.GradientAngle = 90;
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.Shape = this.qsTabButton;
			this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.AppearanceHot.BorderWidth = 2;
			this.qTabControl1.TabStripTopConfiguration.StripPadding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 120);
			this.qTabControl1.Text = "qTabControl1";
			this.qTabControl1.WrapTabButtonNavigationAround = false;
			// 
			// qtpNewSection
			// 
			this.qtpNewSection.Appearance.GradientAngle = 90;
			this.qtpNewSection.Appearance.GradientBlendFactor = 80;
			this.qtpNewSection.ButtonOrder = 0;
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonActiveBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabPageBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabPageBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(186)), ((System.Byte)(174))), false);
			this.qtpNewSection.ColorScheme.TabPageBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabPageBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabPageBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabPageBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection.ColorScheme.TabPageBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qtpNewSection.Controls.Add(this.qtcChildTabControl);
			this.qtpNewSection.DockPadding.All = 5;
			this.qtpNewSection.Location = new System.Drawing.Point(0, 27);
			this.qtpNewSection.Name = "qtpNewSection";
			this.qtpNewSection.PersistGuid = new System.Guid("cc0537d4-5b4b-4a46-a392-fc8aee744a10");
			this.qtpNewSection.Size = new System.Drawing.Size(430, 227);
			this.qtpNewSection.Text = "New Section";
			// 
			// qtcChildTabControl
			// 
			this.qtcChildTabControl.ActiveTabPage = this.qTabPage1;
			this.qtcChildTabControl.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qtcChildTabControl.Appearance.ShowBorders = false;
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground2.SetColor("Default", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground2.SetColor("LunaBlue", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground2.SetColor("LunaOlive", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground2.SetColor("LunaSilver", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBackground2.SetColor("VistaBlack", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonActiveBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(201)), ((System.Byte)(221)), ((System.Byte)(215))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(201)), ((System.Byte)(221)), ((System.Byte)(215))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(201)), ((System.Byte)(221)), ((System.Byte)(215))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(201)), ((System.Byte)(221)), ((System.Byte)(215))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(201)), ((System.Byte)(221)), ((System.Byte)(215))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground1.SetColor("Default", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground1.SetColor("LunaBlue", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground1.SetColor("LunaOlive", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground1.SetColor("LunaSilver", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground1.SetColor("VistaBlack", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground2.SetColor("Default", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground2.SetColor("LunaBlue", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground2.SetColor("LunaOlive", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground2.SetColor("LunaSilver", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBackground2.SetColor("VistaBlack", System.Drawing.Color.Moccasin, false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabButtonHotBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground1.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground1.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground1.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground1.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground1.SetColor("VistaBlack", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground2.SetColor("Default", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabControlBackground2.SetColor("VistaBlack", System.Drawing.Color.Transparent, false);
			this.qtcChildTabControl.ColorScheme.TabPageBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabPageBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qtcChildTabControl.ColorScheme.TabPageBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabPageBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabPageBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabPageBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabPageBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabStripBackground1.ColorReference = "@Empty";
			this.qtcChildTabControl.ColorScheme.TabStripBackground2.ColorReference = "@Empty";
			this.qtcChildTabControl.ColorScheme.TabStripBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabStripBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabStripBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.ColorScheme.TabStripBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(45)), ((System.Byte)(150))), false);
			this.qtcChildTabControl.Controls.Add(this.qTabPage4);
			this.qtcChildTabControl.Controls.Add(this.qTabPage3);
			this.qtcChildTabControl.Controls.Add(this.qTabPage2);
			this.qtcChildTabControl.Controls.Add(this.qTabPage1);
			this.qtcChildTabControl.Controls.Add(this.qtpSubPage1);
			this.qtcChildTabControl.Cursor = System.Windows.Forms.Cursors.Default;
			this.qtcChildTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qtcChildTabControl.FocusTabButtons = false;
			this.qtcChildTabControl.Location = new System.Drawing.Point(5, 5);
			this.qtcChildTabControl.Name = "qtcChildTabControl";
			this.qtcChildTabControl.PersistGuid = new System.Guid("03946f0f-edb2-424a-988d-ebe013f21b3a");
			this.qtcChildTabControl.Size = new System.Drawing.Size(420, 217);
			this.qtcChildTabControl.TabIndex = 0;
			this.qtcChildTabControl.TabStripLeftConfiguration.ButtonConfiguration.Appearance.Shape = this.qsSubTabButton;
			this.qtcChildTabControl.TabStripLeftConfiguration.ButtonConfiguration.AppearanceHot.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qtcChildTabControl.TabStripLeftConfiguration.ButtonConfiguration.MinimumSize = new System.Drawing.Size(78, 22);
			this.qtcChildTabControl.TabStripLeftConfiguration.ButtonConfiguration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qtcChildTabControl.TabStripLeftConfiguration.ButtonSpacing = 0;
			this.qtcChildTabControl.TabStripLeftConfiguration.FontStyleActive = new Qios.DevSuite.Components.QFontStyle(false, false, false, false);
			this.qtcChildTabControl.Text = "ChildTabControl";
			this.qtcChildTabControl.WrapTabButtonNavigationAround = false;
			// 
			// qTabPage1
			// 
			this.qTabPage1.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qTabPage1.Appearance.ShowBorderLeft = false;
			this.qTabPage1.Appearance.ShowBorders = true;
			this.qTabPage1.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage1.ButtonOrder = 0;
			this.qTabPage1.Controls.Add(this.qPanel2);
			this.qTabPage1.Location = new System.Drawing.Point(84, 0);
			this.qTabPage1.Name = "qTabPage1";
			this.qTabPage1.PersistGuid = new System.Guid("36645ec0-52a7-47b6-886a-083e10910b80");
			this.qTabPage1.Size = new System.Drawing.Size(336, 217);
			this.qTabPage1.Text = "Untitled page";
			// 
			// qPanel2
			// 
			this.qPanel2.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qPanel2.Appearance.ShowBorderLeft = false;
			this.qPanel2.Appearance.ShowBorderRight = false;
			this.qPanel2.Appearance.ShowBorderTop = false;
			this.qPanel2.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel2.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel2.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel2.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel2.ColorScheme.PanelBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.qPanel2.Location = new System.Drawing.Point(0, 0);
			this.qPanel2.Name = "qPanel2";
			this.qPanel2.Size = new System.Drawing.Size(335, 56);
			this.qPanel2.TabIndex = 0;
			this.qPanel2.Text = "qPanel1";
			// 
			// qTabPage4
			// 
			this.qTabPage4.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qTabPage4.Appearance.ShowBorderLeft = false;
			this.qTabPage4.Appearance.ShowBorders = true;
			this.qTabPage4.ButtonConfiguration.Appearance.GradientAngle = 90;
			this.qTabPage4.ButtonConfiguration.Appearance.Shape = this.qsNewSubPageTabButton;
			this.qTabPage4.ButtonConfiguration.AppearanceActive.Shape = this.qsNewSubPageTabButton;
			this.qTabPage4.ButtonConfiguration.AppearanceHot.Shape = this.qsNewSubPageTabButton;
			this.qTabPage4.ButtonConfiguration.MinimumSize = new System.Drawing.Size(60, 22);
			this.qTabPage4.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage4.ButtonOrder = 4;
			this.qTabPage4.Location = new System.Drawing.Point(84, 0);
			this.qTabPage4.Name = "qTabPage4";
			this.qTabPage4.PersistGuid = new System.Guid("3add4071-5e1a-4b64-9f63-c5d8b7ece296");
			this.qTabPage4.Size = new System.Drawing.Size(320, 161);
			// 
			// qsNewSubPageTabButton
			// 
			this.qsNewSubPageTabButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsNewSubPageTabButton.ContentBounds = new System.Drawing.Rectangle(3, 2, 94, 16);
			this.qsNewSubPageTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNewSubPageTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 8F, 0F, 0F, 0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNewSubPageTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNewSubPageTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(95F, 0F, 100F, 0F, 100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsNewSubPageTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsNewSubPageTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// qTabPage3
			// 
			this.qTabPage3.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qTabPage3.Appearance.ShowBorderLeft = false;
			this.qTabPage3.Appearance.ShowBorders = true;
			this.qTabPage3.ButtonBackgroundImage = ((System.Drawing.Image)(resources.GetObject("qTabPage3.ButtonBackgroundImage")));
			this.qTabPage3.ButtonConfiguration.Appearance.GradientAngle = 90;
			this.qTabPage3.ButtonConfiguration.Spacing = new Qios.DevSuite.Components.QSpacing(5, 0);
			this.qTabPage3.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage3.ButtonOrder = 3;
			this.qTabPage3.Location = new System.Drawing.Point(84, 0);
			this.qTabPage3.Name = "qTabPage3";
			this.qTabPage3.PersistGuid = new System.Guid("d7fcb632-0602-45c8-8810-26be2de069fa");
			this.qTabPage3.Size = new System.Drawing.Size(320, 161);
			// 
			// qTabPage2
			// 
			this.qTabPage2.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qTabPage2.Appearance.ShowBorderLeft = false;
			this.qTabPage2.Appearance.ShowBorders = true;
			this.qTabPage2.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage2.ButtonOrder = 2;
			this.qTabPage2.Controls.Add(this.qPanel3);
			this.qTabPage2.Location = new System.Drawing.Point(84, 0);
			this.qTabPage2.Name = "qTabPage2";
			this.qTabPage2.PersistGuid = new System.Guid("a6f7f820-3325-475a-a50e-a6a05fea080c");
			this.qTabPage2.Size = new System.Drawing.Size(320, 161);
			this.qTabPage2.Text = "Untitled page";
			// 
			// qPanel3
			// 
			this.qPanel3.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qPanel3.Appearance.ShowBorderLeft = false;
			this.qPanel3.Appearance.ShowBorderRight = false;
			this.qPanel3.Appearance.ShowBorderTop = false;
			this.qPanel3.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel3.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel3.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel3.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.qPanel3.Location = new System.Drawing.Point(0, 0);
			this.qPanel3.Name = "qPanel3";
			this.qPanel3.Size = new System.Drawing.Size(319, 56);
			this.qPanel3.TabIndex = 0;
			this.qPanel3.Text = "qPanel1";
			// 
			// qtpSubPage1
			// 
			this.qtpSubPage1.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qtpSubPage1.Appearance.ShowBorderLeft = false;
			this.qtpSubPage1.Appearance.ShowBorders = true;
			this.qtpSubPage1.ButtonConfiguration.Appearance.Shape = this.qsNewSubPageTabButton;
			this.qtpSubPage1.ButtonConfiguration.AppearanceActive.Shape = this.qsNewSubPageTabButton;
			this.qtpSubPage1.ButtonConfiguration.AppearanceHot.Shape = this.qsNewSubPageTabButton;
			this.qtpSubPage1.ButtonConfiguration.MinimumSize = new System.Drawing.Size(60, 22);
			this.qtpSubPage1.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qtpSubPage1.ButtonOrder = 1;
			this.qtpSubPage1.Controls.Add(this.qPanel1);
			this.qtpSubPage1.Location = new System.Drawing.Point(84, 0);
			this.qtpSubPage1.Name = "qtpSubPage1";
			this.qtpSubPage1.PersistGuid = new System.Guid("bcac39b9-932f-4d1c-b026-5865389f2390");
			this.qtpSubPage1.Size = new System.Drawing.Size(336, 217);
			// 
			// qPanel1
			// 
			this.qPanel1.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qPanel1.Appearance.ShowBorderLeft = false;
			this.qPanel1.Appearance.ShowBorderRight = false;
			this.qPanel1.Appearance.ShowBorderTop = false;
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(189)), ((System.Byte)(232)), ((System.Byte)(220))), false);
			this.qPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.qPanel1.Location = new System.Drawing.Point(0, 0);
			this.qPanel1.Name = "qPanel1";
			this.qPanel1.Size = new System.Drawing.Size(335, 56);
			this.qPanel1.TabIndex = 1;
			this.qPanel1.Text = "qPanel1";
			// 
			// qsSubTabButton
			// 
			this.qsSubTabButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsSubTabButton.ContentBounds = new System.Drawing.Rectangle(3, 2, 94, 16);
			this.qsSubTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSubTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 8F, 0F, 4F, 0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSubTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsSubTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(95F, 0F, 100F, 0F, 100F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsSubTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsSubTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// tbFind
			// 
			this.tbFind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.tbFind.Location = new System.Drawing.Point(312, 2);
			this.tbFind.Name = "tbFind";
			this.tbFind.Size = new System.Drawing.Size(100, 20);
			this.tbFind.TabIndex = 3;
			this.tbFind.Text = "Type text to find";
			// 
			// qtpNewSection1
			// 
			this.qtpNewSection1.Appearance.GradientAngle = 90;
			this.qtpNewSection1.Appearance.GradientBlendFactor = 80;
			this.qtpNewSection1.ButtonOrder = 1;
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonActiveBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabPageBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabPageBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(164)), ((System.Byte)(187))), false);
			this.qtpNewSection1.ColorScheme.TabPageBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabPageBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabPageBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabPageBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection1.ColorScheme.TabPageBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qtpNewSection1.Location = new System.Drawing.Point(0, 27);
			this.qtpNewSection1.Name = "qtpNewSection1";
			this.qtpNewSection1.PersistGuid = new System.Guid("a6807c3e-e9a0-4faa-a39e-e4a06385ba5c");
			this.qtpNewSection1.Size = new System.Drawing.Size(430, 227);
			this.qtpNewSection1.Text = "New Section 1";
			// 
			// qtpNewSection2
			// 
			this.qtpNewSection2.Appearance.GradientAngle = 90;
			this.qtpNewSection2.Appearance.GradientBlendFactor = 80;
			this.qtpNewSection2.ButtonOrder = 2;
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonActiveBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabPageBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabPageBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(142)), ((System.Byte)(179)), ((System.Byte)(231))), false);
			this.qtpNewSection2.ColorScheme.TabPageBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabPageBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabPageBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabPageBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qtpNewSection2.ColorScheme.TabPageBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qtpNewSection2.Location = new System.Drawing.Point(0, 27);
			this.qtpNewSection2.Name = "qtpNewSection2";
			this.qtpNewSection2.PersistGuid = new System.Guid("daf9350c-94f6-49a8-9b7a-c257c8b5a244");
			this.qtpNewSection2.Size = new System.Drawing.Size(430, 227);
			this.qtpNewSection2.Text = "New Section 2";
			// 
			// qsTabButton
			// 
			this.qsTabButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.MSOneNoteTab;
			this.qsTabButton.ClonedBaseShapeType = Qios.DevSuite.Components.QBaseShapeType.MSOneNoteTab;
			// 
			// UcOneNote
			// 
			this.Controls.Add(this.qTabControl1);
			this.Name = "UcOneNote";
			this.Size = new System.Drawing.Size(432, 256);
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).EndInit();
			this.qTabControl1.ResumeLayout(false);
			this.qtpNewSection.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.qtcChildTabControl)).EndInit();
			this.qtcChildTabControl.ResumeLayout(false);
			this.qTabPage1.ResumeLayout(false);
			this.qTabPage2.ResumeLayout(false);
			this.qtpSubPage1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
