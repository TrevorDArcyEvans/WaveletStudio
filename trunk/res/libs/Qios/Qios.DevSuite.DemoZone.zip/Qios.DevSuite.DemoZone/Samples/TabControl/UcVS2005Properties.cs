using System;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.TabControl
{
	/// <summary>
	/// Summary description for UcOneNote.
	/// </summary>
	public class UcVS2005Properties : System.Windows.Forms.UserControl
	{
		private Qios.DevSuite.Components.QTabControl qTabControl1;
		private Qios.DevSuite.Components.QTabPage qTabPage1;
		private Qios.DevSuite.Components.QShape qsLeftTabStrip;
		private Qios.DevSuite.Components.QShape qsTabButton;
		private Qios.DevSuite.Components.QTabPage qTabPage3;
		private Qios.DevSuite.Components.QTabPage qTabPage4;
		private Qios.DevSuite.Components.QTabPage qTabPage5;
		private Qios.DevSuite.Components.QTabPage qTabPage6;
		private Qios.DevSuite.Components.QShape qsTabButtonInactive;
		private Qios.DevSuite.Components.QShape qsNavigationArea;
		private Qios.DevSuite.Components.QShape qsContentArea;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public UcVS2005Properties()
		{
			this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
			InitializeComponent();
			//Set a new painter.
			this.qTabControl1.TabStripLeft.Painter = new QTabStripVS2005Painter();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.qTabControl1 = new Qios.DevSuite.Components.QTabControl();
			this.qTabPage6 = new Qios.DevSuite.Components.QTabPage();
			this.qsContentArea = new Qios.DevSuite.Components.QShape();
			this.qTabPage5 = new Qios.DevSuite.Components.QTabPage();
			this.qTabPage4 = new Qios.DevSuite.Components.QTabPage();
			this.qTabPage3 = new Qios.DevSuite.Components.QTabPage();
			this.qTabPage1 = new Qios.DevSuite.Components.QTabPage();
			this.qsLeftTabStrip = new Qios.DevSuite.Components.QShape();
			this.qsTabButtonInactive = new Qios.DevSuite.Components.QShape();
			this.qsTabButton = new Qios.DevSuite.Components.QShape();
			this.qsNavigationArea = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).BeginInit();
			this.qTabControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// qTabControl1
			// 
			this.qTabControl1.ActiveTabPage = this.qTabPage6;
			this.qTabControl1.Appearance.GradientAngle = 45;
			this.qTabControl1.Appearance.ShowBorders = false;
			this.qTabControl1.ColorScheme.TabButtonActiveBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground1.SetColor("HighContrast", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground2.SetColor("HighContrast", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonBackground1.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabButtonBackground2.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(235)), ((System.Byte)(234)), ((System.Byte)(226))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(235)), ((System.Byte)(234)), ((System.Byte)(226))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(235)), ((System.Byte)(234)), ((System.Byte)(226))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(235)), ((System.Byte)(234)), ((System.Byte)(226))), false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("HighContrast", System.Drawing.SystemColors.Control, false);
			this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(235)), ((System.Byte)(234)), ((System.Byte)(226))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBackground1.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("HighContrast", System.Drawing.SystemColors.ActiveCaption, false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabControlBackground1.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabControlBackground2.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabControlContentBackground1.ColorReference = "@TabStripBackground1";
			this.qTabControl1.ColorScheme.TabControlContentBackground2.ColorReference = "@TabStripBackground2";
			this.qTabControl1.ColorScheme.TabControlContentBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(153)), ((System.Byte)(157)), ((System.Byte)(169))), false);
			this.qTabControl1.ColorScheme.TabControlContentBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(153)), ((System.Byte)(157)), ((System.Byte)(169))), false);
			this.qTabControl1.ColorScheme.TabControlContentBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(153)), ((System.Byte)(157)), ((System.Byte)(169))), false);
			this.qTabControl1.ColorScheme.TabControlContentBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(153)), ((System.Byte)(157)), ((System.Byte)(169))), false);
			this.qTabControl1.ColorScheme.TabControlContentBorder.SetColor("HighContrast", System.Drawing.SystemColors.ControlDark, false);
			this.qTabControl1.ColorScheme.TabControlContentBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(153)), ((System.Byte)(157)), ((System.Byte)(169))), false);
			this.qTabControl1.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.SystemColors.Control, false);
			this.qTabControl1.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.SystemColors.Control, false);
			this.qTabControl1.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.SystemColors.Control, false);
			this.qTabControl1.ColorScheme.TabPageBackground1.SetColor("VistaBlack", System.Drawing.SystemColors.Control, false);
			this.qTabControl1.ColorScheme.TabPageBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabPageBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabPageBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabPageBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabPageBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabPageBorder.ColorReference = "@TabStripBorder";
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("HighContrast", System.Drawing.SystemColors.Window, false);
			this.qTabControl1.ColorScheme.TabStripBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("HighContrast", System.Drawing.SystemColors.Window, false);
			this.qTabControl1.ColorScheme.TabStripBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground1.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.ColorReference = "@Transparent";
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(145)), ((System.Byte)(167)), ((System.Byte)(180))), false);
			this.qTabControl1.Configuration.ContentAppearance.Shape = this.qsContentArea;
			this.qTabControl1.Controls.Add(this.qTabPage6);
			this.qTabControl1.Controls.Add(this.qTabPage5);
			this.qTabControl1.Controls.Add(this.qTabPage4);
			this.qTabControl1.Controls.Add(this.qTabPage3);
			this.qTabControl1.Controls.Add(this.qTabPage1);
			this.qTabControl1.Cursor = System.Windows.Forms.Cursors.Default;
			this.qTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qTabControl1.FocusTabButtons = false;
			this.qTabControl1.Location = new System.Drawing.Point(0, 0);
			this.qTabControl1.Name = "qTabControl1";
			this.qTabControl1.PersistGuid = new System.Guid("d71a5cf7-2a3a-469f-a114-58bfdbd1b9ad");
			this.qTabControl1.Size = new System.Drawing.Size(488, 368);
			this.qTabControl1.TabIndex = 0;
			this.qTabControl1.TabStripLeftConfiguration.Appearance.GradientAngle = 180;
			this.qTabControl1.TabStripLeftConfiguration.Appearance.Shape = this.qsLeftTabStrip;
			this.qTabControl1.TabStripLeftConfiguration.ButtonAreaClip = true;
			this.qTabControl1.TabStripLeftConfiguration.ButtonAreaMargin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 0);
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.Appearance.Shape = this.qsTabButtonInactive;
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.AppearanceActive.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.AppearanceActive.Shape = this.qsTabButton;
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.AppearanceHot.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.AppearanceHot.Shape = this.qsTabButton;
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.MinimumSize = new System.Drawing.Size(100, 30);
			this.qTabControl1.TabStripLeftConfiguration.ButtonConfiguration.Padding = new Qios.DevSuite.Components.QPadding(10, 1, 1, 3);
			this.qTabControl1.TabStripLeftConfiguration.ButtonSpacing = 1;
			this.qTabControl1.TabStripLeftConfiguration.FontStyleHot = new Qios.DevSuite.Components.QFontStyle(false, false, false, false);
			this.qTabControl1.TabStripLeftConfiguration.NavigationAreaAppearance.Shape = this.qsNavigationArea;
			this.qTabControl1.TabStripLeftConfiguration.NavigationAreaMargin = new Qios.DevSuite.Components.QMargin(-30, 0, 0, 0);
			this.qTabControl1.TabStripLeftConfiguration.NavigationAreaPadding = new Qios.DevSuite.Components.QPadding(0, 0, 5, 0);
			this.qTabControl1.TabStripLeftConfiguration.StripMinimumHeight = 100;
			this.qTabControl1.TabStripLeftConfiguration.StripVisibleWithoutButtons = true;
			this.qTabControl1.Text = "qTabControl1";
			this.qTabControl1.WrapTabButtonNavigationAround = false;
			// 
			// qTabPage6
			// 
			this.qTabPage6.Appearance.ShowBorders = true;
			this.qTabPage6.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage6.ButtonOrder = 0;
			this.qTabPage6.Location = new System.Drawing.Point(100, 4);
			this.qTabPage6.Name = "qTabPage6";
			this.qTabPage6.PersistGuid = new System.Guid("8ee57f14-b8f8-47a0-bbbb-2c9c4e535893");
			this.qTabPage6.Size = new System.Drawing.Size(384, 361);
			this.qTabPage6.Text = "Application";
			// 
			// qsContentArea
			// 
			this.qsContentArea.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareContent;
			this.qsContentArea.ContentBounds = new System.Drawing.Rectangle(-1, 4, 47, 43);
			this.qsContentArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(-2F, 49F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsContentArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(-2F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsContentArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(49F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsContentArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(49F, 49F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsContentArea.Size = new System.Drawing.Size(50, 50);
			// 
			// qTabPage5
			// 
			this.qTabPage5.Appearance.ShowBorders = true;
			this.qTabPage5.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage5.ButtonOrder = 1;
			this.qTabPage5.Location = new System.Drawing.Point(100, 4);
			this.qTabPage5.Name = "qTabPage5";
			this.qTabPage5.PersistGuid = new System.Guid("5b8e19c0-587c-438a-a85f-cecc3c793b64");
			this.qTabPage5.Size = new System.Drawing.Size(384, 361);
			this.qTabPage5.Text = "Build";
			// 
			// qTabPage4
			// 
			this.qTabPage4.Appearance.ShowBorders = true;
			this.qTabPage4.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage4.ButtonOrder = 2;
			this.qTabPage4.Location = new System.Drawing.Point(100, 4);
			this.qTabPage4.Name = "qTabPage4";
			this.qTabPage4.PersistGuid = new System.Guid("c2327dab-2abd-4298-803a-44c404650d7d");
			this.qTabPage4.Size = new System.Drawing.Size(384, 361);
			this.qTabPage4.Text = "Build Events";
			// 
			// qTabPage3
			// 
			this.qTabPage3.Appearance.ShowBorders = true;
			this.qTabPage3.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage3.ButtonOrder = 3;
			this.qTabPage3.Location = new System.Drawing.Point(100, 4);
			this.qTabPage3.Name = "qTabPage3";
			this.qTabPage3.PersistGuid = new System.Guid("01e494ac-1968-4eff-8d29-a6a0c94de24b");
			this.qTabPage3.Size = new System.Drawing.Size(384, 361);
			this.qTabPage3.Text = "Debug";
			// 
			// qTabPage1
			// 
			this.qTabPage1.Appearance.ShowBorders = true;
			this.qTabPage1.ButtonDockStyle = Qios.DevSuite.Components.QTabButtonDockStyle.Left;
			this.qTabPage1.ButtonOrder = 4;
			this.qTabPage1.Location = new System.Drawing.Point(100, 4);
			this.qTabPage1.Name = "qTabPage1";
			this.qTabPage1.PersistGuid = new System.Guid("c4a11769-fbac-4f9b-88d6-3b617c4fa410");
			this.qTabPage1.Size = new System.Drawing.Size(384, 361);
			this.qTabPage1.Text = "Settings";
			// 
			// qsLeftTabStrip
			// 
			this.qsLeftTabStrip.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTabStrip;
			this.qsLeftTabStrip.ContentBounds = new System.Drawing.Rectangle(9, 0, 300, 100);
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 11F, 0F, 5F, 3F, 1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(9F, 1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(309F, 1F, 315F, 1F, 317F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(318F, 7F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(348F, 88F, 350F, 93F, 353F, 95F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(358F, 95F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(499F, 95F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsLeftTabStrip.Items.Add(new Qios.DevSuite.Components.QShapeItem(499F, 100F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsLeftTabStrip.Size = new System.Drawing.Size(500, 100);
			// 
			// qsTabButtonInactive
			// 
			this.qsTabButtonInactive.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTab;
			this.qsTabButtonInactive.ContentBounds = new System.Drawing.Rectangle(0, 0, 100, 20);
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 15.25F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 4.25F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 4.5F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 15.25F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsTabButtonInactive.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsTabButtonInactive.Precision = 2;
			// 
			// qsTabButton
			// 
			this.qsTabButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedTab;
			this.qsTabButton.ContentBounds = new System.Drawing.Rectangle(0, 0, 100, 20);
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(95F, 0F, 100F, 0F, 100F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 13F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 13F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 8F, 0F, 4F, 0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsTabButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(5F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			// 
			// qsNavigationArea
			// 
			this.qsNavigationArea.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareTabStripNavigationArea;
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsNavigationArea.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// UcVS2005Properties
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.qTabControl1);
			this.Name = "UcVS2005Properties";
			this.Size = new System.Drawing.Size(488, 368);
			((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).EndInit();
			this.qTabControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}

	/// <summary>
	/// This class is responsible of adding the orange part to an Active or Hot tabButton.
	/// </summary>
	public class QTabStripVS2005Painter : Qios.DevSuite.Components.QTabStripPainter
	{

		/// <summary>
		/// Overridden Draws the base background and the orange part.
		/// </summary>
		protected override void DrawTabButtonBackground(Qios.DevSuite.Components.QTabButton button, Qios.DevSuite.Components.QTabButtonConfiguration buttonConfiguration, Qios.DevSuite.Components.QTabStripConfiguration stripConfiguration, Qios.DevSuite.Components.QTabButtonAppearance buttonAppearance, Rectangle buttonBounds, Rectangle controlAndButtonBounds, DockStyle dockStyle, Color backColor1, Color backColor2, Color borderColor, Graphics graphics)
		{
			base.DrawTabButtonBackground (button, buttonConfiguration, stripConfiguration, buttonAppearance, buttonBounds, controlAndButtonBounds, dockStyle, backColor1, backColor2, borderColor, graphics);

			int tmp_iOrangePartWidth = 4;

			if (((button.IsHot) || (button.IsActivated)) && (button.LastDrawnGraphicsPath != null))
			{
				//Get the bounds
				Rectangle tmp_oButtonBounds = button.BoundsToControl;

				//Create a gradient
				Rectangle tmp_oRect = new Rectangle(tmp_oButtonBounds.Left, tmp_oButtonBounds.Top, tmp_iOrangePartWidth, tmp_oButtonBounds.Height);
				LinearGradientBrush tmp_oBrush = new LinearGradientBrush(tmp_oRect, Color.Orange, Color.White, 0, false);

				//Set the clip to the dran path.
				Region tmp_oCurrentClip = graphics.Clip;
				Region tmp_oNewClip = tmp_oCurrentClip.Clone();
				tmp_oNewClip.Intersect(new Region(button.LastDrawnGraphicsPath));
				graphics.Clip = tmp_oNewClip;

				//Fill the rectangle
				graphics.FillRectangle(tmp_oBrush, tmp_oRect);

				//Reset the clip
				graphics.Clip = tmp_oCurrentClip;

				//Dispose resources.
				tmp_oNewClip.Dispose();
				tmp_oBrush.Dispose();
			}
		}

	}


}
