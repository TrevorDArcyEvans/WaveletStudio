using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.DemoZone.Misc;

namespace Qios.DevSuite.DemoZone.Samples.TabControl
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	[SelectorDisplay(40,
		 "TabControl Sample",
		 "Shows various QTabControl configurations.")]
	public class FrmMain : Qios.DevSuite.Components.Ribbon.QRibbonForm
	{
		private Qios.DevSuite.Components.QTabControl qTabControl1;
		private Qios.DevSuite.Components.QShape qsTabButton;
		private Qios.DevSuite.Components.QTabPage qtpOneNote;
		private Qios.DevSuite.Components.QTabPage qtpVS2005Properties;
		private Qios.DevSuite.DemoZone.Samples.TabControl.UcOneNote ucOneNote1;
		private Qios.DevSuite.DemoZone.Samples.TabControl.UcVS2005Properties ucVS2005Properties;
		private Qios.DevSuite.Components.QTabPage qtpCustom01;
		private Qios.DevSuite.DemoZone.Samples.TabControl.UcCustom01 ucCustom011;
		private Qios.DevSuite.Components.QTabPage qtpCustom02;
		private Qios.DevSuite.DemoZone.Samples.TabControl.UcCustom02 ucCustom021;
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qRibbonCaption1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.qTabControl1 = new Qios.DevSuite.Components.QTabControl();
            this.qtpCustom01 = new Qios.DevSuite.Components.QTabPage();
            this.ucCustom011 = new Qios.DevSuite.DemoZone.Samples.TabControl.UcCustom01();
            this.qtpOneNote = new Qios.DevSuite.Components.QTabPage();
            this.ucOneNote1 = new Qios.DevSuite.DemoZone.Samples.TabControl.UcOneNote();
            this.qtpCustom02 = new Qios.DevSuite.Components.QTabPage();
            this.ucCustom021 = new Qios.DevSuite.DemoZone.Samples.TabControl.UcCustom02();
            this.qtpVS2005Properties = new Qios.DevSuite.Components.QTabPage();
            this.ucVS2005Properties = new Qios.DevSuite.DemoZone.Samples.TabControl.UcVS2005Properties();
            this.qsTabButton = new Qios.DevSuite.Components.QShape();
            this.qRibbonCaption1 = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            ((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).BeginInit();
            this.qTabControl1.SuspendLayout();
            this.qtpCustom01.SuspendLayout();
            this.qtpOneNote.SuspendLayout();
            this.qtpCustom02.SuspendLayout();
            this.qtpVS2005Properties.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption1)).BeginInit();
            this.SuspendLayout();
            // 
            // qTabControl1
            // 
            this.qTabControl1.ActiveTabPage = this.qtpCustom01;
            this.qTabControl1.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qTabControl1.Appearance.ShowBorders = false;
            this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabButtonActiveBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabButtonBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonBackground2.SetColor("Default", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonBackground2.SetColor("LunaBlue", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonBackground2.SetColor("LunaOlive", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonBackground2.SetColor("LunaSilver", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaBlue", System.Drawing.SystemColors.ControlDark, false);
            this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaOlive", System.Drawing.SystemColors.ControlDark, false);
            this.qTabControl1.ColorScheme.TabButtonBorder.SetColor("LunaSilver", System.Drawing.SystemColors.ControlDark, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("Default", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("LunaBlue", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("LunaOlive", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonHotBackground2.SetColor("LunaSilver", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaBlue", System.Drawing.SystemColors.ControlDark, false);
            this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaOlive", System.Drawing.SystemColors.ControlDark, false);
            this.qTabControl1.ColorScheme.TabButtonHotBorder.SetColor("LunaSilver", System.Drawing.SystemColors.ControlDark, false);
            this.qTabControl1.ColorScheme.TabControlBackground1.ColorReference = "@RibbonPanelBackground1";
            this.qTabControl1.ColorScheme.TabControlBackground2.ColorReference = "@RibbonPanelBackground2";
            this.qTabControl1.ColorScheme.TabStripBorder.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("Default", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("LunaBlue", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("LunaOlive", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBackground2.SetColor("LunaSilver", System.Drawing.SystemColors.Control, false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.ColorScheme.TabStripNavigationAreaBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185))))), false);
            this.qTabControl1.Controls.Add(this.qtpOneNote);
            this.qTabControl1.Controls.Add(this.qtpCustom02);
            this.qTabControl1.Controls.Add(this.qtpVS2005Properties);
            this.qTabControl1.Controls.Add(this.qtpCustom01);
            this.qTabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.qTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qTabControl1.FocusTabButtons = false;
            this.qTabControl1.Location = new System.Drawing.Point(0, 28);
            this.qTabControl1.Name = "qTabControl1";
            this.qTabControl1.PersistGuid = new System.Guid("abeec0cb-bba8-4ab2-9f24-b9ef316f9131");
            this.qTabControl1.Size = new System.Drawing.Size(527, 396);
            this.qTabControl1.TabIndex = 0;
            this.qTabControl1.TabStripTopConfiguration.ButtonAreaMargin = new Qios.DevSuite.Components.QMargin(0, 2, 0, 0);
            this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.GradientAngle = 90;
            this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.GradientBlendFactor = 40;
            this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.GradientBlendPosition = 70;
            this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.Appearance.Shape = this.qsTabButton;
            this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
            this.qTabControl1.TabStripTopConfiguration.FontStyleHot = new Qios.DevSuite.Components.QFontStyle(false, false, false, false);
            this.qTabControl1.TabStripTopConfiguration.StripPadding = new Qios.DevSuite.Components.QPadding(3, 0, 0, 3);
            this.qTabControl1.Text = "qtcMain";
            // 
            // qtpCustom01
            // 
            this.qtpCustom01.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qtpCustom01.ButtonOrder = 0;
            this.qtpCustom01.ColorScheme.TabPageBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qtpCustom01.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qtpCustom01.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qtpCustom01.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qtpCustom01.Controls.Add(this.ucCustom011);
            this.qtpCustom01.Location = new System.Drawing.Point(0, 23);
            this.qtpCustom01.Name = "qtpCustom01";
            this.qtpCustom01.Padding = new System.Windows.Forms.Padding(5);
            this.qtpCustom01.PersistGuid = new System.Guid("74a45d69-9a5d-4e04-a700-a85fa289edfc");
            this.qtpCustom01.Size = new System.Drawing.Size(527, 373);
            this.qtpCustom01.Text = "Custom 01";
            // 
            // ucCustom011
            // 
            this.ucCustom011.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucCustom011.Location = new System.Drawing.Point(5, 5);
            this.ucCustom011.Name = "ucCustom011";
            this.ucCustom011.Size = new System.Drawing.Size(517, 363);
            this.ucCustom011.TabIndex = 0;
            // 
            // qtpOneNote
            // 
            this.qtpOneNote.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qtpOneNote.ButtonOrder = 2;
            this.qtpOneNote.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qtpOneNote.Controls.Add(this.ucOneNote1);
            this.qtpOneNote.Location = new System.Drawing.Point(0, 23);
            this.qtpOneNote.Name = "qtpOneNote";
            this.qtpOneNote.Padding = new System.Windows.Forms.Padding(5);
            this.qtpOneNote.PersistGuid = new System.Guid("a4abfe12-ad58-44d3-959f-92d857503a4e");
            this.qtpOneNote.Size = new System.Drawing.Size(527, 373);
            this.qtpOneNote.Text = "Microsoft OneNote";
            // 
            // ucOneNote1
            // 
            this.ucOneNote1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOneNote1.Location = new System.Drawing.Point(5, 5);
            this.ucOneNote1.Name = "ucOneNote1";
            this.ucOneNote1.Size = new System.Drawing.Size(517, 363);
            this.ucOneNote1.TabIndex = 0;
            // 
            // qtpCustom02
            // 
            this.qtpCustom02.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qtpCustom02.ButtonOrder = 1;
            this.qtpCustom02.ColorScheme.TabPageBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qtpCustom02.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qtpCustom02.ColorScheme.TabPageBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qtpCustom02.ColorScheme.TabPageBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qtpCustom02.Controls.Add(this.ucCustom021);
            this.qtpCustom02.Location = new System.Drawing.Point(0, 23);
            this.qtpCustom02.Name = "qtpCustom02";
            this.qtpCustom02.Padding = new System.Windows.Forms.Padding(5);
            this.qtpCustom02.PersistGuid = new System.Guid("81261224-d550-4888-af10-c0933c7ae350");
            this.qtpCustom02.Size = new System.Drawing.Size(527, 373);
            this.qtpCustom02.Text = "Custom 02";
            // 
            // ucCustom021
            // 
            this.ucCustom021.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucCustom021.Location = new System.Drawing.Point(5, 5);
            this.ucCustom021.Name = "ucCustom021";
            this.ucCustom021.Size = new System.Drawing.Size(517, 363);
            this.ucCustom021.TabIndex = 0;
            // 
            // qtpVS2005Properties
            // 
            this.qtpVS2005Properties.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qtpVS2005Properties.ButtonOrder = 3;
            this.qtpVS2005Properties.ColorScheme.TabPageBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qtpVS2005Properties.Controls.Add(this.ucVS2005Properties);
            this.qtpVS2005Properties.Location = new System.Drawing.Point(0, 23);
            this.qtpVS2005Properties.Name = "qtpVS2005Properties";
            this.qtpVS2005Properties.Padding = new System.Windows.Forms.Padding(5);
            this.qtpVS2005Properties.PersistGuid = new System.Guid("29d1ed25-2aba-4dff-a637-6ded62e57384");
            this.qtpVS2005Properties.Size = new System.Drawing.Size(527, 373);
            this.qtpVS2005Properties.Text = "Visual Studio 2005 Properties";
            // 
            // ucVS2005Properties
            // 
            this.ucVS2005Properties.BackColor = System.Drawing.Color.Transparent;
            this.ucVS2005Properties.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucVS2005Properties.Location = new System.Drawing.Point(5, 5);
            this.ucVS2005Properties.Name = "ucVS2005Properties";
            this.ucVS2005Properties.Size = new System.Drawing.Size(517, 363);
            this.ucVS2005Properties.TabIndex = 0;
            // 
            // qsTabButton
            // 
            this.qsTabButton.ClonedBaseShapeType = Qios.DevSuite.Components.QBaseShapeType.MSVisualStudio2005Tab;
            this.qsTabButton.ContentBounds = new System.Drawing.Rectangle(15, 0, 80, 20);
            this.qsTabButton.Precision = 2;
            // 
            // qRibbonCaption1
            // 
            this.qRibbonCaption1.Location = new System.Drawing.Point(0, 0);
            this.qRibbonCaption1.Name = "qRibbonCaption1";
            this.qRibbonCaption1.Size = new System.Drawing.Size(527, 28);
            this.qRibbonCaption1.TabIndex = 6;
            this.qRibbonCaption1.Text = "TabControl Sample - Qios.DevSuite.DemoZone";
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(527, 424);
            this.Controls.Add(this.qTabControl1);
            this.Controls.Add(this.qRibbonCaption1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.Text = "TabControl Sample - Qios.DevSuite.DemoZone";
            ((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).EndInit();
            this.qTabControl1.ResumeLayout(false);
            this.qtpCustom01.ResumeLayout(false);
            this.qtpOneNote.ResumeLayout(false);
            this.qtpCustom02.ResumeLayout(false);
            this.qtpVS2005Properties.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption1)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		private void llQiosDevSuiteWebsite_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start("http://www.qiosdevsuite.com");		
		}
	}
}
