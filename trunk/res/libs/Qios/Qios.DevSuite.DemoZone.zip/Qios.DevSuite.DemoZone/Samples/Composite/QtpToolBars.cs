using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.DemoZone.Shared;

namespace Qios.DevSuite.DemoZone.Samples.Composite
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	public class QtpToolBars : Qios.DevSuite.Components.QTabPage
	{
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		private Qios.DevSuite.Components.QCompositeControl qccToolBar;
		private Qios.DevSuite.Components.QCompositeGroup qcgToolBarItems;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPaste;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCopy;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCut;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiHelp;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiNew;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiNewItem1;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiNewItem2;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiDelete;
		private Qios.DevSuite.Components.QCompositeSeparator qcsToolBarSeparator01;
		private Qios.DevSuite.Components.QCompositeItem qciToolBarCustomize;
		private Qios.DevSuite.Components.QCompositeImage qciToolBarCustomizeImage;
		private Qios.DevSuite.Components.QShape qsToolBarCustomizeItem;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCustomizeItem1;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCustomizeItem2;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiCustomizeItem3;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibSearch;
		private Qios.DevSuite.Components.QCompositeSeparator qcsToolBarSeparator02;
		private Qios.DevSuite.Components.QCompositeSeparator qcsToolBarSeparator03;
		private Qios.DevSuite.Components.QCompositeSeparator qcsToolBarSeparator04;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiFont;
		private QccVerticalBar qccVerticalBar;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup1;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup2;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup3;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup4;
		private Qios.DevSuite.Components.QCompositeText qCompositeText2;
		private QccHorizontalBar qccHorizontalBar;
		private Qios.DevSuite.Components.QPanel qPanel1;
		private Qios.DevSuite.Components.QTextBox qtbDefaultContextMenu;
		private Qios.DevSuite.Components.QTextBox qtbRibbonApplicationMenu;
		private Qios.DevSuite.Components.QTextBox qtbCustomCompositeWindow;
		private Qios.DevSuite.Components.QCompositeMenu qcmDefaultCompositeMenu;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuCut;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuCopy;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuPaste;
		private Qios.DevSuite.Components.QCompositeSeparator qcsContextMenuSeparator01;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuBold;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuItalic;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuUnderline;
		private Qios.DevSuite.Components.QCompositeMenu qcmRibbonApplicationMenu;
		private Qios.DevSuite.Components.QCompositeMenu qcmCustomContextMenu;
		private Qios.DevSuite.Components.QCompositeSeparator qcsContextMenuSeparator02;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuOtherActions;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuOtherAction1;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiContextMenuOtherAction2;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QtpToolBars()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//Create attach new custom windows
			this.qcmiFont.CustomChildWindow = new QcwFontWindow();
			this.qcmCustomContextMenu.CustomWindow = new QcwFontMenuWindow();

			//Create a QribbonApplicationMenuWindow
			QrmwMainMenuWindow tmp_oRibbonApplicationMenuWindow = new QrmwMainMenuWindow();

			//Change some default values, 
			tmp_oRibbonApplicationMenuWindow.Width = 250;
			tmp_oRibbonApplicationMenuWindow.CompositeConfiguration.ShowSubMenusAboveDocumentArea = false;

			//Assign it.
			this.qcmRibbonApplicationMenu.CustomWindow = tmp_oRibbonApplicationMenuWindow;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			Qios.DevSuite.Components.QMarkupTextStyle qMarkupTextStyle1 = new Qios.DevSuite.Components.QMarkupTextStyle();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QtpToolBars));
			this.qCompositeGroup3 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeGroup4 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeText2 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeGroup1 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeGroup2 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
			this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
			this.qccToolBar = new Qios.DevSuite.Components.QCompositeControl();
			this.qcgToolBarItems = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiNew = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiNewItem1 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiNewItem2 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiDelete = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcsToolBarSeparator01 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcmiCopy = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiCut = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiPaste = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcsToolBarSeparator04 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcmiFont = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcsToolBarSeparator02 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcibSearch = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcsToolBarSeparator03 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcmiHelp = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qciToolBarCustomize = new Qios.DevSuite.Components.QCompositeItem();
			this.qcmiCustomizeItem1 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiCustomizeItem2 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiCustomizeItem3 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qsToolBarCustomizeItem = new Qios.DevSuite.Components.QShape();
			this.qciToolBarCustomizeImage = new Qios.DevSuite.Components.QCompositeImage();
			this.qccVerticalBar = new Qios.DevSuite.DemoZone.Samples.Composite.QccVerticalBar();
			this.qccHorizontalBar = new Qios.DevSuite.DemoZone.Samples.Composite.QccHorizontalBar();
			this.qPanel1 = new Qios.DevSuite.Components.QPanel();
			this.qtbCustomCompositeWindow = new Qios.DevSuite.Components.QTextBox();
			this.qtbRibbonApplicationMenu = new Qios.DevSuite.Components.QTextBox();
			this.qtbDefaultContextMenu = new Qios.DevSuite.Components.QTextBox();
			this.qcmDefaultCompositeMenu = new Qios.DevSuite.Components.QCompositeMenu();
			this.qcmiContextMenuCut = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiContextMenuCopy = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiContextMenuPaste = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcsContextMenuSeparator01 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcmiContextMenuBold = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiContextMenuItalic = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiContextMenuUnderline = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcsContextMenuSeparator02 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcmiContextMenuOtherActions = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiContextMenuOtherAction1 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmiContextMenuOtherAction2 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qcmRibbonApplicationMenu = new Qios.DevSuite.Components.QCompositeMenu();
			this.qcmCustomContextMenu = new Qios.DevSuite.Components.QCompositeMenu();
			((System.ComponentModel.ISupportInitialize)(this.qccToolBar)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.qccVerticalBar)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.qccHorizontalBar)).BeginInit();
			this.qPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// qCompositeGroup3
			// 
			this.qCompositeGroup3.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup3.Configuration.StretchHorizontal = true;
			// 
			// qCompositeGroup4
			// 
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qCompositeGroup4.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qCompositeGroup4.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qCompositeGroup4.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeGroup4.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup4.Configuration.StretchHorizontal = true;
			this.qCompositeGroup4.Items.Add(this.qCompositeText2);
			// 
			// qCompositeText2
			// 
			this.qCompositeText2.Title = "qCompositeText1";
			// 
			// qCompositeGroup1
			// 
			this.qCompositeGroup1.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup1.Configuration.StretchHorizontal = true;
			// 
			// qCompositeGroup2
			// 
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qCompositeGroup2.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qCompositeGroup2.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qCompositeGroup2.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qCompositeGroup2.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeGroup2.Configuration.ShrinkHorizontal = true;
			this.qCompositeGroup2.Configuration.StretchHorizontal = true;
			this.qCompositeGroup2.Items.Add(this.qCompositeText1);
			// 
			// qCompositeText1
			// 
			this.qCompositeText1.Title = "qCompositeText1";
			// 
			// qMarkupLabel1
			// 
			this.qMarkupLabel1.Appearance.ShowBorders = true;
			this.qMarkupLabel1.ColorScheme.MarkupLabelBackground1.ColorReference = "@RibbonPanelBackground2";
			this.qMarkupLabel1.ColorScheme.MarkupLabelBackground2.ColorReference = "@RibbonPanelBackground2";
			this.qMarkupLabel1.ColorScheme.MarkupLabelBorder.ColorReference = "@RibbonPanelBorder";
			this.qMarkupLabel1.Configuration.BiggerSmallerStep = 1;
			this.qMarkupLabel1.Configuration.MarkupPadding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
			qMarkupTextStyle1.DefaultTag = "H1";
			qMarkupTextStyle1.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 12F);
			qMarkupTextStyle1.NewLineAfter = true;
			qMarkupTextStyle1.TextColorProperty = "RibbonTabButtonActiveText";
			this.qMarkupLabel1.CustomStyles.Add(qMarkupTextStyle1);
			this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.qMarkupLabel1.Location = new System.Drawing.Point(5, 5);
			this.qMarkupLabel1.MarkupText = @"<h1>ToolBars and ContextMenus</h1><big>This sample demonstrates that <b>QComposite</b> is not limited. You can do what you want. Here you see Toolbars and ContextMenus.</big><br /><br />(Note: some of these controls are created in a separate file and added to this Form. Edit those controls in the separate files)";
			this.qMarkupLabel1.Name = "qMarkupLabel1";
			this.qMarkupLabel1.Size = new System.Drawing.Size(686, 83);
			this.qMarkupLabel1.TabIndex = 1;
			// 
			// qccToolBar
			// 
			this.qccToolBar.ChildCompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qccToolBar.ChildCompositeConfiguration.IconBackgroundVisible = true;
			this.qccToolBar.ChildCompositeConfiguration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qccToolBar.ColorScheme.CompositeBackground1.ColorReference = "@Toolbarbevel1";
			this.qccToolBar.ColorScheme.CompositeBackground2.ColorReference = "@Toolbarbevel2";
			this.qccToolBar.ColorScheme.CompositeBorder.ColorReference = "@toolbarbevel2";
			this.qccToolBar.ColorScheme.CompositeSeparator1.ColorReference = "@ToolBarSeparator";
			this.qccToolBar.ColorScheme.CompositeSeparator2.ColorReference = "@ToolBarBevel1";
			this.qccToolBar.ColorScheme.CompositeText.ColorReference = "@ToolbarText";
			this.qccToolBar.ColorScheme.CompositeTextDisabled.ColorReference = "@ToolbarTextDisabled";
			this.qccToolBar.ColorScheme.CompositeTextExpanded.ColorReference = "@ToolbarTextActive";
			this.qccToolBar.ColorScheme.CompositeTextHot.ColorReference = "@ToolbarTextActive";
			this.qccToolBar.ColorScheme.CompositeTextPressed.ColorReference = "@ToolbarTextActive";
			this.qccToolBar.Configuration.Appearance.GradientAngle = 90;
			this.qccToolBar.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qccToolBar.Configuration.ExpandBehavior = Qios.DevSuite.Components.QCompositeExpandBehavior.AutoChangeExpand;
			this.qccToolBar.Configuration.ExpandDirection = Qios.DevSuite.Components.QCompositeExpandDirection.Down;
			this.qccToolBar.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Linear;
			this.qccToolBar.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 5, 5, 0);
			this.qccToolBar.Configuration.ShrinkVertical = false;
			this.qccToolBar.Configuration.StretchVertical = false;
			this.qccToolBar.Dock = System.Windows.Forms.DockStyle.Top;
			this.qccToolBar.HandleAltKey = true;
			this.qccToolBar.Items.Add(this.qcgToolBarItems);
			this.qccToolBar.Items.Add(this.qciToolBarCustomize);
			this.qccToolBar.Location = new System.Drawing.Point(5, 88);
			this.qccToolBar.Name = "qccToolBar";
			this.qccToolBar.Size = new System.Drawing.Size(686, 38);
			this.qccToolBar.TabIndex = 2;
			this.qccToolBar.Text = "qccToolBar";
			this.qccToolBar.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qccToolBar_ItemActivated);
			// 
			// qcgToolBarItems
			// 
			this.qcgToolBarItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Flow;
			this.qcgToolBarItems.Configuration.ShrinkHorizontal = true;
			this.qcgToolBarItems.Items.Add(this.qcmiNew);
			this.qcgToolBarItems.Items.Add(this.qcmiDelete);
			this.qcgToolBarItems.Items.Add(this.qcsToolBarSeparator01);
			this.qcgToolBarItems.Items.Add(this.qcmiCopy);
			this.qcgToolBarItems.Items.Add(this.qcmiCut);
			this.qcgToolBarItems.Items.Add(this.qcmiPaste);
			this.qcgToolBarItems.Items.Add(this.qcsToolBarSeparator04);
			this.qcgToolBarItems.Items.Add(this.qcmiFont);
			this.qcgToolBarItems.Items.Add(this.qcsToolBarSeparator02);
			this.qcgToolBarItems.Items.Add(this.qcibSearch);
			this.qcgToolBarItems.Items.Add(this.qcsToolBarSeparator03);
			this.qcgToolBarItems.Items.Add(this.qcmiHelp);
			// 
			// qcmiNew
			// 
			this.qcmiNew.ChildItems.Add(this.qcmiNewItem1);
			this.qcmiNew.ChildItems.Add(this.qcmiNewItem2);
			this.qcmiNew.Configuration.DropDownButtonConfiguration.Mask = ((System.Drawing.Image)(resources.GetObject("resource.Mask")));
			this.qcmiNew.Configuration.DropDownSeparated = true;
			this.qcmiNew.HotkeyText = "N";
			this.qcmiNew.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiNew.Icon")));
			this.qcmiNew.Title = "&New";
			// 
			// qcmiNewItem1
			// 
			this.qcmiNewItem1.HotkeyText = "1";
			this.qcmiNewItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiNewItem1.Icon")));
			this.qcmiNewItem1.Title = "New Item &1";
			// 
			// qcmiNewItem2
			// 
			this.qcmiNewItem2.HotkeyText = "2";
			this.qcmiNewItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiNewItem2.Icon")));
			this.qcmiNewItem2.Title = "New Item &2";
			// 
			// qcmiDelete
			// 
			this.qcmiDelete.HotkeyText = "D";
			this.qcmiDelete.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiDelete.Icon")));
			this.qcmiDelete.Title = "&Delete";
			// 
			// qcmiCopy
			// 
			this.qcmiCopy.HotkeyText = "C";
			this.qcmiCopy.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCopy.Icon")));
			this.qcmiCopy.Title = "&Copy";
			// 
			// qcmiCut
			// 
			this.qcmiCut.HotkeyText = "T";
			this.qcmiCut.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCut.Icon")));
			this.qcmiCut.Title = "Cu&t";
			// 
			// qcmiPaste
			// 
			this.qcmiPaste.HotkeyText = "P";
			this.qcmiPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPaste.Icon")));
			this.qcmiPaste.Title = "&Paste";
			// 
			// qcmiFont
			// 
			this.qcmiFont.Configuration.DropDownButtonConfiguration.Mask = ((System.Drawing.Image)(resources.GetObject("resource.Mask1")));
			this.qcmiFont.HotkeyText = "F";
			this.qcmiFont.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiFont.Icon")));
			this.qcmiFont.Title = "&Font";
			// 
			// qcibSearch
			// 
			this.qcibSearch.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibSearch.InputBox
			// 
			this.qcibSearch.InputBox.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
			this.qcibSearch.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDown;
			this.qcibSearch.InputBox.CueText = "Search";
			this.qcibSearch.InputBox.Location = new System.Drawing.Point(369, 9);
			this.qcibSearch.InputBox.Name = "";
			this.qcibSearch.InputBox.PaintTransparentBackground = true;
			this.qcibSearch.InputBox.Size = new System.Drawing.Size(100, 20);
			this.qcibSearch.InputBox.TabIndex = 0;
			// 
			// qcmiHelp
			// 
			this.qcmiHelp.Configuration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
			this.qcmiHelp.HotkeyText = "H";
			this.qcmiHelp.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiHelp.Icon")));
			this.qcmiHelp.Title = "&Help";
			// 
			// qciToolBarCustomize
			// 
			this.qciToolBarCustomize.ChildItems.Add(this.qcmiCustomizeItem1);
			this.qciToolBarCustomize.ChildItems.Add(this.qcmiCustomizeItem2);
			this.qciToolBarCustomize.ChildItems.Add(this.qcmiCustomizeItem3);
			this.qciToolBarCustomize.ColorScheme.CompositeItemBackground1.ColorReference = "@ToolBarMoreItemsArea1";
			this.qciToolBarCustomize.ColorScheme.CompositeItemBackground2.ColorReference = "@ToolBarMoreItemsArea2";
			this.qciToolBarCustomize.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qciToolBarCustomize.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Gradient;
			this.qciToolBarCustomize.Configuration.Appearance.MetallicInnerGlowWidth = 0;
			this.qciToolBarCustomize.Configuration.Appearance.Shape = this.qsToolBarCustomizeItem;
			this.qciToolBarCustomize.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, -2, -2, -2);
			this.qciToolBarCustomize.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
			this.qciToolBarCustomize.Configuration.StretchVertical = true;
			this.qciToolBarCustomize.Items.Add(this.qciToolBarCustomizeImage);
			// 
			// qcmiCustomizeItem1
			// 
			this.qcmiCustomizeItem1.HotkeyText = "1";
			this.qcmiCustomizeItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCustomizeItem1.Icon")));
			this.qcmiCustomizeItem1.Title = "Customize &1";
			// 
			// qcmiCustomizeItem2
			// 
			this.qcmiCustomizeItem2.HotkeyText = "2";
			this.qcmiCustomizeItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCustomizeItem2.Icon")));
			this.qcmiCustomizeItem2.Title = "Customize &2";
			// 
			// qcmiCustomizeItem3
			// 
			this.qcmiCustomizeItem3.HotkeyText = "3";
			this.qcmiCustomizeItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiCustomizeItem3.Icon")));
			this.qcmiCustomizeItem3.Title = "Customize &3";
			// 
			// qsToolBarCustomizeItem
			// 
			this.qsToolBarCustomizeItem.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton2;
			this.qsToolBarCustomizeItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsToolBarCustomizeItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsToolBarCustomizeItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 0F, 100F, 0F, 100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsToolBarCustomizeItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsToolBarCustomizeItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 16F, 100F, 20F, 100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsToolBarCustomizeItem.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			// 
			// qciToolBarCustomizeImage
			// 
			this.qciToolBarCustomizeImage.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qciToolBarCustomizeImage.Image = ((System.Drawing.Image)(resources.GetObject("qciToolBarCustomizeImage.Image")));
			// 
			// qccVerticalBar
			// 
			this.qccVerticalBar.Dock = System.Windows.Forms.DockStyle.Left;
			this.qccVerticalBar.Location = new System.Drawing.Point(5, 126);
			this.qccVerticalBar.Name = "qccVerticalBar";
			this.qccVerticalBar.Size = new System.Drawing.Size(235, 285);
			this.qccVerticalBar.TabIndex = 5;
			// 
			// qccHorizontalBar
			// 
			this.qccHorizontalBar.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.qccHorizontalBar.Location = new System.Drawing.Point(240, 278);
			this.qccHorizontalBar.Name = "qccHorizontalBar";
			this.qccHorizontalBar.Size = new System.Drawing.Size(451, 133);
			this.qccHorizontalBar.TabIndex = 4;
			this.qccHorizontalBar.Text = "qccHorizontalBar";
			// 
			// qPanel1
			// 
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qPanel1.ColorScheme.PanelBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qPanel1.Controls.Add(this.qtbCustomCompositeWindow);
			this.qPanel1.Controls.Add(this.qtbRibbonApplicationMenu);
			this.qPanel1.Controls.Add(this.qtbDefaultContextMenu);
			this.qPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qPanel1.Location = new System.Drawing.Point(240, 126);
			this.qPanel1.Name = "qPanel1";
			this.qPanel1.Size = new System.Drawing.Size(451, 152);
			this.qPanel1.TabIndex = 6;
			this.qPanel1.Text = "qPanel1";
			// 
			// qtbCustomCompositeWindow
			// 
			this.qtbCustomCompositeWindow.Location = new System.Drawing.Point(8, 48);
			this.qtbCustomCompositeWindow.Multiline = true;
			this.qtbCustomCompositeWindow.Name = "qtbCustomCompositeWindow";
			this.qtbCustomCompositeWindow.Size = new System.Drawing.Size(296, 32);
			this.qtbCustomCompositeWindow.TabIndex = 2;
			this.qtbCustomCompositeWindow.Text = "Right click me!\r\nThis shows a custom QCompositeWindow as context menu";
			// 
			// qtbRibbonApplicationMenu
			// 
			this.qtbRibbonApplicationMenu.Location = new System.Drawing.Point(8, 88);
			this.qtbRibbonApplicationMenu.Multiline = true;
			this.qtbRibbonApplicationMenu.Name = "qtbRibbonApplicationMenu";
			this.qtbRibbonApplicationMenu.Size = new System.Drawing.Size(296, 32);
			this.qtbRibbonApplicationMenu.TabIndex = 1;
			this.qtbRibbonApplicationMenu.Text = "Right click me!\r\nThis shows a QRibbonMenu as context menu";
			// 
			// qtbDefaultContextMenu
			// 
			this.qtbDefaultContextMenu.Location = new System.Drawing.Point(8, 8);
			this.qtbDefaultContextMenu.Multiline = true;
			this.qtbDefaultContextMenu.Name = "qtbDefaultContextMenu";
			this.qtbDefaultContextMenu.Size = new System.Drawing.Size(296, 32);
			this.qtbDefaultContextMenu.TabIndex = 0;
			this.qtbDefaultContextMenu.Text = "Right click me!\r\nThis shows a default QCompositeMenu as context menu";
			// 
			// qcmDefaultCompositeMenu
			// 
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuCut);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuCopy);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuPaste);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcsContextMenuSeparator01);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuBold);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuItalic);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuUnderline);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcsContextMenuSeparator02);
			this.qcmDefaultCompositeMenu.Items.Add(this.qcmiContextMenuOtherActions);
			this.qcmDefaultCompositeMenu.AddListener(this.qtbDefaultContextMenu);
			// 
			// qcmiContextMenuCut
			// 
			this.qcmiContextMenuCut.HotkeyText = "T";
			this.qcmiContextMenuCut.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuCut.Icon")));
			this.qcmiContextMenuCut.Title = "Cu&t";
			// 
			// qcmiContextMenuCopy
			// 
			this.qcmiContextMenuCopy.HotkeyText = "C";
			this.qcmiContextMenuCopy.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuCopy.Icon")));
			this.qcmiContextMenuCopy.Title = "&Copy";
			// 
			// qcmiContextMenuPaste
			// 
			this.qcmiContextMenuPaste.HotkeyText = "P";
			this.qcmiContextMenuPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuPaste.Icon")));
			this.qcmiContextMenuPaste.Title = "&Paste";
			// 
			// qcmiContextMenuBold
			// 
			this.qcmiContextMenuBold.HotkeyText = "B";
			this.qcmiContextMenuBold.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuBold.Icon")));
			this.qcmiContextMenuBold.Title = "&Bold";
			// 
			// qcmiContextMenuItalic
			// 
			this.qcmiContextMenuItalic.HotkeyText = "I";
			this.qcmiContextMenuItalic.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuItalic.Icon")));
			this.qcmiContextMenuItalic.Title = "&Italic";
			// 
			// qcmiContextMenuUnderline
			// 
			this.qcmiContextMenuUnderline.HotkeyText = "U";
			this.qcmiContextMenuUnderline.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuUnderline.Icon")));
			this.qcmiContextMenuUnderline.Title = "&Underline";
			// 
			// qcmiContextMenuOtherActions
			// 
			this.qcmiContextMenuOtherActions.ChildItems.Add(this.qcmiContextMenuOtherAction1);
			this.qcmiContextMenuOtherActions.ChildItems.Add(this.qcmiContextMenuOtherAction2);
			this.qcmiContextMenuOtherActions.HotkeyText = "O";
			this.qcmiContextMenuOtherActions.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuOtherActions.Icon")));
			this.qcmiContextMenuOtherActions.Title = "&Other actions";
			// 
			// qcmiContextMenuOtherAction1
			// 
			this.qcmiContextMenuOtherAction1.HotkeyText = "1";
			this.qcmiContextMenuOtherAction1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuOtherAction1.Icon")));
			this.qcmiContextMenuOtherAction1.Title = "Other action&1";
			// 
			// qcmiContextMenuOtherAction2
			// 
			this.qcmiContextMenuOtherAction2.HotkeyText = "2";
			this.qcmiContextMenuOtherAction2.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiContextMenuOtherAction2.Icon")));
			this.qcmiContextMenuOtherAction2.Title = "Ohter action &2";
			// 
			// qcmRibbonApplicationMenu
			// 
			this.qcmRibbonApplicationMenu.AddListener(this.qtbRibbonApplicationMenu);
			// 
			// qcmCustomContextMenu
			// 
			this.qcmCustomContextMenu.AddListener(this.qtbCustomCompositeWindow);
			// 
			// QtpToolBars
			// 
			this.ColorScheme.TabPageBackground1.ColorReference = "@CompositeBackground1";
			this.ColorScheme.TabPageBackground2.ColorReference = "@CompositeBackground2";
			this.Controls.Add(this.qPanel1);
			this.Controls.Add(this.qccHorizontalBar);
			this.Controls.Add(this.qccVerticalBar);
			this.Controls.Add(this.qccToolBar);
			this.Controls.Add(this.qMarkupLabel1);
			this.DockPadding.All = 5;
			this.Name = "QtpToolBars";
			this.Size = new System.Drawing.Size(696, 416);
			((System.ComponentModel.ISupportInitialize)(this.qccToolBar)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.qccVerticalBar)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.qccHorizontalBar)).EndInit();
			this.qPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void qccToolBar_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeControl1_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}
	}
}
