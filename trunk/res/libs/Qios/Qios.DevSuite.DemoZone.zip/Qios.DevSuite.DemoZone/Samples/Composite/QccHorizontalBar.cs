using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

using Qios.DevSuite.DemoZone.Shared;

namespace Qios.DevSuite.DemoZone.Samples.Composite
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	public class QccHorizontalBar : Qios.DevSuite.Components.QCompositeControl
	{
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory1;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory1Header;
		private Qios.DevSuite.Components.QCompositeText qctCategory1Header;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory1Items;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem3;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem2;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem1;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem4;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem5;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem6;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory2Header;
		private Qios.DevSuite.Components.QCompositeText qctCategory2Header;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory2;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory2Items;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QccHorizontalBar()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ChildCompositeColorScheme
		{
			get { return base.ChildCompositeColorScheme; }
			set { base.ChildCompositeColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration ChildCompositeConfiguration
		{
			get { return base.ChildCompositeConfiguration; }
			set { base.ChildCompositeConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeWindowConfiguration ChildWindowConfiguration
		{
			get { return base.ChildWindowConfiguration; }
			set { base.ChildWindowConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ColorScheme
		{
			get { return base.ColorScheme; }
			set { base.ColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration Configuration
		{
			get { return base.Configuration; }
			set { base.Configuration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QToolTipConfiguration ToolTipConfiguration
		{
			get { return base.ToolTipConfiguration; }
			set { base.ToolTipConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QPartCollection Items
		{
			get { return base.Items; }
		}

		/// <summary>
		/// Overridden. We don't want the designer be able to add Items (because they won't be serialized) when this Control
		/// is placed on a Form.
		/// </summary>
		protected override IList AssociatedComponents
		{
			get { return null; }
		}


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QccHorizontalBar));
			this.qcgCategory1 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgCategory1Header = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCategory1Header = new Qios.DevSuite.Components.QCompositeText();
			this.qcgCategory1Items = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiItem3 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem2 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem1 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcgCategory2 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgCategory2Header = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCategory2Header = new Qios.DevSuite.Components.QCompositeText();
			this.qcgCategory2Items = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiItem4 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem5 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem6 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// qcgCategory1
			// 
			this.qcgCategory1.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory1.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory1.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory1.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory1.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory1.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeBorder";
			this.qcgCategory1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory1.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 5);
			this.qcgCategory1.Items.Add(this.qcgCategory1Header);
			this.qcgCategory1.Items.Add(this.qcgCategory1Items);
			// 
			// qcgCategory1Header
			// 
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory1Header.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgCategory1Header.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgCategory1Header.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgCategory1Header.Configuration.ShrinkHorizontal = true;
			this.qcgCategory1Header.Configuration.StretchHorizontal = true;
			this.qcgCategory1Header.Items.Add(this.qctCategory1Header);
			// 
			// qctCategory1Header
			// 
			this.qctCategory1Header.Title = "Category 1";
			// 
			// qcgCategory1Items
			// 
			this.qcgCategory1Items.Items.Add(this.qcmiItem1);
			this.qcgCategory1Items.Items.Add(this.qcmiItem2);
			this.qcgCategory1Items.Items.Add(this.qcmiItem3);
			// 
			// qcmiItem3
			// 
			this.qcmiItem3.Configuration.ContentConfiguration.DescriptionConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem3.Configuration.ContentConfiguration.TitleConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem3.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcmiItem3.Configuration.MaximumSize = new System.Drawing.Size(100, 0);
			this.qcmiItem3.Description = "This is the description for item 3";
			this.qcmiItem3.HotkeyText = "3";
			this.qcmiItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem3.Icon")));
			this.qcmiItem3.Title = "Item &3";
			// 
			// qcmiItem2
			// 
			this.qcmiItem2.Configuration.ContentConfiguration.DescriptionConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem2.Configuration.ContentConfiguration.TitleConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcmiItem2.Configuration.MaximumSize = new System.Drawing.Size(100, 0);
			this.qcmiItem2.Description = "This is the description for item 2";
			this.qcmiItem2.HotkeyText = "2";
			this.qcmiItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem2.Icon")));
			this.qcmiItem2.Title = "Item &2";
			// 
			// qcmiItem1
			// 
			this.qcmiItem1.Configuration.ContentConfiguration.DescriptionConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem1.Configuration.ContentConfiguration.TitleConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcmiItem1.Configuration.MaximumSize = new System.Drawing.Size(100, 0);
			this.qcmiItem1.Description = "This is the description for item 1";
			this.qcmiItem1.HotkeyText = "1";
			this.qcmiItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem1.Icon")));
			this.qcmiItem1.Title = "Item &1";
			// 
			// qcgCategory2
			// 
			this.qcgCategory2.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory2.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory2.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory2.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory2.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory2.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeBorder";
			this.qcgCategory2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory2.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 5);
			this.qcgCategory2.Items.Add(this.qcgCategory2Header);
			this.qcgCategory2.Items.Add(this.qcgCategory2Items);
			// 
			// qcgCategory2Header
			// 
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory2Header.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgCategory2Header.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgCategory2Header.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgCategory2Header.Configuration.ShrinkHorizontal = true;
			this.qcgCategory2Header.Configuration.StretchHorizontal = true;
			this.qcgCategory2Header.Items.Add(this.qctCategory2Header);
			// 
			// qctCategory2Header
			// 
			this.qctCategory2Header.Title = "Category 2";
			// 
			// qcgCategory2Items
			// 
			this.qcgCategory2Items.Items.Add(this.qcmiItem4);
			this.qcgCategory2Items.Items.Add(this.qcmiItem5);
			this.qcgCategory2Items.Items.Add(this.qcmiItem6);
			// 
			// qcmiItem4
			// 
			this.qcmiItem4.Configuration.ContentConfiguration.DescriptionConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem4.Configuration.ContentConfiguration.TitleConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem4.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcmiItem4.Configuration.MaximumSize = new System.Drawing.Size(100, 0);
			this.qcmiItem4.Description = "This is the description for item 4";
			this.qcmiItem4.HotkeyText = "4";
			this.qcmiItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem4.Icon")));
			this.qcmiItem4.Title = "Item &4";
			// 
			// qcmiItem5
			// 
			this.qcmiItem5.Configuration.ContentConfiguration.DescriptionConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem5.Configuration.ContentConfiguration.TitleConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem5.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcmiItem5.Configuration.MaximumSize = new System.Drawing.Size(100, 0);
			this.qcmiItem5.Description = "This is the description for item 5";
			this.qcmiItem5.HotkeyText = "5";
			this.qcmiItem5.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem5.Icon")));
			this.qcmiItem5.Title = "Item &5";
			// 
			// qcmiItem6
			// 
			this.qcmiItem6.Configuration.ContentConfiguration.DescriptionConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem6.Configuration.ContentConfiguration.TitleConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qcmiItem6.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcmiItem6.Configuration.MaximumSize = new System.Drawing.Size(100, 0);
			this.qcmiItem6.Description = "This is the description for item 6";
			this.qcmiItem6.HotkeyText = "6";
			this.qcmiItem6.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem6.Icon")));
			this.qcmiItem6.Title = "Item &6";
			// 
			// QccHorizontalBar
			// 
			this.ColorScheme.CompositeBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.ColorScheme.CompositeBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 5, 0, 0);
			this.Configuration.ScrollConfiguration.ScrollHorizontal = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.Configuration.ShrinkVertical = false;
			this.Configuration.StretchVertical = false;
			this.Items.Add(this.qcgCategory1);
			this.Items.Add(this.qcgCategory2);
			this.Name = "QccHorizontalBar";
			this.Size = new System.Drawing.Size(536, 133);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion

		private void qccToolBar_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

		private void qCompositeControl1_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}
	}
}
