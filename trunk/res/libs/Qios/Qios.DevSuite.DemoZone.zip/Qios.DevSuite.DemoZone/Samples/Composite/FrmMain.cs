using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.DemoZone.Misc;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone.Samples.Composite
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	[SelectorDisplay(
		 30,
		"Composite Sample",
		"Shows several QCompositeControls that display custom layout's of MenuItems, Controls, Groups and shapes.")]
	public class FrmMain : QRibbonForm
	{
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qrcCaption;
		private Qios.DevSuite.Components.QTabControl qTabControl1;
		private Qios.DevSuite.Components.QTabPage qTabPage1;
		private Qios.DevSuite.Components.Ribbon.QRibbonLaunchBar qRibbonLaunchBar1;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		private Qios.DevSuite.Components.QShape qsTabButton;
		private Qios.DevSuite.DemoZone.Samples.Composite.QtpAddCustomer qtpAddCustomer1;
		private Qios.DevSuite.DemoZone.Samples.Composite.QtpToolBars qtpToolBars1;
		private Qios.DevSuite.DemoZone.Samples.Composite.QtpTemplates qtpTemplates1;
		private System.ComponentModel.Container components = null;

		public FrmMain()
		{
			InitializeComponent();

			//Create the MainMenuWindow (this is under the ApplicatbionButton);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            Qios.DevSuite.Components.QMarkupTextStyle qMarkupTextStyle1 = new Qios.DevSuite.Components.QMarkupTextStyle();
            this.qrcCaption = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            this.qRibbonLaunchBar1 = new Qios.DevSuite.Components.Ribbon.QRibbonLaunchBar();
            this.qTabControl1 = new Qios.DevSuite.Components.QTabControl();
            this.qTabPage1 = new Qios.DevSuite.Components.QTabPage();
            this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
            this.qtpTemplates1 = new Qios.DevSuite.DemoZone.Samples.Composite.QtpTemplates();
            this.qtpAddCustomer1 = new Qios.DevSuite.DemoZone.Samples.Composite.QtpAddCustomer();
            this.qtpToolBars1 = new Qios.DevSuite.DemoZone.Samples.Composite.QtpToolBars();
            this.qsTabButton = new Qios.DevSuite.Components.QShape();
            ((System.ComponentModel.ISupportInitialize)(this.qrcCaption)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).BeginInit();
            this.qTabControl1.SuspendLayout();
            this.qTabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // qrcCaption
            // 
            this.qrcCaption.Location = new System.Drawing.Point(0, 0);
            this.qrcCaption.Name = "qrcCaption";
            this.qrcCaption.Size = new System.Drawing.Size(562, 28);
            this.qrcCaption.TabIndex = 0;
            this.qrcCaption.Text = "Composite Sample - Qios.DevSuite.DemoZone ";
            // 
            // qTabControl1
            // 
            this.qTabControl1.ActiveTabPage = this.qTabPage1;
            this.qTabControl1.Appearance.BorderWidth = 0;
            this.qTabControl1.ColorScheme.TabButtonActiveBorder.ColorReference = "@RibbonTabButtonActiveBorder";
            this.qTabControl1.ColorScheme.TabButtonActiveText.ColorReference = "@RibbonTabButtonActiveText";
            this.qTabControl1.ColorScheme.TabControlBorder.SetColor("Default", System.Drawing.Color.Empty, false);
            this.qTabControl1.ColorScheme.TabControlBorder.SetColor("LunaBlue", System.Drawing.Color.Empty, false);
            this.qTabControl1.ColorScheme.TabControlBorder.SetColor("LunaOlive", System.Drawing.Color.Empty, false);
            this.qTabControl1.ColorScheme.TabControlBorder.SetColor("LunaSilver", System.Drawing.Color.Empty, false);
            this.qTabControl1.ColorScheme.TabControlBorder.SetColor("HighContrast", System.Drawing.Color.Empty, false);
            this.qTabControl1.ColorScheme.TabControlBorder.SetColor("VistaBlack", System.Drawing.Color.Empty, false);
            this.qTabControl1.ColorScheme.TabControlContentBorder.ColorReference = "@RibbonTabStripBorder";
            this.qTabControl1.ColorScheme.TabPageBackground1.ColorReference = "@TabButtonActiveBackground2";
            this.qTabControl1.ColorScheme.TabPageBackground2.ColorReference = "@RibbonPageBackground2";
            this.qTabControl1.ColorScheme.TabStripBorder.ColorReference = "@RibbonTabStripBorder";
            this.qTabControl1.Configuration.ContentAppearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.RibbonContent);
            this.qTabControl1.Configuration.ContentAppearance.UseControlBackgroundForShape = true;
            this.qTabControl1.Controls.Add(this.qtpTemplates1);
            this.qTabControl1.Controls.Add(this.qtpAddCustomer1);
            this.qTabControl1.Controls.Add(this.qTabPage1);
            this.qTabControl1.Controls.Add(this.qtpToolBars1);
            this.qTabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.qTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qTabControl1.Location = new System.Drawing.Point(0, 28);
            this.qTabControl1.Name = "qTabControl1";
            this.qTabControl1.PersistGuid = new System.Guid("d9c01421-24d7-44fc-90ba-9d74c7ea0349");
            this.qTabControl1.Size = new System.Drawing.Size(562, 438);
            this.qTabControl1.TabIndex = 3;
            this.qTabControl1.TabStripTopConfiguration.ButtonConfiguration.AppearanceActive.UseControlBackgroundForTabButton = true;
            this.qTabControl1.TabStripTopConfiguration.StripMargin = new Qios.DevSuite.Components.QMargin(5, 0, 0, 7);
            this.qTabControl1.Text = "qTabControl1";
            // 
            // qTabPage1
            // 
            this.qTabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qTabPage1.BackgroundImage")));
            this.qTabPage1.ButtonOrder = 0;
            this.qTabPage1.Controls.Add(this.qMarkupLabel1);
            this.qTabPage1.Location = new System.Drawing.Point(2, 32);
            this.qTabPage1.Name = "qTabPage1";
            this.qTabPage1.Padding = new System.Windows.Forms.Padding(10);
            this.qTabPage1.PersistGuid = new System.Guid("1d7b6d91-958c-4d1b-ae07-5b0b33a077d5");
            this.qTabPage1.Size = new System.Drawing.Size(556, 402);
            this.qTabPage1.Text = "Welcome";
            // 
            // qMarkupLabel1
            // 
            this.qMarkupLabel1.Configuration.BiggerSmallerStep = 1;
            qMarkupTextStyle1.DefaultTag = "H1";
            qMarkupTextStyle1.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 12F);
            qMarkupTextStyle1.NewLineAfter = true;
            qMarkupTextStyle1.TextColorProperty = "RibbonTabButtonActiveText";
            this.qMarkupLabel1.CustomStyles.Add(qMarkupTextStyle1);
            this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.qMarkupLabel1.Location = new System.Drawing.Point(10, 10);
            this.qMarkupLabel1.MarkupText = resources.GetString("qMarkupLabel1.MarkupText");
            this.qMarkupLabel1.Name = "qMarkupLabel1";
            this.qMarkupLabel1.Size = new System.Drawing.Size(536, 123);
            this.qMarkupLabel1.TabIndex = 0;
            // 
            // qtpTemplates1
            // 
            this.qtpTemplates1.ButtonOrder = 3;
            this.qtpTemplates1.Location = new System.Drawing.Point(2, 32);
            this.qtpTemplates1.Name = "qtpTemplates1";
            this.qtpTemplates1.Padding = new System.Windows.Forms.Padding(5);
            this.qtpTemplates1.PersistGuid = new System.Guid("465fa0cb-03ea-47c6-b943-5533545a069c");
            this.qtpTemplates1.Size = new System.Drawing.Size(556, 402);
            this.qtpTemplates1.Text = "Templates";
            // 
            // qtpAddCustomer1
            // 
            this.qtpAddCustomer1.ButtonOrder = 4;
            this.qtpAddCustomer1.Location = new System.Drawing.Point(2, 32);
            this.qtpAddCustomer1.Name = "qtpAddCustomer1";
            this.qtpAddCustomer1.Padding = new System.Windows.Forms.Padding(5);
            this.qtpAddCustomer1.PersistGuid = new System.Guid("1e5ccf48-a82b-4755-9d4b-bcd1e822dde9");
            this.qtpAddCustomer1.Size = new System.Drawing.Size(556, 402);
            this.qtpAddCustomer1.Text = "Add Customer";
            // 
            // qtpToolBars1
            // 
            this.qtpToolBars1.ButtonOrder = 2;
            this.qtpToolBars1.ColorScheme.TabPageBackground1.ColorReference = "@CompositeBackground1";
            this.qtpToolBars1.ColorScheme.TabPageBackground2.ColorReference = "@CompositeBackground2";
            this.qtpToolBars1.Location = new System.Drawing.Point(2, 32);
            this.qtpToolBars1.Name = "qtpToolBars1";
            this.qtpToolBars1.Padding = new System.Windows.Forms.Padding(5);
            this.qtpToolBars1.PersistGuid = new System.Guid("465fa0cb-03ea-47c6-b943-5533545a069c");
            this.qtpToolBars1.Size = new System.Drawing.Size(556, 402);
            this.qtpToolBars1.Text = "Toolbars & ContextMenus";
            // 
            // qsTabButton
            // 
            this.qsTabButton.ClonedBaseShapeType = Qios.DevSuite.Components.QBaseShapeType.MSVisualStudio2005Tab;
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(562, 466);
            this.Controls.Add(this.qTabControl1);
            this.Controls.Add(this.qrcCaption);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.Text = "Composite Sample - Qios.DevSuite.DemoZone ";
            ((System.ComponentModel.ISupportInitialize)(this.qrcCaption)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qTabControl1)).EndInit();
            this.qTabControl1.ResumeLayout(false);
            this.qTabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

	}
}
