using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.Composite
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	public class QtpTemplates : Qios.DevSuite.Components.QTabPage
	{
		private Qios.DevSuite.Components.QCompositeControl qccAddCustomer;
		private Qios.DevSuite.Components.QCompositeGroup qcgHeading;
		private Qios.DevSuite.Components.QCompositeText qctHeaderTitle;
		private Qios.DevSuite.Components.QCompositeGroup qcgContent;
		private Qios.DevSuite.Components.QCompositeText qctCaption;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem1;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage37;
		private Qios.DevSuite.Components.QCompositeText qCompositeText38;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem2;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage38;
		private Qios.DevSuite.Components.QCompositeText qCompositeText39;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem3;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage39;
		private Qios.DevSuite.Components.QCompositeText qCompositeText40;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem4;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage40;
		private Qios.DevSuite.Components.QCompositeText qCompositeText41;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem5;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage41;
		private Qios.DevSuite.Components.QCompositeText qCompositeText42;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem6;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage42;
		private Qios.DevSuite.Components.QCompositeText qCompositeText43;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem7;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage43;
		private Qios.DevSuite.Components.QCompositeText qCompositeText44;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem8;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage44;
		private Qios.DevSuite.Components.QCompositeText qCompositeText45;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem9;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage45;
		private Qios.DevSuite.Components.QCompositeText qCompositeText46;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem10;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage46;
		private Qios.DevSuite.Components.QCompositeText qCompositeText47;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem11;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage47;
		private Qios.DevSuite.Components.QCompositeText qCompositeText48;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem12;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage48;
		private Qios.DevSuite.Components.QCompositeText qCompositeText49;
		private Qios.DevSuite.Components.QCompositeGroup qcgTemplateItems;
		private Qios.DevSuite.Components.QCompositeGroup qcgMenuItems;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem5;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem6;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem14;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem15;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem16;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem7;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem1;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem2;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem3;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem8;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem11;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem12;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem13;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem9;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem10;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem4;
		private Qios.DevSuite.Components.QCompositeGroup qcgTemplateHeader;
		private Qios.DevSuite.Components.QCompositeText qctHeaderDescription;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QtpTemplates()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QtpTemplates));
			this.qccAddCustomer = new Qios.DevSuite.Components.QCompositeControl();
			this.qcgHeading = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctHeaderTitle = new Qios.DevSuite.Components.QCompositeText();
			this.qctHeaderDescription = new Qios.DevSuite.Components.QCompositeText();
			this.qcgContent = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgTemplateHeader = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCaption = new Qios.DevSuite.Components.QCompositeText();
			this.qcgTemplateItems = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeItem1 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage37 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText38 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem2 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage38 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText39 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem3 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage39 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText40 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem4 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage40 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText41 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem5 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage41 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText42 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem6 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage42 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText43 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem7 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage43 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText44 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem8 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage44 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText45 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem9 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage45 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText46 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem10 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage46 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText47 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem11 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage47 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText48 = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem12 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage48 = new Qios.DevSuite.Components.QCompositeImage();
			this.qCompositeText49 = new Qios.DevSuite.Components.QCompositeText();
			this.qcgMenuItems = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeMenuItem5 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem6 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem14 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem15 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem16 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem7 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem1 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem2 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem3 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem8 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem11 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem12 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem13 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem9 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem10 = new Qios.DevSuite.Components.QCompositeMenuItem();
			this.qCompositeMenuItem4 = new Qios.DevSuite.Components.QCompositeMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.qccAddCustomer)).BeginInit();
			this.SuspendLayout();
			// 
			// qccAddCustomer
			// 
			this.qccAddCustomer.ChildCompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qccAddCustomer.ChildCompositeConfiguration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qccAddCustomer.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qccAddCustomer.Configuration.IconBackgroundSize = 32;
			this.qccAddCustomer.Configuration.IconBackgroundVisible = true;
			this.qccAddCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qccAddCustomer.Focusable = true;
			this.qccAddCustomer.Items.Add(this.qcgHeading);
			this.qccAddCustomer.Items.Add(this.qctHeaderDescription);
			this.qccAddCustomer.Items.Add(this.qcgContent);
			this.qccAddCustomer.Location = new System.Drawing.Point(5, 5);
			this.qccAddCustomer.Name = "qccAddCustomer";
			this.qccAddCustomer.Size = new System.Drawing.Size(614, 382);
			this.qccAddCustomer.TabIndex = 1;
			this.qccAddCustomer.Text = "qCompositeControl1";
			this.qccAddCustomer.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qccAddCustomer_ItemActivated);
			// 
			// qcgHeading
			// 
			this.qcgHeading.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
			this.qcgHeading.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
			this.qcgHeading.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
			this.qcgHeading.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgHeading.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 3, 0);
			this.qcgHeading.Configuration.ShrinkHorizontal = true;
			this.qcgHeading.Configuration.StretchHorizontal = true;
			this.qcgHeading.Items.Add(this.qctHeaderTitle);
			// 
			// qctHeaderTitle
			// 
			this.qctHeaderTitle.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 11F);
			this.qctHeaderTitle.Title = "Templates";
			// 
			// qctHeaderDescription
			// 
			this.qctHeaderDescription.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 9F);
			this.qctHeaderDescription.Configuration.Margin = new Qios.DevSuite.Components.QMargin(34, 0, 0, 0);
			this.qctHeaderDescription.Configuration.ShrinkHorizontal = true;
			this.qctHeaderDescription.Configuration.WrapText = true;
			this.qctHeaderDescription.Title = "Here you see a QComposite that is layed out with some flowing selectable ite" +
				"ms and a menu";
			// 
			// qcgContent
			// 
			this.qcgContent.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgContent.Configuration.ShrinkHorizontal = true;
			this.qcgContent.Configuration.ShrinkVertical = true;
			this.qcgContent.Configuration.StretchHorizontal = true;
			this.qcgContent.Configuration.StretchVertical = true;
			this.qcgContent.Items.Add(this.qcgTemplateHeader);
			this.qcgContent.Items.Add(this.qcgTemplateItems);
			this.qcgContent.Items.Add(this.qcgMenuItems);
			// 
			// qcgTemplateHeader
			// 
			this.qcgTemplateHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
			this.qcgTemplateHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@RibbonPanelBackground2";
			this.qcgTemplateHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@RibbonPanelBorder";
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(221)), ((System.Byte)(231)), ((System.Byte)(238))), false);
			this.qcgTemplateHeader.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Linear;
			this.qcgTemplateHeader.Configuration.StretchHorizontal = true;
			this.qcgTemplateHeader.Items.Add(this.qctCaption);
			// 
			// qctCaption
			// 
			this.qctCaption.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
			this.qctCaption.Title = "Built-In";
			// 
			// qcgTemplateItems
			// 
			this.qcgTemplateItems.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeBackground1";
			this.qcgTemplateItems.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeBackground2";
			this.qcgTemplateItems.ColorScheme.CompositeGroupBorder.ColorReference = "@RibbonPanelBorder";
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground1.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBorder.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(197)), ((System.Byte)(197)), ((System.Byte)(197))), false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBorder.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(197)), ((System.Byte)(197)), ((System.Byte)(197))), false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBorder.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(197)), ((System.Byte)(197)), ((System.Byte)(197))), false);
			this.qcgTemplateItems.ColorScheme.CompositeItemBorder.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(197)), ((System.Byte)(197)), ((System.Byte)(197))), false);
			this.qcgTemplateItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Flow;
			this.qcgTemplateItems.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 3, 3, 0);
			this.qcgTemplateItems.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgTemplateItems.Configuration.ScrollConfiguration.ScrollType = Qios.DevSuite.Components.QCompositeScrollType.ScrollBar;
			this.qcgTemplateItems.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.qcgTemplateItems.Configuration.ShrinkHorizontal = true;
			this.qcgTemplateItems.Configuration.ShrinkVertical = true;
			this.qcgTemplateItems.Configuration.StretchHorizontal = true;
			this.qcgTemplateItems.Configuration.StretchVertical = true;
			this.qcgTemplateItems.Items.Add(this.qCompositeItem1);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem2);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem3);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem4);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem5);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem6);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem7);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem8);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem9);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem10);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem11);
			this.qcgTemplateItems.Items.Add(this.qCompositeItem12);
			// 
			// qCompositeItem1
			// 
			this.qCompositeItem1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem1.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem1.Items.Add(this.qCompositeImage37);
			this.qCompositeItem1.Items.Add(this.qCompositeText38);
			// 
			// qCompositeImage37
			// 
			this.qCompositeImage37.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage37.Image")));
			// 
			// qCompositeText38
			// 
			this.qCompositeText38.Title = "Item 1";
			// 
			// qCompositeItem2
			// 
			this.qCompositeItem2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem2.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem2.Items.Add(this.qCompositeImage38);
			this.qCompositeItem2.Items.Add(this.qCompositeText39);
			// 
			// qCompositeImage38
			// 
			this.qCompositeImage38.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage38.Image")));
			// 
			// qCompositeText39
			// 
			this.qCompositeText39.Title = "Item 2";
			// 
			// qCompositeItem3
			// 
			this.qCompositeItem3.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem3.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem3.Items.Add(this.qCompositeImage39);
			this.qCompositeItem3.Items.Add(this.qCompositeText40);
			// 
			// qCompositeImage39
			// 
			this.qCompositeImage39.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage39.Image")));
			// 
			// qCompositeText40
			// 
			this.qCompositeText40.Title = "Item 3";
			// 
			// qCompositeItem4
			// 
			this.qCompositeItem4.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem4.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem4.Items.Add(this.qCompositeImage40);
			this.qCompositeItem4.Items.Add(this.qCompositeText41);
			// 
			// qCompositeImage40
			// 
			this.qCompositeImage40.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage40.Image")));
			// 
			// qCompositeText41
			// 
			this.qCompositeText41.Title = "Item 4";
			// 
			// qCompositeItem5
			// 
			this.qCompositeItem5.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem5.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem5.Items.Add(this.qCompositeImage41);
			this.qCompositeItem5.Items.Add(this.qCompositeText42);
			// 
			// qCompositeImage41
			// 
			this.qCompositeImage41.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage41.Image")));
			// 
			// qCompositeText42
			// 
			this.qCompositeText42.Title = "Item 5";
			// 
			// qCompositeItem6
			// 
			this.qCompositeItem6.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem6.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem6.Items.Add(this.qCompositeImage42);
			this.qCompositeItem6.Items.Add(this.qCompositeText43);
			// 
			// qCompositeImage42
			// 
			this.qCompositeImage42.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage42.Image")));
			// 
			// qCompositeText43
			// 
			this.qCompositeText43.Title = "Item 6";
			// 
			// qCompositeItem7
			// 
			this.qCompositeItem7.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem7.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem7.Items.Add(this.qCompositeImage43);
			this.qCompositeItem7.Items.Add(this.qCompositeText44);
			// 
			// qCompositeImage43
			// 
			this.qCompositeImage43.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage43.Image")));
			// 
			// qCompositeText44
			// 
			this.qCompositeText44.Title = "Item 7";
			// 
			// qCompositeItem8
			// 
			this.qCompositeItem8.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem8.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem8.Items.Add(this.qCompositeImage44);
			this.qCompositeItem8.Items.Add(this.qCompositeText45);
			// 
			// qCompositeImage44
			// 
			this.qCompositeImage44.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage44.Image")));
			// 
			// qCompositeText45
			// 
			this.qCompositeText45.Title = "Item 8";
			// 
			// qCompositeItem9
			// 
			this.qCompositeItem9.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem9.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem9.Items.Add(this.qCompositeImage45);
			this.qCompositeItem9.Items.Add(this.qCompositeText46);
			// 
			// qCompositeImage45
			// 
			this.qCompositeImage45.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage45.Image")));
			// 
			// qCompositeText46
			// 
			this.qCompositeText46.Title = "Item 9";
			// 
			// qCompositeItem10
			// 
			this.qCompositeItem10.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem10.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem10.Items.Add(this.qCompositeImage46);
			this.qCompositeItem10.Items.Add(this.qCompositeText47);
			// 
			// qCompositeImage46
			// 
			this.qCompositeImage46.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage46.Image")));
			// 
			// qCompositeText47
			// 
			this.qCompositeText47.Title = "Item 10";
			// 
			// qCompositeItem11
			// 
			this.qCompositeItem11.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem11.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem11.Items.Add(this.qCompositeImage47);
			this.qCompositeItem11.Items.Add(this.qCompositeText48);
			// 
			// qCompositeImage47
			// 
			this.qCompositeImage47.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage47.Image")));
			// 
			// qCompositeText48
			// 
			this.qCompositeText48.Title = "Item 11";
			// 
			// qCompositeItem12
			// 
			this.qCompositeItem12.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeItem12.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qCompositeItem12.Items.Add(this.qCompositeImage48);
			this.qCompositeItem12.Items.Add(this.qCompositeText49);
			// 
			// qCompositeImage48
			// 
			this.qCompositeImage48.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage48.Image")));
			// 
			// qCompositeText49
			// 
			this.qCompositeText49.Title = "Item 12";
			// 
			// qcgMenuItems
			// 
			this.qcgMenuItems.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgMenuItems.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qcgMenuItems.Configuration.ShrinkHorizontal = true;
			this.qcgMenuItems.Configuration.StretchHorizontal = true;
			this.qcgMenuItems.Items.Add(this.qCompositeMenuItem5);
			this.qcgMenuItems.Items.Add(this.qCompositeMenuItem1);
			this.qcgMenuItems.Items.Add(this.qCompositeMenuItem2);
			this.qcgMenuItems.Items.Add(this.qCompositeMenuItem3);
			this.qcgMenuItems.Items.Add(this.qCompositeMenuItem4);
			// 
			// qCompositeMenuItem5
			// 
			this.qCompositeMenuItem5.ChildItems.Add(this.qCompositeMenuItem6);
			this.qCompositeMenuItem5.ChildItems.Add(this.qCompositeMenuItem7);
			this.qCompositeMenuItem5.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(24, 24);
			this.qCompositeMenuItem5.Configuration.ShrinkHorizontal = true;
			this.qCompositeMenuItem5.Configuration.StretchHorizontal = true;
			this.qCompositeMenuItem5.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qCompositeMenuItem5.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qCompositeMenuItem5.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qCompositeMenuItem5.HotkeyText = "S";
			this.qCompositeMenuItem5.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem5.Icon")));
			this.qCompositeMenuItem5.Title = "Cu&stom stuff";
			// 
			// qCompositeMenuItem6
			// 
			this.qCompositeMenuItem6.ChildItems.Add(this.qCompositeMenuItem14);
			this.qCompositeMenuItem6.ChildItems.Add(this.qCompositeMenuItem15);
			this.qCompositeMenuItem6.ChildItems.Add(this.qCompositeMenuItem16);
			this.qCompositeMenuItem6.HotkeyText = "I";
			this.qCompositeMenuItem6.Title = "&Item1";
			// 
			// qCompositeMenuItem14
			// 
			this.qCompositeMenuItem14.Title = "CustomStuff21";
			// 
			// qCompositeMenuItem15
			// 
			this.qCompositeMenuItem15.Title = "CustomStuff22";
			// 
			// qCompositeMenuItem16
			// 
			this.qCompositeMenuItem16.Title = "CustomStuff23";
			// 
			// qCompositeMenuItem7
			// 
			this.qCompositeMenuItem7.HotkeyText = "T";
			this.qCompositeMenuItem7.Title = "I&tem2";
			// 
			// qCompositeMenuItem1
			// 
			this.qCompositeMenuItem1.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(24, 24);
			this.qCompositeMenuItem1.Configuration.ShrinkHorizontal = true;
			this.qCompositeMenuItem1.Configuration.StretchHorizontal = true;
			this.qCompositeMenuItem1.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qCompositeMenuItem1.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qCompositeMenuItem1.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qCompositeMenuItem1.HotkeyText = "R";
			this.qCompositeMenuItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem1.Icon")));
			this.qCompositeMenuItem1.Title = "&Reset to Theme from Template";
			// 
			// qCompositeMenuItem2
			// 
			this.qCompositeMenuItem2.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(24, 24);
			this.qCompositeMenuItem2.Configuration.ShrinkHorizontal = true;
			this.qCompositeMenuItem2.Configuration.StretchHorizontal = true;
			this.qCompositeMenuItem2.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qCompositeMenuItem2.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qCompositeMenuItem2.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qCompositeMenuItem2.HotkeyText = "O";
			this.qCompositeMenuItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem2.Icon")));
			this.qCompositeMenuItem2.Title = "Search &Office Online";
			// 
			// qCompositeMenuItem3
			// 
			this.qCompositeMenuItem3.ChildItems.Add(this.qCompositeMenuItem8);
			this.qCompositeMenuItem3.ChildItems.Add(this.qCompositeMenuItem9);
			this.qCompositeMenuItem3.ChildItems.Add(this.qCompositeMenuItem10);
			this.qCompositeMenuItem3.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(24, 24);
			this.qCompositeMenuItem3.Configuration.ShrinkHorizontal = true;
			this.qCompositeMenuItem3.Configuration.StretchHorizontal = true;
			this.qCompositeMenuItem3.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qCompositeMenuItem3.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qCompositeMenuItem3.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qCompositeMenuItem3.HotkeyText = "B";
			this.qCompositeMenuItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem3.Icon")));
			this.qCompositeMenuItem3.Title = "&Browse for Themes";
			// 
			// qCompositeMenuItem8
			// 
			this.qCompositeMenuItem8.ChildItems.Add(this.qCompositeMenuItem11);
			this.qCompositeMenuItem8.ChildItems.Add(this.qCompositeMenuItem12);
			this.qCompositeMenuItem8.ChildItems.Add(this.qCompositeMenuItem13);
			this.qCompositeMenuItem8.HotkeyText = "B";
			this.qCompositeMenuItem8.Title = "&Browse1";
			// 
			// qCompositeMenuItem11
			// 
			this.qCompositeMenuItem11.Title = "Browse21";
			// 
			// qCompositeMenuItem12
			// 
			this.qCompositeMenuItem12.Title = "Browse22";
			// 
			// qCompositeMenuItem13
			// 
			this.qCompositeMenuItem13.Title = "Browse23";
			// 
			// qCompositeMenuItem9
			// 
			this.qCompositeMenuItem9.HotkeyText = "B";
			this.qCompositeMenuItem9.Title = "&Browse2";
			// 
			// qCompositeMenuItem10
			// 
			this.qCompositeMenuItem10.HotkeyText = "B";
			this.qCompositeMenuItem10.Title = "&Browse3";
			// 
			// qCompositeMenuItem4
			// 
			this.qCompositeMenuItem4.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(24, 24);
			this.qCompositeMenuItem4.Configuration.ShrinkHorizontal = true;
			this.qCompositeMenuItem4.Configuration.StretchHorizontal = true;
			this.qCompositeMenuItem4.Configuration.TitleConfiguration.DrawTextOptions = Qios.DevSuite.Components.QDrawTextOptions.EndEllipsis;
			this.qCompositeMenuItem4.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qCompositeMenuItem4.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qCompositeMenuItem4.HotkeyText = "A";
			this.qCompositeMenuItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem4.Icon")));
			this.qCompositeMenuItem4.Title = "S&ave Current Theme";
			// 
			// QtpTemplates
			// 
			this.Controls.Add(this.qccAddCustomer);
			this.DockPadding.All = 5;
			this.Name = "QtpTemplates";
			this.Size = new System.Drawing.Size(624, 392);
			((System.ComponentModel.ISupportInitialize)(this.qccAddCustomer)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void qccAddCustomer_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}
	}
}
