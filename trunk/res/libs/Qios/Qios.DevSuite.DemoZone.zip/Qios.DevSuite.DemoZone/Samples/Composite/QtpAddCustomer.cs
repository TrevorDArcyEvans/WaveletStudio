using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Qios.DevSuite.DemoZone.Samples.Composite
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	public class QtpAddCustomer : Qios.DevSuite.Components.QTabPage
	{
		private Qios.DevSuite.Components.QCompositeControl qccAddCustomer;
		private Qios.DevSuite.Components.QCompositeSeparator qcsAddCustomer01;
		private Qios.DevSuite.Components.QCompositeSeparator qCompositeSeparator02;
		private Qios.DevSuite.Components.QCompositeButton qcbAddCustomerSave;
		private Qios.DevSuite.Components.QCompositeButton qcbAddCustomerCancel;
		private Qios.DevSuite.Components.QShape qsDetailsGroup;
		private Qios.DevSuite.Components.QCompositeGroup qcgHeading;
		private Qios.DevSuite.Components.QCompositeText qctHeaderTitle;
		private Qios.DevSuite.Components.QCompositeText qctHeaderDescription;
		private Qios.DevSuite.Components.QCompositeGroup qcgContent;
		private Qios.DevSuite.Components.QCompositeGroup qcgFooter;
		private Qios.DevSuite.Components.QCompositeGroup qcgContentLeft;
		private Qios.DevSuite.Components.QCompositeGroup qcgContentRight;
		private Qios.DevSuite.Components.QCompositeGroup qcgPersonalInformation;
		private Qios.DevSuite.Components.QCompositeGroup qcgPersonalHeading;
		private Qios.DevSuite.Components.QCompositeText qctPersonalHeading;
		private Qios.DevSuite.Components.QCompositeGroup qcgPersonalDetails;
		private Qios.DevSuite.Components.QCompositeGroup qcgName;
		private Qios.DevSuite.Components.QCompositeText qctName;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibName;
		private Qios.DevSuite.Components.QCompositeGroup qcgDateOfBirth;
		private Qios.DevSuite.Components.QCompositeText qctDateOfBirth;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibDateOfBirth;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup3;
		private Qios.DevSuite.Components.QCompositeGroup qcgPlaceOfBirth;
		private Qios.DevSuite.Components.QCompositeText qctPlaceOfBirth;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibPlaceOfBirth;
		private Qios.DevSuite.Components.QCompositeGroup qcgGender;
		private Qios.DevSuite.Components.QCompositeText qctGender;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibGender;
		private Qios.DevSuite.Components.QCompositeGroup qcgStreet;
		private Qios.DevSuite.Components.QCompositeText qctStreet;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibStreet;
		private Qios.DevSuite.Components.QCompositeGroup qcgZipcode;
		private Qios.DevSuite.Components.QCompositeText qctZipcode;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibZipcode;
		private Qios.DevSuite.Components.QCompositeGroup qcgState;
		private Qios.DevSuite.Components.QCompositeText qctState;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibState;
		private Qios.DevSuite.Components.QCompositeGroup qcgCountry;
		private Qios.DevSuite.Components.QCompositeText qctCountry;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibCountry;
		private Qios.DevSuite.Components.QCompositeGroup qcgLocationHeader;
		private Qios.DevSuite.Components.QCompositeText qctLocationHeader;
		private Qios.DevSuite.Components.QCompositeGroup qcgLocationDetails;
		private Qios.DevSuite.Components.QCompositeGroup qcgLocationInformation;
		private Qios.DevSuite.Components.QCompositeGroup qcgContactInformation;
		private Qios.DevSuite.Components.QCompositeGroup qcgContactHeader;
		private Qios.DevSuite.Components.QCompositeText qctContactHeader;
		private Qios.DevSuite.Components.QCompositeGroup qcgEmail;
		private Qios.DevSuite.Components.QCompositeText qctEmail;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibEmail;
		private Qios.DevSuite.Components.QCompositeGroup qcgPhone;
		private Qios.DevSuite.Components.QCompositeText qctPhone;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibPhone;
		private Qios.DevSuite.Components.QCompositeGroup qcgFax;
		private Qios.DevSuite.Components.QCompositeText qctFax;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibFax;
		private Qios.DevSuite.Components.QCompositeGroup qcgAdditionalInformation;
		private Qios.DevSuite.Components.QCompositeGroup qcgAdditionalHeader;
		private Qios.DevSuite.Components.QCompositeText qctAdditionalHeader;
		private Qios.DevSuite.Components.QCompositeGroup qCompositeGroup4;
		private Qios.DevSuite.Components.QCompositeGroup qcgGraduationYear;
		private Qios.DevSuite.Components.QCompositeText qctGraduationYear;
		private Qios.DevSuite.Components.QCompositeItemInputBox qcibGraduationYear;
		private Qios.DevSuite.Components.QCompositeGroup qcgRemarks;
		private Qios.DevSuite.Components.QCompositeText qctRemarks;
		private Qios.DevSuite.Components.QCompositeItemInputBox qCompositeItemInputBox2;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QtpAddCustomer()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.qccAddCustomer = new Qios.DevSuite.Components.QCompositeControl();
			this.qcgHeading = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctHeaderTitle = new Qios.DevSuite.Components.QCompositeText();
			this.qctHeaderDescription = new Qios.DevSuite.Components.QCompositeText();
			this.qcsAddCustomer01 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcgContent = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgContentLeft = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgPersonalInformation = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgPersonalHeading = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctPersonalHeading = new Qios.DevSuite.Components.QCompositeText();
			this.qcgPersonalDetails = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgName = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctName = new Qios.DevSuite.Components.QCompositeText();
			this.qcibName = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgDateOfBirth = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctDateOfBirth = new Qios.DevSuite.Components.QCompositeText();
			this.qcibDateOfBirth = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgPlaceOfBirth = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctPlaceOfBirth = new Qios.DevSuite.Components.QCompositeText();
			this.qcibPlaceOfBirth = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgGender = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctGender = new Qios.DevSuite.Components.QCompositeText();
			this.qcibGender = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgLocationInformation = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgLocationHeader = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctLocationHeader = new Qios.DevSuite.Components.QCompositeText();
			this.qcgLocationDetails = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgStreet = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctStreet = new Qios.DevSuite.Components.QCompositeText();
			this.qcibStreet = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgZipcode = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctZipcode = new Qios.DevSuite.Components.QCompositeText();
			this.qcibZipcode = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgState = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctState = new Qios.DevSuite.Components.QCompositeText();
			this.qcibState = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgCountry = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCountry = new Qios.DevSuite.Components.QCompositeText();
			this.qcibCountry = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgContentRight = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgContactInformation = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgContactHeader = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctContactHeader = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeGroup3 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgEmail = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctEmail = new Qios.DevSuite.Components.QCompositeText();
			this.qcibEmail = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgPhone = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctPhone = new Qios.DevSuite.Components.QCompositeText();
			this.qcibPhone = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgFax = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctFax = new Qios.DevSuite.Components.QCompositeText();
			this.qcibFax = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgAdditionalInformation = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgAdditionalHeader = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctAdditionalHeader = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeGroup4 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgGraduationYear = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctGraduationYear = new Qios.DevSuite.Components.QCompositeText();
			this.qcibGraduationYear = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qcgRemarks = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctRemarks = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItemInputBox2 = new Qios.DevSuite.Components.QCompositeItemInputBox();
			this.qCompositeSeparator02 = new Qios.DevSuite.Components.QCompositeSeparator();
			this.qcgFooter = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcbAddCustomerSave = new Qios.DevSuite.Components.QCompositeButton();
			this.qcbAddCustomerCancel = new Qios.DevSuite.Components.QCompositeButton();
			this.qsDetailsGroup = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this.qccAddCustomer)).BeginInit();
			this.SuspendLayout();
			// 
			// qccAddCustomer
			// 
			this.qccAddCustomer.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qccAddCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.qccAddCustomer.Focusable = true;
			this.qccAddCustomer.Items.Add(this.qcgHeading);
			this.qccAddCustomer.Items.Add(this.qcsAddCustomer01);
			this.qccAddCustomer.Items.Add(this.qcgContent);
			this.qccAddCustomer.Items.Add(this.qCompositeSeparator02);
			this.qccAddCustomer.Items.Add(this.qcgFooter);
			this.qccAddCustomer.Location = new System.Drawing.Point(5, 5);
			this.qccAddCustomer.Name = "qccAddCustomer";
			this.qccAddCustomer.Size = new System.Drawing.Size(574, 406);
			this.qccAddCustomer.TabIndex = 1;
			this.qccAddCustomer.Text = "qCompositeControl1";
			this.qccAddCustomer.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qccAddCustomer_ItemActivated);
			// 
			// qcgHeading
			// 
			this.qcgHeading.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgHeading.Configuration.ShrinkHorizontal = true;
			this.qcgHeading.Configuration.StretchHorizontal = true;
			this.qcgHeading.Items.Add(this.qctHeaderTitle);
			this.qcgHeading.Items.Add(this.qctHeaderDescription);
			// 
			// qctHeaderTitle
			// 
			this.qctHeaderTitle.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 11F);
			this.qctHeaderTitle.Title = "Add Customer";
			// 
			// qctHeaderDescription
			// 
			this.qctHeaderDescription.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 9F);
			this.qctHeaderDescription.Configuration.ShrinkHorizontal = true;
			this.qctHeaderDescription.Configuration.WrapText = true;
			this.qctHeaderDescription.Title = "Here you see how you can use a QCompositeControl to create a slick Data entry for" +
				"m. Resizing this Form shows you the huge benefit of automatically positioned, al" +
				"igned and stretched controls.";
			// 
			// qcgContent
			// 
			this.qcgContent.Configuration.ScrollConfiguration.ButtonAppearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgContent.Configuration.ScrollConfiguration.ScrollHorizontal = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.qcgContent.Configuration.ScrollConfiguration.ScrollType = Qios.DevSuite.Components.QCompositeScrollType.ScrollBar;
			this.qcgContent.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.qcgContent.Configuration.ScrollConfiguration.TrackButtonAppearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgContent.Configuration.ScrollConfiguration.TrackButtonAppearance.MetallicDirection = Qios.DevSuite.Components.QMetallicAppearanceDirection.Vertical;
			this.qcgContent.Configuration.ShrinkHorizontal = true;
			this.qcgContent.Configuration.ShrinkVertical = true;
			this.qcgContent.Configuration.StretchHorizontal = true;
			this.qcgContent.Configuration.StretchVertical = true;
			this.qcgContent.Items.Add(this.qcgContentLeft);
			this.qcgContent.Items.Add(this.qcgContentRight);
			// 
			// qcgContentLeft
			// 
			this.qcgContentLeft.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgContentLeft.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgContentLeft.Configuration.StretchHorizontal = true;
			this.qcgContentLeft.Items.Add(this.qcgPersonalInformation);
			this.qcgContentLeft.Items.Add(this.qcgLocationInformation);
			// 
			// qcgPersonalInformation
			// 
			this.qcgPersonalInformation.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgPersonalInformation.Configuration.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 3, 1);
			this.qcgPersonalInformation.Configuration.StretchHorizontal = true;
			this.qcgPersonalInformation.Items.Add(this.qcgPersonalHeading);
			this.qcgPersonalInformation.Items.Add(this.qcgPersonalDetails);
			// 
			// qcgPersonalHeading
			// 
			this.qcgPersonalHeading.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
			this.qcgPersonalHeading.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
			this.qcgPersonalHeading.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
			this.qcgPersonalHeading.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgPersonalHeading.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgPersonalHeading.Configuration.ShrinkHorizontal = true;
			this.qcgPersonalHeading.Configuration.StretchHorizontal = true;
			this.qcgPersonalHeading.Items.Add(this.qctPersonalHeading);
			// 
			// qctPersonalHeading
			// 
			this.qctPersonalHeading.ColorScheme.CompositeText.ColorReference = "@CompositeBackground1";
			this.qctPersonalHeading.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
			this.qctPersonalHeading.Title = "Personal information";
			// 
			// qcgPersonalDetails
			// 
			this.qcgPersonalDetails.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
			this.qcgPersonalDetails.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qcgPersonalDetails.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qcgPersonalDetails.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgPersonalDetails.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qcgPersonalDetails.Configuration.Margin = new Qios.DevSuite.Components.QMargin(5, 2, 0, 5);
			this.qcgPersonalDetails.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
			this.qcgPersonalDetails.Configuration.StretchHorizontal = true;
			this.qcgPersonalDetails.Items.Add(this.qcgName);
			this.qcgPersonalDetails.Items.Add(this.qcgDateOfBirth);
			this.qcgPersonalDetails.Items.Add(this.qcgPlaceOfBirth);
			this.qcgPersonalDetails.Items.Add(this.qcgGender);
			// 
			// qcgName
			// 
			this.qcgName.Configuration.ShrinkHorizontal = true;
			this.qcgName.Configuration.StretchHorizontal = true;
			this.qcgName.Items.Add(this.qctName);
			this.qcgName.Items.Add(this.qcibName);
			// 
			// qctName
			// 
			this.qctName.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctName.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctName.Title = "Name";
			// 
			// qcibName
			// 
			this.qcibName.Configuration.StretchHorizontal = true;
			this.qcibName.Configuration.StretchVertical = true;
			this.qcibName.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibName.InputBox
			// 
			this.qcibName.InputBox.Appearance.GradientAngle = 90;
			this.qcibName.InputBox.Appearance.GradientBlendPosition = 40;
			this.qcibName.InputBox.CueText = "Enter the name";
			this.qcibName.InputBox.Location = new System.Drawing.Point(109, 90);
			this.qcibName.InputBox.Name = "";
			this.qcibName.InputBox.Size = new System.Drawing.Size(174, 20);
			this.qcibName.InputBox.TabIndex = 0;
			// 
			// qcgDateOfBirth
			// 
			this.qcgDateOfBirth.Configuration.ShrinkHorizontal = true;
			this.qcgDateOfBirth.Configuration.StretchHorizontal = true;
			this.qcgDateOfBirth.Items.Add(this.qctDateOfBirth);
			this.qcgDateOfBirth.Items.Add(this.qcibDateOfBirth);
			// 
			// qctDateOfBirth
			// 
			this.qctDateOfBirth.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctDateOfBirth.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctDateOfBirth.Title = "Date of birth";
			// 
			// qcibDateOfBirth
			// 
			this.qcibDateOfBirth.Configuration.StretchHorizontal = true;
			this.qcibDateOfBirth.Configuration.StretchVertical = true;
			this.qcibDateOfBirth.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibDateOfBirth.InputBox
			// 
			this.qcibDateOfBirth.InputBox.CueText = "Enter the date of birth";
			this.qcibDateOfBirth.InputBox.Location = new System.Drawing.Point(109, 114);
			this.qcibDateOfBirth.InputBox.Name = "";
			this.qcibDateOfBirth.InputBox.Size = new System.Drawing.Size(174, 20);
			this.qcibDateOfBirth.InputBox.TabIndex = 1;
			// 
			// qcgPlaceOfBirth
			// 
			this.qcgPlaceOfBirth.Configuration.ShrinkHorizontal = true;
			this.qcgPlaceOfBirth.Configuration.StretchHorizontal = true;
			this.qcgPlaceOfBirth.Items.Add(this.qctPlaceOfBirth);
			this.qcgPlaceOfBirth.Items.Add(this.qcibPlaceOfBirth);
			// 
			// qctPlaceOfBirth
			// 
			this.qctPlaceOfBirth.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctPlaceOfBirth.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctPlaceOfBirth.Title = "Place of birth";
			// 
			// qcibPlaceOfBirth
			// 
			this.qcibPlaceOfBirth.Configuration.StretchHorizontal = true;
			this.qcibPlaceOfBirth.Configuration.StretchVertical = true;
			this.qcibPlaceOfBirth.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibPlaceOfBirth.InputBox
			// 
			this.qcibPlaceOfBirth.InputBox.CueText = "Enter place of birth";
			this.qcibPlaceOfBirth.InputBox.Location = new System.Drawing.Point(109, 138);
			this.qcibPlaceOfBirth.InputBox.Name = "";
			this.qcibPlaceOfBirth.InputBox.Size = new System.Drawing.Size(174, 20);
			this.qcibPlaceOfBirth.InputBox.TabIndex = 2;
			// 
			// qcgGender
			// 
			this.qcgGender.Configuration.ShrinkHorizontal = true;
			this.qcgGender.Configuration.StretchHorizontal = true;
			this.qcgGender.Items.Add(this.qctGender);
			this.qcgGender.Items.Add(this.qcibGender);
			// 
			// qctGender
			// 
			this.qctGender.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctGender.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctGender.Title = "Gender";
			// 
			// qcibGender
			// 
			this.qcibGender.Configuration.StretchHorizontal = true;
			this.qcibGender.Configuration.StretchVertical = true;
			this.qcibGender.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibGender.InputBox
			// 
			this.qcibGender.InputBox.Configuration.InputBoxButtonDrawHot = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
			this.qcibGender.InputBox.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
			this.qcibGender.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDownList;
			this.qcibGender.InputBox.CueText = "Select the gender";
			this.qcibGender.InputBox.Items.AddRange(new object[] {
																	 "",
																	 "Male",
																	 "Female",
																	 "Unknown"});
			this.qcibGender.InputBox.Location = new System.Drawing.Point(109, 162);
			this.qcibGender.InputBox.Name = "";
			this.qcibGender.InputBox.SelectedIndex = 0;
			this.qcibGender.InputBox.SelectedItem = "";
			this.qcibGender.InputBox.Size = new System.Drawing.Size(174, 20);
			this.qcibGender.InputBox.TabIndex = 3;
			// 
			// qcgLocationInformation
			// 
			this.qcgLocationInformation.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgLocationInformation.Configuration.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 3, 1);
			this.qcgLocationInformation.Configuration.StretchHorizontal = true;
			this.qcgLocationInformation.Items.Add(this.qcgLocationHeader);
			this.qcgLocationInformation.Items.Add(this.qcgLocationDetails);
			// 
			// qcgLocationHeader
			// 
			this.qcgLocationHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
			this.qcgLocationHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
			this.qcgLocationHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
			this.qcgLocationHeader.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgLocationHeader.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgLocationHeader.Configuration.ShrinkHorizontal = true;
			this.qcgLocationHeader.Configuration.StretchHorizontal = true;
			this.qcgLocationHeader.Items.Add(this.qctLocationHeader);
			// 
			// qctLocationHeader
			// 
			this.qctLocationHeader.ColorScheme.CompositeText.ColorReference = "@CompositeBackground1";
			this.qctLocationHeader.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
			this.qctLocationHeader.Title = "Location information";
			// 
			// qcgLocationDetails
			// 
			this.qcgLocationDetails.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
			this.qcgLocationDetails.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qcgLocationDetails.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qcgLocationDetails.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgLocationDetails.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qcgLocationDetails.Configuration.Margin = new Qios.DevSuite.Components.QMargin(5, 2, 0, 5);
			this.qcgLocationDetails.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
			this.qcgLocationDetails.Configuration.StretchHorizontal = true;
			this.qcgLocationDetails.Items.Add(this.qcgStreet);
			this.qcgLocationDetails.Items.Add(this.qcgZipcode);
			this.qcgLocationDetails.Items.Add(this.qcgState);
			this.qcgLocationDetails.Items.Add(this.qcgCountry);
			// 
			// qcgStreet
			// 
			this.qcgStreet.Configuration.ShrinkHorizontal = true;
			this.qcgStreet.Configuration.StretchHorizontal = true;
			this.qcgStreet.Items.Add(this.qctStreet);
			this.qcgStreet.Items.Add(this.qcibStreet);
			// 
			// qctStreet
			// 
			this.qctStreet.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctStreet.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctStreet.Title = "Street Address";
			// 
			// qcibStreet
			// 
			this.qcibStreet.Configuration.StretchHorizontal = true;
			this.qcibStreet.Configuration.StretchVertical = true;
			this.qcibStreet.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibStreet.InputBox
			// 
			this.qcibStreet.InputBox.CueText = "Enter the street name";
			this.qcibStreet.InputBox.Location = new System.Drawing.Point(116, 219);
			this.qcibStreet.InputBox.Name = "";
			this.qcibStreet.InputBox.Size = new System.Drawing.Size(167, 20);
			this.qcibStreet.InputBox.TabIndex = 4;
			// 
			// qcgZipcode
			// 
			this.qcgZipcode.Configuration.ShrinkHorizontal = true;
			this.qcgZipcode.Configuration.StretchHorizontal = true;
			this.qcgZipcode.Items.Add(this.qctZipcode);
			this.qcgZipcode.Items.Add(this.qcibZipcode);
			// 
			// qctZipcode
			// 
			this.qctZipcode.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctZipcode.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctZipcode.Title = "Zip code";
			// 
			// qcibZipcode
			// 
			this.qcibZipcode.Configuration.StretchHorizontal = true;
			this.qcibZipcode.Configuration.StretchVertical = true;
			this.qcibZipcode.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibZipcode.InputBox
			// 
			this.qcibZipcode.InputBox.CueText = "Enter the zip code";
			this.qcibZipcode.InputBox.Location = new System.Drawing.Point(116, 243);
			this.qcibZipcode.InputBox.Name = "";
			this.qcibZipcode.InputBox.Size = new System.Drawing.Size(167, 20);
			this.qcibZipcode.InputBox.TabIndex = 5;
			// 
			// qcgState
			// 
			this.qcgState.Configuration.ShrinkHorizontal = true;
			this.qcgState.Configuration.StretchHorizontal = true;
			this.qcgState.Items.Add(this.qctState);
			this.qcgState.Items.Add(this.qcibState);
			// 
			// qctState
			// 
			this.qctState.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctState.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctState.Title = "State";
			// 
			// qcibState
			// 
			this.qcibState.Configuration.StretchHorizontal = true;
			this.qcibState.Configuration.StretchVertical = true;
			this.qcibState.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibState.InputBox
			// 
			this.qcibState.InputBox.CueText = "Enter the state";
			this.qcibState.InputBox.Location = new System.Drawing.Point(116, 267);
			this.qcibState.InputBox.Name = "";
			this.qcibState.InputBox.Size = new System.Drawing.Size(167, 20);
			this.qcibState.InputBox.TabIndex = 6;
			// 
			// qcgCountry
			// 
			this.qcgCountry.Configuration.ShrinkHorizontal = true;
			this.qcgCountry.Configuration.StretchHorizontal = true;
			this.qcgCountry.Items.Add(this.qctCountry);
			this.qcgCountry.Items.Add(this.qcibCountry);
			// 
			// qctCountry
			// 
			this.qctCountry.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctCountry.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctCountry.Title = "Country";
			// 
			// qcibCountry
			// 
			this.qcibCountry.Configuration.StretchHorizontal = true;
			this.qcibCountry.Configuration.StretchVertical = true;
			this.qcibCountry.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibCountry.InputBox
			// 
			this.qcibCountry.InputBox.Configuration.InputBoxButtonDrawHot = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
			this.qcibCountry.InputBox.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
			this.qcibCountry.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDownList;
			this.qcibCountry.InputBox.CueText = "Select the country";
			this.qcibCountry.InputBox.Items.AddRange(new object[] {
																	  "",
																	  "Belgium",
																	  "France",
																	  "Netherlands, The",
																	  "United States"});
			this.qcibCountry.InputBox.Location = new System.Drawing.Point(116, 291);
			this.qcibCountry.InputBox.Name = "";
			this.qcibCountry.InputBox.SelectedIndex = 0;
			this.qcibCountry.InputBox.SelectedItem = "";
			this.qcibCountry.InputBox.Size = new System.Drawing.Size(167, 20);
			this.qcibCountry.InputBox.TabIndex = 7;
			// 
			// qcgContentRight
			// 
			this.qcgContentRight.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgContentRight.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgContentRight.Configuration.StretchHorizontal = true;
			this.qcgContentRight.Items.Add(this.qcgContactInformation);
			this.qcgContentRight.Items.Add(this.qcgAdditionalInformation);
			// 
			// qcgContactInformation
			// 
			this.qcgContactInformation.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgContactInformation.Configuration.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 3, 1);
			this.qcgContactInformation.Configuration.StretchHorizontal = true;
			this.qcgContactInformation.Items.Add(this.qcgContactHeader);
			this.qcgContactInformation.Items.Add(this.qCompositeGroup3);
			// 
			// qcgContactHeader
			// 
			this.qcgContactHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
			this.qcgContactHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
			this.qcgContactHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
			this.qcgContactHeader.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgContactHeader.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgContactHeader.Configuration.StretchHorizontal = true;
			this.qcgContactHeader.Items.Add(this.qctContactHeader);
			// 
			// qctContactHeader
			// 
			this.qctContactHeader.ColorScheme.CompositeText.ColorReference = "@CompositeBackground1";
			this.qctContactHeader.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
			this.qctContactHeader.Title = "Contact information";
			// 
			// qCompositeGroup3
			// 
			this.qCompositeGroup3.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
			this.qCompositeGroup3.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qCompositeGroup3.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qCompositeGroup3.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeGroup3.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.qCompositeGroup3.Configuration.Margin = new Qios.DevSuite.Components.QMargin(5, 2, 0, 5);
			this.qCompositeGroup3.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
			this.qCompositeGroup3.Configuration.StretchHorizontal = true;
			this.qCompositeGroup3.Items.Add(this.qcgEmail);
			this.qCompositeGroup3.Items.Add(this.qcgPhone);
			this.qCompositeGroup3.Items.Add(this.qcgFax);
			// 
			// qcgEmail
			// 
			this.qcgEmail.Configuration.ShrinkHorizontal = true;
			this.qcgEmail.Configuration.StretchHorizontal = true;
			this.qcgEmail.Items.Add(this.qctEmail);
			this.qcgEmail.Items.Add(this.qcibEmail);
			// 
			// qctEmail
			// 
			this.qctEmail.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctEmail.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctEmail.Title = "E-mail";
			// 
			// qcibEmail
			// 
			this.qcibEmail.Configuration.StretchHorizontal = true;
			this.qcibEmail.Configuration.StretchVertical = true;
			this.qcibEmail.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibEmail.InputBox
			// 
			this.qcibEmail.InputBox.CueText = "Enter the e-mail address";
			this.qcibEmail.InputBox.Location = new System.Drawing.Point(370, 90);
			this.qcibEmail.InputBox.Name = "";
			this.qcibEmail.InputBox.Size = new System.Drawing.Size(185, 20);
			this.qcibEmail.InputBox.TabIndex = 8;
			// 
			// qcgPhone
			// 
			this.qcgPhone.Configuration.ShrinkHorizontal = true;
			this.qcgPhone.Configuration.StretchHorizontal = true;
			this.qcgPhone.Items.Add(this.qctPhone);
			this.qcgPhone.Items.Add(this.qcibPhone);
			// 
			// qctPhone
			// 
			this.qctPhone.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctPhone.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctPhone.Title = "Phone";
			// 
			// qcibPhone
			// 
			this.qcibPhone.Configuration.StretchHorizontal = true;
			this.qcibPhone.Configuration.StretchVertical = true;
			this.qcibPhone.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibPhone.InputBox
			// 
			this.qcibPhone.InputBox.CueText = "Enter the phone number";
			this.qcibPhone.InputBox.Location = new System.Drawing.Point(370, 114);
			this.qcibPhone.InputBox.Name = "";
			this.qcibPhone.InputBox.Size = new System.Drawing.Size(185, 20);
			this.qcibPhone.InputBox.TabIndex = 9;
			// 
			// qcgFax
			// 
			this.qcgFax.Configuration.ShrinkHorizontal = true;
			this.qcgFax.Configuration.StretchHorizontal = true;
			this.qcgFax.Items.Add(this.qctFax);
			this.qcgFax.Items.Add(this.qcibFax);
			// 
			// qctFax
			// 
			this.qctFax.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctFax.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctFax.Title = "Fax";
			// 
			// qcibFax
			// 
			this.qcibFax.Configuration.StretchHorizontal = true;
			this.qcibFax.Configuration.StretchVertical = true;
			this.qcibFax.ControlSize = new System.Drawing.Size(100, 20);
			// 
			// qcibFax.InputBox
			// 
			this.qcibFax.InputBox.CueText = "Enter the fax number";
			this.qcibFax.InputBox.Location = new System.Drawing.Point(370, 138);
			this.qcibFax.InputBox.Name = "";
			this.qcibFax.InputBox.Size = new System.Drawing.Size(185, 20);
			this.qcibFax.InputBox.TabIndex = 10;
			// 
			// qcgAdditionalInformation
			// 
			this.qcgAdditionalInformation.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgAdditionalInformation.Configuration.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 3, 1);
			this.qcgAdditionalInformation.Configuration.StretchHorizontal = true;
			this.qcgAdditionalInformation.Items.Add(this.qcgAdditionalHeader);
			this.qcgAdditionalInformation.Items.Add(this.qCompositeGroup4);
			// 
			// qcgAdditionalHeader
			// 
			this.qcgAdditionalHeader.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeItemPressedBackground1";
			this.qcgAdditionalHeader.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeItemPressedBackground2";
			this.qcgAdditionalHeader.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeItemPressedBorder";
			this.qcgAdditionalHeader.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgAdditionalHeader.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgAdditionalHeader.Configuration.StretchHorizontal = true;
			this.qcgAdditionalHeader.Items.Add(this.qctAdditionalHeader);
			// 
			// qctAdditionalHeader
			// 
			this.qctAdditionalHeader.ColorScheme.CompositeText.ColorReference = "@CompositeBackground1";
			this.qctAdditionalHeader.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, -1F);
			this.qctAdditionalHeader.Title = "Additional information";
			// 
			// qCompositeGroup4
			// 
			this.qCompositeGroup4.ColorScheme.CompositeGroupBackground1.ColorReference = "@RibbonPanelBackground1";
			this.qCompositeGroup4.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qCompositeGroup4.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
			this.qCompositeGroup4.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qCompositeGroup4.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Linear;
			this.qCompositeGroup4.Configuration.Margin = new Qios.DevSuite.Components.QMargin(5, 2, 0, 5);
			this.qCompositeGroup4.Configuration.Padding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
			this.qCompositeGroup4.Configuration.StretchHorizontal = true;
			this.qCompositeGroup4.Items.Add(this.qcgGraduationYear);
			this.qCompositeGroup4.Items.Add(this.qcgRemarks);
			// 
			// qcgGraduationYear
			// 
			this.qcgGraduationYear.Configuration.ShrinkHorizontal = true;
			this.qcgGraduationYear.Configuration.StretchHorizontal = true;
			this.qcgGraduationYear.Items.Add(this.qctGraduationYear);
			this.qcgGraduationYear.Items.Add(this.qcibGraduationYear);
			// 
			// qctGraduationYear
			// 
			this.qctGraduationYear.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctGraduationYear.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctGraduationYear.Title = "Graduation year";
			// 
			// qcibGraduationYear
			// 
			this.qcibGraduationYear.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qcibGraduationYear.ControlSize = new System.Drawing.Size(70, 20);
			// 
			// qcibGraduationYear.InputBox
			// 
			this.qcibGraduationYear.InputBox.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
			this.qcibGraduationYear.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.UpDown;
			this.qcibGraduationYear.InputBox.CueText = "";
			this.qcibGraduationYear.InputBox.FormatString = "0000";
			this.qcibGraduationYear.InputBox.Location = new System.Drawing.Point(485, 195);
			this.qcibGraduationYear.InputBox.MaximumValue = new System.Decimal(new int[] {
																							 2100,
																							 0,
																							 0,
																							 0});
			this.qcibGraduationYear.InputBox.MinimumValue = new System.Decimal(new int[] {
																							 1950,
																							 0,
																							 0,
																							 0});
			this.qcibGraduationYear.InputBox.Name = "";
			this.qcibGraduationYear.InputBox.NumericValue = new System.Decimal(new int[] {
																							 1950,
																							 0,
																							 0,
																							 0});
			this.qcibGraduationYear.InputBox.Size = new System.Drawing.Size(70, 20);
			this.qcibGraduationYear.InputBox.TabIndex = 11;
			this.qcibGraduationYear.InputBox.Text = "1950";
			this.qcibGraduationYear.InputBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// qcgRemarks
			// 
			this.qcgRemarks.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgRemarks.Configuration.ShrinkHorizontal = true;
			this.qcgRemarks.Configuration.StretchHorizontal = true;
			this.qcgRemarks.Items.Add(this.qctRemarks);
			this.qcgRemarks.Items.Add(this.qCompositeItemInputBox2);
			// 
			// qctRemarks
			// 
			this.qctRemarks.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 20);
			this.qctRemarks.Title = "Remarks";
			// 
			// qCompositeItemInputBox2
			// 
			this.qCompositeItemInputBox2.Configuration.StretchHorizontal = true;
			this.qCompositeItemInputBox2.Configuration.StretchVertical = true;
			this.qCompositeItemInputBox2.ControlSize = new System.Drawing.Size(100, 77);
			// 
			// qCompositeItemInputBox2.InputBox
			// 
			this.qCompositeItemInputBox2.InputBox.Configuration.InputBoxTextPadding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.qCompositeItemInputBox2.InputBox.CueText = "Enter any additional remarks here";
			this.qCompositeItemInputBox2.InputBox.Location = new System.Drawing.Point(315, 234);
			this.qCompositeItemInputBox2.InputBox.Multiline = true;
			this.qCompositeItemInputBox2.InputBox.Name = "";
			this.qCompositeItemInputBox2.InputBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.qCompositeItemInputBox2.InputBox.Size = new System.Drawing.Size(240, 77);
			this.qCompositeItemInputBox2.InputBox.TabIndex = 12;
			// 
			// qcgFooter
			// 
			this.qcgFooter.Configuration.ShrinkHorizontal = true;
			this.qcgFooter.Configuration.StretchHorizontal = true;
			this.qcgFooter.Items.Add(this.qcbAddCustomerSave);
			this.qcgFooter.Items.Add(this.qcbAddCustomerCancel);
			// 
			// qcbAddCustomerSave
			// 
			this.qcbAddCustomerSave.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qcbAddCustomerSave.Title = "Save";
			// 
			// qcbAddCustomerCancel
			// 
			this.qcbAddCustomerCancel.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qcbAddCustomerCancel.Title = "Cancel";
			// 
			// qsDetailsGroup
			// 
			this.qsDetailsGroup.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedContent;
			this.qsDetailsGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 20F, 2F, 20F, 0F, 18F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDetailsGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 16F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsDetailsGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsDetailsGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDetailsGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 16F, 100F, 18F, 98F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsDetailsGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			// 
			// QtpAddCustomer
			// 
			this.Controls.Add(this.qccAddCustomer);
			this.DockPadding.All = 5;
			this.Name = "QtpAddCustomer";
			this.Size = new System.Drawing.Size(584, 416);
			((System.ComponentModel.ISupportInitialize)(this.qccAddCustomer)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void qccAddCustomer_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}
	}
}
