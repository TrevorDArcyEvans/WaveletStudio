using System;
using System.Reflection;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using Qios.DevSuite.Components;

using Qios.DevSuite.DemoZone.Shared;

namespace Qios.DevSuite.DemoZone.Samples.Composite
{
	/// <summary>
	/// Summary description for QtpAddCustomer.
	/// </summary>
	public class QccVerticalBar : Qios.DevSuite.Components.QCompositeControl
	{
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory1;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory1Header;
		private Qios.DevSuite.Components.QCompositeText qctCategory1Header;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory2;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory2Header;
		private Qios.DevSuite.Components.QCompositeText qctCategory2Header;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory3;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory3Header;
		private Qios.DevSuite.Components.QCompositeText qctCategory3Header;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory1Items;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem3;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem2;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem1;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory2Items;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem5;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem4;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem6;
		private Qios.DevSuite.Components.QCompositeGroup qcgCategory3Items;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem8;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem7;
		private Qios.DevSuite.Components.QCompositeLargeMenuItem qcmiItem9;
		private Qios.DevSuite.Components.QCompositeItem qciExpand1;
		private Qios.DevSuite.Components.QCompositeImage qciExpand1Image;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem1;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage1;
		private Qios.DevSuite.Components.QCompositeItem qCompositeItem2;
		private Qios.DevSuite.Components.QCompositeImage qCompositeImage2;
		private Qios.DevSuite.Components.QShape qsCategory1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QccVerticalBar()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//Fill the collapse information.
			this.FillCollapseInformation();
		}

		/// <summary>
		/// Fills the root parts with collapse information.
		/// </summary>
		private void FillCollapseInformation()
		{
			//Iterate through the rootparts and set the userrefence to the collapse information.
			for (int i = 0; i < this.Items.Count; i++)
			{
				QCompositeItemBase tmp_oItem = this.Items[i] as QCompositeItemBase;
				tmp_oItem.UserReference = new CategoryCollapseInfo(tmp_oItem);
			}
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ChildCompositeColorScheme
		{
			get { return base.ChildCompositeColorScheme; }
			set { base.ChildCompositeColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration ChildCompositeConfiguration
		{
			get { return base.ChildCompositeConfiguration; }
			set { base.ChildCompositeConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeWindowConfiguration ChildWindowConfiguration
		{
			get { return base.ChildWindowConfiguration; }
			set { base.ChildWindowConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QColorScheme ColorScheme
		{
			get { return base.ColorScheme; }
			set { base.ColorScheme = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QCompositeConfiguration Configuration
		{
			get { return base.Configuration; }
			set { base.Configuration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QToolTipConfiguration ToolTipConfiguration
		{
			get { return base.ToolTipConfiguration; }
			set { base.ToolTipConfiguration = value; }
		}

		/// <summary>
		/// Overridden. We don't want this property to be serialized (again) when placed on a Form.
		/// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public override QPartCollection Items
		{
			get { return base.Items; }
		}

		/// <summary>
		/// Overridden. We don't want the designer be able to add Items (because they won't be serialized) when this Control
		/// is placed on a Form.
		/// </summary>
		protected override IList AssociatedComponents
		{
			get { return null; }
		}


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QccVerticalBar));
			this.qcgCategory1 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgCategory1Header = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCategory1Header = new Qios.DevSuite.Components.QCompositeText();
			this.qciExpand1 = new Qios.DevSuite.Components.QCompositeItem();
			this.qciExpand1Image = new Qios.DevSuite.Components.QCompositeImage();
			this.qcgCategory1Items = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiItem3 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem2 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem1 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcgCategory2 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgCategory2Header = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCategory2Header = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem1 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage1 = new Qios.DevSuite.Components.QCompositeImage();
			this.qcgCategory2Items = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiItem5 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem4 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem6 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcgCategory3 = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgCategory3Header = new Qios.DevSuite.Components.QCompositeGroup();
			this.qctCategory3Header = new Qios.DevSuite.Components.QCompositeText();
			this.qCompositeItem2 = new Qios.DevSuite.Components.QCompositeItem();
			this.qCompositeImage2 = new Qios.DevSuite.Components.QCompositeImage();
			this.qcgCategory3Items = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcmiItem8 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem7 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qcmiItem9 = new Qios.DevSuite.Components.QCompositeLargeMenuItem();
			this.qsCategory1 = new Qios.DevSuite.Components.QShape();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// qcgCategory1
			// 
			this.qcgCategory1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory1.Configuration.ShrinkHorizontal = true;
			this.qcgCategory1.Configuration.StretchHorizontal = true;
			this.qcgCategory1.Items.Add(this.qcgCategory1Header);
			this.qcgCategory1.Items.Add(this.qcgCategory1Items);
			// 
			// qcgCategory1Header
			// 
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory1Header.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory1Header.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgCategory1Header.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgCategory1Header.Configuration.Appearance.Shape = new Qios.DevSuite.Components.QShape(Qios.DevSuite.Components.QBaseShapeType.RoundedContent);
			this.qcgCategory1Header.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgCategory1Header.Configuration.ShrinkHorizontal = true;
			this.qcgCategory1Header.Configuration.StretchHorizontal = true;
			this.qcgCategory1Header.Items.Add(this.qctCategory1Header);
			this.qcgCategory1Header.Items.Add(this.qciExpand1);
			// 
			// qctCategory1Header
			// 
			this.qctCategory1Header.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctCategory1Header.Title = "Category 1";
			// 
			// qciExpand1
			// 
			this.qciExpand1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qciExpand1.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qciExpand1.ItemName = "CollapseToggleItem";
			this.qciExpand1.Items.Add(this.qciExpand1Image);
			// 
			// qciExpand1Image
			// 
			this.qciExpand1Image.Image = ((System.Drawing.Image)(resources.GetObject("qciExpand1Image.Image")));
			// 
			// qcgCategory1Items
			// 
			this.qcgCategory1Items.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory1Items.Configuration.ShrinkHorizontal = true;
			this.qcgCategory1Items.Configuration.StretchHorizontal = true;
			this.qcgCategory1Items.ItemName = "CollapsableItem";
			this.qcgCategory1Items.Items.Add(this.qcmiItem3);
			this.qcgCategory1Items.Items.Add(this.qcmiItem2);
			this.qcgCategory1Items.Items.Add(this.qcmiItem1);
			// 
			// qcmiItem3
			// 
			this.qcmiItem3.Description = "This is the description for item 3";
			this.qcmiItem3.HotkeyText = "3";
			this.qcmiItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem3.Icon")));
			this.qcmiItem3.Title = "Item &3";
			// 
			// qcmiItem2
			// 
			this.qcmiItem2.Description = "This is the description for item 2";
			this.qcmiItem2.HotkeyText = "2";
			this.qcmiItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem2.Icon")));
			this.qcmiItem2.Title = "Item &2";
			// 
			// qcmiItem1
			// 
			this.qcmiItem1.Description = "This is the description for item 1";
			this.qcmiItem1.HotkeyText = "1";
			this.qcmiItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem1.Icon")));
			this.qcmiItem1.Title = "Item &1";
			// 
			// qcgCategory2
			// 
			this.qcgCategory2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory2.Configuration.ShrinkHorizontal = true;
			this.qcgCategory2.Configuration.StretchHorizontal = true;
			this.qcgCategory2.Items.Add(this.qcgCategory2Header);
			this.qcgCategory2.Items.Add(this.qcgCategory2Items);
			// 
			// qcgCategory2Header
			// 
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory2Header.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory2Header.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgCategory2Header.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgCategory2Header.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgCategory2Header.Configuration.ShrinkHorizontal = true;
			this.qcgCategory2Header.Configuration.StretchHorizontal = true;
			this.qcgCategory2Header.Items.Add(this.qctCategory2Header);
			this.qcgCategory2Header.Items.Add(this.qCompositeItem1);
			// 
			// qctCategory2Header
			// 
			this.qctCategory2Header.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctCategory2Header.Title = "Category 2";
			// 
			// qCompositeItem1
			// 
			this.qCompositeItem1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qCompositeItem1.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qCompositeItem1.ItemName = "CollapseToggleItem";
			this.qCompositeItem1.Items.Add(this.qCompositeImage1);
			// 
			// qCompositeImage1
			// 
			this.qCompositeImage1.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage1.Image")));
			// 
			// qcgCategory2Items
			// 
			this.qcgCategory2Items.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory2Items.Configuration.ShrinkHorizontal = true;
			this.qcgCategory2Items.Configuration.StretchHorizontal = true;
			this.qcgCategory2Items.ItemName = "CollapsableItem";
			this.qcgCategory2Items.Items.Add(this.qcmiItem5);
			this.qcgCategory2Items.Items.Add(this.qcmiItem4);
			this.qcgCategory2Items.Items.Add(this.qcmiItem6);
			// 
			// qcmiItem5
			// 
			this.qcmiItem5.Description = "This is the description for item 5";
			this.qcmiItem5.HotkeyText = "5";
			this.qcmiItem5.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem5.Icon")));
			this.qcmiItem5.Title = "Item &5";
			// 
			// qcmiItem4
			// 
			this.qcmiItem4.Description = "This is the description for item 4";
			this.qcmiItem4.HotkeyText = "4";
			this.qcmiItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem4.Icon")));
			this.qcmiItem4.Title = "Item &4";
			// 
			// qcmiItem6
			// 
			this.qcmiItem6.Description = "This is the description for item 6";
			this.qcmiItem6.HotkeyText = "6";
			this.qcmiItem6.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem6.Icon")));
			this.qcmiItem6.Title = "Item &6";
			// 
			// qcgCategory3
			// 
			this.qcgCategory3.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory3.Configuration.ShrinkHorizontal = true;
			this.qcgCategory3.Configuration.StretchHorizontal = true;
			this.qcgCategory3.Items.Add(this.qcgCategory3Header);
			this.qcgCategory3.Items.Add(this.qcgCategory3Items);
			// 
			// qcgCategory3Header
			// 
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(221)), ((System.Byte)(125))), false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground2.SetColor("Default", System.Drawing.Color.White, false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
			this.qcgCategory3Header.ColorScheme.CompositeGroupBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
			this.qcgCategory3Header.Configuration.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
			this.qcgCategory3Header.Configuration.Appearance.MetallicInnerGlowWidth = 1;
			this.qcgCategory3Header.Configuration.Padding = new Qios.DevSuite.Components.QPadding(3, 3, 3, 3);
			this.qcgCategory3Header.Configuration.ShrinkHorizontal = true;
			this.qcgCategory3Header.Configuration.StretchHorizontal = true;
			this.qcgCategory3Header.Items.Add(this.qctCategory3Header);
			this.qcgCategory3Header.Items.Add(this.qCompositeItem2);
			// 
			// qctCategory3Header
			// 
			this.qctCategory3Header.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qctCategory3Header.Title = "Category 3";
			// 
			// qCompositeItem2
			// 
			this.qCompositeItem2.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qCompositeItem2.Configuration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Centered;
			this.qCompositeItem2.ItemName = "CollapseToggleItem";
			this.qCompositeItem2.Items.Add(this.qCompositeImage2);
			// 
			// qCompositeImage2
			// 
			this.qCompositeImage2.Image = ((System.Drawing.Image)(resources.GetObject("qCompositeImage2.Image")));
			// 
			// qcgCategory3Items
			// 
			this.qcgCategory3Items.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.qcgCategory3Items.Configuration.ShrinkHorizontal = true;
			this.qcgCategory3Items.Configuration.StretchHorizontal = true;
			this.qcgCategory3Items.ItemName = "CollapsableItem";
			this.qcgCategory3Items.Items.Add(this.qcmiItem8);
			this.qcgCategory3Items.Items.Add(this.qcmiItem7);
			this.qcgCategory3Items.Items.Add(this.qcmiItem9);
			// 
			// qcmiItem8
			// 
			this.qcmiItem8.Description = "This is the description for item 8";
			this.qcmiItem8.HotkeyText = "8";
			this.qcmiItem8.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem8.Icon")));
			this.qcmiItem8.Title = "Item &8";
			// 
			// qcmiItem7
			// 
			this.qcmiItem7.Description = "This is the description for item 7";
			this.qcmiItem7.HotkeyText = "7";
			this.qcmiItem7.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem7.Icon")));
			this.qcmiItem7.Title = "Item &7";
			// 
			// qcmiItem9
			// 
			this.qcmiItem9.Description = "This is the description for item 9";
			this.qcmiItem9.HotkeyText = "9";
			this.qcmiItem9.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiItem9.Icon")));
			this.qcmiItem9.Title = "Item &9";
			// 
			// qsCategory1
			// 
			this.qsCategory1.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedContent2;
			this.qsCategory1.ContentBounds = new System.Drawing.Rectangle(0, 9, 100, 33);
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 50F, 0F, 50F, 0F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 46F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 4F, 0F, 0F, 0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 0F, 5F, 14F, 47F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 0F, 100F, 0F, 100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 46F, 100F, 50F, 100F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsCategory1.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 50F, 65F, 50F, 5F, 34F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			this.qsCategory1.Size = new System.Drawing.Size(100, 50);
			// 
			// QccVerticalBar
			// 
			this.ColorScheme.CompositeBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.ColorScheme.CompositeBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((System.Byte)(182)), ((System.Byte)(230)), ((System.Byte)(200))), false);
			this.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.Configuration.Margin = new Qios.DevSuite.Components.QMargin(0, 0, 0, 5);
			this.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.Items.Add(this.qcgCategory1);
			this.Items.Add(this.qcgCategory2);
			this.Items.Add(this.qcgCategory3);
			this.Name = "QccVerticalBar";
			this.Size = new System.Drawing.Size(152, 496);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion

		/// <summary>
		/// Defines collapse information for expanding collapsing this composite.
		/// </summary>
		private class CategoryCollapseInfo
		{
			private static Image m_oUpImage;
			private static Image m_oDownImage;

			/// <summary>
			/// Indicatse whether this item is collapsed.
			/// </summary>
			private bool m_bCollapsed;

			/// <summary>
			/// Contains the owner composite group.
			/// </summary>
			private QCompositeItemBase m_oOwner;

			/// <summary>
			/// Contains the button that is pressed for collasing expanding.
			/// </summary>
			private QCompositeItemBase m_oCollapseToggleItem;

			/// <summary>
			/// Contains the image part of the button.
			/// </summary>
			private QCompositeImage m_oCollapsableToggleItemImage;

			/// <summary>
			/// Contains the group that is collapsed or expanded.
			/// </summary>
			private QCompositeItemBase m_oCollapsableItem;

			/// <summary>
			/// Constructor.
			/// </summary>
			/// <param name="owner"></param>
			public CategoryCollapseInfo(QCompositeItemBase owner)
			{
				if (m_oDownImage == null)
				{
					m_oDownImage = new Bitmap(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Images.SmallArrowDownMask.png"));
					m_oUpImage = new Bitmap(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Images.SmallArrowUpMask.png"));
				}

				//Set the owner.
				this.m_oOwner = owner;

				//Find the required child items.
				this.m_oCollapseToggleItem = this.m_oOwner.Items.FindPart("CollapseToggleItem") as QCompositeItemBase;

				//Find the group that is collapsable
				this.m_oCollapsableItem = this.m_oOwner.Items.FindPart("CollapsableItem") as QCompositeItemBase;

				if (this.m_oCollapseToggleItem != null)
				{
					//Find the image of the button.
					this.m_oCollapsableToggleItemImage = 
						(((this.m_oCollapseToggleItem.Parts != null) && (this.m_oCollapseToggleItem.Parts.Count > 0)) ?
						this.m_oCollapseToggleItem.Parts[0] : null) as QCompositeImage;

					//Attach an eventhandler.
					this.m_oCollapseToggleItem.ItemActivated += new QCompositeEventHandler(CollapseToggleItem_ItemActivated);
				}
			}

			/// <summary>
			/// Gets or sets whether the owner is expanded or collapsed.
			/// </summary>
			public  bool Collapsed
			{
				get { return m_bCollapsed; }
				set
				{
					//Return if it is the same.
					if (m_bCollapsed == value) return;

					//Set the value.
					m_bCollapsed = value;

					//Return if the owner is empty.
					if ((this.m_oOwner == null) || (this.m_oOwner.Parts == null)) return;

					//Suspend changes.
					this.m_oOwner.Parts.SuspendChangeNotification();

					//Change visibility
					if (m_oCollapsableItem != null)
					{
						m_oCollapsableItem.Visible = (!value);
					}

					//Change the image.
					if (m_oCollapseToggleItem != null)
					{
						m_oCollapsableToggleItemImage.Image = value ? m_oDownImage : m_oUpImage;
					}

					//Resume changed.
					this.m_oOwner.Parts.ResumeChangeNotification(true);
				}
			}

			/// <summary>
			/// Handles the press of the button
			/// </summary>
			private void CollapseToggleItem_ItemActivated(object sender, QCompositeEventArgs e)
			{
				//Toggle collapsed
				this.Collapsed = (!this.Collapsed);
			}
		}
	}

}
