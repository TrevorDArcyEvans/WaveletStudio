using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using Qios.DevSuite.DemoZone.Misc;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone.Samples.CustomRibbon
{
	/// <summary>
	/// Summary description for Form3.
	/// </summary>
	[SelectorDisplay(
		 60,
		 "Custom Ribbon Sample",
		 "Shows a custom configured QRibbon. Several items, shapes, fonts and colors are changed from the default in this sample.")]
	public class FrmMain : QRibbonForm
	{
		private QCompositeEventListener m_oEventListener1;
		private QCompositeEventListener m_oEventListener2;

		private Qios.DevSuite.Components.Ribbon.QRibbon qRibbon1;
		private Qios.DevSuite.Components.Ribbon.QRibbonPanel qrpClipboard;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriPaste;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPaste;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPasteSpecial;
		private Qios.DevSuite.Components.QCompositeSeparator qcsPaste01;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPasteCustom;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPasteCustom01;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiPasteCustom02;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem1;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem2;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemGroup qrgClipboardOther;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriCut;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriCopy;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriFormatPainter;
		private Qios.DevSuite.Components.Ribbon.QRibbonPanel qrpFont;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemGroup qrigFont1;
		private Qios.DevSuite.Components.Ribbon.QRibbonInputBoxItem qriibFontSize;
		private Qios.DevSuite.Components.Ribbon.QRibbonInputBoxItem qriibFontFamily;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemBar qribFontSizes;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriFontIncrease;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriFontDecrease;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemBar qribClearFormatting;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriClearFormatting;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemGroup qrigFont2;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemBar qribFontStyle;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriBold;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriItalic;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriUnderline;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiUnderline1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriStrikeThrough;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriSubscript;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriChangeCase;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiChangeCase1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemBar qribFontColor;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriTextHighlightColor;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiHighLight1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriTextColor;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiTextColor1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriReplace;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriGoTo;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriSelect;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem3;
		private Qios.DevSuite.Components.Ribbon.QRibbonPanel qrpEditing;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriFind;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemGroup qrgEditing;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem2;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem4;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qrpHome;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qrpInsert;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qrpPageLayout;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qrpReferences;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qrpMailings;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qriSuperscript;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPage1;
		private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPage2;
		private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanel1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem5;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemGroup qRibbonItemGroup1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem6;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem7;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem8;
		private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanel2;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem9;
		private Qios.DevSuite.Components.Ribbon.QRibbonItemGroup qRibbonItemGroup2;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem10;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem11;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem12;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem3;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem4;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem5;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem6;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem7;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem8;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem9;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem10;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem11;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem12;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem13;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem14;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem15;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem16;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem17;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem18;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem19;
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qRibbonCaption2;
		private Qios.DevSuite.Components.Ribbon.QRibbonLaunchBar qRibbonLaunchBar1;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem17;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem18;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem19;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem20;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem13;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem14;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem15;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem24;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem25;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem26;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem27;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem28;
		private Qios.DevSuite.Components.Ribbon.QRibbonLaunchBar qRibbonLaunchBar3;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem16;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem25;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem26;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem27;
		private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem28;
		private Qios.DevSuite.Components.Ribbon.QRibbonLaunchBarHost qRibbonLaunchBarHost2;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem29;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem30;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem31;
		private Qios.DevSuite.Components.QShape qsLeftRibbonPanel;
		private Qios.DevSuite.Components.QShape qsRightRibbonPanel;
		private Qios.DevSuite.Components.QShape qsMiddleRibbonPanel;
		private Qios.DevSuite.Components.QShape qsLaunchBarBottom;
		private Qios.DevSuite.Components.QShape qsRibbonLaunchBarTop;
		private Qios.DevSuite.Components.QShape qsInputBox;
		private Qios.DevSuite.Components.QShape qsRibbonBar;
		private Qios.DevSuite.Components.Ribbon.QRibbonApplicationButton qRibbonApplicationButton1;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem20;
		private Qios.DevSuite.Components.QCompositeMenuItem qCompositeMenuItem21;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.qRibbonApplicationButton1.CustomChildWindow = new Qios.DevSuite.DemoZone.Shared.QrmwMainMenuWindow();
			m_oEventListener1 = new QCompositeEventListener(this.qRibbon1);
			m_oEventListener2 = new QCompositeEventListener(this.qRibbonLaunchBar1);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.qRibbon1 = new Qios.DevSuite.Components.Ribbon.QRibbon();
            this.qrpHome = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qrpEditing = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qsRightRibbonPanel = new Qios.DevSuite.Components.QShape();
            this.qriFind = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qrgEditing = new Qios.DevSuite.Components.Ribbon.QRibbonItemGroup();
            this.qRibbonItem1 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem2 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem4 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qrpClipboard = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qsLeftRibbonPanel = new Qios.DevSuite.Components.QShape();
            this.qriPaste = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qcmiPaste = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiPasteSpecial = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcsPaste01 = new Qios.DevSuite.Components.QCompositeSeparator();
            this.qcmiPasteCustom = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiPasteCustom01 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qcmiPasteCustom02 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem1 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem2 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem15 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem16 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem17 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem18 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem19 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem3 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem5 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem4 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem6 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem7 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem10 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem8 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem9 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem11 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem14 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem12 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem13 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qrgClipboardOther = new Qios.DevSuite.Components.Ribbon.QRibbonItemGroup();
            this.qriCut = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriCopy = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriFormatPainter = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qrpFont = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qsMiddleRibbonPanel = new Qios.DevSuite.Components.QShape();
            this.qrigFont1 = new Qios.DevSuite.Components.Ribbon.QRibbonItemGroup();
            this.qriibFontFamily = new Qios.DevSuite.Components.Ribbon.QRibbonInputBoxItem();
            this.qsInputBox = new Qios.DevSuite.Components.QShape();
            this.qriibFontSize = new Qios.DevSuite.Components.Ribbon.QRibbonInputBoxItem();
            this.qribFontSizes = new Qios.DevSuite.Components.Ribbon.QRibbonItemBar();
            this.qriFontIncrease = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriFontDecrease = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qribClearFormatting = new Qios.DevSuite.Components.Ribbon.QRibbonItemBar();
            this.qsRibbonBar = new Qios.DevSuite.Components.QShape();
            this.qriClearFormatting = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qrigFont2 = new Qios.DevSuite.Components.Ribbon.QRibbonItemGroup();
            this.qribFontStyle = new Qios.DevSuite.Components.Ribbon.QRibbonItemBar();
            this.qriBold = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriItalic = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriUnderline = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qcmiUnderline1 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qriStrikeThrough = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriSubscript = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriSuperscript = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriChangeCase = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qcmiChangeCase1 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qribFontColor = new Qios.DevSuite.Components.Ribbon.QRibbonItemBar();
            this.qriTextHighlightColor = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qcmiHighLight1 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qriTextColor = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qcmiTextColor1 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qRibbonCaption2 = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            this.qRibbonApplicationButton1 = new Qios.DevSuite.Components.Ribbon.QRibbonApplicationButton();
            this.qRibbonLaunchBar1 = new Qios.DevSuite.Components.Ribbon.QRibbonLaunchBar();
            this.qsRibbonLaunchBarTop = new Qios.DevSuite.Components.QShape();
            this.qCompositeMenuItem20 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem21 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qRibbonItem13 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem18 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem20 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem15 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem14 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem19 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qCompositeMenuItem29 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem30 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem31 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qRibbonItem17 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qrpInsert = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qrpPageLayout = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qrpReferences = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qrpMailings = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPage1 = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPanel2 = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItem9 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGroup2 = new Qios.DevSuite.Components.Ribbon.QRibbonItemGroup();
            this.qRibbonItem10 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem11 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem12 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanel1 = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItem5 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGroup1 = new Qios.DevSuite.Components.Ribbon.QRibbonItemGroup();
            this.qRibbonItem6 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem7 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem8 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPage2 = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonLaunchBarHost2 = new Qios.DevSuite.Components.Ribbon.QRibbonLaunchBarHost();
            this.qRibbonLaunchBar3 = new Qios.DevSuite.Components.Ribbon.QRibbonLaunchBar();
            this.qsLaunchBarBottom = new Qios.DevSuite.Components.QShape();
            this.qCompositeMenuItem24 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem25 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem26 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem27 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qCompositeMenuItem28 = new Qios.DevSuite.Components.QCompositeMenuItem();
            this.qRibbonItem16 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem25 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem26 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem27 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem28 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem3 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriReplace = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriGoTo = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qriSelect = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbon1)).BeginInit();
            this.qRibbon1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qrpHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpInsert)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpPageLayout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpReferences)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpMailings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPage1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPage2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonLaunchBarHost2)).BeginInit();
            this.SuspendLayout();
            // 
            // qRibbon1
            // 
            this.qRibbon1.ActiveTabPage = this.qrpHome;
            this.qRibbon1.Caption = this.qRibbonCaption2;
            this.qRibbon1.Controls.Add(this.qrpHome);
            this.qRibbon1.Controls.Add(this.qrpInsert);
            this.qRibbon1.Controls.Add(this.qrpPageLayout);
            this.qRibbon1.Controls.Add(this.qrpReferences);
            this.qRibbon1.Controls.Add(this.qrpMailings);
            this.qRibbon1.Controls.Add(this.qRibbonPage1);
            this.qRibbon1.Controls.Add(this.qRibbonPage2);
            this.qRibbon1.Cursor = System.Windows.Forms.Cursors.Default;
            this.qRibbon1.Dock = System.Windows.Forms.DockStyle.Top;
            this.qRibbon1.Form = this;
            this.qRibbon1.LaunchBarHost = this.qRibbonLaunchBarHost2;
            this.qRibbon1.Location = new System.Drawing.Point(0, 28);
            this.qRibbon1.Name = "qRibbon1";
            this.qRibbon1.PersistGuid = new System.Guid("f549a281-ecb8-4c57-ab72-08ae6e49b352");
            this.qRibbon1.Size = new System.Drawing.Size(683, 136);
            this.qRibbon1.TabIndex = 0;
            this.qRibbon1.TabStripConfiguration.ButtonAreaMargin = new Qios.DevSuite.Components.QMargin(35, 5, 0, 0);
            this.qRibbon1.Text = "qRibbon1";
            // 
            // qrpHome
            // 
            this.qrpHome.ButtonOrder = 0;
            this.qrpHome.HotkeyText = "H";
            this.qrpHome.Items.Add(this.qrpEditing);
            this.qrpHome.Items.Add(this.qrpClipboard);
            this.qrpHome.Items.Add(this.qrpFont);
            this.qrpHome.Location = new System.Drawing.Point(2, 31);
            this.qrpHome.Name = "qrpHome";
            this.qrpHome.PersistGuid = new System.Guid("2e2b0a94-9455-4cb8-b5f6-846d36c129de");
            this.qrpHome.Size = new System.Drawing.Size(677, 101);
            this.qrpHome.Text = "Home";
            // 
            // qrpEditing
            // 
            this.qrpEditing.ColorScheme.RibbonPanelCaptionArea2.SetColor("Default", System.Drawing.Color.Transparent, false);
            this.qrpEditing.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
            this.qrpEditing.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
            this.qrpEditing.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
            this.qrpEditing.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qrpEditing.Configuration.Appearance.Shape = this.qsRightRibbonPanel;
            this.qrpEditing.Configuration.CaptionConfiguration.Margin = new Qios.DevSuite.Components.QMargin(-16, 0, 0, -16);
            this.qrpEditing.Configuration.CaptionConfiguration.ShowDialogConfiguration.Margin = new Qios.DevSuite.Components.QMargin(1, 0, 1, 15);
            this.qrpEditing.HotkeyTextCollapsed = "ZN";
            this.qrpEditing.HotkeyTextShowDialog = "ZE";
            this.qrpEditing.Icon = ((System.Drawing.Icon)(resources.GetObject("qrpEditing.Icon")));
            this.qrpEditing.Items.Add(this.qriFind);
            this.qrpEditing.Items.Add(this.qrgEditing);
            this.qrpEditing.Title = "Editing";
            this.qrpEditing.CaptionShowDialogItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qrpEditing_CaptionShowDialogItemActivated);
            // 
            // qsRightRibbonPanel
            // 
            this.qsRightRibbonPanel.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RibbonPanel;
            this.qsRightRibbonPanel.ContentBounds = new System.Drawing.Rectangle(19, 0, 62, 50);
            this.qsRightRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsRightRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(71F, 0F, 109F, 0F, 109F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsRightRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(71F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsRightRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 49F, 25F, 36F, 24F, 14F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            // 
            // qriFind
            // 
            this.qriFind.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qriFind.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qriFind.HotkeyText = "FD";
            this.qriFind.Icon = ((System.Drawing.Icon)(resources.GetObject("qriFind.Icon")));
            this.qriFind.Title = "Find";
            // 
            // qrgEditing
            // 
            this.qrgEditing.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qrgEditing.Items.Add(this.qRibbonItem1);
            this.qrgEditing.Items.Add(this.qRibbonItem2);
            this.qrgEditing.Items.Add(this.qRibbonItem4);
            // 
            // qRibbonItem1
            // 
            this.qRibbonItem1.HotkeyText = "R";
            this.qRibbonItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem1.Icon")));
            this.qRibbonItem1.Title = "Replace";
            // 
            // qRibbonItem2
            // 
            this.qRibbonItem2.HotkeyText = "G";
            this.qRibbonItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem2.Icon")));
            this.qRibbonItem2.Title = "Go To";
            // 
            // qRibbonItem4
            // 
            this.qRibbonItem4.Configuration.DropDownButtonConfiguration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qRibbonItem4.HotkeyText = "S";
            this.qRibbonItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem4.Icon")));
            this.qRibbonItem4.Title = "Select";
            // 
            // qrpClipboard
            // 
            this.qrpClipboard.ColorScheme.RibbonPanelCaptionArea2.SetColor("Default", System.Drawing.Color.Transparent, false);
            this.qrpClipboard.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
            this.qrpClipboard.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
            this.qrpClipboard.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
            this.qrpClipboard.Configuration.Appearance.Shape = this.qsLeftRibbonPanel;
            this.qrpClipboard.Configuration.CaptionConfiguration.Margin = new Qios.DevSuite.Components.QMargin(-13, 0, 0, -13);
            this.qrpClipboard.Configuration.CaptionConfiguration.ShowDialogConfiguration.Margin = new Qios.DevSuite.Components.QMargin(1, 0, 1, 10);
            this.qrpClipboard.HotkeyTextCollapsed = "CP";
            this.qrpClipboard.HotkeyTextShowDialog = "FO";
            this.qrpClipboard.Icon = ((System.Drawing.Icon)(resources.GetObject("qrpClipboard.Icon")));
            this.qrpClipboard.Items.Add(this.qriPaste);
            this.qrpClipboard.Items.Add(this.qrgClipboardOther);
            this.qrpClipboard.Title = "Clipboard";
            this.qrpClipboard.CaptionShowDialogItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qrpClipboard_CaptionShowDialogItemActivated);
            // 
            // qsLeftRibbonPanel
            // 
            this.qsLeftRibbonPanel.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RibbonPanel;
            this.qsLeftRibbonPanel.ContentBounds = new System.Drawing.Rectangle(15, 0, 69, 50);
            this.qsLeftRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 50F, -5F, 50F, -7F, 1F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsLeftRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsLeftRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, 77F, 6F, 75F, 45F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsLeftRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qriPaste
            // 
            this.qriPaste.ChildItems.Add(this.qcmiPaste);
            this.qriPaste.ChildItems.Add(this.qcmiPasteSpecial);
            this.qriPaste.ChildItems.Add(this.qcsPaste01);
            this.qriPaste.ChildItems.Add(this.qcmiPasteCustom);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem1);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem3);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem4);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem7);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem8);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem11);
            this.qriPaste.ChildItems.Add(this.qCompositeMenuItem12);
            this.qriPaste.Configuration.ContentLayoutOrder = "Icon, DropDownSplit, Content, Shortcut, DropDownButton";
            this.qriPaste.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qriPaste.Configuration.DropDownSeparated = true;
            this.qriPaste.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qriPaste.HotkeyText = "V";
            this.qriPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qriPaste.Icon")));
            this.qriPaste.ItemName = "Paste";
            this.qriPaste.Shortcut = System.Windows.Forms.Shortcut.CtrlV;
            this.qriPaste.Title = "Paste";
            // 
            // qcmiPaste
            // 
            this.qcmiPaste.HotkeyText = "P";
            this.qcmiPaste.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPaste.Icon")));
            this.qcmiPaste.Title = "&Paste";
            // 
            // qcmiPasteSpecial
            // 
            this.qcmiPasteSpecial.HotkeyText = "S";
            this.qcmiPasteSpecial.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiPasteSpecial.Icon")));
            this.qcmiPasteSpecial.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftV;
            this.qcmiPasteSpecial.Title = "Paste &Special";
            // 
            // qcmiPasteCustom
            // 
            this.qcmiPasteCustom.ChildItems.Add(this.qcmiPasteCustom01);
            this.qcmiPasteCustom.ChildItems.Add(this.qcmiPasteCustom02);
            this.qcmiPasteCustom.HotkeyText = "C";
            this.qcmiPasteCustom.Shortcut = System.Windows.Forms.Shortcut.CtrlShift1;
            this.qcmiPasteCustom.Title = "Paste &Custom";
            // 
            // qcmiPasteCustom01
            // 
            this.qcmiPasteCustom01.HotkeyText = "C";
            this.qcmiPasteCustom01.Title = "Paste &Custom 01";
            // 
            // qcmiPasteCustom02
            // 
            this.qcmiPasteCustom02.HotkeyText = "C";
            this.qcmiPasteCustom02.Title = "Paste &Custom 02";
            // 
            // qCompositeMenuItem1
            // 
            this.qCompositeMenuItem1.ChildItems.Add(this.qCompositeMenuItem2);
            this.qCompositeMenuItem1.ChildItems.Add(this.qCompositeMenuItem15);
            this.qCompositeMenuItem1.ChildItems.Add(this.qCompositeMenuItem16);
            this.qCompositeMenuItem1.HotkeyText = "T";
            this.qCompositeMenuItem1.Title = "&Test With Much Child Items";
            // 
            // qCompositeMenuItem2
            // 
            this.qCompositeMenuItem2.Shortcut = System.Windows.Forms.Shortcut.F3;
            this.qCompositeMenuItem2.Title = "TestChild1";
            // 
            // qCompositeMenuItem15
            // 
            this.qCompositeMenuItem15.HotkeyText = "2";
            this.qCompositeMenuItem15.Shortcut = System.Windows.Forms.Shortcut.F4;
            this.qCompositeMenuItem15.Title = "TestChild&2";
            // 
            // qCompositeMenuItem16
            // 
            this.qCompositeMenuItem16.ChildItems.Add(this.qCompositeMenuItem17);
            this.qCompositeMenuItem16.ChildItems.Add(this.qCompositeMenuItem18);
            this.qCompositeMenuItem16.ChildItems.Add(this.qCompositeMenuItem19);
            this.qCompositeMenuItem16.HotkeyText = "3";
            this.qCompositeMenuItem16.Shortcut = System.Windows.Forms.Shortcut.F5;
            this.qCompositeMenuItem16.Title = "TestChild&3";
            // 
            // qCompositeMenuItem17
            // 
            this.qCompositeMenuItem17.Title = "Test1";
            // 
            // qCompositeMenuItem18
            // 
            this.qCompositeMenuItem18.Title = "Test2";
            // 
            // qCompositeMenuItem19
            // 
            this.qCompositeMenuItem19.Title = "Test3";
            // 
            // qCompositeMenuItem3
            // 
            this.qCompositeMenuItem3.ChildItems.Add(this.qCompositeMenuItem5);
            this.qCompositeMenuItem3.HotkeyText = "H";
            this.qCompositeMenuItem3.Title = "&HotkeyTest1";
            // 
            // qCompositeMenuItem5
            // 
            this.qCompositeMenuItem5.HotkeyText = "T";
            this.qCompositeMenuItem5.Title = "&Test";
            // 
            // qCompositeMenuItem4
            // 
            this.qCompositeMenuItem4.ChildItems.Add(this.qCompositeMenuItem6);
            this.qCompositeMenuItem4.HotkeyText = "H";
            this.qCompositeMenuItem4.Title = "&HotkeyTest2";
            // 
            // qCompositeMenuItem6
            // 
            this.qCompositeMenuItem6.HotkeyText = "T";
            this.qCompositeMenuItem6.Title = "&Test";
            // 
            // qCompositeMenuItem7
            // 
            this.qCompositeMenuItem7.ChildItems.Add(this.qCompositeMenuItem10);
            this.qCompositeMenuItem7.HotkeyText = "KE";
            this.qCompositeMenuItem7.Title = "Hot&k&eyTest3";
            // 
            // qCompositeMenuItem10
            // 
            this.qCompositeMenuItem10.HotkeyText = "T";
            this.qCompositeMenuItem10.Title = "&Test";
            // 
            // qCompositeMenuItem8
            // 
            this.qCompositeMenuItem8.ChildItems.Add(this.qCompositeMenuItem9);
            this.qCompositeMenuItem8.HotkeyText = "KE";
            this.qCompositeMenuItem8.Title = "Hot&k&eyTest4";
            // 
            // qCompositeMenuItem9
            // 
            this.qCompositeMenuItem9.HotkeyText = "T";
            this.qCompositeMenuItem9.Title = "&Test";
            // 
            // qCompositeMenuItem11
            // 
            this.qCompositeMenuItem11.ChildItems.Add(this.qCompositeMenuItem14);
            this.qCompositeMenuItem11.HotkeyText = "ES";
            this.qCompositeMenuItem11.Title = "HotKeyT&e&st5";
            // 
            // qCompositeMenuItem14
            // 
            this.qCompositeMenuItem14.HotkeyText = "2";
            this.qCompositeMenuItem14.Title = "Test&2";
            // 
            // qCompositeMenuItem12
            // 
            this.qCompositeMenuItem12.ChildItems.Add(this.qCompositeMenuItem13);
            this.qCompositeMenuItem12.HotkeyText = "E6";
            this.qCompositeMenuItem12.Title = "HotkeyT&est&6";
            // 
            // qCompositeMenuItem13
            // 
            this.qCompositeMenuItem13.HotkeyText = "T";
            this.qCompositeMenuItem13.Title = "&Test";
            // 
            // qrgClipboardOther
            // 
            this.qrgClipboardOther.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qrgClipboardOther.ItemName = "ClipboardOther";
            this.qrgClipboardOther.Items.Add(this.qriCut);
            this.qrgClipboardOther.Items.Add(this.qriCopy);
            this.qrgClipboardOther.Items.Add(this.qriFormatPainter);
            // 
            // qriCut
            // 
            this.qriCut.HotkeyText = "X";
            this.qriCut.Icon = ((System.Drawing.Icon)(resources.GetObject("qriCut.Icon")));
            this.qriCut.ItemName = "Cut";
            this.qriCut.Title = "Cut";
            // 
            // qriCopy
            // 
            this.qriCopy.HotkeyText = "C";
            this.qriCopy.Icon = ((System.Drawing.Icon)(resources.GetObject("qriCopy.Icon")));
            this.qriCopy.ItemName = "Copy";
            this.qriCopy.Title = "Copy";
            // 
            // qriFormatPainter
            // 
            this.qriFormatPainter.HotkeyText = "FP";
            this.qriFormatPainter.Icon = ((System.Drawing.Icon)(resources.GetObject("qriFormatPainter.Icon")));
            this.qriFormatPainter.ItemName = "FormatPainter";
            this.qriFormatPainter.Title = "Format Painter";
            // 
            // qrpFont
            // 
            this.qrpFont.ColorScheme.RibbonPanelCaptionArea2.SetColor("Default", System.Drawing.Color.Transparent, false);
            this.qrpFont.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
            this.qrpFont.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
            this.qrpFont.ColorScheme.RibbonPanelCaptionArea2.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
            this.qrpFont.Configuration.Appearance.MetallicOffset = 60;
            this.qrpFont.Configuration.Appearance.Shape = this.qsMiddleRibbonPanel;
            this.qrpFont.Configuration.CaptionConfiguration.ShowDialogConfiguration.Margin = new Qios.DevSuite.Components.QMargin(1, 0, 1, 15);
            this.qrpFont.Configuration.CaptionConfiguration.TitleConfiguration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 10F);
            this.qrpFont.Configuration.ContentLayoutOrder = "Caption, ItemArea";
            this.qrpFont.Configuration.ItemAreaConfiguration.AlignmentVertical = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qrpFont.Configuration.ItemAreaConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qrpFont.Configuration.StretchHorizontal = true;
            this.qrpFont.HotkeyTextCollapsed = "ZP";
            this.qrpFont.HotkeyTextShowDialog = "FN";
            this.qrpFont.Icon = ((System.Drawing.Icon)(resources.GetObject("qrpFont.Icon")));
            this.qrpFont.Items.Add(this.qrigFont1);
            this.qrpFont.Items.Add(this.qrigFont2);
            this.qrpFont.Title = "Font";
            this.qrpFont.CaptionShowDialogItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qrpFont_CaptionShowDialogItemActivated);
            // 
            // qsMiddleRibbonPanel
            // 
            this.qsMiddleRibbonPanel.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RibbonPanel;
            this.qsMiddleRibbonPanel.ContentBounds = new System.Drawing.Rectangle(1, 0, 98, 50);
            this.qsMiddleRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(71F, 0F, 109F, 0F, 107F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsMiddleRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(73F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsMiddleRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(27F, 50F, -7F, 50F, -9F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsMiddleRibbonPanel.Items.Add(new Qios.DevSuite.Components.QShapeItem(29F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            // 
            // qrigFont1
            // 
            this.qrigFont1.Configuration.StretchHorizontal = true;
            this.qrigFont1.Configuration.Visible = Qios.DevSuite.Components.QTristateBool.True;
            this.qrigFont1.Items.Add(this.qriibFontFamily);
            this.qrigFont1.Items.Add(this.qriibFontSize);
            this.qrigFont1.Items.Add(this.qribFontSizes);
            this.qrigFont1.Items.Add(this.qribClearFormatting);
            // 
            // qriibFontFamily
            // 
            this.qriibFontFamily.Configuration.ControlConfiguration.StretchHorizontal = true;
            this.qriibFontFamily.Configuration.HasHotState = Qios.DevSuite.Components.QTristateBool.False;
            this.qriibFontFamily.Configuration.HasPressedState = Qios.DevSuite.Components.QTristateBool.False;
            this.qriibFontFamily.Configuration.Margin = new Qios.DevSuite.Components.QMargin(1, 1, 0, 1);
            this.qriibFontFamily.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
            this.qriibFontFamily.Configuration.StretchHorizontal = true;
            this.qriibFontFamily.ControlSize = new System.Drawing.Size(170, 22);
            this.qriibFontFamily.HotkeyText = "FS";
            // 
            // 
            // 
            this.qriibFontFamily.InputBox.Appearance.Shape = this.qsInputBox;
            this.qriibFontFamily.InputBox.Configuration.InputBoxTextPadding = new Qios.DevSuite.Components.QPadding(2, 3, 3, 2);
            this.qriibFontFamily.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDown;
            this.qriibFontFamily.InputBox.Location = new System.Drawing.Point(117, 28);
            this.qriibFontFamily.InputBox.Name = "";
            this.qriibFontFamily.InputBox.Size = new System.Drawing.Size(214, 23);
            this.qriibFontFamily.InputBox.TabIndex = 1;
            this.qriibFontFamily.InputBox.Text = "Calibri (Body)";
            // 
            // qsInputBox
            // 
            this.qsInputBox.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedInputBox2;
            this.qsInputBox.ContentBounds = new System.Drawing.Rectangle(14, 1, 84, 18);
            this.qsInputBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, 0F, 12F, 0F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsInputBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsInputBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 0F, 100F, 0F, 100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsInputBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsInputBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 16F, 100F, 20F, 100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsInputBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qriibFontSize
            // 
            this.qriibFontSize.Configuration.HasHotState = Qios.DevSuite.Components.QTristateBool.False;
            this.qriibFontSize.Configuration.HasPressedState = Qios.DevSuite.Components.QTristateBool.False;
            this.qriibFontSize.Configuration.Margin = new Qios.DevSuite.Components.QMargin(1, 1, 0, 1);
            this.qriibFontSize.Configuration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
            this.qriibFontSize.ControlSize = new System.Drawing.Size(42, 22);
            this.qriibFontSize.HotkeyText = "FF";
            // 
            // 
            // 
            this.qriibFontSize.InputBox.Configuration.InputBoxTextPadding = new Qios.DevSuite.Components.QPadding(2, 3, 3, 2);
            this.qriibFontSize.InputBox.Configuration.InputStyle = Qios.DevSuite.Components.QInputBoxStyle.DropDown;
            this.qriibFontSize.InputBox.Location = new System.Drawing.Point(335, 28);
            this.qriibFontSize.InputBox.Name = "";
            this.qriibFontSize.InputBox.Size = new System.Drawing.Size(42, 23);
            this.qriibFontSize.InputBox.TabIndex = 0;
            this.qriibFontSize.InputBox.Text = "11";
            // 
            // qribFontSizes
            // 
            this.qribFontSizes.Items.Add(this.qriFontIncrease);
            this.qribFontSizes.Items.Add(this.qriFontDecrease);
            // 
            // qriFontIncrease
            // 
            this.qriFontIncrease.HotkeyText = "FG";
            this.qriFontIncrease.Icon = ((System.Drawing.Icon)(resources.GetObject("qriFontIncrease.Icon")));
            // 
            // qriFontDecrease
            // 
            this.qriFontDecrease.HotkeyText = "FK";
            this.qriFontDecrease.Icon = ((System.Drawing.Icon)(resources.GetObject("qriFontDecrease.Icon")));
            // 
            // qribClearFormatting
            // 
            this.qribClearFormatting.Configuration.Appearance.Shape = this.qsRibbonBar;
            this.qribClearFormatting.Items.Add(this.qriClearFormatting);
            // 
            // qsRibbonBar
            // 
            this.qsRibbonBar.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RibbonItemBar;
            this.qsRibbonBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 20F, 0F, 20F, 0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsRibbonBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 16F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsRibbonBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 4F, 0F, 0F, 0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsRibbonBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(4F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsRibbonBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(95F, 0F, 99F, 2F, 100F, 12F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsRibbonBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qriClearFormatting
            // 
            this.qriClearFormatting.HotkeyText = "E";
            this.qriClearFormatting.Icon = ((System.Drawing.Icon)(resources.GetObject("qriClearFormatting.Icon")));
            // 
            // qrigFont2
            // 
            this.qrigFont2.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qrigFont2.Items.Add(this.qribFontStyle);
            this.qrigFont2.Items.Add(this.qribFontColor);
            // 
            // qribFontStyle
            // 
            this.qribFontStyle.Items.Add(this.qriBold);
            this.qribFontStyle.Items.Add(this.qriItalic);
            this.qribFontStyle.Items.Add(this.qriUnderline);
            this.qribFontStyle.Items.Add(this.qriStrikeThrough);
            this.qribFontStyle.Items.Add(this.qriSubscript);
            this.qribFontStyle.Items.Add(this.qriSuperscript);
            this.qribFontStyle.Items.Add(this.qriChangeCase);
            // 
            // qriBold
            // 
            this.qriBold.HotkeyText = "1";
            this.qriBold.Icon = ((System.Drawing.Icon)(resources.GetObject("qriBold.Icon")));
            // 
            // qriItalic
            // 
            this.qriItalic.HotkeyText = "2";
            this.qriItalic.Icon = ((System.Drawing.Icon)(resources.GetObject("qriItalic.Icon")));
            // 
            // qriUnderline
            // 
            this.qriUnderline.ChildItems.Add(this.qcmiUnderline1);
            this.qriUnderline.HotkeyText = "3";
            this.qriUnderline.Icon = ((System.Drawing.Icon)(resources.GetObject("qriUnderline.Icon")));
            // 
            // qcmiUnderline1
            // 
            this.qcmiUnderline1.Title = "Underline1";
            // 
            // qriStrikeThrough
            // 
            this.qriStrikeThrough.HotkeyText = "4";
            this.qriStrikeThrough.Icon = ((System.Drawing.Icon)(resources.GetObject("qriStrikeThrough.Icon")));
            // 
            // qriSubscript
            // 
            this.qriSubscript.HotkeyText = "5";
            this.qriSubscript.Icon = ((System.Drawing.Icon)(resources.GetObject("qriSubscript.Icon")));
            // 
            // qriSuperscript
            // 
            this.qriSuperscript.HotkeyText = "6";
            this.qriSuperscript.Icon = ((System.Drawing.Icon)(resources.GetObject("qriSuperscript.Icon")));
            // 
            // qriChangeCase
            // 
            this.qriChangeCase.ChildItems.Add(this.qcmiChangeCase1);
            this.qriChangeCase.HotkeyText = "7";
            this.qriChangeCase.Icon = ((System.Drawing.Icon)(resources.GetObject("qriChangeCase.Icon")));
            // 
            // qcmiChangeCase1
            // 
            this.qcmiChangeCase1.Title = "ChangeCase1";
            // 
            // qribFontColor
            // 
            this.qribFontColor.Items.Add(this.qriTextHighlightColor);
            this.qribFontColor.Items.Add(this.qriTextColor);
            // 
            // qriTextHighlightColor
            // 
            this.qriTextHighlightColor.ChildItems.Add(this.qcmiHighLight1);
            this.qriTextHighlightColor.Configuration.DropDownSeparated = true;
            this.qriTextHighlightColor.HotkeyText = "I";
            this.qriTextHighlightColor.Icon = ((System.Drawing.Icon)(resources.GetObject("qriTextHighlightColor.Icon")));
            // 
            // qcmiHighLight1
            // 
            this.qcmiHighLight1.Title = "HighLight1";
            // 
            // qriTextColor
            // 
            this.qriTextColor.ChildItems.Add(this.qcmiTextColor1);
            this.qriTextColor.Configuration.DropDownSeparated = true;
            this.qriTextColor.HotkeyText = "FC";
            this.qriTextColor.Icon = ((System.Drawing.Icon)(resources.GetObject("qriTextColor.Icon")));
            // 
            // qcmiTextColor1
            // 
            this.qcmiTextColor1.Title = "TextColor1";
            // 
            // qRibbonCaption2
            // 
            this.qRibbonCaption2.ApplicationButton = this.qRibbonApplicationButton1;
            this.qRibbonCaption2.Configuration.IconConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.False;
            this.qRibbonCaption2.Configuration.LaunchBarAreaConfiguration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qRibbonCaption2.Configuration.TextAreaConfiguration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Near;
            this.qRibbonCaption2.Configuration.TextAreaConfiguration.Margin = new Qios.DevSuite.Components.QMargin(10, 0, 0, 0);
            this.qRibbonCaption2.LaunchBar = this.qRibbonLaunchBar1;
            this.qRibbonCaption2.Location = new System.Drawing.Point(0, 0);
            this.qRibbonCaption2.Name = "qRibbonCaption2";
            this.qRibbonCaption2.Size = new System.Drawing.Size(683, 28);
            this.qRibbonCaption2.TabIndex = 23;
            this.qRibbonCaption2.Text = "Custom Ribbon Sample - Qios.DevSuite.DemoZone";
            // 
            // qRibbonApplicationButton1
            // 
            this.qRibbonApplicationButton1.ForegroundImage = ((System.Drawing.Image)(resources.GetObject("qRibbonApplicationButton1.ForegroundImage")));
            // 
            // qRibbonLaunchBar1
            // 
            this.qRibbonLaunchBar1.ColorScheme.RibbonLaunchBarBackground1.SetColor("Default", System.Drawing.Color.Transparent, false);
            this.qRibbonLaunchBar1.ColorScheme.RibbonLaunchBarBackground1.SetColor("LunaBlue", System.Drawing.Color.Transparent, false);
            this.qRibbonLaunchBar1.ColorScheme.RibbonLaunchBarBackground1.SetColor("LunaOlive", System.Drawing.Color.Transparent, false);
            this.qRibbonLaunchBar1.ColorScheme.RibbonLaunchBarBackground1.SetColor("LunaSilver", System.Drawing.Color.Transparent, false);
            this.qRibbonLaunchBar1.Configuration.Appearance.GradientAngle = 0;
            this.qRibbonLaunchBar1.Configuration.Appearance.GradientBlendPosition = 90;
            this.qRibbonLaunchBar1.Configuration.Appearance.Shape = this.qsRibbonLaunchBarTop;
            this.qRibbonLaunchBar1.CustomizeItems.Add(this.qCompositeMenuItem20);
            this.qRibbonLaunchBar1.CustomizeItems.Add(this.qCompositeMenuItem21);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem13);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem18);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem20);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem15);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem14);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem19);
            this.qRibbonLaunchBar1.Items.Add(this.qRibbonItem17);
            // 
            // qsRibbonLaunchBarTop
            // 
            this.qsRibbonLaunchBarTop.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RibbonLaunchBar;
            this.qsRibbonLaunchBarTop.ContentBounds = new System.Drawing.Rectangle(12, 0, 76, 22);
            this.qsRibbonLaunchBarTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 22F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
            this.qsRibbonLaunchBarTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsRibbonLaunchBarTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 0F, 90F, 4F, 89F, 18F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsRibbonLaunchBarTop.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 22F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qCompositeMenuItem20
            // 
            this.qCompositeMenuItem20.HotkeyText = "C";
            this.qCompositeMenuItem20.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem20.Icon")));
            this.qCompositeMenuItem20.Title = "&Customize Item &1";
            // 
            // qCompositeMenuItem21
            // 
            this.qCompositeMenuItem21.HotkeyText = "C";
            this.qCompositeMenuItem21.Icon = ((System.Drawing.Icon)(resources.GetObject("qCompositeMenuItem21.Icon")));
            this.qCompositeMenuItem21.Title = "&Customize item &2";
            // 
            // qRibbonItem13
            // 
            this.qRibbonItem13.HotkeyText = "00";
            this.qRibbonItem13.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem13.Icon")));
            this.qRibbonItem13.Title = "";
            // 
            // qRibbonItem18
            // 
            this.qRibbonItem18.HotkeyText = "01";
            this.qRibbonItem18.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem18.Icon")));
            // 
            // qRibbonItem20
            // 
            this.qRibbonItem20.HotkeyText = "02";
            this.qRibbonItem20.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem20.Icon")));
            // 
            // qRibbonItem15
            // 
            this.qRibbonItem15.HotkeyText = "03";
            this.qRibbonItem15.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem15.Icon")));
            this.qRibbonItem15.Title = "";
            // 
            // qRibbonItem14
            // 
            this.qRibbonItem14.HotkeyText = "04";
            this.qRibbonItem14.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem14.Icon")));
            this.qRibbonItem14.Title = "";
            // 
            // qRibbonItem19
            // 
            this.qRibbonItem19.ChildItems.Add(this.qCompositeMenuItem29);
            this.qRibbonItem19.ChildItems.Add(this.qCompositeMenuItem30);
            this.qRibbonItem19.ChildItems.Add(this.qCompositeMenuItem31);
            this.qRibbonItem19.Configuration.DropDownSeparated = true;
            this.qRibbonItem19.HotkeyText = "05";
            this.qRibbonItem19.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem19.Icon")));
            // 
            // qCompositeMenuItem29
            // 
            this.qCompositeMenuItem29.HotkeyText = "P";
            this.qCompositeMenuItem29.Title = "&Paste1";
            // 
            // qCompositeMenuItem30
            // 
            this.qCompositeMenuItem30.HotkeyText = "A";
            this.qCompositeMenuItem30.Title = "P&aste2";
            // 
            // qCompositeMenuItem31
            // 
            this.qCompositeMenuItem31.HotkeyText = "3";
            this.qCompositeMenuItem31.Title = "Paste&3";
            // 
            // qRibbonItem17
            // 
            this.qRibbonItem17.HotkeyText = "06";
            this.qRibbonItem17.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem17.Icon")));
            // 
            // qrpInsert
            // 
            this.qrpInsert.ButtonOrder = 1;
            this.qrpInsert.HotkeyText = "N";
            this.qrpInsert.Location = new System.Drawing.Point(2, 28);
            this.qrpInsert.Name = "qrpInsert";
            this.qrpInsert.PersistGuid = new System.Guid("f98751ef-4f36-4e2c-bee1-d2b709dc848d");
            this.qrpInsert.Size = new System.Drawing.Size(599, 136);
            this.qrpInsert.Text = "Insert";
            // 
            // qrpPageLayout
            // 
            this.qrpPageLayout.ButtonOrder = 2;
            this.qrpPageLayout.HotkeyText = "PA";
            this.qrpPageLayout.Location = new System.Drawing.Point(2, 28);
            this.qrpPageLayout.Name = "qrpPageLayout";
            this.qrpPageLayout.PersistGuid = new System.Guid("57e0aaea-cdaa-45d3-bfaf-ccc5d23e6e57");
            this.qrpPageLayout.Size = new System.Drawing.Size(599, 136);
            this.qrpPageLayout.Text = "Page Layout";
            // 
            // qrpReferences
            // 
            this.qrpReferences.ButtonOrder = 3;
            this.qrpReferences.HotkeyText = "PS";
            this.qrpReferences.Location = new System.Drawing.Point(2, 28);
            this.qrpReferences.Name = "qrpReferences";
            this.qrpReferences.PersistGuid = new System.Guid("47e23ec5-41d9-4e9f-9bd1-006b1bb0854d");
            this.qrpReferences.Size = new System.Drawing.Size(599, 136);
            this.qrpReferences.Text = "References";
            // 
            // qrpMailings
            // 
            this.qrpMailings.ButtonOrder = 4;
            this.qrpMailings.Enabled = false;
            this.qrpMailings.HotkeyText = "M";
            this.qrpMailings.Location = new System.Drawing.Point(2, 28);
            this.qrpMailings.Name = "qrpMailings";
            this.qrpMailings.PersistGuid = new System.Guid("6291f32b-b421-4798-8353-c78a6fd89684");
            this.qrpMailings.Size = new System.Drawing.Size(599, 136);
            this.qrpMailings.Text = "Mailings";
            // 
            // qRibbonPage1
            // 
            this.qRibbonPage1.ButtonOrder = 5;
            this.qRibbonPage1.HotkeyText = "QR";
            this.qRibbonPage1.Items.Add(this.qRibbonPanel2);
            this.qRibbonPage1.Items.Add(this.qRibbonPanel1);
            this.qRibbonPage1.Location = new System.Drawing.Point(2, 28);
            this.qRibbonPage1.Name = "qRibbonPage1";
            this.qRibbonPage1.PersistGuid = new System.Guid("ea85f321-5f5d-4be5-b84e-e09b73b23a86");
            this.qRibbonPage1.Size = new System.Drawing.Size(599, 136);
            this.qRibbonPage1.Text = "qRibbonPage1";
            // 
            // qRibbonPanel2
            // 
            this.qRibbonPanel2.HotkeyTextCollapsed = "FA";
            this.qRibbonPanel2.HotkeyTextShowDialog = "FE";
            this.qRibbonPanel2.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonPanel2.Icon")));
            this.qRibbonPanel2.Items.Add(this.qRibbonItem9);
            this.qRibbonPanel2.Items.Add(this.qRibbonItemGroup2);
            this.qRibbonPanel2.Title = "Editing";
            // 
            // qRibbonItem9
            // 
            this.qRibbonItem9.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItem9.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qRibbonItem9.HotkeyText = "F";
            this.qRibbonItem9.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem9.Icon")));
            this.qRibbonItem9.Title = "Find";
            // 
            // qRibbonItemGroup2
            // 
            this.qRibbonItemGroup2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGroup2.Items.Add(this.qRibbonItem10);
            this.qRibbonItemGroup2.Items.Add(this.qRibbonItem11);
            this.qRibbonItemGroup2.Items.Add(this.qRibbonItem12);
            // 
            // qRibbonItem10
            // 
            this.qRibbonItem10.HotkeyText = "R";
            this.qRibbonItem10.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem10.Icon")));
            this.qRibbonItem10.Title = "Replace";
            // 
            // qRibbonItem11
            // 
            this.qRibbonItem11.HotkeyText = "G";
            this.qRibbonItem11.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem11.Icon")));
            this.qRibbonItem11.Title = "Go To";
            // 
            // qRibbonItem12
            // 
            this.qRibbonItem12.Configuration.DropDownButtonConfiguration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qRibbonItem12.HotkeyText = "S";
            this.qRibbonItem12.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem12.Icon")));
            this.qRibbonItem12.Title = "Select";
            // 
            // qRibbonPanel1
            // 
            this.qRibbonPanel1.HotkeyTextCollapsed = "FB";
            this.qRibbonPanel1.HotkeyTextShowDialog = "FE";
            this.qRibbonPanel1.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonPanel1.Icon")));
            this.qRibbonPanel1.Items.Add(this.qRibbonItem5);
            this.qRibbonPanel1.Items.Add(this.qRibbonItemGroup1);
            this.qRibbonPanel1.Title = "Editing";
            // 
            // qRibbonItem5
            // 
            this.qRibbonItem5.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItem5.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(32, 32);
            this.qRibbonItem5.HotkeyText = "F";
            this.qRibbonItem5.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem5.Icon")));
            this.qRibbonItem5.Title = "Find";
            // 
            // qRibbonItemGroup1
            // 
            this.qRibbonItemGroup1.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGroup1.Items.Add(this.qRibbonItem6);
            this.qRibbonItemGroup1.Items.Add(this.qRibbonItem7);
            this.qRibbonItemGroup1.Items.Add(this.qRibbonItem8);
            // 
            // qRibbonItem6
            // 
            this.qRibbonItem6.HotkeyText = "R";
            this.qRibbonItem6.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem6.Icon")));
            this.qRibbonItem6.Title = "Replace";
            // 
            // qRibbonItem7
            // 
            this.qRibbonItem7.HotkeyText = "G";
            this.qRibbonItem7.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem7.Icon")));
            this.qRibbonItem7.Title = "Go To";
            // 
            // qRibbonItem8
            // 
            this.qRibbonItem8.Configuration.DropDownButtonConfiguration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
            this.qRibbonItem8.HotkeyText = "S";
            this.qRibbonItem8.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem8.Icon")));
            this.qRibbonItem8.Title = "Select";
            // 
            // qRibbonPage2
            // 
            this.qRibbonPage2.ButtonOrder = 6;
            this.qRibbonPage2.HotkeyText = "QR";
            this.qRibbonPage2.Location = new System.Drawing.Point(2, 28);
            this.qRibbonPage2.Name = "qRibbonPage2";
            this.qRibbonPage2.PersistGuid = new System.Guid("35a73ef8-4f63-4b71-ac8d-e7d897ef3296");
            this.qRibbonPage2.Size = new System.Drawing.Size(599, 136);
            this.qRibbonPage2.Text = "qRibbonPage2";
            // 
            // qRibbonLaunchBarHost2
            // 
            this.qRibbonLaunchBarHost2.ColorScheme.RibbonLaunchBarBackground1.ColorReference = "@RibbonPanelBackground1";
            this.qRibbonLaunchBarHost2.ColorScheme.RibbonLaunchBarBackground2.ColorReference = "@RibbonPanelBackground2";
            this.qRibbonLaunchBarHost2.Configuration.LaunchBarAreaConfiguration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qRibbonLaunchBarHost2.Configuration.Padding = new Qios.DevSuite.Components.QPadding(1, 1, 1, 1);
            this.qRibbonLaunchBarHost2.Dock = System.Windows.Forms.DockStyle.Top;
            this.qRibbonLaunchBarHost2.LaunchBar = this.qRibbonLaunchBar3;
            this.qRibbonLaunchBarHost2.Location = new System.Drawing.Point(0, 164);
            this.qRibbonLaunchBarHost2.Name = "qRibbonLaunchBarHost2";
            this.qRibbonLaunchBarHost2.Size = new System.Drawing.Size(683, 28);
            this.qRibbonLaunchBarHost2.TabIndex = 28;
            this.qRibbonLaunchBarHost2.Text = "qRibbonLaunchBarHost2";
            // 
            // qRibbonLaunchBar3
            // 
            this.qRibbonLaunchBar3.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qRibbonLaunchBar3.Configuration.Appearance.Shape = this.qsLaunchBarBottom;
            this.qRibbonLaunchBar3.Configuration.DefaultItemConfiguration.TitleConfiguration.Visible = Qios.DevSuite.Components.QTristateBool.Undefined;
            this.qRibbonLaunchBar3.Configuration.DrawShape = Qios.DevSuite.Components.QTristateBool.True;
            this.qRibbonLaunchBar3.CustomizeItems.Add(this.qCompositeMenuItem24);
            this.qRibbonLaunchBar3.CustomizeItems.Add(this.qCompositeMenuItem25);
            this.qRibbonLaunchBar3.CustomizeItems.Add(this.qCompositeMenuItem26);
            this.qRibbonLaunchBar3.CustomizeItems.Add(this.qCompositeMenuItem27);
            this.qRibbonLaunchBar3.CustomizeItems.Add(this.qCompositeMenuItem28);
            this.qRibbonLaunchBar3.Items.Add(this.qRibbonItem16);
            this.qRibbonLaunchBar3.Items.Add(this.qRibbonItem25);
            this.qRibbonLaunchBar3.Items.Add(this.qRibbonItem26);
            this.qRibbonLaunchBar3.Items.Add(this.qRibbonItem27);
            this.qRibbonLaunchBar3.Items.Add(this.qRibbonItem28);
            // 
            // qsLaunchBarBottom
            // 
            this.qsLaunchBarBottom.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RibbonLaunchBar;
            this.qsLaunchBarBottom.ContentBounds = new System.Drawing.Rectangle(12, 0, 77, 22);
            this.qsLaunchBarBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 22F, 12F, 14F, 10F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsLaunchBarBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(1F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsLaunchBarBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 0F, 90F, 4F, 88F, 14F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsLaunchBarBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(89F, 22F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qCompositeMenuItem24
            // 
            this.qCompositeMenuItem24.Title = "CustomizeItem2";
            // 
            // qCompositeMenuItem25
            // 
            this.qCompositeMenuItem25.Title = "CustomizeItem2";
            // 
            // qCompositeMenuItem26
            // 
            this.qCompositeMenuItem26.Title = "CustomizeItem3";
            // 
            // qCompositeMenuItem27
            // 
            this.qCompositeMenuItem27.Title = "CustomizeItem4";
            // 
            // qCompositeMenuItem28
            // 
            this.qCompositeMenuItem28.Title = "CustomizeItem5";
            // 
            // qRibbonItem16
            // 
            this.qRibbonItem16.HotkeyText = "11";
            this.qRibbonItem16.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem16.Icon")));
            this.qRibbonItem16.Title = "MyFirstItem";
            // 
            // qRibbonItem25
            // 
            this.qRibbonItem25.HotkeyText = "12";
            this.qRibbonItem25.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem25.Icon")));
            this.qRibbonItem25.Title = "MySecondItem";
            // 
            // qRibbonItem26
            // 
            this.qRibbonItem26.HotkeyText = "13";
            this.qRibbonItem26.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem26.Icon")));
            this.qRibbonItem26.Title = "MyThirdItem";
            // 
            // qRibbonItem27
            // 
            this.qRibbonItem27.HotkeyText = "14";
            this.qRibbonItem27.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem27.Icon")));
            this.qRibbonItem27.Title = "MyFourthItem";
            // 
            // qRibbonItem28
            // 
            this.qRibbonItem28.HotkeyText = "15";
            this.qRibbonItem28.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem28.Icon")));
            this.qRibbonItem28.Title = "MyFifthItem";
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.TopMiddle;
            this.BackgroundImageOffset = new System.Drawing.Point(0, 200);
            this.ClientSize = new System.Drawing.Size(683, 366);
            this.Controls.Add(this.qRibbonLaunchBarHost2);
            this.Controls.Add(this.qRibbon1);
            this.Controls.Add(this.qRibbonCaption2);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.Text = "Custom Ribbon Sample - Qios.DevSuite.DemoZone";
            ((System.ComponentModel.ISupportInitialize)(this.qRibbon1)).EndInit();
            this.qRibbon1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.qrpHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonCaption2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpInsert)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpPageLayout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpReferences)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrpMailings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPage1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPage2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonLaunchBarHost2)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			if (this.qRibbonCaption2.LaunchBar != null)
			{
				this.qRibbonLaunchBarHost2.LaunchBar = this.qRibbonCaption2.LaunchBar;
			}
			else if (this.qRibbonLaunchBarHost2.LaunchBar != null)
			{
				this.qRibbonCaption2.LaunchBar = this.qRibbonLaunchBarHost2.LaunchBar;
			}
		}

		private void qrpClipboard_CaptionShowDialogItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
			MessageBox.Show("Clipboard ShowDialog activated");		
		}

		private void qrpFont_CaptionShowDialogItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
			MessageBox.Show("Font ShowDialog activated");		
		}

		private void qrpEditing_CaptionShowDialogItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
			MessageBox.Show("Editing ShowDialog activated");		
		}

	}
}
