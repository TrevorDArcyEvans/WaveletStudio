using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone.Samples.SmallControls
{
	/// <summary>
	/// Summary description for QrmwMenuWindow.
	/// </summary>
	public class QibwFriends : QInputBoxCompositeWindow
	{
		private Qios.DevSuite.Components.QCompositeResizeItem qCompositeResizeItem1;
		private Qios.DevSuite.Components.QCompositeImage qciResizeItem;
		private Qios.DevSuite.Components.QCompositeResizeItem qcrResizeItemBottom;
		private Qios.DevSuite.Components.QShape qsResizeItemBottom;
		private Qios.DevSuite.Components.QShape qsItemGroup;
		private Qios.DevSuite.Components.QCompositeGroup qcgPopularFriends;
		private Qios.DevSuite.Components.QCompositeGroup qcgPopularFriendsHeading;
		private Qios.DevSuite.Components.QCompositeText qCompositeText2;
		private Qios.DevSuite.Components.QCompositeMenuItem qcmiNotSoPopularFriends;
		private Qios.DevSuite.Components.QCompositeText qCompositeText1;

		public QibwFriends()
		{
			this.InitializeComponent();
		}

		/// <summary>
		/// Overridden. Clears the inputBoxItems
		/// </summary>
		public override void ClearInputBoxItems()
		{
			this.SuspendChangeNotification();
			this.qcgPopularFriends.Items.Clear();
			this.qcmiNotSoPopularFriends.ChildItems.Clear();
			this.ResumeChangeNotification(true);
		}


		/// <summary>
		/// Creates an inputBoxItem for the specified item.
		/// </summary>
		public override QCompositeItemBase CreateInputBoxItem(object item, QInputBox owner, bool selected)
		{
			DataRowView tmp_oRowView = item as DataRowView;
			DsMyFriends.FriendRow tmp_oRow = ((tmp_oRowView != null) ? tmp_oRowView.Row : null) as DsMyFriends.FriendRow;

			if ((tmp_oRow == null) || (tmp_oRow.FriendID <= 0)) return null;

			//Create the items.
			QCompositeItem tmp_oItem = new QCompositeItem();
			QCompositeText tmp_oFriendName = new QCompositeText();
			QCompositeImage tmp_oFriendImage = new QCompositeImage();

			//Set the item values
			tmp_oItem.LayoutOrder = (int)tmp_oRow.Popularity;
			tmp_oFriendName.Title = tmp_oRow.Name;
			tmp_oFriendImage.ImageResourceName = tmp_oRow.ImageResource;

			//Map the QCompositeItem to the item.
			tmp_oItem.SystemReference = item;

			//Add the sub items.
			tmp_oItem.Items.Add(tmp_oFriendImage);
			tmp_oItem.Items.Add(tmp_oFriendName);

			//Configure the item (based on its popularity
			if (tmp_oRow.Popularity >= 100)
			{
				//Not popular
				tmp_oItem.Configuration.Direction = QPartDirection.Horizontal;
				tmp_oFriendImage.Configuration.AlignmentVertical = QPartAlignment.Centered;
				tmp_oFriendName.Configuration.AlignmentVertical = QPartAlignment.Centered;
			}
			else
			{
				//Very popular
				tmp_oItem.Configuration.Direction = QPartDirection.Vertical;
				tmp_oFriendImage.Configuration.AlignmentHorizontal = QPartAlignment.Centered;
				tmp_oFriendName.Configuration.AlignmentHorizontal = QPartAlignment.Centered;
			}

			//Return it
			return tmp_oItem;
		}

		/// <summary>
		/// Adds the created inputBox item
		/// </summary>
		public override void AddInputBoxItem(QCompositeItemBase item)
		{
			DataRowView tmp_oRowView = item.SystemReference as DataRowView;
			DsMyFriends.FriendRow tmp_oRow = ((tmp_oRowView != null) ? tmp_oRowView.Row : null) as DsMyFriends.FriendRow;

			if (tmp_oRow.Popularity >= 100)
			{
				this.qcmiNotSoPopularFriends.ChildItems.Add(item);
			}
			else
			{
				this.qcgPopularFriends.Items.Add(item);
			}
		}
	
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(QibwFriends));
			this.qCompositeResizeItem1 = new Qios.DevSuite.Components.QCompositeResizeItem();
			this.qCompositeText1 = new Qios.DevSuite.Components.QCompositeText();
			this.qsItemGroup = new Qios.DevSuite.Components.QShape();
			this.qcrResizeItemBottom = new Qios.DevSuite.Components.QCompositeResizeItem();
			this.qsResizeItemBottom = new Qios.DevSuite.Components.QShape();
			this.qciResizeItem = new Qios.DevSuite.Components.QCompositeImage();
			this.qcgPopularFriends = new Qios.DevSuite.Components.QCompositeGroup();
			this.qcgPopularFriendsHeading = new Qios.DevSuite.Components.QCompositeGroup();
			this.qCompositeText2 = new Qios.DevSuite.Components.QCompositeText();
			this.qcmiNotSoPopularFriends = new Qios.DevSuite.Components.QCompositeMenuItem();
			// 
			// qCompositeResizeItem1
			// 
			this.qCompositeResizeItem1.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qCompositeResizeItem1.Items.Add(this.qCompositeText1);
			// 
			// qCompositeText1
			// 
			this.qCompositeText1.Title = "Resize";
			// 
			// qsItemGroup
			// 
			this.qsItemGroup.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareContent;
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsItemGroup.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
			// 
			// qcrResizeItemBottom
			// 
			this.qcrResizeItemBottom.ColorScheme.CompositeItemBackground1.ColorReference = "@CompositeButtonBackground1";
			this.qcrResizeItemBottom.ColorScheme.CompositeItemBackground2.ColorReference = "@CompositeButtonBackground2";
			this.qcrResizeItemBottom.ColorScheme.CompositeItemBorder.ColorReference = "@CompositeButtonBorder";
			this.qcrResizeItemBottom.Configuration.Appearance.Shape = this.qsResizeItemBottom;
			this.qcrResizeItemBottom.Configuration.HasHotState = Qios.DevSuite.Components.QTristateBool.False;
			this.qcrResizeItemBottom.Configuration.HasPressedState = Qios.DevSuite.Components.QTristateBool.False;
			this.qcrResizeItemBottom.Configuration.Padding = new Qios.DevSuite.Components.QPadding(2, 2, 2, 2);
			this.qcrResizeItemBottom.Configuration.StretchHorizontal = true;
			this.qcrResizeItemBottom.Items.Add(this.qciResizeItem);
			// 
			// qsResizeItemBottom
			// 
			this.qsResizeItemBottom.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareButton;
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), false));
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), false));
			this.qsResizeItemBottom.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), false));
			// 
			// qciResizeItem
			// 
			this.qciResizeItem.Configuration.AlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
			this.qciResizeItem.Image = ((System.Drawing.Image)(resources.GetObject("qciResizeItem.Image")));
			// 
			// qcgPopularFriends
			// 
			this.qcgPopularFriends.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeBackground1";
			this.qcgPopularFriends.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeBackground2";
			this.qcgPopularFriends.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qcgPopularFriends.ColorScheme.CompositeScrollButtonBackground1.ColorReference = "@Empty";
			this.qcgPopularFriends.ColorScheme.CompositeScrollButtonBackground2.ColorReference = "@Empty";
			this.qcgPopularFriends.ColorScheme.CompositeScrollButtonDisabledBackground1.ColorReference = "@Empty";
			this.qcgPopularFriends.ColorScheme.CompositeScrollButtonDisabledBackground2.ColorReference = "@Empty";
			this.qcgPopularFriends.Configuration.Appearance.Shape = this.qsItemGroup;
			this.qcgPopularFriends.Configuration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Flow;
			this.qcgPopularFriends.Configuration.ScrollConfiguration.ScrollVertical = Qios.DevSuite.Components.QCompositeScrollVisibility.Automatic;
			this.qcgPopularFriends.Configuration.ShrinkHorizontal = true;
			this.qcgPopularFriends.Configuration.ShrinkVertical = true;
			this.qcgPopularFriends.Configuration.StretchHorizontal = true;
			this.qcgPopularFriends.Configuration.StretchVertical = true;
			// 
			// qcgPopularFriendsHeading
			// 
			this.qcgPopularFriendsHeading.ColorScheme.CompositeGroupBackground1.ColorReference = "@CompositeButtonBackground1";
			this.qcgPopularFriendsHeading.ColorScheme.CompositeGroupBackground2.ColorReference = "@CompositeButtonBackground2";
			this.qcgPopularFriendsHeading.ColorScheme.CompositeGroupBorder.ColorReference = "@CompositeButtonBorder";
			this.qcgPopularFriendsHeading.Configuration.Appearance.Shape = this.qsItemGroup;
			this.qcgPopularFriendsHeading.Configuration.ShrinkHorizontal = true;
			this.qcgPopularFriendsHeading.Configuration.StretchHorizontal = true;
			this.qcgPopularFriendsHeading.Items.Add(this.qCompositeText2);
			// 
			// qCompositeText2
			// 
			this.qCompositeText2.Configuration.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, true, false, false, false, 10F);
			this.qCompositeText2.Title = "Popular Friends";
			// 
			// qcmiNotSoPopularFriends
			// 
			this.qcmiNotSoPopularFriends.Configuration.ShrinkHorizontal = true;
			this.qcmiNotSoPopularFriends.Configuration.StretchHorizontal = true;
			this.qcmiNotSoPopularFriends.Configuration.TitleConfiguration.ShrinkHorizontal = true;
			this.qcmiNotSoPopularFriends.Configuration.TitleConfiguration.StretchHorizontal = true;
			this.qcmiNotSoPopularFriends.Icon = ((System.Drawing.Icon)(resources.GetObject("qcmiNotSoPopularFriends.Icon")));
			this.qcmiNotSoPopularFriends.Title = "Not so popular friends";
			// 
			// QibwFriends
			// 
			this.ChildCompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.ChildCompositeConfiguration.Layout = Qios.DevSuite.Components.QCompositeItemLayout.Table;
			this.CompositeConfiguration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
			this.CompositeConfiguration.IconBackgroundSize = 22;
			this.CompositeConfiguration.IconBackgroundVisible = true;
			this.CompositeConfiguration.Padding = new Qios.DevSuite.Components.QPadding(0, 0, 0, 0);
			this.Configuration.UseSizeAsRequestedSize = true;
			this.Items.Add(this.qcgPopularFriendsHeading);
			this.Items.Add(this.qcgPopularFriends);
			this.Items.Add(this.qcmiNotSoPopularFriends);
			this.Items.Add(this.qcrResizeItemBottom);
			this.Name = "QibwFriends";
			this.Size = new System.Drawing.Size(160, 160);

		}
	}
}
