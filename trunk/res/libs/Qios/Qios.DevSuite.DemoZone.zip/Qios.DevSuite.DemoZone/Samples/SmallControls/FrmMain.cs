using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.DemoZone.Misc;
using Qios.DevSuite.DemoZone.Shared;

using Qios.DevSuite.Components;
using Qios.DevSuite.Components.Ribbon;

namespace Qios.DevSuite.DemoZone.Samples.SmallControls
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	[SelectorDisplay(
		 20,
		"Small Controls Sample",
		"Shows QTextBox, QComboBox, QNumericUpdown, QScrollBar and QButton.")]
	public class FrmMain : QRibbonForm
	{
		private Qios.DevSuite.Components.Ribbon.QRibbonCaption qrcCaption;
		private Qios.DevSuite.Components.QPanel qPanel1;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel1;
		private Qios.DevSuite.Components.QPanel qpTextBoxes;
		private Qios.DevSuite.Components.QTextBox qtbDefault;
		private Qios.DevSuite.Components.QTextBox qtbCueText;
		private Qios.DevSuite.Components.QTextBox qtbShaped2;
		private Qios.DevSuite.Components.QTextBox qtbColored;
		private Qios.DevSuite.Components.QTextBox qtbAll;
		private Qios.DevSuite.Components.QPanel qPanel2;
		private Qios.DevSuite.Components.QPanel qpnComboBox;
		private Qios.DevSuite.Components.QMarkupLabel qmlComboBoxExplanation;
		private Qios.DevSuite.Components.QComboBox qComboBox1;
		private Qios.DevSuite.Components.QShape qsShapedTextBox1;
		private Qios.DevSuite.Components.QComboBox qcbButtonAlways;
		private Qios.DevSuite.Components.QComboBox qcbShaped;
		private Qios.DevSuite.Components.QShape qsShapedComboBoxButton;
		private Qios.DevSuite.Components.QShape qsShapedComboBox;
		private Qios.DevSuite.Components.QComboBox qcbCustomDropDown;
		private Qios.DevSuite.DemoZone.Samples.SmallControls.DsMyFriends dsMyFriends1;
		private Qios.DevSuite.Components.QMarkupLabel qMarkupLabel2;
		private Qios.DevSuite.Components.QPanel qpnNumericUpDown;
		private Qios.DevSuite.Components.QNumericUpDown qnudDefault;
		private Qios.DevSuite.Components.QNumericUpDown qnudDefault2;
		private Qios.DevSuite.Components.QNumericUpDown qnudShaped;
		private Qios.DevSuite.Components.QShape qsShapedNud;
		private Qios.DevSuite.Components.QShape qsShapedNudButton;
		private Qios.DevSuite.Components.QNumericUpDown qNumericUpDown1;
		private Qios.DevSuite.Components.QMarkupLabel qmlNumericUpDownExplanation;
		private Qios.DevSuite.Components.QPanel qpnScrollBar;
		private Qios.DevSuite.Components.QMarkupLabel qmlScrollBarExplanation;
		private Qios.DevSuite.Components.QScrollBar qsbDefault;
		private Qios.DevSuite.Components.QScrollBar qsbDefault2;
		private Qios.DevSuite.Components.QScrollBar qsbShaped;
		private Qios.DevSuite.Components.QShape qsShapedScrollBar;
		private Qios.DevSuite.Components.QScrollBar qScrollBar1;
		private Qios.DevSuite.Components.QShape qsShapedScrollButton;
		private Qios.DevSuite.Components.QShape qsShapedTrackButton;
        private QPanel qPanel3;
        private QButton qbSimple;
        private QButton qbVerticalRightColored;
        private QButton qbVertical;
        private QButton qbWithSomeText1;
        private QButton qbImaged;
        private QButton qbInstenseMetallic;
        private QButton qbWithSomeTextDisabled;
        private QShape qsShapedButton;
        private QButton qbShaped;
        private QButton qbShaped2;
        private QShape qsShapedButton2;
		private System.ComponentModel.Container components = null;

		public FrmMain()
		{
			InitializeComponent();

			//Read the data
			this.dsMyFriends1.ReadXml(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Samples.SmallControls.MyFriends.xml"));

			//Set the custom drop down window
			this.qcbCustomDropDown.CustomDropDownWindow = new QibwFriends();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            Qios.DevSuite.Components.QMarkupTextStyle qMarkupTextStyle1 = new Qios.DevSuite.Components.QMarkupTextStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.qrcCaption = new Qios.DevSuite.Components.Ribbon.QRibbonCaption();
            this.qMarkupLabel1 = new Qios.DevSuite.Components.QMarkupLabel();
            this.qPanel1 = new Qios.DevSuite.Components.QPanel();
            this.qPanel2 = new Qios.DevSuite.Components.QPanel();
            this.qPanel3 = new Qios.DevSuite.Components.QPanel();
            this.qbShaped2 = new Qios.DevSuite.Components.QButton();
            this.qsShapedButton2 = new Qios.DevSuite.Components.QShape();
            this.qbShaped = new Qios.DevSuite.Components.QButton();
            this.qsShapedButton = new Qios.DevSuite.Components.QShape();
            this.qbInstenseMetallic = new Qios.DevSuite.Components.QButton();
            this.qbWithSomeTextDisabled = new Qios.DevSuite.Components.QButton();
            this.qbVerticalRightColored = new Qios.DevSuite.Components.QButton();
            this.qbVertical = new Qios.DevSuite.Components.QButton();
            this.qbWithSomeText1 = new Qios.DevSuite.Components.QButton();
            this.qbImaged = new Qios.DevSuite.Components.QButton();
            this.qbSimple = new Qios.DevSuite.Components.QButton();
            this.qpnScrollBar = new Qios.DevSuite.Components.QPanel();
            this.qScrollBar1 = new Qios.DevSuite.Components.QScrollBar();
            this.qsShapedScrollBar = new Qios.DevSuite.Components.QShape();
            this.qsShapedScrollButton = new Qios.DevSuite.Components.QShape();
            this.qsShapedTrackButton = new Qios.DevSuite.Components.QShape();
            this.qsbShaped = new Qios.DevSuite.Components.QScrollBar();
            this.qsbDefault2 = new Qios.DevSuite.Components.QScrollBar();
            this.qsbDefault = new Qios.DevSuite.Components.QScrollBar();
            this.qmlScrollBarExplanation = new Qios.DevSuite.Components.QMarkupLabel();
            this.qpnNumericUpDown = new Qios.DevSuite.Components.QPanel();
            this.qNumericUpDown1 = new Qios.DevSuite.Components.QNumericUpDown();
            this.qnudShaped = new Qios.DevSuite.Components.QNumericUpDown();
            this.qsShapedNud = new Qios.DevSuite.Components.QShape();
            this.qsShapedNudButton = new Qios.DevSuite.Components.QShape();
            this.qnudDefault2 = new Qios.DevSuite.Components.QNumericUpDown();
            this.qmlNumericUpDownExplanation = new Qios.DevSuite.Components.QMarkupLabel();
            this.qnudDefault = new Qios.DevSuite.Components.QNumericUpDown();
            this.qpnComboBox = new Qios.DevSuite.Components.QPanel();
            this.qMarkupLabel2 = new Qios.DevSuite.Components.QMarkupLabel();
            this.qcbCustomDropDown = new Qios.DevSuite.Components.QComboBox();
            this.qsShapedComboBox = new Qios.DevSuite.Components.QShape();
            this.qsShapedComboBoxButton = new Qios.DevSuite.Components.QShape();
            this.dsMyFriends1 = new Qios.DevSuite.DemoZone.Samples.SmallControls.DsMyFriends();
            this.qcbShaped = new Qios.DevSuite.Components.QComboBox();
            this.qcbButtonAlways = new Qios.DevSuite.Components.QComboBox();
            this.qComboBox1 = new Qios.DevSuite.Components.QComboBox();
            this.qmlComboBoxExplanation = new Qios.DevSuite.Components.QMarkupLabel();
            this.qpTextBoxes = new Qios.DevSuite.Components.QPanel();
            this.qtbAll = new Qios.DevSuite.Components.QTextBox();
            this.qsShapedTextBox1 = new Qios.DevSuite.Components.QShape();
            this.qtbColored = new Qios.DevSuite.Components.QTextBox();
            this.qtbShaped2 = new Qios.DevSuite.Components.QTextBox();
            this.qtbCueText = new Qios.DevSuite.Components.QTextBox();
            this.qtbDefault = new Qios.DevSuite.Components.QTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.qrcCaption)).BeginInit();
            this.qPanel1.SuspendLayout();
            this.qPanel2.SuspendLayout();
            this.qPanel3.SuspendLayout();
            this.qpnScrollBar.SuspendLayout();
            this.qpnNumericUpDown.SuspendLayout();
            this.qpnComboBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsMyFriends1)).BeginInit();
            this.qpTextBoxes.SuspendLayout();
            this.SuspendLayout();
            // 
            // qrcCaption
            // 
            this.qrcCaption.Location = new System.Drawing.Point(0, 0);
            this.qrcCaption.Name = "qrcCaption";
            this.qrcCaption.Size = new System.Drawing.Size(862, 28);
            this.qrcCaption.TabIndex = 0;
            this.qrcCaption.Text = "Small Control Sample - Qios.DevSuite.DemoZone ";
            // 
            // qMarkupLabel1
            // 
            this.qMarkupLabel1.Appearance.ShowBorders = true;
            this.qMarkupLabel1.ColorScheme.MarkupLabelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qMarkupLabel1.ColorScheme.MarkupLabelBackground2.ColorReference = "@RibbonPanelBackground2";
            this.qMarkupLabel1.ColorScheme.MarkupLabelBorder.ColorReference = "@RibbonPanelBorder";
            this.qMarkupLabel1.Configuration.BiggerSmallerStep = 1;
            this.qMarkupLabel1.Configuration.MarkupPadding = new Qios.DevSuite.Components.QPadding(5, 5, 5, 5);
            qMarkupTextStyle1.DefaultTag = "H1";
            qMarkupTextStyle1.FontDefinition = new Qios.DevSuite.Components.QFontDefinition(null, false, false, false, false, 12F);
            qMarkupTextStyle1.NewLineAfter = true;
            qMarkupTextStyle1.TextColorProperty = "RibbonTabButtonActiveText";
            this.qMarkupLabel1.CustomStyles.Add(qMarkupTextStyle1);
            this.qMarkupLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.qMarkupLabel1.Location = new System.Drawing.Point(5, 5);
            this.qMarkupLabel1.MarkupText = resources.GetString("qMarkupLabel1.MarkupText");
            this.qMarkupLabel1.Name = "qMarkupLabel1";
            this.qMarkupLabel1.Size = new System.Drawing.Size(852, 48);
            this.qMarkupLabel1.TabIndex = 2;
            // 
            // qPanel1
            // 
            this.qPanel1.Appearance.ShowBorders = false;
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("Default", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qPanel1.ColorScheme.PanelBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qPanel1.Controls.Add(this.qPanel2);
            this.qPanel1.Controls.Add(this.qMarkupLabel1);
            this.qPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qPanel1.Location = new System.Drawing.Point(0, 28);
            this.qPanel1.Name = "qPanel1";
            this.qPanel1.Padding = new System.Windows.Forms.Padding(5);
            this.qPanel1.Size = new System.Drawing.Size(862, 492);
            this.qPanel1.TabIndex = 1;
            this.qPanel1.Text = "qpnMain";
            // 
            // qPanel2
            // 
            this.qPanel2.Appearance.ShowBorders = false;
            this.qPanel2.AutoScroll = true;
            this.qPanel2.ColorScheme.PanelBackground1.SetColor("Default", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground1.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground1.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground1.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground2.SetColor("Default", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qPanel2.ColorScheme.PanelBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qPanel2.Controls.Add(this.qPanel3);
            this.qPanel2.Controls.Add(this.qpnScrollBar);
            this.qPanel2.Controls.Add(this.qpnNumericUpDown);
            this.qPanel2.Controls.Add(this.qpnComboBox);
            this.qPanel2.Controls.Add(this.qpTextBoxes);
            this.qPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qPanel2.Location = new System.Drawing.Point(5, 53);
            this.qPanel2.Name = "qPanel2";
            this.qPanel2.Padding = new System.Windows.Forms.Padding(5);
            this.qPanel2.Size = new System.Drawing.Size(852, 434);
            this.qPanel2.TabIndex = 4;
            this.qPanel2.Text = "qpnContent";
            // 
            // qPanel3
            // 
            this.qPanel3.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qPanel3.BackgroundImage = global::Qios.DevSuite.DemoZone.Properties.Resources.Kyle40;
            this.qPanel3.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomRight;
            this.qPanel3.BackgroundImageOffset = new System.Drawing.Point(-30, -3);
            this.qPanel3.ColorScheme.PanelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qPanel3.Configuration.ShowText = true;
            this.qPanel3.Configuration.TextDock = System.Windows.Forms.DockStyle.Left;
            this.qPanel3.Configuration.VerticalTextOrientation = Qios.DevSuite.Components.QVerticalTextOrientation.VerticalUp;
            this.qPanel3.Controls.Add(this.qbShaped2);
            this.qPanel3.Controls.Add(this.qbShaped);
            this.qPanel3.Controls.Add(this.qbInstenseMetallic);
            this.qPanel3.Controls.Add(this.qbWithSomeTextDisabled);
            this.qPanel3.Controls.Add(this.qbVerticalRightColored);
            this.qPanel3.Controls.Add(this.qbVertical);
            this.qPanel3.Controls.Add(this.qbWithSomeText1);
            this.qPanel3.Controls.Add(this.qbImaged);
            this.qPanel3.Controls.Add(this.qbSimple);
            this.qPanel3.Location = new System.Drawing.Point(636, 16);
            this.qPanel3.Name = "qPanel3";
            this.qPanel3.Padding = new System.Windows.Forms.Padding(12, 5, 12, 5);
            this.qPanel3.Size = new System.Drawing.Size(207, 407);
            this.qPanel3.TabIndex = 7;
            this.qPanel3.Text = "QButton";
            // 
            // qbShaped2
            // 
            this.qbShaped2.Appearance.Shape = this.qsShapedButton2;
            this.qbShaped2.ColorScheme.ButtonBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))), false);
            this.qbShaped2.ColorScheme.ButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))), false);
            this.qbShaped2.ColorScheme.ButtonBorder.SetColor("Default", System.Drawing.Color.DarkGreen, false);
            this.qbShaped2.ColorScheme.ButtonBorder.SetColor("LunaBlue", System.Drawing.Color.DarkGreen, false);
            this.qbShaped2.ColorScheme.ButtonBorder.SetColor("LunaOlive", System.Drawing.Color.DarkGreen, false);
            this.qbShaped2.ColorScheme.ButtonBorder.SetColor("LunaSilver", System.Drawing.Color.DarkGreen, false);
            this.qbShaped2.ColorScheme.ButtonBorder.SetColor("VistaBlack", System.Drawing.Color.DarkGreen, false);
            this.qbShaped2.ColorScheme.ButtonHotBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(250)))), ((int)(((byte)(211))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(250)))), ((int)(((byte)(211))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(250)))), ((int)(((byte)(211))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(250)))), ((int)(((byte)(211))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(250)))), ((int)(((byte)(211))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(73))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(73))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(73))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(73))))), false);
            this.qbShaped2.ColorScheme.ButtonHotBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(73))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(213)))), ((int)(((byte)(165))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(213)))), ((int)(((byte)(165))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(213)))), ((int)(((byte)(165))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(213)))), ((int)(((byte)(165))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(252)))), ((int)(((byte)(213)))), ((int)(((byte)(165))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(250)))), ((int)(((byte)(146)))), ((int)(((byte)(42))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(250)))), ((int)(((byte)(146)))), ((int)(((byte)(42))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(250)))), ((int)(((byte)(146)))), ((int)(((byte)(42))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(250)))), ((int)(((byte)(146)))), ((int)(((byte)(42))))), false);
            this.qbShaped2.ColorScheme.ButtonPressedBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(250)))), ((int)(((byte)(146)))), ((int)(((byte)(42))))), false);
            this.qbShaped2.Configuration.TextConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qbShaped2.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbShaped2.Location = new System.Drawing.Point(9, 321);
            this.qbShaped2.Name = "qbShaped2";
            this.qbShaped2.PaintTransparentBackground = true;
            this.qbShaped2.Size = new System.Drawing.Size(162, 76);
            this.qbShaped2.TabIndex = 8;
            this.qbShaped2.Text = "Shaped, Colored && Transparent";
            // 
            // qsShapedButton2
            // 
            this.qsShapedButton2.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton;
            this.qsShapedButton2.ContentBounds = new System.Drawing.Rectangle(8, 17, 86, 16);
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(51F, 0F, 61F, 0F, 80F, 12F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(90F, 16F, 97F, 19F, 100F, 21F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 24F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 26F, 100F, 29F, 97F, 31F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(90F, 34F, 80F, 38F, 61F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(51F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(49F, 50F, 39F, 50F, 20F, 38F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(10F, 34F, 3F, 31F, 0F, 29F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 26F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 24F, 0F, 21F, 3F, 19F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(10F, 16F, 20F, 12F, 39F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton2.Items.Add(new Qios.DevSuite.Components.QShapeItem(49F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton2.Size = new System.Drawing.Size(100, 50);
            // 
            // qbShaped
            // 
            this.qbShaped.Appearance.Shape = this.qsShapedButton;
            this.qbShaped.ColorScheme.ButtonBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252))))), false);
            this.qbShaped.ColorScheme.ButtonBackground2.SetColor("Default", System.Drawing.Color.Lime, false);
            this.qbShaped.ColorScheme.ButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.Lime, false);
            this.qbShaped.ColorScheme.ButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.Lime, false);
            this.qbShaped.ColorScheme.ButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.Lime, false);
            this.qbShaped.ColorScheme.ButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.Lime, false);
            this.qbShaped.ColorScheme.ButtonBorder.SetColor("Default", System.Drawing.Color.DarkGreen, false);
            this.qbShaped.ColorScheme.ButtonBorder.SetColor("LunaBlue", System.Drawing.Color.DarkGreen, false);
            this.qbShaped.ColorScheme.ButtonBorder.SetColor("LunaOlive", System.Drawing.Color.DarkGreen, false);
            this.qbShaped.ColorScheme.ButtonBorder.SetColor("LunaSilver", System.Drawing.Color.DarkGreen, false);
            this.qbShaped.ColorScheme.ButtonBorder.SetColor("VistaBlack", System.Drawing.Color.DarkGreen, false);
            this.qbShaped.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbShaped.Location = new System.Drawing.Point(9, 251);
            this.qbShaped.Name = "qbShaped";
            this.qbShaped.Size = new System.Drawing.Size(106, 62);
            this.qbShaped.TabIndex = 7;
            this.qbShaped.Text = "Shaped && Colored";
            // 
            // qsShapedButton
            // 
            this.qsShapedButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton;
            this.qsShapedButton.ContentBounds = new System.Drawing.Rectangle(2, 7, 92, 32);
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 32F, 91F, 12F, 69F, 35F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(85F, 50F, 89F, 37F, 24F, 39F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(23F, 50F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 50F, 21F, 39F, 8F, 12F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 34F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 2F, 24F, 14F, 23F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(17F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(45F, 0F, 32F, 7F, 56F, 21F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(66F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(72F, 0F, 65F, 21F, 101F, -3F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 9F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedButton.Size = new System.Drawing.Size(100, 50);
            // 
            // qbInstenseMetallic
            // 
            this.qbInstenseMetallic.Appearance.MetallicFarIntensity = 100;
            this.qbInstenseMetallic.Appearance.MetallicNearIntensity = 50;
            this.qbInstenseMetallic.Appearance.MetallicOffset = 90;
            this.qbInstenseMetallic.Appearance.MetallicOffsetUnit = Qios.DevSuite.Components.QAppearanceUnit.Pixel;
            this.qbInstenseMetallic.Appearance.MetallicShineIntensity = 100;
            this.qbInstenseMetallic.ColorScheme.ButtonBackground2.SetColor("Default", System.Drawing.SystemColors.ControlDark, false);
            this.qbInstenseMetallic.ColorScheme.ButtonBackground2.SetColor("LunaBlue", System.Drawing.SystemColors.ControlDark, false);
            this.qbInstenseMetallic.ColorScheme.ButtonBackground2.SetColor("LunaOlive", System.Drawing.SystemColors.ControlDark, false);
            this.qbInstenseMetallic.ColorScheme.ButtonBackground2.SetColor("LunaSilver", System.Drawing.SystemColors.ControlDark, false);
            this.qbInstenseMetallic.ColorScheme.ButtonBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.ControlDark, false);
            this.qbInstenseMetallic.Configuration.ContentLayoutOrder = "Text, Image";
            this.qbInstenseMetallic.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qbInstenseMetallic.Configuration.TextConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Centered;
            this.qbInstenseMetallic.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbInstenseMetallic.Location = new System.Drawing.Point(121, 142);
            this.qbInstenseMetallic.Name = "qbInstenseMetallic";
            this.qbInstenseMetallic.Size = new System.Drawing.Size(50, 171);
            this.qbInstenseMetallic.TabIndex = 6;
            this.qbInstenseMetallic.Text = "A bit more intense metallic look";
            // 
            // qbWithSomeTextDisabled
            // 
            this.qbWithSomeTextDisabled.Configuration.ContentLayoutOrder = "Text, Image";
            this.qbWithSomeTextDisabled.Configuration.TextConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qbWithSomeTextDisabled.Enabled = false;
            this.qbWithSomeTextDisabled.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbWithSomeTextDisabled.Location = new System.Drawing.Point(9, 90);
            this.qbWithSomeTextDisabled.Name = "qbWithSomeTextDisabled";
            this.qbWithSomeTextDisabled.Size = new System.Drawing.Size(162, 46);
            this.qbWithSomeTextDisabled.TabIndex = 5;
            this.qbWithSomeTextDisabled.Text = "With some text && disabled";
            // 
            // qbVerticalRightColored
            // 
            this.qbVerticalRightColored.ColorScheme.ButtonBackground2.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(181)))), ((int)(((byte)(100))))), false);
            this.qbVerticalRightColored.ColorScheme.ButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(181)))), ((int)(((byte)(100))))), false);
            this.qbVerticalRightColored.ColorScheme.ButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(181)))), ((int)(((byte)(100))))), false);
            this.qbVerticalRightColored.ColorScheme.ButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(181)))), ((int)(((byte)(100))))), false);
            this.qbVerticalRightColored.ColorScheme.ButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(181)))), ((int)(((byte)(100))))), false);
            this.qbVerticalRightColored.Configuration.ContentLayoutOrder = "Text, Image";
            this.qbVerticalRightColored.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qbVerticalRightColored.Configuration.TextConfiguration.ContentAlignmentHorizontal = Qios.DevSuite.Components.QPartAlignment.Far;
            this.qbVerticalRightColored.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbVerticalRightColored.Location = new System.Drawing.Point(65, 142);
            this.qbVerticalRightColored.Name = "qbVerticalRightColored";
            this.qbVerticalRightColored.Size = new System.Drawing.Size(50, 100);
            this.qbVerticalRightColored.TabIndex = 4;
            this.qbVerticalRightColored.Text = "Vertical Right Colored";
            // 
            // qbVertical
            // 
            this.qbVertical.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qbVertical.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbVertical.Location = new System.Drawing.Point(9, 142);
            this.qbVertical.Name = "qbVertical";
            this.qbVertical.Size = new System.Drawing.Size(50, 100);
            this.qbVertical.TabIndex = 3;
            this.qbVertical.Text = "Vertical";
            // 
            // qbWithSomeText1
            // 
            this.qbWithSomeText1.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbWithSomeText1.Location = new System.Drawing.Point(65, 38);
            this.qbWithSomeText1.Name = "qbWithSomeText1";
            this.qbWithSomeText1.Size = new System.Drawing.Size(106, 46);
            this.qbWithSomeText1.TabIndex = 2;
            this.qbWithSomeText1.Text = "With some text";
            // 
            // qbImaged
            // 
            this.qbImaged.Image = global::Qios.DevSuite.DemoZone.Properties.Resources.Qios_DevSuite_AllSizes;
            this.qbImaged.Location = new System.Drawing.Point(9, 38);
            this.qbImaged.Name = "qbImaged";
            this.qbImaged.Size = new System.Drawing.Size(50, 46);
            this.qbImaged.TabIndex = 1;
            // 
            // qbSimple
            // 
            this.qbSimple.Image = null;
            this.qbSimple.Location = new System.Drawing.Point(9, 5);
            this.qbSimple.Name = "qbSimple";
            this.qbSimple.Size = new System.Drawing.Size(162, 27);
            this.qbSimple.TabIndex = 0;
            this.qbSimple.Text = "A simple QButton";
            // 
            // qpnScrollBar
            // 
            this.qpnScrollBar.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qpnScrollBar.ColorScheme.PanelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qpnScrollBar.Configuration.ShowText = true;
            this.qpnScrollBar.Configuration.TextDock = System.Windows.Forms.DockStyle.Left;
            this.qpnScrollBar.Configuration.VerticalTextOrientation = Qios.DevSuite.Components.QVerticalTextOrientation.VerticalUp;
            this.qpnScrollBar.Controls.Add(this.qScrollBar1);
            this.qpnScrollBar.Controls.Add(this.qsbShaped);
            this.qpnScrollBar.Controls.Add(this.qsbDefault2);
            this.qpnScrollBar.Controls.Add(this.qsbDefault);
            this.qpnScrollBar.Controls.Add(this.qmlScrollBarExplanation);
            this.qpnScrollBar.Location = new System.Drawing.Point(318, 256);
            this.qpnScrollBar.Name = "qpnScrollBar";
            this.qpnScrollBar.Padding = new System.Windows.Forms.Padding(12, 5, 12, 5);
            this.qpnScrollBar.Size = new System.Drawing.Size(312, 167);
            this.qpnScrollBar.TabIndex = 6;
            this.qpnScrollBar.Text = "QScrollBar";
            // 
            // qScrollBar1
            // 
            this.qScrollBar1.Appearance.Shape = this.qsShapedScrollBar;
            this.qScrollBar1.ColorScheme.ScrollBarBorder.SetColor("Default", System.Drawing.Color.LightGreen, false);
            this.qScrollBar1.ColorScheme.ScrollBarBorder.SetColor("LunaBlue", System.Drawing.Color.LightGreen, false);
            this.qScrollBar1.ColorScheme.ScrollBarBorder.SetColor("LunaOlive", System.Drawing.Color.LightGreen, false);
            this.qScrollBar1.ColorScheme.ScrollBarBorder.SetColor("LunaSilver", System.Drawing.Color.LightGreen, false);
            this.qScrollBar1.ColorScheme.ScrollBarBorder.SetColor("VistaBlack", System.Drawing.Color.LightGreen, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground1.SetColor("Default", System.Drawing.Color.Lime, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.Lime, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.Lime, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.Lime, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground1.SetColor("VistaBlack", System.Drawing.Color.Lime, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground2.SetColor("Default", System.Drawing.Color.White, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qScrollBar1.ColorScheme.ScrollBarButtonBorder.ColorReference = "@ScrollBarButtonBackground1";
            this.qScrollBar1.Configuration.AlwaysDrawBackground = ((Qios.DevSuite.Components.QCompositeScrollBarItem)(((Qios.DevSuite.Components.QCompositeScrollBarItem.ScrollButton | Qios.DevSuite.Components.QCompositeScrollBarItem.ScrollBar)
                        | Qios.DevSuite.Components.QCompositeScrollBarItem.CustomButton)));
            this.qScrollBar1.Configuration.ButtonAppearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qScrollBar1.Configuration.ButtonAppearance.MetallicInnerGlowWidth = 1;
            this.qScrollBar1.Configuration.ButtonAppearance.Shape = this.qsShapedScrollButton;
            this.qScrollBar1.Configuration.ButtonPadding = new Qios.DevSuite.Components.QPadding(4, 4, 4, 6);
            this.qScrollBar1.Configuration.Direction = Qios.DevSuite.Components.QScrollBarDirection.Horizontal;
            this.qScrollBar1.Configuration.TrackButtonAppearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qScrollBar1.Configuration.TrackButtonAppearance.MetallicInnerGlowWidth = 1;
            this.qScrollBar1.Configuration.TrackButtonAppearance.Shape = this.qsShapedTrackButton;
            this.qScrollBar1.Location = new System.Drawing.Point(104, 48);
            this.qScrollBar1.Maximum = 20;
            this.qScrollBar1.Name = "qScrollBar1";
            this.qScrollBar1.Size = new System.Drawing.Size(168, 25);
            this.qScrollBar1.TabIndex = 11;
            this.qScrollBar1.Text = "qScrollBar2";
            this.qScrollBar1.Value = 4;
            // 
            // qsShapedScrollBar
            // 
            this.qsShapedScrollBar.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton;
            this.qsShapedScrollBar.ContentBounds = new System.Drawing.Rectangle(0, 0, 25, 100);
            this.qsShapedScrollBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(10F, 6F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedScrollBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 6F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedScrollBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(15F, 94F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedScrollBar.Items.Add(new Qios.DevSuite.Components.QShapeItem(10F, 94F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedScrollBar.Size = new System.Drawing.Size(25, 100);
            // 
            // qsShapedScrollButton
            // 
            this.qsShapedScrollButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton;
            this.qsShapedScrollButton.ContentBounds = new System.Drawing.Rectangle(4, 5, 13, 15);
            this.qsShapedScrollButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, 1F, 12F, 3F, 3F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedScrollButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(10F, 1F, 17F, 3F, 19F, 12F, System.Windows.Forms.AnchorStyles.Top, true));
            this.qsShapedScrollButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(20F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedScrollButton.Size = new System.Drawing.Size(20, 20);
            // 
            // qsShapedTrackButton
            // 
            this.qsShapedTrackButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton2;
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(6F, 20F, 2F, 20F, 2F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(2F, 16F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(2F, 4F, 2F, 0F, 2F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(6F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(94F, 0F, 98F, 0F, 98F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(98F, 4F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(98F, 16F, 98F, 20F, 98F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedTrackButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(94F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qsbShaped
            // 
            this.qsbShaped.Appearance.Shape = this.qsShapedScrollBar;
            this.qsbShaped.ColorScheme.ScrollBarBorder.SetColor("Default", System.Drawing.Color.LightGreen, false);
            this.qsbShaped.ColorScheme.ScrollBarBorder.SetColor("LunaBlue", System.Drawing.Color.LightGreen, false);
            this.qsbShaped.ColorScheme.ScrollBarBorder.SetColor("LunaOlive", System.Drawing.Color.LightGreen, false);
            this.qsbShaped.ColorScheme.ScrollBarBorder.SetColor("LunaSilver", System.Drawing.Color.LightGreen, false);
            this.qsbShaped.ColorScheme.ScrollBarBorder.SetColor("VistaBlack", System.Drawing.Color.LightGreen, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground1.SetColor("Default", System.Drawing.Color.Lime, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground1.SetColor("LunaBlue", System.Drawing.Color.Lime, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground1.SetColor("LunaOlive", System.Drawing.Color.Lime, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground1.SetColor("LunaSilver", System.Drawing.Color.Lime, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground1.SetColor("VistaBlack", System.Drawing.Color.Lime, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground2.SetColor("Default", System.Drawing.Color.White, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground2.SetColor("LunaBlue", System.Drawing.Color.White, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground2.SetColor("LunaOlive", System.Drawing.Color.White, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground2.SetColor("LunaSilver", System.Drawing.Color.White, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBackground2.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qsbShaped.ColorScheme.ScrollBarButtonBorder.ColorReference = "@ScrollBarButtonBackground1";
            this.qsbShaped.Configuration.AlwaysDrawBackground = ((Qios.DevSuite.Components.QCompositeScrollBarItem)(((Qios.DevSuite.Components.QCompositeScrollBarItem.ScrollButton | Qios.DevSuite.Components.QCompositeScrollBarItem.ScrollBar)
                        | Qios.DevSuite.Components.QCompositeScrollBarItem.CustomButton)));
            this.qsbShaped.Configuration.ButtonAppearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qsbShaped.Configuration.ButtonAppearance.MetallicInnerGlowWidth = 1;
            this.qsbShaped.Configuration.ButtonAppearance.Shape = this.qsShapedScrollButton;
            this.qsbShaped.Configuration.ButtonPadding = new Qios.DevSuite.Components.QPadding(4, 4, 4, 6);
            this.qsbShaped.Configuration.TrackButtonAppearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qsbShaped.Configuration.TrackButtonAppearance.MetallicInnerGlowWidth = 1;
            this.qsbShaped.Configuration.TrackButtonAppearance.Shape = this.qsShapedTrackButton;
            this.qsbShaped.Location = new System.Drawing.Point(56, 48);
            this.qsbShaped.Maximum = 20;
            this.qsbShaped.Name = "qsbShaped";
            this.qsbShaped.Size = new System.Drawing.Size(25, 88);
            this.qsbShaped.TabIndex = 10;
            this.qsbShaped.Text = "qScrollBar2";
            this.qsbShaped.Value = 10;
            // 
            // qsbDefault2
            // 
            this.qsbDefault2.Configuration.AlwaysDrawBackground = ((Qios.DevSuite.Components.QCompositeScrollBarItem)(((Qios.DevSuite.Components.QCompositeScrollBarItem.ScrollButton | Qios.DevSuite.Components.QCompositeScrollBarItem.ScrollBar)
                        | Qios.DevSuite.Components.QCompositeScrollBarItem.CustomButton)));
            this.qsbDefault2.Location = new System.Drawing.Point(32, 48);
            this.qsbDefault2.Name = "qsbDefault2";
            this.qsbDefault2.Size = new System.Drawing.Size(16, 88);
            this.qsbDefault2.TabIndex = 9;
            this.qsbDefault2.Text = "qScrollBar2";
            // 
            // qsbDefault
            // 
            this.qsbDefault.Location = new System.Drawing.Point(8, 48);
            this.qsbDefault.Name = "qsbDefault";
            this.qsbDefault.Size = new System.Drawing.Size(16, 88);
            this.qsbDefault.TabIndex = 8;
            this.qsbDefault.Text = "qScrollBar1";
            // 
            // qmlScrollBarExplanation
            // 
            this.qmlScrollBarExplanation.Dock = System.Windows.Forms.DockStyle.Top;
            this.qmlScrollBarExplanation.Location = new System.Drawing.Point(12, 5);
            this.qmlScrollBarExplanation.MarkupText = "A <b>QScrollBar</b> can be shaped (what a surprise!) , contains custom colors for" +
                " every aspect and every theme. You can even add custom buttons";
            this.qmlScrollBarExplanation.Name = "qmlScrollBarExplanation";
            this.qmlScrollBarExplanation.Size = new System.Drawing.Size(268, 45);
            this.qmlScrollBarExplanation.TabIndex = 7;
            // 
            // qpnNumericUpDown
            // 
            this.qpnNumericUpDown.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qpnNumericUpDown.ColorScheme.PanelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qpnNumericUpDown.Configuration.ShowText = true;
            this.qpnNumericUpDown.Configuration.TextDock = System.Windows.Forms.DockStyle.Left;
            this.qpnNumericUpDown.Configuration.VerticalTextOrientation = Qios.DevSuite.Components.QVerticalTextOrientation.VerticalUp;
            this.qpnNumericUpDown.Controls.Add(this.qNumericUpDown1);
            this.qpnNumericUpDown.Controls.Add(this.qnudShaped);
            this.qpnNumericUpDown.Controls.Add(this.qnudDefault2);
            this.qpnNumericUpDown.Controls.Add(this.qmlNumericUpDownExplanation);
            this.qpnNumericUpDown.Controls.Add(this.qnudDefault);
            this.qpnNumericUpDown.Location = new System.Drawing.Point(0, 256);
            this.qpnNumericUpDown.Name = "qpnNumericUpDown";
            this.qpnNumericUpDown.Padding = new System.Windows.Forms.Padding(12, 5, 12, 5);
            this.qpnNumericUpDown.Size = new System.Drawing.Size(312, 167);
            this.qpnNumericUpDown.TabIndex = 5;
            this.qpnNumericUpDown.Text = "QNumericUpDown";
            // 
            // qNumericUpDown1
            // 
            this.qNumericUpDown1.Configuration.InputBoxButtonDrawHot = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
            this.qNumericUpDown1.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
            this.qNumericUpDown1.FormatString = "X8";
            this.qNumericUpDown1.Increment = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.qNumericUpDown1.Location = new System.Drawing.Point(120, 64);
            this.qNumericUpDown1.MaximumValue = new decimal(new int[] {
            4000000,
            0,
            0,
            0});
            this.qNumericUpDown1.Name = "qNumericUpDown1";
            this.qNumericUpDown1.NumericValue = new decimal(new int[] {
            934655,
            0,
            0,
            0});
            this.qNumericUpDown1.Size = new System.Drawing.Size(96, 21);
            this.qNumericUpDown1.TabIndex = 10;
            this.qNumericUpDown1.Text = "000E42FF";
            this.qNumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // qnudShaped
            // 
            this.qnudShaped.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qnudShaped.Appearance.MetallicInnerGlowWidth = 1;
            this.qnudShaped.Appearance.Shape = this.qsShapedNud;
            this.qnudShaped.ColorScheme.InputBoxBackground.ColorReference = "@Transparent";
            this.qnudShaped.ColorScheme.InputBoxOuterBackground1.SetColor("Default", System.Drawing.Color.Lime, false);
            this.qnudShaped.ColorScheme.InputBoxOuterBackground1.SetColor("LunaBlue", System.Drawing.Color.Lime, false);
            this.qnudShaped.ColorScheme.InputBoxOuterBackground1.SetColor("LunaOlive", System.Drawing.Color.Lime, false);
            this.qnudShaped.ColorScheme.InputBoxOuterBackground1.SetColor("LunaSilver", System.Drawing.Color.Lime, false);
            this.qnudShaped.ColorScheme.InputBoxOuterBackground1.SetColor("VistaBlack", System.Drawing.Color.Lime, false);
            this.qnudShaped.Configuration.ButtonAppearance.Shape = this.qsShapedNudButton;
            this.qnudShaped.Configuration.InputBoxButtonDrawHot = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
            this.qnudShaped.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
            this.qnudShaped.FormatString = "\'$\' 0,000.00";
            this.qnudShaped.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.qnudShaped.Location = new System.Drawing.Point(16, 64);
            this.qnudShaped.MaximumValue = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.qnudShaped.Name = "qnudShaped";
            this.qnudShaped.NumericValue = new decimal(new int[] {
            105000,
            0,
            0,
            131072});
            this.qnudShaped.Size = new System.Drawing.Size(96, 27);
            this.qnudShaped.TabIndex = 9;
            this.qnudShaped.Text = "$ 1.050,00";
            this.qnudShaped.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // qsShapedNud
            // 
            this.qsShapedNud.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareInputBox;
            this.qsShapedNud.ContentBounds = new System.Drawing.Rectangle(6, 4, 87, 12);
            this.qsShapedNud.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 20F, -3F, 20F, -3F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedNud.Items.Add(new Qios.DevSuite.Components.QShapeItem(11F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedNud.Items.Add(new Qios.DevSuite.Components.QShapeItem(88F, 0F, 100F, 0F, 100F, 8F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedNud.Items.Add(new Qios.DevSuite.Components.QShapeItem(96F, 10F, 100F, 12F, 100F, 20F, System.Windows.Forms.AnchorStyles.Right, true));
            this.qsShapedNud.Items.Add(new Qios.DevSuite.Components.QShapeItem(90F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qsShapedNudButton
            // 
            this.qsShapedNudButton.ClonedBaseShapeType = Qios.DevSuite.Components.QBaseShapeType.RoundedButton;
            // 
            // qnudDefault2
            // 
            this.qnudDefault2.Configuration.InputBoxButtonDrawHot = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
            this.qnudDefault2.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
            this.qnudDefault2.Location = new System.Drawing.Point(120, 40);
            this.qnudDefault2.Name = "qnudDefault2";
            this.qnudDefault2.Size = new System.Drawing.Size(96, 21);
            this.qnudDefault2.TabIndex = 8;
            this.qnudDefault2.Text = "0,00";
            this.qnudDefault2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // qmlNumericUpDownExplanation
            // 
            this.qmlNumericUpDownExplanation.Dock = System.Windows.Forms.DockStyle.Top;
            this.qmlNumericUpDownExplanation.Location = new System.Drawing.Point(12, 5);
            this.qmlNumericUpDownExplanation.MarkupText = "A <b>QNumericUpDown</b> can do exactly the same as a <b>QTextBox</b>... Plus the " +
                "following (and more):";
            this.qmlNumericUpDownExplanation.Name = "qmlNumericUpDownExplanation";
            this.qmlNumericUpDownExplanation.Size = new System.Drawing.Size(268, 30);
            this.qmlNumericUpDownExplanation.TabIndex = 7;
            // 
            // qnudDefault
            // 
            this.qnudDefault.Location = new System.Drawing.Point(16, 40);
            this.qnudDefault.Name = "qnudDefault";
            this.qnudDefault.Size = new System.Drawing.Size(100, 21);
            this.qnudDefault.TabIndex = 0;
            this.qnudDefault.Text = "0,00";
            // 
            // qpnComboBox
            // 
            this.qpnComboBox.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qpnComboBox.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomMiddle;
            this.qpnComboBox.BackgroundImageOffset = new System.Drawing.Point(0, -20);
            this.qpnComboBox.ColorScheme.PanelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qpnComboBox.Configuration.ShowText = true;
            this.qpnComboBox.Configuration.TextDock = System.Windows.Forms.DockStyle.Left;
            this.qpnComboBox.Configuration.VerticalTextOrientation = Qios.DevSuite.Components.QVerticalTextOrientation.VerticalUp;
            this.qpnComboBox.Controls.Add(this.qMarkupLabel2);
            this.qpnComboBox.Controls.Add(this.qcbCustomDropDown);
            this.qpnComboBox.Controls.Add(this.qcbShaped);
            this.qpnComboBox.Controls.Add(this.qcbButtonAlways);
            this.qpnComboBox.Controls.Add(this.qComboBox1);
            this.qpnComboBox.Controls.Add(this.qmlComboBoxExplanation);
            this.qpnComboBox.Location = new System.Drawing.Point(318, 16);
            this.qpnComboBox.Name = "qpnComboBox";
            this.qpnComboBox.Size = new System.Drawing.Size(312, 232);
            this.qpnComboBox.TabIndex = 4;
            this.qpnComboBox.Text = "QComboBox";
            // 
            // qMarkupLabel2
            // 
            this.qMarkupLabel2.Location = new System.Drawing.Point(12, 120);
            this.qMarkupLabel2.MarkupText = "You remember <b>QComposite</b>?<br />Let\'s add a custom window here and bind it t" +
                "o a custom data source:";
            this.qMarkupLabel2.Name = "qMarkupLabel2";
            this.qMarkupLabel2.Size = new System.Drawing.Size(272, 45);
            this.qMarkupLabel2.TabIndex = 12;
            // 
            // qcbCustomDropDown
            // 
            this.qcbCustomDropDown.Appearance.Shape = this.qsShapedComboBox;
            this.qcbCustomDropDown.Configuration.ButtonAppearance.Shape = this.qsShapedComboBoxButton;
            this.qcbCustomDropDown.Configuration.ButtonMargin = new Qios.DevSuite.Components.QMargin(0, 1, 2, -5);
            this.qcbCustomDropDown.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
            this.qcbCustomDropDown.DataSource = this.dsMyFriends1.Friend;
            this.qcbCustomDropDown.DisplayMember = "Name";
            this.qcbCustomDropDown.Location = new System.Drawing.Point(8, 168);
            this.qcbCustomDropDown.Name = "qcbCustomDropDown";
            this.qcbCustomDropDown.Size = new System.Drawing.Size(168, 22);
            this.qcbCustomDropDown.TabIndex = 11;
            // 
            // qsShapedComboBox
            // 
            this.qsShapedComboBox.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareInputBox;
            this.qsShapedComboBox.ContentBounds = new System.Drawing.Rectangle(22, 2, 68, 17);
            this.qsShapedComboBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, 12F, 18F, 8F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedComboBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(22F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedComboBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, 92F, 7F, 94F, 19F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedComboBox.Items.Add(new Qios.DevSuite.Components.QShapeItem(77F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qsShapedComboBoxButton
            // 
            this.qsShapedComboBoxButton.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareInputBox;
            this.qsShapedComboBoxButton.ContentBounds = new System.Drawing.Rectangle(12, 2, 76, 16);
            this.qsShapedComboBoxButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(12F, 20F, 0F, 20F, 1F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedComboBoxButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(13F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedComboBoxButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(99F, 0F, 93F, 5F, 94F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedComboBoxButton.Items.Add(new Qios.DevSuite.Components.QShapeItem(79F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedComboBoxButton.ShapeType = Qios.DevSuite.Components.QShapeType.Button;
            // 
            // dsMyFriends1
            // 
            this.dsMyFriends1.DataSetName = "DsMyFriends";
            this.dsMyFriends1.Locale = new System.Globalization.CultureInfo("en-US");
            this.dsMyFriends1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // qcbShaped
            // 
            this.qcbShaped.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qcbShaped.Appearance.MetallicInnerGlowWidth = 1;
            this.qcbShaped.Appearance.Shape = this.qsShapedComboBox;
            this.qcbShaped.ColorScheme.InputBoxBackground.ColorReference = "@Transparent";
            this.qcbShaped.ColorScheme.InputBoxOuterBackground1.SetColor("Default", System.Drawing.Color.Lime, false);
            this.qcbShaped.ColorScheme.InputBoxOuterBackground1.SetColor("LunaBlue", System.Drawing.Color.Lime, false);
            this.qcbShaped.ColorScheme.InputBoxOuterBackground1.SetColor("LunaOlive", System.Drawing.Color.Lime, false);
            this.qcbShaped.ColorScheme.InputBoxOuterBackground1.SetColor("LunaSilver", System.Drawing.Color.Lime, false);
            this.qcbShaped.ColorScheme.InputBoxOuterBackground1.SetColor("VistaBlack", System.Drawing.Color.Lime, false);
            this.qcbShaped.Configuration.ButtonAppearance.Shape = this.qsShapedComboBoxButton;
            this.qcbShaped.Configuration.ButtonMargin = new Qios.DevSuite.Components.QMargin(0, 1, 2, -5);
            this.qcbShaped.Configuration.InputBoxButtonDrawHot = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
            this.qcbShaped.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonHot;
            this.qcbShaped.Items.AddRange(new object[] {
            "Eric Cartman",
            "Kyle Broflovski",
            "Kenny McCormick",
            "Stan Marsh"});
            this.qcbShaped.Location = new System.Drawing.Point(8, 96);
            this.qcbShaped.Name = "qcbShaped";
            this.qcbShaped.Size = new System.Drawing.Size(168, 22);
            this.qcbShaped.TabIndex = 9;
            this.qcbShaped.Text = "Let\'s change stuff";
            // 
            // qcbButtonAlways
            // 
            this.qcbButtonAlways.Configuration.InputBoxButtonDrawNormal = Qios.DevSuite.Components.QInputBoxButtonDrawType.DrawButtonNormal;
            this.qcbButtonAlways.Items.AddRange(new object[] {
            "Eric Cartman",
            "Kyle Broflovski",
            "Kenny McCormick",
            "Stan Marsh"});
            this.qcbButtonAlways.Location = new System.Drawing.Point(8, 74);
            this.qcbButtonAlways.Name = "qcbButtonAlways";
            this.qcbButtonAlways.Size = new System.Drawing.Size(168, 21);
            this.qcbButtonAlways.TabIndex = 8;
            this.qcbButtonAlways.Text = "Let\'s always show the button";
            // 
            // qComboBox1
            // 
            this.qComboBox1.Items.AddRange(new object[] {
            "Eric Cartman",
            "Kyle Broflovski",
            "Kenny McCormick",
            "Stan Marsh"});
            this.qComboBox1.Location = new System.Drawing.Point(8, 40);
            this.qComboBox1.Multiline = true;
            this.qComboBox1.Name = "qComboBox1";
            this.qComboBox1.Size = new System.Drawing.Size(272, 32);
            this.qComboBox1.TabIndex = 7;
            this.qComboBox1.Text = "A default multiline QComboBox, (Multiline?... yes)\r\nOnly shows the drop down butt" +
                "on when hot";
            // 
            // qmlComboBoxExplanation
            // 
            this.qmlComboBoxExplanation.Dock = System.Windows.Forms.DockStyle.Top;
            this.qmlComboBoxExplanation.Location = new System.Drawing.Point(0, 0);
            this.qmlComboBoxExplanation.MarkupText = "A <b>QComboBox</b> can do exactly the same as a <b>QTextBox</b>... Plus the follo" +
                "wing (and more):";
            this.qmlComboBoxExplanation.Name = "qmlComboBoxExplanation";
            this.qmlComboBoxExplanation.Size = new System.Drawing.Size(292, 30);
            this.qmlComboBoxExplanation.TabIndex = 6;
            // 
            // qpTextBoxes
            // 
            this.qpTextBoxes.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qpTextBoxes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qpTextBoxes.BackgroundImage")));
            this.qpTextBoxes.BackgroundImageAlign = Qios.DevSuite.Components.QImageAlign.BottomMiddle;
            this.qpTextBoxes.ColorScheme.PanelBackground1.ColorReference = "@RibbonPanelBackground2";
            this.qpTextBoxes.Configuration.ShowText = true;
            this.qpTextBoxes.Configuration.TextDock = System.Windows.Forms.DockStyle.Left;
            this.qpTextBoxes.Configuration.VerticalTextOrientation = Qios.DevSuite.Components.QVerticalTextOrientation.VerticalUp;
            this.qpTextBoxes.Controls.Add(this.qtbAll);
            this.qpTextBoxes.Controls.Add(this.qtbColored);
            this.qpTextBoxes.Controls.Add(this.qtbShaped2);
            this.qpTextBoxes.Controls.Add(this.qtbCueText);
            this.qpTextBoxes.Controls.Add(this.qtbDefault);
            this.qpTextBoxes.Location = new System.Drawing.Point(0, 16);
            this.qpTextBoxes.Name = "qpTextBoxes";
            this.qpTextBoxes.Size = new System.Drawing.Size(312, 232);
            this.qpTextBoxes.TabIndex = 3;
            this.qpTextBoxes.Text = "QTextBox";
            // 
            // qtbAll
            // 
            this.qtbAll.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Solid;
            this.qtbAll.Appearance.MetallicInnerGlowWidth = 1;
            this.qtbAll.Appearance.Shape = this.qsShapedTextBox1;
            this.qtbAll.ColorScheme.InputBoxBackground.ColorReference = "@Transparent";
            this.qtbAll.ColorScheme.InputBoxOuterBackground1.SetColor("Default", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qtbAll.ColorScheme.InputBoxOuterBackground1.SetColor("LunaBlue", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qtbAll.ColorScheme.InputBoxOuterBackground1.SetColor("LunaOlive", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qtbAll.ColorScheme.InputBoxOuterBackground1.SetColor("LunaSilver", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qtbAll.ColorScheme.InputBoxOuterBackground1.SetColor("VistaBlack", System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), false);
            this.qtbAll.ColorScheme.InputBoxOuterBorder.SetColor("Default", System.Drawing.Color.Red, false);
            this.qtbAll.ColorScheme.InputBoxOuterBorder.SetColor("LunaBlue", System.Drawing.Color.Red, false);
            this.qtbAll.ColorScheme.InputBoxOuterBorder.SetColor("LunaOlive", System.Drawing.Color.Red, false);
            this.qtbAll.ColorScheme.InputBoxOuterBorder.SetColor("LunaSilver", System.Drawing.Color.Red, false);
            this.qtbAll.ColorScheme.InputBoxOuterBorder.SetColor("VistaBlack", System.Drawing.Color.Red, false);
            this.qtbAll.Location = new System.Drawing.Point(8, 120);
            this.qtbAll.Multiline = true;
            this.qtbAll.Name = "qtbAll";
            this.qtbAll.PaintTransparentBackground = true;
            this.qtbAll.Size = new System.Drawing.Size(272, 88);
            this.qtbAll.TabIndex = 5;
            this.qtbAll.Text = "\"Ladies and Gentlemen... We\'ve got him\"\r\n\r\nOur QTextBox, inheriting from TextBoxB" +
                "ase, supports translucent background...\r\n\r\n(Without all kind of obscure other wi" +
                "ndows)";
            // 
            // qsShapedTextBox1
            // 
            this.qsShapedTextBox1.BaseShapeType = Qios.DevSuite.Components.QBaseShapeType.SquareInputBox;
            this.qsShapedTextBox1.ContentBounds = new System.Drawing.Rectangle(22, 2, 56, 17);
            this.qsShapedTextBox1.Items.Add(new Qios.DevSuite.Components.QShapeItem(0F, 20F, 12F, 18F, 8F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedTextBox1.Items.Add(new Qios.DevSuite.Components.QShapeItem(22F, 0F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left))), true));
            this.qsShapedTextBox1.Items.Add(new Qios.DevSuite.Components.QShapeItem(100F, 0F, 92F, 7F, 94F, 19F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right))), true));
            this.qsShapedTextBox1.Items.Add(new Qios.DevSuite.Components.QShapeItem(77F, 20F, ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right))), true));
            // 
            // qtbColored
            // 
            this.qtbColored.Appearance.BackgroundStyle = Qios.DevSuite.Components.QColorStyle.Metallic;
            this.qtbColored.Appearance.MetallicInnerGlowWidth = 1;
            this.qtbColored.Appearance.Shape = this.qsShapedTextBox1;
            this.qtbColored.ColorScheme.InputBoxBackground.ColorReference = "@Transparent";
            this.qtbColored.ColorScheme.InputBoxHotOuterBackground1.ColorReference = "@CompositeItemHotBackground1";
            this.qtbColored.ColorScheme.InputBoxHotOuterBackground2.ColorReference = "@CompositeItemHotBackground2";
            this.qtbColored.ColorScheme.InputBoxOuterBackground1.ColorReference = "@CompositeItemHotBackground1";
            this.qtbColored.ColorScheme.InputBoxOuterBackground2.ColorReference = "@CompositeItemHotBackground2";
            this.qtbColored.ColorScheme.InputBoxOuterBorder.ColorReference = "@CompositeItemHotBorder";
            this.qtbColored.Location = new System.Drawing.Point(8, 96);
            this.qtbColored.Name = "qtbColored";
            this.qtbColored.Size = new System.Drawing.Size(272, 22);
            this.qtbColored.TabIndex = 4;
            this.qtbColored.Text = "Let\'s change a color (Yes, this is a TextBox)";
            // 
            // qtbShaped2
            // 
            this.qtbShaped2.Appearance.Shape = this.qsShapedTextBox1;
            this.qtbShaped2.Location = new System.Drawing.Point(8, 72);
            this.qtbShaped2.Name = "qtbShaped2";
            this.qtbShaped2.Size = new System.Drawing.Size(272, 22);
            this.qtbShaped2.TabIndex = 3;
            this.qtbShaped2.Text = "Let\'s change a shape";
            // 
            // qtbCueText
            // 
            this.qtbCueText.CueText = "We have cue text";
            this.qtbCueText.Location = new System.Drawing.Point(8, 48);
            this.qtbCueText.Name = "qtbCueText";
            this.qtbCueText.Size = new System.Drawing.Size(272, 21);
            this.qtbCueText.TabIndex = 1;
            // 
            // qtbDefault
            // 
            this.qtbDefault.Location = new System.Drawing.Point(8, 24);
            this.qtbDefault.Name = "qtbDefault";
            this.qtbDefault.Size = new System.Drawing.Size(272, 21);
            this.qtbDefault.TabIndex = 0;
            this.qtbDefault.Text = "A default QTextBox";
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
            this.ClientSize = new System.Drawing.Size(862, 520);
            this.Controls.Add(this.qPanel1);
            this.Controls.Add(this.qrcCaption);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.Text = "Small Control Sample - Qios.DevSuite.DemoZone ";
            ((System.ComponentModel.ISupportInitialize)(this.qrcCaption)).EndInit();
            this.qPanel1.ResumeLayout(false);
            this.qPanel2.ResumeLayout(false);
            this.qPanel3.ResumeLayout(false);
            this.qpnScrollBar.ResumeLayout(false);
            this.qpnNumericUpDown.ResumeLayout(false);
            this.qpnComboBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dsMyFriends1)).EndInit();
            this.qpTextBoxes.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		private void xBox360Dash1_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
		{
		
		}

	}
}
