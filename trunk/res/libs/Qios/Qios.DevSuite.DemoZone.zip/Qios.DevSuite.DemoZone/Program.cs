using System;
using System.Reflection;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Qios.DevSuite.Components;

namespace Qios.DevSuite.DemoZone
{
	/// <summary>
	/// Summary description for Program.
	/// </summary>
	public class Program
	{
		private static QTranslucentWindow m_oSplash;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
            //Enable Visual Styles
            Application.EnableVisualStyles();

            //Qios.DevSuite.Components.QControlPaint.UseNativeTextRendering = true;

			//run the application
			ShowSplashScreen();


            QGlobalFont.Instance.InheritFromWindows = false;
            try
            {
                //First try to set the Segoe UI Font with 9.0 size.
                //This is the Windows 7 Font. This is done via the FontFamily Constructor
                //because Fonts don't crash when calling with the an unexisting Font in .NET 2.0
                FontFamily tmp_oFamily = new FontFamily("Segoe UI");
                QGlobalFont.Instance.Font = new Font(tmp_oFamily, 9.0F);
            }
            catch
            {
                //Otherwise set the Tahoma Font, 8.25F
                QGlobalFont.Instance.Font = new Font("Tahoma", 8.25F);
            }

            //We fixate the Color on LunaBlue.
            QColorScheme.Global.InheritCurrentThemeFromWindows = false;
            QColorScheme.Global.CurrentTheme = "LunaBlue";

			Application.Run(new FrmLoadingZone());
		}

		/// <summary>
		/// Shows the Splash screen
		/// </summary>
		public static void ShowSplashScreen()
		{
			m_oSplash = new QTranslucentWindow();
			m_oSplash.BackgroundImage = new Bitmap(Assembly.GetExecutingAssembly().GetManifestResourceStream("Qios.DevSuite.DemoZone.Images.QDevSuite5-200.png"));
			m_oSplash.TopMost = true;
			m_oSplash.ShowCenteredOnScreen();
			Application.Idle += new EventHandler(Application_Idle);
		}

		private static void Application_Idle(object sender, EventArgs e)
		{
			Application.Idle -= new EventHandler(Application_Idle);
			if (m_oSplash != null)
			{
				m_oSplash.Close();
				m_oSplash = null;
			}
			
		}
	}
}
